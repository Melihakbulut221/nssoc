# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from collections import Counter
import json,hashlib,pya
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-rx-import-fidelity-20261004';O=Path('/dev/shm/nssoc-rx-import-fidelity-v1-final');source=Path('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')
l=pya.Layout();l.read(str(source));c=l.cell('v2_RX');assert c and l.dbu==0.001
rows={}
for k in l.layer_indices():
 info=l.get_info(k);off=[];texts=[];n=0
 it=c.begin_shapes_rec(k)
 while not it.at_end():
  s=it.shape();t=it.itrans()
  if s.is_text():
   v=t*pya.Point(s.text.trans.disp.x,s.text.trans.disp.y)
   if v.x%5 or v.y%5:texts.append(dict(text=s.text.string,point_nm=[v.x,v.y],residue_nm=[v.x%5,v.y%5],cell=l.cell(it.cell_index()).name))
  elif s.is_box() or s.is_polygon() or s.is_path():
   poly=s.polygon.transformed(t);n+=1
   points=[(p.x,p.y) for p in poly.each_point_hull()]
   bad=[p for p in points if p[0]%5 or p[1]%5]
   if bad:off.append(dict(cell=l.cell(it.cell_index()).name,bbox=str(poly.bbox()),points_nm=bad))
  it.next()
 if n or texts:rows[str(info)]=dict(polygons=n,off5nm_polygons=off,off5nm_texts=texts)
o=pya.Layout();o.dbu=l.dbu;d=o.create_cell('v2_RX');d.copy_tree(c);o.write(str(O/'original-rx.gds'))
r=dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),dbu_um=l.dbu,cell=c.name,layers=rows,physical_off5nm=sum(len(x['off5nm_polygons']) for x in rows.values()),text_off5nm=sum(len(x['off5nm_texts']) for x in rows.values()),method_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest());(B/'original-grid.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='layers'}));print([(k,len(v['off5nm_polygons']),len(v['off5nm_texts'])) for k,v in rows.items() if v['off5nm_polygons'] or v['off5nm_texts']])
