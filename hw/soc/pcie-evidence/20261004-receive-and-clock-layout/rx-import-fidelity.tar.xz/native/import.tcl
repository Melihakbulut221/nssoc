puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-rx-import-fidelity-v1-final}
drc off
gds read {/dev/shm/nssoc-rx-import-fidelity-v1-final/original-rx.gds}
load v2_RX
flatten rx_import_flat
load rx_import_flat
select top cell
save rx_import_flat
cif ostyle gdsii
gds write {/dev/shm/nssoc-rx-import-fidelity-v1-final/imported-rx.gds}
puts NSSOC_RX_IMPORT_ROUNDTRIP_COMPLETE
quit -noprompt
