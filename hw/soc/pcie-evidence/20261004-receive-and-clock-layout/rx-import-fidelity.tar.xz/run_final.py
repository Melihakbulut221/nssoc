# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,subprocess
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
B=R/'hw/soc/out/pcie-magic-rx-import-fidelity-20261004';O=Path('/dev/shm/nssoc-rx-import-fidelity-v1-final');O.mkdir()
app=R/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
a=execute([app,'python',B/'scan_original.py'],O,'source-grid');assert a['returncode']==0
subprocess.run([sys.executable,B/'import_rx.py'],check=True)
b=execute([app,'python',B/'compare_layers.py'],O,'geometry');assert b['returncode']==0
(B/'source-grid-execution.json').write_text(json.dumps(a,indent=2)+'\n')
(B/'geometry-execution.json').write_text(json.dumps(b,indent=2)+'\n');print('PASS_ACTUAL_FINAL_REPLAY')
