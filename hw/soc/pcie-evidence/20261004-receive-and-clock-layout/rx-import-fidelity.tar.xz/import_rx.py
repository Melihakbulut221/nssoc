# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
sys.path.insert(0,str(R/'scripts'));from check_magic_hbt_multiplicity_v3 import pin
O=Path('/dev/shm/nssoc-rx-import-fidelity-v1-final');T=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1');RT=Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib')
script=O/'import.tcl';script.write_text(f'''puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {{{O}}}
drc off
gds read {{{O/'original-rx.gds'}}}
load v2_RX
flatten rx_import_flat
load rx_import_flat
select top cell
save rx_import_flat
cif ostyle gdsii
gds write {{{O/'imported-rx.gds'}}}
puts NSSOC_RX_IMPORT_ROUNDTRIP_COMPLETE
quit -noprompt
''')
inputs={str(p):pin(p) for p in [Path(__file__),O/'original-rx.gds',script,RT/'magic/tcl/tclmagic.so',*T.glob('*.tech')]}
x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',script],O,'native')
assert x['returncode']==0
for p,v in inputs.items():assert pin(p)==v
(O/'result.json').write_text(json.dumps(dict(execution=x,inputs=inputs,outputs={p.name:pin(p) for p in O.iterdir() if p.is_file()},qualification=False),indent=2)+'\n');print(x)
