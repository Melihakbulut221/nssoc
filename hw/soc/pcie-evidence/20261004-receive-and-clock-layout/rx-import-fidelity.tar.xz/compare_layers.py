# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import pya,json,hashlib,re
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-rx-import-fidelity-20261004';O=Path('/dev/shm/nssoc-rx-import-fidelity-v1-final')
a=pya.Layout();a.read(str(O/'original-rx.gds'));b=pya.Layout();b.read(str(O/'imported-rx.gds'));assert a.dbu==b.dbu==0.001
ca=a.cell('v2_RX');cb=b.cell('rx_import_flat');assert ca and cb
layers={str(l.get_info(i)):(l.get_info(i).layer,l.get_info(i).datatype) for l in (a,b) for i in l.layer_indices()}
rows={}
for key,(layer,datatype) in sorted(layers.items()):
 ka=a.find_layer(layer,datatype);kb=b.find_layer(layer,datatype)
 x=pya.Region(ca.begin_shapes_rec(ka)).merged() if ka is not None else pya.Region()
 y=pya.Region(cb.begin_shapes_rec(kb)).merged() if kb is not None else pya.Region()
 if x.is_empty() and y.is_empty():continue
 d=x^y;missing=x-y;extra=y-x
 off=[(p.x,p.y) for poly in x.each() for p in poly.each_point_hull() if p.x%5 or p.y%5]
 rows[key]=dict(original_area_nm2=x.area(),imported_export_area_nm2=y.area(),xor_area_nm2=d.area(),missing_area_nm2=missing.area(),extra_area_nm2=extra.area(),original_area_um2=x.area()*a.dbu**2,imported_export_area_um2=y.area()*a.dbu**2,xor_area_um2=d.area()*a.dbu**2,missing_area_um2=missing.area()*a.dbu**2,extra_area_um2=extra.area()*a.dbu**2,xor_components=d.count(),original_merged_off5nm_vertices=off,xor_bboxes_nm=[str(poly.bbox()) for poly in d.each()][:32])
# Native flat MAG M4 plane includes its metal and both adjacent contact types.
mag=(O/'rx_import_flat.mag').read_text();assert 'magscale 1 2\n' in mag
m4=pya.Region();section=None
for line in mag.splitlines():
 if line.startswith('<< '):section=line[3:-3]
 elif section in ('metal4','via3','via4') and line.startswith('rect '):
  box=[int(x)*5 for x in line.split()[1:]];assert len(box)==4;m4.insert(pya.Box(*box))
 elif section in ('metal4','via3','via4') and line.startswith('tri '):raise ValueError('Unexpected native nonrectangular M4')
original_m4=pya.Region(ca.begin_shapes_rec(a.find_layer(50,0))).merged();raw_m4_xor=(m4.merged()^original_m4).area()
routing=['8/0','10/0','30/0','50/0','67/0','126/0','134/0'];vias=['6/0','19/0','29/0','49/0','66/0','125/0','133/0']
record=dict(status='NATIVE_RX_IMPORT_EXPORT_PER_LAYER_DIAGNOSTIC',sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),O/'original-rx.gds',O/'imported-rx.gds',O/'rx_import_flat.mag',O/'native.log')},grid_um=a.dbu,raw_native_M4_union_xor_nm2=raw_m4_xor,layers=rows,routing_xor={k:rows.get(k,{}).get('xor_area_um2',0) for k in routing},contact_via_xor={k:rows.get(k,{}).get('xor_area_um2',0) for k in vias},caveat='Includes both native import and native GDS reconstruction; process-layer changes cannot yet be attributed solely to import. No tolerance, polygon replacement or qualified PEX.')
(B/'per-layer-roundtrip.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('sources','layers')},indent=2));print('nonzero',[(k,v['xor_area_um2'],len(v['original_merged_off5nm_vertices'])) for k,v in rows.items() if v['xor_area_um2']])
