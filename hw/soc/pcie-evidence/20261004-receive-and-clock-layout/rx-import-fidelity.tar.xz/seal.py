# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,tarfile,io,sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));from check_magic_hbt_multiplicity_v3 import pin
B=R/'hw/soc/out/pcie-magic-rx-import-fidelity-20261004';O=Path('/dev/shm/nssoc-rx-import-fidelity-v1-final');T=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1');S=Path('/dev/shm/nssoc-magic-esd-v1-build-final/source')
grid=json.loads((B/'original-grid.json').read_text());layers=json.loads((B/'per-layer-roundtrip.json').read_text());native=json.loads((O/'result.json').read_text());ancestor=R/'hw/soc/out/pcie-magic-pad-stack-v1-20261004'
assert grid['physical_off5nm']==4 and grid['text_off5nm']==12
assert layers['raw_native_M4_union_xor_nm2']==0
assert all(layers['layers'][k]['xor_area_nm2']==0 for k in ('8/0','10/0','30/0','50/0','67/0','19/0','29/0','49/0','66/0'))
assert layers['layers']['6/0']['xor_area_nm2']==5684800
for path,value in native['inputs'].items():assert pin(path)==value
for name,value in native['outputs'].items():assert pin(O/name)==value
for path,sha in layers['sources'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha
technology=json.loads((ancestor/'technology-audit.json').read_text())['after']
for name,value in technology.items():assert pin(T/name)==value
sources=[B/n for n in ('scan_original.py','import_rx.py','compare_layers.py','run_final.py','seal.py')]
provenance=[R/'hw/soc/flow/make_pcie_rx_cell_v2.py',S/'cif/CIFrdutils.c',S/'calma/CalmaRdcl.c',T/'ihp-sg13g2-cifin.tech',T/'ihp-sg13g2-cifout.tech',T/'ihp-sg13g2.tech',R/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage']
notice=(ancestor/'UPSTREAM-NOTICES.txt').read_text()+'\nRX IMPORT FIDELITY DIAGNOSTIC\nContains only project analysis code, original-PCell-derived RX geometry and native intermediate/output records. Original runtime/model implementations are not redistributed. Runtime/technology/source pins are retrieval/audit references.\n'
(B/'UPSTREAM-NOTICES.txt').write_text(notice)
record=dict(status='PASS_RX_ROUTING_MASK_FIDELITY_ONLY_PROCESS_ROUNDTRIP_NOT_LOSSLESS',original_full_bank_gds_sha256=grid['source_sha256'],sources={str(p.relative_to(R)):pin(p) for p in sources},native_source_and_tool_pins={str(p):pin(p) for p in provenance},exact_ancestral_technology_inventory_rechecked=True,ancestor_full_graph=pin(ancestor/'bank-validation.json'),native_record=pin(O/'result.json'),original_grid=pin(B/'original-grid.json'),per_layer=pin(B/'per-layer-roundtrip.json'),native_seconds=native['execution']['seconds'],native_memory_limit_bytes=native['execution']['memory_limit_bytes'],findings=['Four original M4 rectangles have endpoint coordinates at2/3nm residues relative to5nm import grid; twelve native text positions are also off-grid.','All four physical off-grid edges are internal to overlapping M4 geometry: merged original M4 has no off5nm boundary vertices.','Native raw MAG M4-plane metal/via union equals the original GDS M4 region exactly, XOR0nm2; not merely an exported-GDS observation.','Native import/export has XOR0nm2 on all five occupied routing metals and four occupied routing-via layers, with no tolerance.','Native import/export process contact layer6/0 loses5684800nm2; several HBT process/marker/pin layers also differ. These are recorded separately and are not attributed solely to import or numerical grid snapping.','Current CIFScaleCoord has explicit gridlimit-triggered rounding; cifin/cifout5nm limits remain unchanged. The warning is retained, not suppressed.'],limitations=['This is the exact isolated v2_RX subset of the unchanged padded bank, not a whole-bank all-layer mask-conservation certificate.','Raw MAG stores compact device/contact abstractions; native GDS output reconstructs them. Process-layer roundtrip differences require a separate import-vs-reconstruction audit.','Connectivity351device/56port pass is separate from geometry and RC metrology. No qualified PEX, device-parameter replacement, ESD stress, post-layout RF timing or mainchip adoption.'],qualified_pex=False,whole_process_mask_lossless=False,old_sources_unchanged=True)
files={}
for p in O.iterdir():
 if p.is_file():files['native/'+p.name]=p.read_bytes()
for p in B.iterdir():
 if p.is_file() and p.suffix in ('.json','.py','.txt') and p.name!='validation.json':files[p.name]=p.read_bytes()
files['MANIFEST.json']=(json.dumps({n:dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in files.items()},indent=2)+'\n').encode()
cap=B/'rx-import-fidelity-native.tar.xz'
with tarfile.open(cap,'w:xz') as t:
 for n,d in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(d);m.mtime=0;t.addfile(m,io.BytesIO(d))
with tarfile.open(cap) as t:
 assert len(t.getmembers())==len(files)
 for m in t.getmembers():assert t.extractfile(m).read()==files[m.name]
record['capsule']=dict(**pin(cap),members=len(files),all_roundtrip_verified=True)
(B/'validation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({p.name:pin(p) for p in (cap,B/'validation.json')},indent=2))
