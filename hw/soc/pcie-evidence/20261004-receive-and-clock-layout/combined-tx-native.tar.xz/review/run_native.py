#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Direct frozen map+Makefile recipe under one guarded process group per stage."""
import ast,json,os,pathlib,resource,shutil,signal,subprocess,sys,time
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT/'scripts'))
from check_pcie_integrity import pin,tool_environment
from check_pcie_integrity_native import LIB_SHA,MODEL_SHA,quote
from cocotb_results import count_results
from check_pcie_gen3_framer import PROFILES
OUT=pathlib.Path('/dev/shm/nssoc-gen3-framed-path-native-final');TOP='soc_pcie_gen3_packet_tx_path'
TOOLS=ROOT/'hw/soc/tools/oss-cad-suite/bin'
PDK=pathlib.Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell')
LIB=PDK/'lib/sg13g2_stdcell_typ_1p20V_25C.lib';MODEL=PDK/'verilog/sg13g2_stdcell.v'
RTL=[ROOT/'hw/soc/rtl/pcie'/f'{n}.v' for n in PROFILES[TOP]]
BENCH=ROOT/'hw/soc/tb/cocotb'/f'test_{TOP}.py';MAKE=BENCH.with_name(f'Makefile.{TOP}')
FLOOR=512*1024**2;LIMIT=2*1024**3
assert pin(LIB)['sha256']==LIB_SHA and pin(MODEL)['sha256']==MODEL_SHA
assert not OUT.exists() and shutil.disk_usage('/dev/shm').free>=FLOOR
expected=sum(isinstance(n,ast.AsyncFunctionDef) and bool(n.decorator_list) for n in ast.parse(BENCH.read_text()).body);assert expected==2
files=[*RTL,BENCH,MAKE,BENCH.with_name('pcie_gen3_framer_support.py'),LIB,MODEL,pathlib.Path(__file__).resolve(),*[ROOT/'scripts'/f for f in ['check_pcie_gen3_framer.py','check_pcie_integrity.py','check_pcie_integrity_native.py','cocotb_results.py']]]
OUT.mkdir();record=dict(status='RUNNING',top=TOP,capacity=150,expected_tests=expected,mode='native',commands=[],scope='Actual whole packet framing plus frozen TXv3 scrambling/gearbox, functional port oracle only. No SDF, timing/placement qualification, Ordered Sets, SKP, training, LTSSM or PMA.',resource=dict(address_space_limit_bytes=LIMIT,tmpfs_floor_bytes=FLOOR,minimum_free_bytes=shutil.disk_usage('/dev/shm').free,checks=0),inputs={str(p):pin(p) for p in files},runtime={str(TOOLS/t):pin(TOOLS/t) for t in ['yosys','iverilog','vvp']})
def save():
 p=OUT/'result.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(record,indent=2)+'\n');t.replace(p)
def limits():resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
def run(command,log,env=None):
 assert shutil.disk_usage('/dev/shm').free>=FLOOR
 start=time.monotonic();row=dict(command=list(map(str,command)),log=log,returncode=None);record['commands'].append(row);save()
 with (OUT/log).open('x') as f:
  process=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,cwd=OUT,env=env,preexec_fn=limits,start_new_session=True)
  try:
   while process.poll() is None:
    free=shutil.disk_usage('/dev/shm').free;record['resource']['minimum_free_bytes']=min(record['resource']['minimum_free_bytes'],free);record['resource']['checks']+=1
    if free<FLOOR:raise RuntimeError('Actual tmpfs free-space floor crossed')
    time.sleep(.2)
   row['returncode']=process.wait();row['elapsed_seconds']=time.monotonic()-start;row['log_pin']=pin(OUT/log);save()
   assert row['returncode']==0,(log,row['returncode'])
  except BaseException:
   try:os.killpg(process.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:pass
   finally:
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    process.wait()
   raise
try:
 script='read_liberty -lib '+quote(LIB)+'; read_verilog -sv '+' '.join(map(quote,RTL))+'; hierarchy -check -top '+TOP+'; flatten -noscopeinfo; synth -top '+TOP+' -noabc; dfflibmap -liberty '+quote(LIB)+'; abc -liberty '+quote(LIB)+'; clean; check -assert; stat -liberty '+quote(LIB)+'; write_json '+quote(OUT/'mapped.json')+'; write_verilog -noattr -noexpr '+quote(OUT/'mapped.v')
 (OUT/'map.ys').write_text(script+'\n');run([str(TOOLS/'yosys'),'-Q','-T','-s',str(OUT/'map.ys')],'map.log')
 cells=json.loads((OUT/'mapped.json').read_text())['modules'][TOP]['cells'];assert cells and all(c['type'].startswith('sg13g2_') for c in cells.values());record['mapped_cells']=len(cells)
 run(['make','-f',str(MAKE),'--no-print-directory','VERILOG_SOURCES='+str(OUT/'mapped.v')+' '+str(MODEL),'SIM_BUILD='+str(OUT/'sim'),'COCOTB_RESULTS_FILE='+str(OUT/'results.xml'),'PCIE_NATIVE=1','PCIE_FRAMER_CAPACITY=150'],'simulation.log',tool_environment(TOOLS))
 counts=count_results([OUT/'results.xml']);assert counts==(expected,0,0),counts
 assert record['inputs']=={str(p):pin(p) for p in files}
 assert record['runtime']=={p:pin(p) for p in record['runtime']}
 record.update(status='PASS_COMBINED_DEFAULT150_GEN3_TX_NATIVE',tests=dict(zip(('passed','failed','skipped'),counts)),all_inputs_rechecked=True)
except BaseException as error:record.update(status='FAIL',error=repr(error));raise
finally:
 record['outputs']={str(p.relative_to(OUT)):pin(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ['result.json','result.tmp'] and 'sim' not in p.relative_to(OUT).parts};save()
print(record['status'],record.get('mapped_cells'),record.get('tests'))
