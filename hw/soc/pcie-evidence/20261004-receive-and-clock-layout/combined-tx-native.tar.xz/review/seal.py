#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,io,json,pathlib,tarfile,xml.etree.ElementTree as ET
R=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent;N=pathlib.Path('/dev/shm/nssoc-gen3-framed-path-native-final')
def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
r=json.loads((N/'result.json').read_text());prior=json.loads((B.parent/'validation.json').read_text())
assert r['status']=='PASS_COMBINED_DEFAULT150_GEN3_TX_NATIVE' and r['tests']==dict(passed=2,failed=0,skipped=0)
root=ET.parse(N/'results.xml').getroot();assert len(list(root.iter('testcase')))==2 and not list(root.iter('failure')) and not list(root.iter('skipped'))
assert r['resource']['minimum_free_bytes']>=r['resource']['tmpfs_floor_bytes']
members={}
for f,h in r['outputs'].items():assert pin(N/f)==h;members['native/'+f]=N/f
members['native/result.json']=N/'result.json'
for table in [r['inputs'],r['runtime']]:
 for f,h in table.items():
  assert pin(f)==h
  path=pathlib.Path(f)
  if path.suffix in ['.py','.v','.lib']:
   name='sources/'+str(path.relative_to(R)) if path.is_relative_to(R) else 'external/'+path.name
   members[name]=path
for f,h in prior['sources'].items():assert pin(f)==h;members['sources/'+f]=R/f
for f in ['run_native.py','seal.py','run.log']:members['review/'+f]=B/f
members['review/prior-core-validation.json']=B.parent/'validation.json'
for license in ['Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0']:members['LICENSES/'+license+'.txt']=R/'LICENSES'/f'{license}.txt'
inv={name:pin(path) for name,path in sorted(members.items())};cap=B/'combined-tx-native.tar.xz';assert not cap.exists()
with tarfile.open(cap,'w:xz',preset=3) as t:
 for name,path in sorted(members.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=path.stat().st_size
  with path.open('rb') as f:t.addfile(info,f)
 data=(json.dumps(inv,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.mode=0o644;info.mtime=0;info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(cap) as t:
 assert set(t.getnames())==set(inv)|{'inventory.json'}
 for name,h in inv.items():
  with t.extractfile(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==h['sha256'] and t.getmember(name).size==h['bytes']
log=(N/'simulation.log').read_text();diagnostics=[line for line in log.splitlines() if 'ERROR' in line]
assert len(diagnostics)==1 and 'Unexpected sys.executable value' in diagnostics[0]
result=dict(status='PASS_COMBINED_DEFAULT150_TX_NATIVE_COMPLETION',sources=prior['sources'],prior_core_validation=pin(B.parent/'validation.json'),native_result=pin(N/'result.json'),mapped_cells=r['mapped_cells'],tests=r['tests'],resource=r['resource'],capsule=dict(path=str(cap),**pin(cap),members=len(inv)+1,all_members_rehashed=True),native_TX_port_cases_now=7,runtime_diagnostic=dict(raw_line=diagnostics[0],disposition='GPI reports executable alias mismatch, then initializes the pinned venv cocotb2.0.1 and executes both actual tests successfully. Raw log retained. Same diagnostic is present in prior coreTX/RX native logs; no clean-log claim.',not_a_missing_test_waiver=True),scope=dict(default_capacity=150,maximum4118_native=False,unmodified_ihp_models=True,framer_scrambler_gearbox_connected=True,independent_serial_descrambling_oracle=True,sdf_timing=False,phy_training_ltssm=False,mainchip=False),failed_oracle_captures_preserved=True)
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(pin(B/'validation.json'),result['capsule'],r['resource'])
