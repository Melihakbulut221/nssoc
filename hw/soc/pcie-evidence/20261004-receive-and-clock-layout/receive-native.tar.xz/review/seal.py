#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,io,json,pathlib,tarfile,xml.etree.ElementTree as ET
R=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent;N=pathlib.Path('/dev/shm/nssoc-gen3-receive-native-final')
def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
r=json.loads((N/'mapping-replay.json').read_text());p=json.loads((N/'ports/result.json').read_text());v=json.loads((B.parent/'validation.json').read_text())
assert r['status']=='PASS_MAPPED_DEFAULT150_RECEIVE_FRAMING' and r['tests']==dict(passed=6,failed=0,skipped=0)
assert len(list(ET.parse(N/'ports/results.xml').getroot().iter('testcase')))==6
assert not list(ET.parse(N/'ports/results.xml').getroot().iter('failure'))
assert p['tests']==r['tests'] and p['mode']=='external_native' and p['max_encoded_bytes']==150
members={}
for f,h in r['outputs'].items():assert pin(N/f)==h;members['native/'+f]=N/f
members['native/mapping-replay.json']=N/'mapping-replay.json'
for table in [r['source_sha256'],p['inputs'],p['runtime']]:
 for f,h in table.items():
  assert pin(f)==h
  path=pathlib.Path(f)
  if path.suffix in ['.py','.v','.lib']:
   if path.is_relative_to(R):name='sources/'+str(path.relative_to(R))
   elif path.is_relative_to(N):continue
   else:name='external/'+path.name
   members[name]=path
for f,h in v['sources'].items():assert pin(f)==h;members['sources/'+f]=R/f
for f in ['run_native.py','seal.py','run.log']:members['review/'+f]=B/f
members['review/prior-rtl-validation.json']=B.parent/'validation.json'
for license in ['Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0']:members['LICENSES/'+license+'.txt']=R/'LICENSES'/f'{license}.txt'
inv={name:pin(path) for name,path in sorted(members.items())}
cap=B/'receive-native.tar.xz';assert not cap.exists()
with tarfile.open(cap,'w:xz',preset=3) as t:
 for name,path in sorted(members.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=path.stat().st_size
  with path.open('rb') as f:t.addfile(info,f)
 data=(json.dumps(inv,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.mode=0o644;info.mtime=0;info.size=len(data);t.addfile(info,io.BytesIO(data))
with tarfile.open(cap) as t:
 assert set(t.getnames())==set(inv)|{'inventory.json'}
 for name,h in inv.items():
  with t.extractfile(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==h['sha256'] and t.getmember(name).size==h['bytes']
result=dict(status='PASS_DEFAULT150_RX_NATIVE_COMPLETION',sources=v['sources'],prior_rtl_validation=pin(B.parent/'validation.json'),native_mapping_receipt=pin(N/'mapping-replay.json'),native_port_receipt=pin(N/'ports/result.json'),mapped_cells=r['mapped_cells'],tests=r['tests'],resource=r['resource'],capsule=dict(path=str(cap),**pin(cap),members=len(inv)+1,all_members_rehashed=True),scope=dict(default_capacity=150,maximum4118_native=False,unmodified_ihp_models=True,port_only=True,sdf_timing=False,phy_training_ltssm=False,independent_peer_execution=False),preserved_initial_failed_oracle=True)
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(pin(B/'validation.json'),result['capsule'])
