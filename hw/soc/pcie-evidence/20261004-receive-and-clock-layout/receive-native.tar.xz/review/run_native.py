#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Default150 receive mapping/port replay; bounded space and process memory."""
import hashlib,json,os,pathlib,resource,shutil,signal,subprocess,sys,time
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT/'scripts'))
from check_pcie_integrity import pin
from check_pcie_integrity_native import LIB_SHA,MODEL_SHA,quote
OUT=pathlib.Path('/dev/shm/nssoc-gen3-receive-native-final')
TOOLS=ROOT/'hw/soc/tools/oss-cad-suite/bin'
PDK=pathlib.Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell')
LIB=PDK/'lib/sg13g2_stdcell_typ_1p20V_25C.lib';MODEL=PDK/'verilog/sg13g2_stdcell.v'
RTL=ROOT/'hw/soc/rtl/pcie/soc_pcie_gen3_framer_rx.v';TOP='soc_pcie_gen3_framer_rx'
FLOOR=512*1024**2;LIMIT=2*1024**3
assert pin(LIB)['sha256']==LIB_SHA and pin(MODEL)['sha256']==MODEL_SHA
assert not OUT.exists() and shutil.disk_usage('/dev/shm').free>=FLOOR
OUT.mkdir();record=dict(status='RUNNING',top=TOP,capacity=150,native_scope='IHP SG13G2 mapped functional ports, no SDF or timing signoff',commands=[],resource=dict(address_space_limit_bytes=LIMIT,tmpfs_floor_bytes=FLOOR,minimum_free_bytes=shutil.disk_usage('/dev/shm').free,checks=0),source_sha256={str(p):pin(p) for p in [RTL,LIB,MODEL,pathlib.Path(__file__).resolve(),ROOT/'scripts/check_pcie_gen3_receive.py']})
def save():
 p=OUT/'mapping-replay.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(record,indent=2)+'\n');t.replace(p)
def limits():resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
def run(command,log):
 assert shutil.disk_usage('/dev/shm').free>=FLOOR
 start=time.monotonic();row=dict(command=list(map(str,command)),log=log,returncode=None);record['commands'].append(row);save()
 with (OUT/log).open('x') as f:
  process=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':'/dev/shm'},preexec_fn=limits,start_new_session=True)
  try:
   while process.poll() is None:
    free=shutil.disk_usage('/dev/shm').free;record['resource']['minimum_free_bytes']=min(record['resource']['minimum_free_bytes'],free);record['resource']['checks']+=1
    if free<FLOOR:raise RuntimeError('Actual tmpfs free-space floor crossed')
    time.sleep(.2)
   row['returncode']=process.wait();row['elapsed_seconds']=time.monotonic()-start;row['log_pin']=pin(OUT/log);save()
   assert row['returncode']==0,(log,row['returncode'])
  except BaseException:
   try:os.killpg(process.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:pass
   finally:
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    process.wait()
   raise
try:
 script='read_liberty -lib '+quote(LIB)+'; read_verilog -sv '+quote(RTL)+'; hierarchy -check -top '+TOP+'; flatten -noscopeinfo; synth -top '+TOP+' -noabc; dfflibmap -liberty '+quote(LIB)+'; abc -liberty '+quote(LIB)+'; clean; check -assert; stat -liberty '+quote(LIB)+'; write_json '+quote(OUT/'mapped.json')+'; write_verilog -noattr -noexpr '+quote(OUT/'mapped.v')
 (OUT/'map.ys').write_text(script+'\n')
 run([str(TOOLS/'yosys'),'-Q','-T','-s',str(OUT/'map.ys')],'map.log')
 cells=json.loads((OUT/'mapped.json').read_text())['modules'][TOP]['cells'];assert cells and all(c['type'].startswith('sg13g2_') for c in cells.values())
 record['mapped_cells']=len(cells)
 run([sys.executable,str(ROOT/'scripts/check_pcie_gen3_receive.py'),'--out',str(OUT/'ports'),'--iverilog-dir',str(TOOLS),'--netlist',str(OUT/'mapped.v'),'--models',str(MODEL)],'port-launch.log')
 ports=json.loads((OUT/'ports/result.json').read_text());assert ports['status']=='PASS_PORT_ONLY_GEN3_RECEIVE_FRAMING' and ports['tests']==dict(passed=6,failed=0,skipped=0)
 assert all(pin(p)==v for p,v in record['source_sha256'].items())
 record.update(status='PASS_MAPPED_DEFAULT150_RECEIVE_FRAMING',ports=pin(OUT/'ports/result.json'),tests=ports['tests'],all_inputs_rechecked=True)
except BaseException as error:
 record.update(status='FAIL',error=repr(error));raise
finally:
 record['outputs']={str(p.relative_to(OUT)):pin(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ['mapping-replay.json','mapping-replay.tmp'] and 'sim' not in p.relative_to(OUT).parts};save()
print(record['status'],record.get('mapped_cells'),record.get('tests'))
