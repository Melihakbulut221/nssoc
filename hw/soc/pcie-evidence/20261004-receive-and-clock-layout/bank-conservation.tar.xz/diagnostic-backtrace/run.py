# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Observe an existing one-device failure; no runtime or geometry patch."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import time

ROOT = Path.cwd()
B = ROOT / 'hw/soc/out/pcie-magic-bank-conservation-v1-20261004/backtrace'
OUT = Path('/dev/shm/nssoc-esd-backtrace-01')
RT = Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib')
TECH = Path('/dev/shm/nssoc-magic-pad-stack-tech-v1')


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


results = {}
for name in ('pnp', 'npn'):
    old = Path('/dev/shm/nssoc-rc-single-' + name + '-01')
    target = OUT / name
    target.mkdir()
    script = target / 'native.tcl'
    original = old / 'native.tcl'
    script.write_text(original.read_text().replace(str(old), str(target)))
    inputs = {str(p): pin(p) for p in [Path(__file__), original, script,
              B / 'crash_trace.c', OUT / 'crash_trace.so', RT / 'magic/tcl/tclmagic.so']}
    env = {k: v for k, v in os.environ.items()
           if k not in ('GH_TOKEN', 'GITHUB_TOKEN', 'PYTHONPATH', 'PYTHONHOME')}
    env.update(CAD_ROOT=str(RT), LD_PRELOAD=str(OUT / 'crash_trace.so'))
    command = ['/usr/bin/tclsh8.6', str(RT / 'magic/tcl/magic.tcl'), '-dnull',
               '-noconsole', '-rcfile', str(TECH / 'ihp-sg13g2.magicrc'), str(script)]
    started = time.monotonic()
    with (target / 'native.log').open('w') as log:
        process = subprocess.run(command, cwd=target, env=env, preexec_fn=limits,
                                 stdout=log, stderr=subprocess.STDOUT, timeout=20, check=False)
    assert all(pin(p) == expected for p, expected in inputs.items())
    lines = (target / 'native.log').read_text().splitlines()
    frames = [line for line in lines if line.startswith('NSSOC_DIAGNOSTIC_')]
    offsets = [line.split()[3] for line in frames if '/magic/tcl/tclmagic.so' in line]
    symbol_command = ['addr2line', '-f', '-C', '-e', str(RT / 'magic/tcl/tclmagic.so'), *offsets]
    symbols = subprocess.run(symbol_command, capture_output=True, text=True, check=True)
    (target / 'symbols.txt').write_text(symbols.stdout)
    results[name] = dict(returncode=process.returncode, seconds=time.monotonic()-started,
                        command=command, inputs=inputs, frames=frames,
                        symbol_command=symbol_command, symbols=symbols.stdout,
                        outputs={p.name: pin(p) for p in target.iterdir() if p.is_file()},
                        observation_only=True, accepted_extraction=False)
    print(name, process.returncode, '\n' + '\n'.join(frames), symbols.stdout, flush=True)
(B / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
