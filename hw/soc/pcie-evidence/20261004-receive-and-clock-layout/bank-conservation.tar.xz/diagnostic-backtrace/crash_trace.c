/* SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut */
/* SPDX-License-Identifier: Apache-2.0 */
/* Diagnostic-only signal trace, never an accepted extraction runtime. */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <execinfo.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static void native_crash(int signal_number, siginfo_t *info, void *context)
{
    void *frames[48];
    int count = backtrace(frames, 48);
    (void) context;
    dprintf(2, "NSSOC_DIAGNOSTIC_SIGNAL signal=%d address=%p frames=%d\n",
            signal_number, info->si_addr, count);
    for (int index = 0; index < count; ++index) {
        Dl_info record = {0};
        if (dladdr(frames[index], &record)) {
            dprintf(2, "NSSOC_DIAGNOSTIC_FRAME %d %s +0x%lx %s +0x%lx\n",
                    index, record.dli_fname,
                    (unsigned long)((uintptr_t)frames[index] - (uintptr_t)record.dli_fbase),
                    record.dli_sname ? record.dli_sname : "?",
                    (unsigned long)((uintptr_t)frames[index] - (uintptr_t)record.dli_saddr));
        }
    }
    _Exit(128 + signal_number);
}

__attribute__((constructor)) static void install_native_crash_trace(void)
{
    struct sigaction action = {0};
    action.sa_sigaction = native_crash;
    action.sa_flags = SA_SIGINFO;
    sigemptyset(&action.sa_mask);
    sigaction(SIGSEGV, &action, NULL);
    sigaction(SIGABRT, &action, NULL);
}
