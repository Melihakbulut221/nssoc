puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-bank-conservation-reload-probe}
drc off
load nssoc_padded_clocked_pad_stack_flat
select top cell
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {/dev/shm/nssoc-bank-conservation-reload-probe/baseline.spice}
puts NSSOC_RELOAD_NO_CIFOUT_COMPLETE
quit -noprompt
