puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-bank-conservation-v1-01}
drc off
load nssoc_padded_clocked_pad_stack_flat
select top cell
cif ostyle gdsii
gds write {/dev/shm/nssoc-bank-conservation-v1-01/imported-bank.gds}
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {/dev/shm/nssoc-bank-conservation-v1-01/baseline.spice}
puts NSSOC_BASELINE_CAPACITANCE_COMPLETE
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice extresist on
ext2spice -o {/dev/shm/nssoc-bank-conservation-v1-01/unreduced.spice}
puts NSSOC_UNREDUCED_RC_COMPLETE
quit -noprompt
