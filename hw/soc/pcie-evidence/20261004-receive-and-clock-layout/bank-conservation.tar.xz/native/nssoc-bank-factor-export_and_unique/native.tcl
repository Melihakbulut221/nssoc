cd {/dev/shm/nssoc-bank-factor-export_and_unique}
drc off
load nssoc_padded_clocked_pad_stack_flat
select top cell
cif ostyle gdsii
gds write {/dev/shm/nssoc-bank-factor-export_and_unique/exported.gds}
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {/dev/shm/nssoc-bank-factor-export_and_unique/baseline.spice}
puts NSSOC_FACTOR_COMPLETE
quit -noprompt
