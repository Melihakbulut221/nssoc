puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-bank-conservation-v1-02}
drc off
load nssoc_padded_clocked_pad_stack_flat
select top cell
cif ostyle gdsii
gds write {/dev/shm/nssoc-bank-conservation-v1-02/imported-bank.gds}
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {/dev/shm/nssoc-bank-conservation-v1-02/baseline.spice}
puts NSSOC_BASELINE_CAPACITANCE_COMPLETE
set f [open {/dev/shm/nssoc-bank-conservation-v1-02/baseline.spice} r]
set baseline [read $f]
close $f
foreach {model count} {npn13g2 122 ptap1 108 ntap1 1 rsil 24 rppd 57 cap_cmim 6 sg13_hv_pmos 1 diodevdd_2kv 16 diodevss_2kv 16} {
 if {[regexp -all -- [format {\s%s\s} $model] $baseline] != $count} {error "Baseline model census differs: $model"}
}
puts NSSOC_BASELINE_351_MODEL_CENSUS_PASSED
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice extresist on
ext2spice -o {/dev/shm/nssoc-bank-conservation-v1-02/unreduced.spice}
puts NSSOC_UNREDUCED_RC_COMPLETE
quit -noprompt
