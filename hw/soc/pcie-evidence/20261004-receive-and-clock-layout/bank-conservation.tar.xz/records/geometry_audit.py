# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Read-only original/raw-paint/cifout comparison; exact integer nanometers."""
from pathlib import Path
import json,hashlib,re,pya
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-bank-conservation-v1-20261004';O=Path('/dev/shm/nssoc-bank-conservation-v1-01');V=Path('/dev/shm/nssoc-padded-clocked-layout-01');T=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1')
a=pya.Layout();a.read(str(V/'nssoc_pcie_padded_clocked_bank4_v1.gds'));b=pya.Layout();b.read(str(O/'imported-bank.gds'));assert a.dbu==b.dbu==.001
ca=a.cell('nssoc_pcie_padded_clocked_bank4_v1');cb=b.cell('nssoc_padded_clocked_pad_stack_flat');assert ca and cb
text=(O/'nssoc_padded_clocked_pad_stack_flat.mag').read_text();assert 'magscale 1 2\n' in text and not re.search(r'^use ',text,re.M)
regs={};counts={};section=None
for line in text.splitlines():
 if line.startswith('<< '):section=line[3:-3];continue
 if not line.startswith(('rect ','tri ')):continue
 f=line.split();xy=[int(v)*5 for v in f[1:5]];x,y,xx,yy=xy;assert x<xx and y<yy
 if f[0]=='rect':shape=pya.Box(*xy)
 else:
  corners={'ne':[(x,yy),(xx,yy),(xx,y)],'nw':[(x,y),(x,yy),(xx,yy)],'se':[(x,y),(xx,y),(xx,yy)],'sw':[(x,y),(xx,y),(x,yy)]}
  shape=pya.Polygon([pya.Point(*v) for v in corners[f[5]]])
 regs.setdefault(section,pya.Region()).insert(shape);counts[section]=counts.get(section,0)+1
# Resolve actual native aliases/contact-plane declarations, not inferred metal joins.
tech=(T/'ihp-sg13g2.tech').read_text();blocks={name:re.search(r'^'+name+r'\n(.*?)^end$',tech,re.M|re.S)[1] for name in ('types','contact')};aliases={}
for line in blocks['types'].splitlines():
 f=line.split()
 if len(f)!=2 or f[0].startswith('#'):continue
 names=f[1].split(',')
 for name in names:aliases[name]=names[0]
metal_types={i:{f'metal{i}'} for i in range(1,8)}
for line in blocks['contact'].splitlines():
 f=line.split()
 if len(f)!=3 or f[0].startswith('#'):continue
 for plane in f[1:]:
  if re.fullmatch('metal[1-7]',plane):metal_types[int(plane[-1])].add(aliases[f[0]])
metal_types[5].update(('mimcap','mimcapcontact'))
metal_gds={1:8,2:10,3:30,4:50,5:67,6:126,7:134};via_gds={1:19,2:29,3:49,4:66,5:125,6:133}
def native_union(names):
 out=pya.Region()
 for n in names:
  if n in regs:out+=regs[n]
 return out.merged()
def region(layout,cell,layer):
 i=layout.find_layer(layer,0)
 return pya.Region(cell.begin_shapes_rec(i)).merged() if i is not None else pya.Region()
def compare(original,other):
 missing=original-other;extra=other-original;delta=missing+extra
 return dict(equal=delta.is_empty(),original_area_nm2=original.area(),actual_area_nm2=other.area(),missing_area_nm2=missing.area(),extra_area_nm2=extra.area(),xor_components=delta.count(),xor_bboxes_nm=[str(p.bbox()) for p in delta.each()][:24])
rows={}
for i,layer in metal_gds.items():
 original=region(a,ca,layer);raw=native_union(metal_types[i]);export=region(b,cb,layer)
 rows['metal'+str(i)]=dict(gds_layer=layer,native_types=sorted(metal_types[i]),raw_material_paint=compare(original,raw),cifout_reconstruction=compare(original,export));print('metal',i,rows['metal'+str(i)]['raw_material_paint'],flush=True)
for i,layer in via_gds.items():
 original=region(a,ca,layer);raw=native_union({'via'+str(i)});export=region(b,cb,layer)
 rows['via'+str(i)]=dict(gds_layer=layer,native_types=['via'+str(i)],raw_contact_footprint=compare(original,raw),cifout_cut_reconstruction=compare(original,export));print('via',i,rows['via'+str(i)]['raw_contact_footprint'],flush=True)
contact_types={aliases[f[0]] for line in blocks['contact'].splitlines() if len(f:=line.split())==3 and f[2]=='metal1'}|{'pbasec'}
original=region(a,ca,6);rows['contact']=dict(gds_layer=6,native_types=sorted(contact_types),raw_contact_footprint=compare(original,native_union(contact_types)),cifout_cut_reconstruction=compare(original,region(b,cb,6)))
record=dict(status='COMPLETE_BANK_WIRE_AND_CONTACT_GEOMETRY_DIAGNOSTIC',layers=rows,raw_type_counts=counts,inputs={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [Path(__file__),V/'nssoc_pcie_padded_clocked_bank4_v1.gds',O/'imported-bank.gds',O/'nssoc_padded_clocked_pad_stack_flat.mag',T/'ihp-sg13g2.tech',T/'ihp-sg13g2-cifout.tech']},qualified_pex=False)
(B/'geometry-review.json').write_text(json.dumps(record,indent=2)+'\n')
