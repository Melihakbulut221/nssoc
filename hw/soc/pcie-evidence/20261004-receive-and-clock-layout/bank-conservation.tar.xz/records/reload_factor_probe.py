# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,os,resource,subprocess,time,hashlib,shutil,sys
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-bank-conservation-v1-20261004';P=Path('/dev/shm/nssoc-padded-clocked-pad-stack-01');RT=Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib');T=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1');TOP='nssoc_padded_clocked_pad_stack_flat'
sys.path.insert(0,str(R/'scripts'));import check_magic_hbt_multiplicity_v3 as h
from collections import Counter
results={}
for name,export,unique in [('no_export_no_unique',False,False),('export_and_unique',True,True)]:
 O=Path('/dev/shm/nssoc-bank-factor-'+name);O.mkdir();shutil.copyfile(P/(TOP+'.mag'),O/(TOP+'.mag'))
 lines=[f'cd {{{O}}}','drc off',f'load {TOP}','select top cell']
 if export:lines+=['cif ostyle gdsii',f'gds write {{{O/"exported.gds"}}}']
 if unique:lines+=['extract unique all']
 lines+=['extract style ngspice()','extract all','ext2spice lvs','ext2spice merge none','ext2spice global off','ext2spice cthresh 0','ext2spice rthresh 0','ext2spice extresist off',f'ext2spice -o {{{O/"baseline.spice"}}}','puts NSSOC_FACTOR_COMPLETE','quit -noprompt']
 script=O/'native.tcl';script.write_text('\n'.join(lines)+'\n')
 cmd=['/usr/bin/tclsh8.6',str(RT/'magic/tcl/magic.tcl'),'-dnull','-noconsole','-rcfile',str(T/'ihp-sg13g2.magicrc'),str(script)];env=dict(os.environ,CAD_ROOT=str(RT))
 for key in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME'):env.pop(key,None)
 def limits():
  resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 start=time.monotonic()
 with (O/'native.log').open('w') as f:p=subprocess.run(cmd,cwd=O,env=env,preexec_fn=limits,stdout=f,stderr=subprocess.STDOUT,timeout=60,check=False)
 c=Counter()
 for row in (line.split() for line in h.spice_lines((O/'baseline.spice').read_text())):
  if row[0][0] in 'XQRMDC' and any('='in t for t in row):i=next(i for i,t in enumerate(row) if '='in t);c[row[i-1]]+=1
 r=dict(returncode=p.returncode,seconds=time.monotonic()-start,export=export,extract_unique=unique,models=dict(c),inputs={str(x):h.pin(x) for x in [Path(__file__),P/(TOP+'.mag'),RT/'magic/tcl/tclmagic.so',*T.iterdir()] if x.is_file()},outputs={x.name:h.pin(x) for x in O.iterdir() if x.is_file()});(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');results[name]=r;print(name,c,flush=True)
(B/'factor-results.json').write_text(json.dumps(results,indent=2)+'\n')
