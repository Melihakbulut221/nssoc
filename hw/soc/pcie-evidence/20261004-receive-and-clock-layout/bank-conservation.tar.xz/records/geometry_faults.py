# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Actual full-bank GDS wire/return/via mutations; no reference net unions."""
from pathlib import Path
import pya,json,hashlib
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-bank-conservation-v1-20261004';O=Path('/dev/shm/nssoc-bank-conservation-v1-01');V=Path('/dev/shm/nssoc-padded-clocked-layout-01');CHECK=Path('/dev/shm/nssoc-padded-clocked-checks-02');TOP='nssoc_pcie_padded_clocked_bank4_v1'
a=pya.Layout();a.read(str(V/(TOP+'.gds')));top=a.cell(TOP);assert a.dbu==.001
layers=(8,10,30,50,67,126,134,19,29,49,66,125,133)
base={k:pya.Region(top.begin_shapes_rec(a.layer(k,0))).merged() for k in layers}
l=pya.Layout();l.read(str(V/(TOP+'.gds')));c=l.cell(TOP)
found=[i for i in c.each_inst() if l.cell(i.cell_index).name.startswith('via_stack') and abs(i.dbbox().center().x-550)<.0001 and abs(i.dbbox().center().y-270)<.0001]
assert len(found)==1
before=dict(cell=l.cell(found[0].cell_index).name,transform=str(found[0].trans),bbox=str(found[0].bbox()))
found[0].delete();missing=O/'missing_pad_via.gds';l.write(str(missing))
paths={'wire_open':CHECK/'open_L0_TX_OUTP/wrong.gds','body_return_short':CHECK/'return_avss_short/wrong.gds','missing_via':missing}
results={}
for name,path in paths.items():
 b=pya.Layout();b.read(str(path));cell=b.cell(TOP);assert cell and b.dbu==a.dbu
 delta={}
 for k in layers:
  actual=pya.Region(cell.begin_shapes_rec(b.layer(k,0))).merged();d=base[k]^actual
  if not d.is_empty():delta[str(k)]=dict(xor_area_nm2=d.area(),missing_area_nm2=(base[k]-actual).area(),extra_area_nm2=(actual-base[k]).area(),components=d.count(),bboxes_nm=[str(poly.bbox()) for poly in d.each()][:16])
 assert delta
 if name=='missing_via':assert delta['133']['missing_area_nm2']>0 and delta['133']['extra_area_nm2']==0
 if name=='wire_open':assert any(v['missing_area_nm2']>0 for v in delta.values())
 if name=='body_return_short':assert any(v['extra_area_nm2']>0 for v in delta.values())
 results[name]=dict(status='REJECTED_ACTUAL_GDS_GEOMETRY_CONSERVATION',source=dict(path=str(path),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()),differences=delta)
record=dict(status='PASS_ACTUAL_FULL_BANK_GEOMETRY_NEGATIVE_CONTROLS',cases=results,removed_native_via_instance=before,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),V/(TOP+'.gds'),V/'result.json']},scope='Actual geometry comparison against the source whose seven native metal regions and six reconstructed via-cut layers passed. These controls do not rerun native Magic RC or waive its failure.')
(B/'geometry-controls.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['cases'],indent=2))
