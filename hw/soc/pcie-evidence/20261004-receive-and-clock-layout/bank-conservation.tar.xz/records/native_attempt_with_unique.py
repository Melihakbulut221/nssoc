# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,os,resource,subprocess,time,hashlib,shutil
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-bank-conservation-v1-20261004';O=Path('/dev/shm/nssoc-bank-conservation-v1-02');O.mkdir()
P=Path('/dev/shm/nssoc-padded-clocked-pad-stack-01');RT=Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib');T=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1');TOP='nssoc_padded_clocked_pad_stack_flat'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={str(p):sha(p) for p in [Path(__file__),P/(TOP+'.mag'),P/(TOP+'.ext'),P/'capacitance.spice',RT/'magic/tcl/tclmagic.so',*T.iterdir()] if p.is_file()}
shutil.copyfile(P/(TOP+'.mag'),O/(TOP+'.mag'))
text=f'''puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {{{O}}}
drc off
load {TOP}
select top cell
cif ostyle gdsii
gds write {{{O/'imported-bank.gds'}}}
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {{{O/'baseline.spice'}}}
puts NSSOC_BASELINE_CAPACITANCE_COMPLETE
set f [open {{/dev/shm/nssoc-bank-conservation-v1-02/baseline.spice}} r]
set baseline [read $f]
close $f
foreach {{model count}} {{npn13g2 122 ptap1 108 ntap1 1 rsil 24 rppd 57 cap_cmim 6 sg13_hv_pmos 1 diodevdd_2kv 16 diodevss_2kv 16}} {{
 if {{[regexp -all -- [format {{\s%s\s}} $model] $baseline] != $count}} {{error "Baseline model census differs: $model"}}
}}
puts NSSOC_BASELINE_351_MODEL_CENSUS_PASSED
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice extresist on
ext2spice -o {{{O/'unreduced.spice'}}}
puts NSSOC_UNREDUCED_RC_COMPLETE
quit -noprompt
'''
script=O/'native.tcl';script.write_text(text);inputs[str(script)]=sha(script)
cmd=['/usr/bin/tclsh8.6',str(RT/'magic/tcl/magic.tcl'),'-dnull','-noconsole','-rcfile',str(T/'ihp-sg13g2.magicrc'),str(script)]
env={k:v for k,v in os.environ.items() if k not in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME')};env['CAD_ROOT']=str(RT)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic()
with (O/'native.log').open('w') as log:
 try:
  proc=subprocess.run(cmd,cwd=O,env=env,preexec_fn=limits,stdout=log,stderr=subprocess.STDOUT,timeout=180,check=False);exitcode=proc.returncode;status='NATIVE_COMPLETED_REQUIRES_AUDIT'
 except subprocess.TimeoutExpired:exitcode=None;status='NATIVE_180S_TIMEOUT_PRESERVED'
assert all(sha(p)==v for p,v in inputs.items())
r=dict(status=status,command=cmd,returncode=exitcode,seconds=time.monotonic()-start,memory_limit_bytes=2*1024**3,inputs=inputs,outputs={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in O.iterdir() if p.is_file()},simplification=False,lumping=False,capacitance_scale=1,qualified_pex=False)
(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items() if k not in ('inputs','outputs')})
