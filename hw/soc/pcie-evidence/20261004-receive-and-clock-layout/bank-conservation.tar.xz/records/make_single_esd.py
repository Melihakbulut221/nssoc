# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import pya,json,hashlib
R=Path.cwd();F=Path('/dev/shm/nssoc-magic-esd-fixture-final02');O=Path('/dev/shm/nssoc-rc-single-esd-fixtures');O.mkdir();r=json.loads((F/'result.json').read_text());a=pya.Layout();a.read(str(F/'fixture.gds'));source=a.cell('nssoc_esd_fixture');result={}
for index,name in [(0,'pnp'),(16,'npn')]:
 t=pya.DTrans(0,False,60.0,60.0+(index//8)*80)
 insts=[i for i in source.each_inst() if i.dtrans==t];assert len(insts)==1;old=a.cell(insts[0].cell_index)
 b=pya.Layout();b.dbu=a.dbu;top=b.create_cell('single_'+name);cell=b.create_cell(old.name);cell.copy_tree(old);top.insert(pya.DCellInstArray(cell.cell_index(),t))
 polygons={}
 for k in a.layer_indices():
  info=a.get_info(k);src=pya.Region(old.begin_shapes_rec(k)).merged();target=pya.Region(cell.begin_shapes_rec(b.layer(info))).merged();assert (src^target).is_empty()
  if not src.is_empty():polygons[str(info)]=hashlib.sha256(src.to_s().encode()).hexdigest()
 ports={key:[values[0] if key!='SUB' else values[index]] for key,values in r['ports'].items() if key in ('SUB',f'PAD{index:02d}',f'VDD{index:02d}')}
 # Existing raw source stores SUB points in exact insertion order0..31.
 for key,values in ports.items():
  p=values[0];box=pya.DBox(*p['box']);layer=p['layer'];top.shapes(b.layer(layer,2)).insert(box);top.shapes(b.layer(layer,25)).insert(pya.DText(key,pya.DTrans(box.center().x,box.center().y)))
 gds=O/(name+'.gds');b.write(str(gds));result[name]=dict(top=top.name,ports=ports,device=r['devices'][index],native_cell=old.name,transform=str(t),unchanged_all_layer_masks=polygons,gds_sha256=hashlib.sha256(gds.read_bytes()).hexdigest())
(O/'result.json').write_text(json.dumps(dict(cases=result,source_fixture_sha256=hashlib.sha256((F/'fixture.gds').read_bytes()).hexdigest(),source_record_sha256=hashlib.sha256((F/'result.json').read_bytes()).hexdigest(),method_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),accepted_bank_reduction=False),indent=2)+'\n');print('SINGLE_NATIVE_ESD_GEOMETRY_PRESERVED')
