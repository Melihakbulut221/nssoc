# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Native one-PCell resistance diagnostics; never an accepted bank reduction."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import time

ROOT = Path.cwd()
B = ROOT / 'hw/soc/out/pcie-magic-bank-conservation-v1-20261004'
FIXTURE = Path('/dev/shm/nssoc-rc-single-esd-fixtures')
RT = Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib')
TECH = Path('/dev/shm/nssoc-magic-pad-stack-tech-v1')
record = json.loads((FIXTURE / 'result.json').read_text())


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


results = {}
for name, case in record['cases'].items():
    output = Path('/dev/shm/nssoc-rc-single-' + name + '-01')
    output.mkdir()
    gds = FIXTURE / (name + '.gds')
    assert pin(gds)['sha256'] == case['gds_sha256']
    lines = [f'puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',
             f'cd {{{output}}}', 'drc off', 'scalegrid 1 1', 'gds readonly true',
             f'gds read {{{gds}}}', f'load {case["top"]}',
             'flatten single_flat', 'load single_flat', 'select top cell']
    for ordinal, (port, boxes) in enumerate(case['ports'].items(), 1):
        for box in boxes:
            layer = {8: 'metal1', 10: 'metal2'}[box['layer']]
            lines += ['box values ' + ' '.join(f'{v}um' for v in box['box']),
                      f'label {port} center {layer}']
        lines += [f'port {port} make {ordinal}', f'port {port} class inout',
                  f'port {port} use signal']
    lines += ['save single_flat', 'extract unique all', 'extract style ngspice()',
              'extract all', 'ext2spice lvs', 'ext2spice merge none',
              'ext2spice global off', 'ext2spice cthresh 0', 'ext2spice rthresh 0',
              'ext2spice extresist off', 'ext2spice -o baseline.spice',
              'puts NSSOC_SINGLE_BASELINE_COMPLETE', 'ext2sim labels on', 'ext2sim',
              'extresist threshold 0', 'extresist tolerance 0.000001',
              'extresist simplify off', 'extresist all', 'ext2spice extresist on',
              'ext2spice -o unreduced.spice', 'puts NSSOC_SINGLE_UNREDUCED_COMPLETE',
              'quit -noprompt']
    script = output / 'native.tcl'
    script.write_text('\n'.join(lines) + '\n')
    inputs = {str(p): pin(p) for p in [Path(__file__), FIXTURE / 'result.json',
              gds, script, RT / 'magic/tcl/tclmagic.so', *TECH.iterdir()] if p.is_file()}
    command = ['/usr/bin/tclsh8.6', str(RT / 'magic/tcl/magic.tcl'), '-dnull',
               '-noconsole', '-rcfile', str(TECH / 'ihp-sg13g2.magicrc'), str(script)]
    env = {k: v for k, v in os.environ.items()
           if k not in ('GH_TOKEN', 'GITHUB_TOKEN', 'PYTHONPATH', 'PYTHONHOME')}
    env['CAD_ROOT'] = str(RT)
    start = time.monotonic()
    with (output / 'native.log').open('w') as log:
        try:
            process = subprocess.run(command, cwd=output, env=env, preexec_fn=limits,
                                     stdout=log, stderr=subprocess.STDOUT,
                                     timeout=60, check=False)
            code = process.returncode
        except subprocess.TimeoutExpired:
            code = None
    assert all(pin(p) == expected for p, expected in inputs.items())
    baseline = (output / 'baseline.spice').read_text()
    device_rows = [line for line in baseline.splitlines() if line.startswith('X')]
    assert len(device_rows) == 1 and case['device']['model'] in device_rows[0]
    result = dict(returncode=code, seconds=time.monotonic() - start,
                  command=command, source_case=case, baseline_device_rows=device_rows,
                  memory_limit_bytes=2 * 1024**3, core_limit_bytes=0, inputs=inputs,
                  outputs={p.name: pin(p) for p in output.iterdir() if p.is_file()},
                  accepted_bank_reduction=False, unreduced_resistance_qualified=False)
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    results[name] = result
    print(name, code, result['seconds'], device_rows, flush=True)
(B / 'single-esd-results.json').write_text(json.dumps(results, indent=2) + '\n')
