# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,os,resource,subprocess,time,hashlib,shutil
R=Path.cwd();O=Path('/dev/shm/nssoc-bank-conservation-reload-probe');O.mkdir();P=Path('/dev/shm/nssoc-padded-clocked-pad-stack-01');RT=Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib');T=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1');TOP='nssoc_padded_clocked_pad_stack_flat'
shutil.copyfile(P/(TOP+'.mag'),O/(TOP+'.mag'));script=O/'native.tcl';script.write_text(f'''puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {{{O}}}
drc off
load {TOP}
select top cell
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {{{O/'baseline.spice'}}}
puts NSSOC_RELOAD_NO_CIFOUT_COMPLETE
quit -noprompt
''')
cmd=['/usr/bin/tclsh8.6',str(RT/'magic/tcl/magic.tcl'),'-dnull','-noconsole','-rcfile',str(T/'ihp-sg13g2.magicrc'),str(script)];env=dict(os.environ,CAD_ROOT=str(RT))
for n in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME'):env.pop(n,None)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
start=time.monotonic()
with (O/'native.log').open('w') as f:p=subprocess.run(cmd,cwd=O,env=env,preexec_fn=limits,stdout=f,stderr=subprocess.STDOUT,timeout=60,check=False)
r=dict(returncode=p.returncode,seconds=time.monotonic()-start,command=cmd,source_mag_sha256=hashlib.sha256((P/(TOP+'.mag')).read_bytes()).hexdigest(),core_limit_bytes=0,memory_limit_bytes=2*1024**3,outputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in O.iterdir() if p.is_file()});(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(p.returncode,r['seconds'])
