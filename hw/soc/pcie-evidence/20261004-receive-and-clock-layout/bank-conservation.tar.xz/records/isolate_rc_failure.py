# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Separate actual native device fixtures; not a reduced accepted bank."""
from pathlib import Path
import os,json,resource,subprocess,time,hashlib,sys
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-bank-conservation-v1-20261004';RT=Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib');T=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1');sys.path.insert(0,str(R/'scripts'));import check_magic_hbt_multiplicity_v3 as h
from collections import Counter
results={}
for name,previous in [('hbt24_finite_tap',Path('/dev/shm/nssoc-magic-esd-hbt-regression-final')),('esd32',Path('/dev/shm/nssoc-magic-esd-native-final05/nominal'))]:
 O=Path('/dev/shm/nssoc-rc-isolation-'+name);O.mkdir();original=previous/'native.tcl'
 text=original.read_text().replace(str(previous),str(O)).replace('ext2spice cthresh infinite','ext2spice cthresh 0')
 suffix='''puts NSSOC_ISOLATED_BASELINE_COMPLETE
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice extresist on
ext2spice -o rc.spice
puts NSSOC_ISOLATED_UNREDUCED_COMPLETE
quit -noprompt
'''
 assert text.count('quit -noprompt')==1;text=text.replace('quit -noprompt',suffix)
 script=O/'native.tcl';script.write_text(text);cmd=['/usr/bin/tclsh8.6',str(RT/'magic/tcl/magic.tcl'),'-dnull','-noconsole','-rcfile',str(T/'ihp-sg13g2.magicrc'),str(script)]
 env=dict(os.environ,CAD_ROOT=str(RT))
 for key in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME'):env.pop(key,None)
 def limits():
  resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 start=time.monotonic()
 with (O/'native.log').open('w') as log:
  try:proc=subprocess.run(cmd,cwd=O,env=env,preexec_fn=limits,stdout=log,stderr=subprocess.STDOUT,timeout=60,check=False);code=proc.returncode
  except subprocess.TimeoutExpired:code=None
 baseline=O/('hbt.spice' if name.startswith('hbt') else 'esd.spice');models=Counter()
 if baseline.exists():
  for row in (line.split() for line in h.spice_lines(baseline.read_text())):
   if row[0][0] in 'XQRMDC' and any('='in t for t in row):i=next(i for i,t in enumerate(row) if '='in t);models[row[i-1]]+=1
 r=dict(returncode=code,seconds=time.monotonic()-start,baseline_models=dict(models),original_script=h.pin(original),method=h.pin(__file__),command=cmd,core_limit_bytes=0,memory_limit_bytes=2*1024**3,inputs={str(p):h.pin(p) for p in [RT/'magic/tcl/tclmagic.so',*T.iterdir()] if p.is_file()},outputs={p.name:h.pin(p) for p in O.iterdir() if p.is_file()},qualified_pex=False)
 (O/'result.json').write_text(json.dumps(r,indent=2)+'\n');results[name]=r;print(name,code,r['seconds'],models,flush=True)
(B/'isolated-rc-results.json').write_text(json.dumps(results,indent=2)+'\n')
