# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Seal bounded geometry/C-accounting evidence and all observed RC failures."""
from pathlib import Path
import hashlib
import json
import tarfile
from datetime import datetime, timezone

ROOT = Path.cwd()
B = ROOT / 'hw/soc/out/pcie-magic-bank-conservation-v1-20261004'
P = Path('/dev/shm/nssoc-padded-clocked-pad-stack-01')
N = Path('/dev/shm/nssoc-bank-conservation-v1-02')
TOP = 'nssoc_padded_clocked_pad_stack_flat'


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def read(name):
    return json.loads((B / name).read_text())


sources = ['scripts/check_magic_bank_capacitance_v1.py',
           'sw/tests/test_magic_bank_capacitance_v1.py']
base = read('baseline-capacitance-final.json')
replay = read('replayed-capacitance-final.json')
geometry = read('geometry-review.json')
for record in (base, replay):
    assert record['nodes'] == 210 and len(record['ports']) == 56
    assert sum(record['device_models'].values()) == 351
    assert record['matrix_entries_compared'] == 44100
    assert not record['unreduced_resistance_qualified']
    assert record['requires_independent_device_graph_audit']
    for path, digest in record['inputs'].items():
        assert pin(path)['sha256'] == digest
assert base['source_intrinsic_af'] == replay['source_intrinsic_af']
assert base['source_edges_af'] == replay['source_edges_af']
assert read('bank-review.json')['full_device_graph_equal']

files = {}


def add(name, path):
    path = Path(path)
    assert path.is_file() and name not in files
    files[name] = path


for relative in sources:
    add('methods/' + relative, ROOT / relative)
for path in sorted(B.glob('*')):
    if path.is_file() and path.suffix in ('.py', '.json', '.log') and path.name not in ('validation.json',):
        add('records/' + path.name, path)
for path in sorted((B / 'backtrace').glob('*')):
    if path.is_file():
        add('diagnostic-backtrace/' + path.name, path)
for relative in ('check_magic_coupled_cap_v2.py', 'check_magic_intrinsic_cap_retirement.py',
                 'check_magic_hbt_multiplicity_v3.py', 'compare_magic_device_graph_v1.py'):
    add('methods/scripts/' + relative, ROOT / 'scripts' / relative)
layout = Path('/dev/shm/nssoc-padded-clocked-layout-01')
for filename in ('nssoc_pcie_padded_clocked_bank4_v1.gds', 'schematic.cir'):
    add('source-bank/' + filename, layout / filename)
for filename in (TOP + '.mag', TOP + '.ext', 'capacitance.spice', 'extract.tcl', 'native.log', 'result.json'):
    add('original-bank/' + filename, P / filename)
for directory in [Path('/dev/shm/nssoc-bank-conservation-v1-01'), N,
                  Path('/dev/shm/nssoc-bank-conservation-reload-probe'),
                  Path('/dev/shm/nssoc-bank-factor-no_export_no_unique'),
                  Path('/dev/shm/nssoc-bank-factor-export_and_unique'),
                  Path('/dev/shm/nssoc-rc-isolation-hbt24_finite_tap'),
                  Path('/dev/shm/nssoc-rc-isolation-esd32'),
                  Path('/dev/shm/nssoc-rc-single-esd-fixtures'),
                  Path('/dev/shm/nssoc-rc-single-pnp-01'), Path('/dev/shm/nssoc-rc-single-npn-01')]:
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix in ('.json', '.tcl', '.log', '.ext', '.spice', '.sim', '.nodes', '.al'):
            add('native/' + directory.name + '/' + path.name, path)
for name in ('pnp', 'npn'):
    for path in (Path('/dev/shm/nssoc-esd-backtrace-01') / name).iterdir():
        if path.is_file() and path.suffix in ('.log', '.tcl', '.txt'):
            add('native/backtrace/' + name + '/' + path.name, path)
for name in ('pnp.gds', 'npn.gds'):
    add('single-esd-source/' + name, Path('/dev/shm/nssoc-rc-single-esd-fixtures') / name)
add('geometry/imported-bank.gds', Path('/dev/shm/nssoc-bank-conservation-v1-01/imported-bank.gds'))
for name, path in [('missing_pad_via', Path('/dev/shm/nssoc-bank-conservation-v1-01/missing_pad_via.gds')),
                   ('open_L0_TX_OUTP', Path('/dev/shm/nssoc-padded-clocked-checks-02/open_L0_TX_OUTP/wrong.gds')),
                   ('return_avss_short', Path('/dev/shm/nssoc-padded-clocked-checks-02/return_avss_short/wrong.gds'))]:
    add('geometry-negatives/' + name + '.gds', path)
for path in Path('/dev/shm/nssoc-magic-pad-stack-tech-v1').iterdir():
    if path.is_file():
        add('technology/' + path.name, path)
add('UPSTREAM-NOTICES.txt', ROOT / 'hw/soc/out/pcie-magic-pad-stack-v1-20261004/UPSTREAM-NOTICES.txt')
members = {name: dict(source=str(path), **pin(path)) for name, path in files.items()}
capsule = B / 'bank-conservation-native.tar.xz'
with tarfile.open(capsule, 'x:xz', preset=6) as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(capsule, 'r:xz') as archive:
    assert len(archive.getmembers()) == len(members)
    for member in archive.getmembers():
        data = archive.extractfile(member).read()
        assert len(data) == members[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == members[member.name]['sha256']
assert all(pin(path) == {k: members[name][k] for k in ('bytes', 'sha256')} for name, path in files.items())

result = dict(
    schema=1, recorded_utc=datetime.now(timezone.utc).isoformat(),
    status='PASS_BASELINE_GRAPH_WIRE_AND_CAPACITANCE_ACCOUNTING__FAIL_NATIVE_RESISTANCE_EXTRACTION',
    source_pins={relative: pin(ROOT / relative) for relative in sources},
    capsule=dict(path=str(capsule), **pin(capsule), members=len(members)),
    capsule_inventory=members,
    baseline=dict(devices=351, ports=56, graph_nodes=1541, original_and_reloaded_graph_equal=True,
                  nodes=210, capacitance_edges=len(base['source_edges_af']), matrix_entries=44100,
                  floating_capacitor_annotations=len(base['native_floating_capacitor_annotations']),
                  native_reference='ESD_RETURN', reference_distinct_from_avss=True,
                  finite_ptaps=108, finite_welltaps=1, original_and_reloaded_capacitance_exactly_equal=True),
    geometry=dict(original_gds=pin(layout / 'nssoc_pcie_padded_clocked_bank4_v1.gds'),
                  seven_raw_material_metal_layers_exact=True,
                  seven_cifout_metal_and_six_via_cut_layers_exact=True,
                  native_via_tile_footprints_are_not_literal_cut_masks=True,
                  cifout_base_contact_missing_area_um2=119.168,
                  base_contact_reconstruction_qualified=False,
                  actual_negative_controls=['open_L0_TX_OUTP', 'return_avss_short', 'missing_pad_via'],
                  negative_scope='Actual GDS mask comparison; no new extresist acceptance on mutated banks.'),
    native_case_states=[
        dict(case='reload_no_export_no_unique', devices=351, baseline='PASS', resistance='NOT_RUN'),
        dict(case='reload_export_no_unique', devices=270, baseline='FAIL_81_RESISTORS_MISSING', resistance='SIGSEGV_-11'),
        dict(case='reload_no_export_unique', devices=351, baseline='PASS', resistance='NOT_RUN'),
        dict(case='reload_export_unique', devices=351, baseline='PASS', resistance='SIGSEGV_-11'),
        dict(case='isolated_24_hbt_plus_finite_tap', devices=25, baseline='PASS', resistance='PROCESS_0_WITH_MISSING_TERMINALS_REJECTED'),
        dict(case='isolated_32_esd', devices=32, baseline='PASS', resistance='SIGSEGV_-11'),
        dict(case='single_native_pnp', devices=1, ports=3, baseline='PASS', resistance='SIGSEGV_-11'),
        dict(case='single_native_npn', devices=1, ports=3, baseline='PASS', resistance='SIGSEGV_-11')],
    backtrace=dict(scope='Diagnostic LD_PRELOAD signal handler only; original extraction library unchanged; no accepted result.',
                   actual_both_polarities='ResFixUpConnections, ResRex.c:1363, invalid substrate-node rn_name read; address0xb9.',
                   hypothesis='One-SD subcircuit allocates three terminal slots, but fixed substrate slot3 is read. Private confirmation/repair pending.'),
    validation=dict(focused_and_adjacent_tests=59, focused_tests=28, ruff='PASS',
                    raw_reviewer_original_and_reloaded='PASS',
                    pytest_command='PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm .venv/bin/python -m pytest sw/tests/test_magic_bank_capacitance_v1.py sw/tests/test_magic_coupled_cap_v2.py -q -p no:cacheprovider',
                    reviewer_command='python scripts/check_magic_bank_capacitance_v1.py --ext <captured-bank.ext> --spice <captured-baseline.spice> --out <fresh-review.json>',
                    native_commands='Exact native.tcl, launcher command, technology/runtime hashes and per-case output identities are retained in native records.'),
    limits=dict(memory_per_native_child_bytes=2*1024**3, core_limit_zero_after_initial_preserved_failure=True,
                first_failure_core_search_found_none=True),
    limitations=['Intrinsic graph and metal connectivity are not distributed resistance acceptance.',
                 'Original substrate/body, ESD devices, all modeled devices and capacitance remain present.',
                 'No global capacitance scale, geometry fitting, node union, device deletion, RC simplification or lumped fallback.',
                 'The FLOATING annotations are retained verbatim, not erased or treated as capacitance loss.',
                 'Geometry source GDS and imported material paint are separated from CIF output reconstruction.',
                 'Runtime ELF and AppImage excluded from capsule; exact retrieval/build provenance remains in frozen ancestor captures.',
                 'Cap reader deliberately requires the separate complete device-graph audit; it alone is not an electrical topology proof.',
                 'Both initial invalid270-device baseline and corrected351-device crashing baseline are retained.',
                 'Historical pre-final reader records are preserved; *-capacitance-final.json bind the sealed reader.'],
    accepted_unreduced_resistance=False, full_bank_pex_qualified=False, rf_qualified=False,
    mainchip_signoff=False, esd_stress_qualified=False)
(B / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(validation=pin(B / 'validation.json'), capsule=pin(capsule), members=len(members), sources=result['source_pins']), indent=2))
