#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,io,json,pathlib,tarfile
ROOT=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent
L=pathlib.Path('/dev/shm/nssoc-div4-v5-layout-02');N=pathlib.Path('/dev/shm/nssoc-div4-v5-checks-02')
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((N/'result.json').read_text());v=json.loads((B/'source-validation.json').read_text());assert all(sha(p)==h for p,h in v['sources'].items())
assert sha(N/'result.json')==v['native']['result_sha256'];assert all(sha(p)==h for p,h in r['inputs'].items());assert all(sha(N/p)==h for p,h in r['outputs'].items())
(B/'NOTICES.txt').write_text('Project Python sources and tests: Copyright2026 Hasan Melih Akbulut, Apache-2.0. Generated native physical circuit/GDS/LEF design artifacts: CERN-OHL-W-2.0. Native logs and measurement/audit records: CC-BY-4.0. Included unmodified IHP PDK/pycell/deck source text retains original copyright and license notices, with Apache-2.0 license text supplied. No compiled tools or model binaries redistributed. Scope: actual VCOv3/div4v5 composite topology/DRC/LEF only, not extracted performance or mainchip/PLL/CDR/PCIe/manufacturing acceptance. First four-marker tiny-MIM TopMetal1 route failure retained; source circuit and native PCells unchanged by corrected parent strap.\n')
members={}
for folder,label in [(L,'layout'),(N,'native'),(pathlib.Path('/dev/shm/nssoc-div4-v5-layout-01'),'first-failure/layout'),(pathlib.Path('/dev/shm/nssoc-div4-v5-checks-01'),'first-failure/native')]:
 for p in folder.rglob('*'):
  if p.is_file():members[label+'/'+str(p.relative_to(folder))]=p
for p in B.rglob('*'):
 if p.is_file() and p.name not in ('validation.json','package.log') and p.suffix not in ('.xz',):members['review/'+str(p.relative_to(B))]=p
for name in v['sources']:members['methods/'+name]=ROOT/name
inputmap={}
for i,(path,h) in enumerate(sorted(r['inputs'].items())):
 p=pathlib.Path(path)
 if p.suffix in ('.py','.json','.spice','.cir','.lib','.va','.lvs','.drc','.lyp','.lef','.txt') and p.stat().st_size<2*1024**2:
  name=f'inputs/{i:03d}-{p.name}';members[name]=p;inputmap[path]=dict(member=name,sha256=h)
 else:inputmap[path]=dict(sha256=h,redistributed=False)
(B/'input-map.json').write_text(json.dumps(inputmap,indent=2)+'\n');members['review/input-map.json']=B/'input-map.json'
for name in ('Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0'):
 p=ROOT/'LICENSES'/f'{name}.txt';members['LICENSES/'+p.name]=p
inventory={name:dict(bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(members.items())}
cap=B/'clock-div4-v5-native-physical.tar.xz';assert not cap.exists()
with tarfile.open(cap,'w:xz',preset=3) as t:
 for name,p in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
  with p.open('rb') as f:t.addfile(info,f)
 data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(cap) as t:
 assert len(t.getmembers())==len(inventory)+1
 for name,pin in inventory.items():
  with t.extractfile(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==pin['sha256']
result=dict(status='PASS_DIV4_V5_PHYSICAL_CAPSULE_ROUNDTRIP',source_receipt=dict(path=str(B/'source-validation.json'),sha256=sha(B/'source-validation.json')),sources=v['sources'],capsule=dict(path=str(cap),bytes=cap.stat().st_size,sha256=sha(cap),members=len(inventory)+1,local_roundtrip=True),native=v['native'],geometry=v['geometry_audit'],scope=v['scope'],no_independent_peer_claim=True)
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
