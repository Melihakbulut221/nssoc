import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v5-layout-02/nssoc_clock_div4_v5_layout.gds')
c=l.cell('nssoc_clock_div4_v5_layout')
region=pya.Region(c.shapes(l.layer(30,0)))
region-=pya.Region(pya.DBox(3817.36,14.549999999999999,3817.56,15.15).to_itype(l.dbu))
c.shapes(l.layer(30,0)).clear()
c.shapes(l.layer(30,0)).insert(region)
l.write('/dev/shm/nssoc-div4-v5-checks-02/feedback_open/wrong.gds')
