import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v5-layout-02/nssoc_clock_div4_v5_layout.gds')
c=l.cell('nssoc_clock_div4_v5_layout')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-div4-v5-checks-02/offgrid/wrong.gds')
