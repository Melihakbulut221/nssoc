import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v5-layout-02/nssoc_clock_div4_v5_layout.gds')
c=l.cell('nssoc_clock_div4_v5_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(0.5,136.03,1.5,146.03))
l.write('/dev/shm/nssoc-div4-v5-checks-02/rails_short/wrong.gds')
