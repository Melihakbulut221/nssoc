import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v5-layout-02/nssoc_clock_div4_v5_layout.gds')
c=l.cell('nssoc_clock_div4_v5_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(4798.5,106.03,4799.5,116.03))
l.write('/dev/shm/nssoc-div4-v5-checks-02/output_short/wrong.gds')
