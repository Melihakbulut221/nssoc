import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v5-layout-02/nssoc_clock_div4_v5_layout.gds')
c=l.cell('nssoc_clock_div4_v5_layout')
region=pya.Region(c.shapes(l.layer(67,0)))
region-=pya.Region(pya.DBox(3,124.03,4,128.03).to_itype(l.dbu))
c.shapes(l.layer(67,0)).clear()
c.shapes(l.layer(67,0)).insert(region)
l.write('/dev/shm/nssoc-div4-v5-checks-02/control_open/wrong.gds')
