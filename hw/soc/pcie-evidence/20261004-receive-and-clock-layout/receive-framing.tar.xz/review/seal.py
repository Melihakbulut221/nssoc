#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Seal current receive tests and retain failed initial mutation campaign."""
import hashlib,io,json,pathlib,sys,tarfile,xml.etree.ElementTree as ET
R=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R/'sw/tests'));import test_pcie_gen3_receive as tests

def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
def xml(p):
 cs=list(ET.parse(p).getroot().iter('testcase'))
 return dict(passed=sum(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cs),failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cs),skipped=sum(c.find('skipped') is not None for c in cs))
files=['hw/soc/rtl/pcie/soc_pcie_gen3_framer_rx.v','hw/soc/tb/cocotb/test_soc_pcie_gen3_framer_rx.py','hw/soc/tb/cocotb/Makefile.soc_pcie_gen3_framer_rx','scripts/check_pcie_gen3_receive.py','sw/tests/test_pcie_gen3_receive.py']
sources={f:pin(f) for f in files};members={'sources/'+f:R/f for f in files};captures=[];inputs={}
for name in ['nssoc-gen3-receive-rtl-final','nssoc-gen3-receive-maximum-rtl-final']:
 p=pathlib.Path('/dev/shm')/name;r=json.loads((p/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_GEN3_RECEIVE_FRAMING'
 assert r['tests']==xml(p/'results.xml')==dict(passed=6,failed=0,skipped=0)
 for f,v in r['inputs'].items():assert pin(f)==v;inputs[f]=v
 for f,v in r['runtime'].items():assert pin(f)==v
 for f,v in r['outputs'].items():assert pin(p/f)==v;members['captures/'+name+'/'+f]=p/f
 members['captures/'+name+'/result.json']=p/'result.json'
 captures.append(dict(name=name,receipt=pin(p/'result.json'),capacity=r['max_encoded_bytes'],tests=r['tests']))
mutations=[];M=pathlib.Path('/dev/shm/nssoc-gen3-receive-faults-final')
for i,(name,old,new) in enumerate(tests.FAULTS):
 p=M/f'test_actual_receive_fault_reje{i}';r=json.loads((p/'capture/result.json').read_text());assert r['status']=='FAIL'
 assert (p/'soc_pcie_gen3_framer_rx.v').read_text()==tests.RTL.read_text().replace(old,new)
 assert xml(p/'capture/results.xml')['failed']>0 and 'AssertionError' in (p/'capture/simulation.log').read_text()
 for f,v in r['inputs'].items():assert pin(f)==v
 for f,v in r['outputs'].items():assert pin(p/'capture'/f)==v
 for f in p.rglob('*'):
  if f.is_file() and 'sim' not in f.relative_to(p).parts:members['faults/'+name+'/'+str(f.relative_to(p))]=f
 mutations.append(dict(name=name,old=old,new=new,receipt=pin(p/'capture/result.json'),xml=xml(p/'capture/results.xml')))
log=pathlib.Path('/dev/shm/nssoc-gen3-receive-faults-final.log');assert '17 passed' in log.read_text();members['faults/tests-final.log']=log
# The initial disabled-CRC mutant really passed; it is never relabeled rejected.
old=pathlib.Path('/dev/shm/nssoc-gen3-receive-faults-01');historical=[]
for p in sorted(old.glob('test_actual_receive_fault_reje*/capture/result.json')):
 r=json.loads(p.read_text());folder=p.parent.parent
 for f,v in r['outputs'].items():assert pin(p.parent/f)==v
 for f in folder.rglob('*'):
  if f.is_file() and 'sim' not in f.relative_to(folder).parts:members['initial-failed-fault-campaign/'+folder.name+'/'+str(f.relative_to(folder))]=f
 historical.append(dict(name=folder.name,status=r['status'],tests=xml(p.parent/'results.xml'),receipt=pin(p)))
assert historical[0]['status']=='PASS_PORT_ONLY_GEN3_RECEIVE_FRAMING'
for f in (B/'initial-method').rglob('*'):
 if f.is_file():members['initial-method/'+str(f.relative_to(B/'initial-method'))]=f
for f in inputs:
 p=pathlib.Path(f);assert p.is_relative_to(R);members['sources/'+str(p.relative_to(R))]=p
for license in ['Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0']:members['LICENSES/'+license+'.txt']=R/'LICENSES'/f'{license}.txt'
(B/'NOTICES.txt').write_text('Project source Copyright 2026 Hasan Melih Akbulut. RTL CERN-OHL-W-2.0; scripts/tests Apache-2.0; generated evidence CC-BY-4.0. Active x4 Data Stream framing only. No PHY/training/LTSSM/native mapping/timing qualification. Original escaped CRC-check mutant and nonunique test-anchor failure are retained; only final executed faults count as rejected. No specification excerpts redistributed.\n')
for f in ['seal.py','NOTICES.txt']:members['review/'+f]=B/f
inventory={name:pin(p) for name,p in sorted(members.items())}
cap=B/'receive-framing-rtl-controls.tar.xz';assert not cap.exists()
with tarfile.open(cap,'w:xz',preset=3) as t:
 for name,p in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
  with p.open('rb') as f:t.addfile(info,f)
 data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(cap) as t:
 assert set(t.getnames())==set(inventory)|{'inventory.json'}
 for name,v in inventory.items():
  assert t.getmember(name).size==v['bytes']
  with t.extractfile(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==v['sha256']
result=dict(status='PASS_FROZEN_GEN3_RECEIVE_FRAMING_RTL_AND_EXECUTED_FAULTS',sources=sources,capsule=dict(path=str(cap),**pin(cap),members=len(inventory)+1,all_members_roundtrip_verified=True),captures=captures,rtl_port_cases=12,actual_hdl_faults=mutations,focused_tests=dict(passed=17,hdl_faults=15,cli_bounds_controls=2,log=pin(log)),initial_failed_campaign=dict(test_summary='2 failed,15 passed: CRC check bypass escaped single-bit-only oracle; second failure was a nonunique mutation anchor with no HDL execution',source_archive='initial-method',actual_results=historical,prior_failure_superseded=False),contract=dict(top='soc_pcie_gen3_framer_rx',input='Already deskewed/descrambled512-bit x4 payload plus each lane2-bit header and ready/valid/block_error',external_control='stream_start from external SDS/training owner; explicit abort for lost/truncated stream; no elapsed stall timeout',output='Complete byte packet with SOP/EOP/DLLP flag; TLP sequence restored with reserved zero upper nibble',tokens='STP CRC4/even parity/length; exact SDP/EDB/IDL; exact EDS only final DW',quarantine='TLP waits for validated immediate successor; exact EDB discards and pulses packet_nullified with sequence; malformed EDB or successor halts with no packet output',successor='Valid immediate STP/SDP/IDL/EDS retained during held prior packet then processed exactly once',header_shape='Normal3DW/4DW optional payload/digest header length agrees with STP length; no Prefix/PMUX',capacity=[150,4118],maximum_digest_exclusion='4122 encoded bytes for4096payload+4DW+digest do not fit4118',metadata='sequence meaningful for non-DLLP packet_good/nullified pulses; DLLP byte flag stable through held output',recovery='Framing error halts stream until fresh external start/reset/flush; exact EDS signals end and delegates OS handling'),primary_source=dict(url='https://studylib.net/doc/28447088/pcie-v4.0',sections='PCI Express Base4.0v1.0 §§4.2.2.1 and4.2.2.3.1/3.3, Figs4-12/13',scope='Primary specification excerpts inspected; not redistributed'),scope=dict(native_mapping=False,independent_rx_oracle=True,tx_helpers_imported_by_oracle=False,formal=False,lcrc_crc16_validation=False,gearbox_descrambling_alignment_deskew=False,os_skp_training_ltssm=False,pma_line_rate_queue=False,mainchip_integration=False,physical_timing_acceptance=False),peer_review_pending=True,source_unchanged_after_capture=all(pin(p)==v for p,v in sources.items()))
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'capsule':result['capsule'],'validation':pin(B/'validation.json')},indent=2))
