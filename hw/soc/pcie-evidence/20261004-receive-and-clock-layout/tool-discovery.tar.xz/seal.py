from pathlib import Path
import hashlib,json,tarfile,zipfile,xml.etree.ElementTree as E
b=Path('hw/soc/out/pcie-gen3-tool-discovery-20261004'); zpath=Path('/dev/shm/nssoc-framer-ci-37203956623.zip');host=b/'hosted';host.mkdir(exist_ok=True)
def pin(p):
 d=p.read_bytes();return {'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 inventory={i.filename:{'bytes':i.file_size,'sha256':hashlib.sha256(z.read(i)).hexdigest()} for i in z.infolist()}
 for i in z.infolist():
  if i.filename.endswith('launch.log'):
   p=host/i.filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(i))
(b/'hosted-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
records=[];root=Path('/dev/shm/nssoc-framer-path-mutations-final')
for p in sorted(root.glob('*/capture/result.json')):
 if p.parent.parent.is_symlink():continue
 r=json.loads(p.read_text());cases=list(E.parse(p.parent/'results.xml').getroot().iter('testcase'));assert r['status']=='FAIL' and any(x.find('failure') is not None for x in cases)
 assert all('/hw/soc/tools/oss-cad-suite/' not in x for x in r['runtime'])
 records.append({'case':p.parent.parent.name,'result':pin(p),'tests':len(cases),'executed_assertion_failure':True,'runtime':r['runtime']})
assert len(records)==28
sources=[Path('sw/tests/test_pcie_gen3_'+n+'.py') for n in ('framer','receive')]
prior=Path('hw/soc/pcie-evidence/20261004-receive-and-clock-layout/prior-tests')
files=[(str(p),p) for p in sources]+[(str(p),p) for p in prior.glob('*original.py.txt')]
files += [(str(p.relative_to(b)),p) for p in b.rglob('*') if p.is_file() and p.suffix!='.xz' and p.name!='validation.json']
files += [('local/'+str(p.relative_to(root)),p) for p in root.rglob('*') if p.is_file() and p.name in ('result.json','results.xml','simulation.log','launch.log')]
a=b/'tool-discovery-controls.tar.xz'
with tarfile.open(a,'w:xz') as t:
 for n,p in files:t.add(p,arcname=n,recursive=False)
with tarfile.open(a) as t:
 assert len(t.getmembers())==len(files)
 for (n,p),i in zip(files,t.getmembers()):assert i.name==n and t.extractfile(i).read()==p.read_bytes()
r={'status':'PASS_PORTABLE_ACTUAL_MUTATION_REPLAY','hosted_failure':{'run_id':37203956623,'artifact_id':11304241074,'zip':pin(zpath),'crc_all_members_pass':True,'members':len(inventory),'cause':'Hardcoded local checkout Icarus path absent on hosted runner; native pinning failed before HDL launch.','launch_logs_retained':len(list(host.rglob('launch.log')))},'source_pins':{str(p):pin(p) for p in sources},'prior_source_pins':{str(p):pin(p) for p in prior.glob('*original.py.txt')},'local_test_log':pin(b/'tests.log'),'tests':{'passed':32,'failed':0,'skipped':0,'actual_hdl_faults':28,'capacity_cli_controls':4},'actual_path_runtime':'/home/hasanmelih/.local/bin; Icarus12 wrappers outside checkout; OSS CAD path absent from test PATH','local_records':records,'capsule':{'path':str(a),**pin(a),'members':len(files),'all_member_bytes_rechecked':True},'scope':'Test-only runtime discovery; frozen RTL, native checker producers, old captures and thresholds unchanged.'}
p=b/'validation.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'receipt':pin(p),'capsule':pin(a),'sources':r['source_pins']},indent=2))
