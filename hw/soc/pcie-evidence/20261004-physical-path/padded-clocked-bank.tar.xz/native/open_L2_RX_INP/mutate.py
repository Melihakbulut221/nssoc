import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')
c=l.cell('nssoc_pcie_padded_clocked_bank4_v1')
region=pya.Region(c.shapes(l.layer(126,0)))
region-=pya.Region(pya.DBox(974.9,348.0,975.1,352.0).to_itype(l.dbu))
c.shapes(l.layer(126,0)).clear()
c.shapes(l.layer(126,0)).insert(region)
l.write('/dev/shm/nssoc-padded-clocked-checks-02/open_L2_RX_INP/wrong.gds')
