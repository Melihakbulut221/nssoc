import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')
c=l.cell('nssoc_pcie_padded_clocked_bank4_v1')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-padded-clocked-checks-02/offgrid/wrong.gds')
