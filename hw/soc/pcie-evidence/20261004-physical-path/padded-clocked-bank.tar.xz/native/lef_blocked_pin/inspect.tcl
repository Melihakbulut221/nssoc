read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-padded-clocked-checks-02/lef_blocked_pin/wrong.lef}
set master [[ord::get_db] findMaster nssoc_pcie_padded_clocked_bank4_v1]
if {$master eq "NULL"} {error "Padded padded clocked bank master missing"}
if {[$master getWidth] != 2940000 || [$master getHeight] != 3440000} {error "Padded padded clocked bank outline changed"}
if {[llength [$master getMTerms]] != 56} {error "Analog terminal census changed"}
set term [$master findMTerm L0_TX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 479000 2000 481000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 479000 2940000 481000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_OUTP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 535000 65000 565000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_OUTN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 635000 65000 665000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 451000 2000 453000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 775000 65000 805000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 875000 65000 905000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 636000 2000 638000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_VCM]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 752000 2940000 754000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_QP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 885030 2940000 887030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_QN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 895030 2940000 897030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 955030 2000 957030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1139000 2000 1141000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 1139000 2940000 1141000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_OUTP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1015000 65000 1045000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_OUTN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1115000 65000 1145000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1111000 2000 1113000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1255000 65000 1285000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1355000 65000 1385000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1296000 2000 1298000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_VCM]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 1412000 2940000 1414000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_QP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 1545030 2940000 1547030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_QN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 1555030 2940000 1557030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1615030 2000 1617030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1799000 2000 1801000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 1799000 2940000 1801000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_OUTP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1495000 65000 1525000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_OUTN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1595000 65000 1625000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1771000 2000 1773000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1735000 65000 1765000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1835000 65000 1865000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1956000 2000 1958000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_VCM]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 2072000 2940000 2074000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_QP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 2205030 2940000 2207030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_QN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 2215030 2940000 2217030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2275030 2000 2277030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2459000 2000 2461000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 2459000 2940000 2461000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_OUTP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1975000 65000 2005000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_OUTN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 2075000 65000 2105000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2431000 2000 2433000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_INP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 2215000 65000 2245000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_INN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 2315000 65000 2345000 95000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2616000 2000 2618000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_VCM]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 2732000 2940000 2734000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_QP]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 2865030 2940000 2867030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_QN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 2938000 2875030 2940000 2877030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_IREF]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2935030 2000 2937030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm AVDD1V8]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1488000 3436000 1492000 3440000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm AVDD2V5]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1508000 3436000 1512000 3440000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1528000 3436000 1532000 3440000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1548000 3436000 1552000 3440000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm AVDD2V3]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 2498000 3436000 2502000 3440000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm VCTRL]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 3205030 2000 3207030}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm ESD_VDD]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 2858000 3436000 2862000 3440000}}} {error "Padded padded clocked bank terminal geometry differs"}
set term [$master findMTerm ESD_RETURN]
if {$term eq "NULL"} {error "Padded padded clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Padded padded clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 2888000 3436000 2892000 3440000}}} {error "Padded padded clocked bank terminal geometry differs"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "Padded padded clocked bank blockage layer census changed"}
foreach term [$master getMTerms] {foreach pin [$term getMPins] {foreach pb [$pin getGeometry] {foreach ob [$master getObstructions] {
if {[[$pb getTechLayer] getName] eq [[$ob getTechLayer] getName] && [$pb xMin] < [$ob xMax] && [$ob xMin] < [$pb xMax] && [$pb yMin] < [$ob yMax] && [$ob yMin] < [$pb yMax]} {error "Padded padded clocked bank pin obstruction overlap"}
}}}}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
