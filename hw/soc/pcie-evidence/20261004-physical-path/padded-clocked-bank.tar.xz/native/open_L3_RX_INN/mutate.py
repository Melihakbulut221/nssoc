import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')
c=l.cell('nssoc_pcie_padded_clocked_bank4_v1')
region=pya.Region(c.shapes(l.layer(126,0)))
region-=pya.Region(pya.DBox(2568.9,388.0,2569.1,392.0).to_itype(l.dbu))
c.shapes(l.layer(126,0)).clear()
c.shapes(l.layer(126,0)).insert(region)
l.write('/dev/shm/nssoc-padded-clocked-checks-02/open_L3_RX_INN/wrong.gds')
