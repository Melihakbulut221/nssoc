# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
B=Path('/dev/shm/nssoc-padded-clocked-check-execution-01');B.mkdir();P=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
x=execute([sys.executable,R/'hw/soc/flow/check_pcie_padded_clocked_bank.py','--pdk',P,'--layout','/dev/shm/nssoc-padded-clocked-layout-01','--out','/dev/shm/nssoc-padded-clocked-checks-01'],B,'check');(B/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(x);raise SystemExit(x['returncode'])
