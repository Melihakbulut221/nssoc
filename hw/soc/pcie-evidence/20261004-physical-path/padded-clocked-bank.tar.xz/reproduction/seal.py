# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Rehash and losslessly preserve the bounded native padded bank experiment."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import tarfile

R = Path.cwd()
B = R / 'hw/soc/out/pcie-padded-clocked-bank-20261004'
sys.path.insert(0, str(R / 'hw/soc/flow'))
from check_pcie_padded_clocked_bank import validate_lvs, validate_device_rows, REFERENCE_FAULTS, PHYSICAL_FAULTS
from make_pcie_padded_clocked_bank import PARENTS, PORTS, SERIAL, TOP, reference
from check_pcie_rx_cell import execute


def pin(p):
    p = Path(p)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return dict(bytes=p.stat().st_size, sha256=h.hexdigest())


def read(p):
    return json.loads(Path(p).read_text())


L = Path('/dev/shm/nssoc-padded-clocked-layout-01')
N = Path('/dev/shm/nssoc-padded-clocked-checks-02')
g, n = read(L / 'result.json'), read(N / 'result.json')
assert n['status'] == 'PASS_PADDED_CLOCKED_BANK_MAIN_DRC_DEEP_FLAT_LVS_AND_TWENTY_NINE_NEGATIVE_CONTROLS_ONLY'
assert len(n['steps']) == 33
for name, h in n['outputs'].items():
    assert pin(N / name)['sha256'] == h, name
for name, h in g['output_sha256'].items():
    assert pin(L / name)['sha256'] == h, name
for name, h in n['inputs'].items():
    assert pin(name)['sha256'] == h, name
for name, h in g['input_sha256'].items():
    assert pin(name)['sha256'] == h, name
assert (L / 'schematic.cir').read_text() == reference(Path('/dev/shm/nssoc-clocked-bank-v4-01/schematic.cir').read_text())
for s in n['steps']:
    if 'audit' in s:
        validate_lvs(s, (N / s['name'] / 'extracted.cir').read_text(), s['name'] in ('lvs', 'lvs_flat'))
assert n['steps'][0]['measurement']['category_count'] == 560 and n['steps'][0]['status'] == 'PASS'
assert set(s['name'] for s in n['steps']) == {'drc', 'offgrid', 'lvs', 'lvs_flat', 'lef', 'lef_missing_pin', 'lef_blocked_pin', *REFERENCE_FAULTS, *PHYSICAL_FAULTS}
assert set(n['native_geometry']) == {'lvs', 'lvs_flat'}
for label, row in n['native_geometry'].items():
    assert row['execution']['returncode'] == 0
    assert row['record'] == read(N / label / 'native-geometry.json')
    validate_device_rows(row['record']['device_rows'])
    assert row['record']['exact_seven_layer_obstructions'] is True
assert len(g['serial_connections']) == 16 and {r['net'] for r in g['serial_connections']} == set(SERIAL)
assert set(g['ports']) == set(PORTS)
own = ['hw/soc/flow/make_pcie_padded_clocked_bank.py', 'hw/soc/flow/check_pcie_padded_clocked_bank.py', 'sw/tests/test_pcie_padded_clocked_bank.py']
for label, cmd in [
    ('tests', [R / '.venv/bin/python', '-m', 'pytest', 'sw/tests/test_pcie_padded_clocked_bank.py', 'sw/tests/test_pcie_clocked_bank_v4.py', 'sw/tests/test_pcie_pad_boundary.py', 'sw/tests/test_pcie_padded_bank.py', '-q', '-p', 'no:cacheprovider']),
    ('ruff', [R / 'hw/soc/tools/dev-env/bin/ruff', 'check', *own]),
]:
    ex = execute(cmd, B, label)
    (B / (label + '-execution.json')).write_text(json.dumps(ex, indent=2) + '\n')
    assert ex['returncode'] == 0

sources = {p: pin(R / p) for p in own}
selected = {}
roots = {
    'layout': L, 'native': N,
    'generation_execution': Path('/dev/shm/nssoc-padded-clocked-generation-01'),
    'first_preflight_failure': Path('/dev/shm/nssoc-padded-clocked-check-execution-01'),
    'final_execution': Path('/dev/shm/nssoc-padded-clocked-check-execution-02'),
    'first_native_geometry_bridge': Path('/dev/shm/nssoc-padded-clocked-native-bridge-01'),
}
for label, folder in roots.items():
    assert folder.is_dir(), folder
    for p in sorted(folder.rglob('*')):
        if p.is_file():
            selected[label + '/' + str(p.relative_to(folder))] = p
for p in own:
    selected['methods/' + p] = R / p
for p in sorted(B.iterdir()):
    if p.is_file() and (p.suffix in ('.py', '.log', '.png') or p.name in ('tests-execution.json', 'ruff-execution.json', 'render-execution.json')):
        selected['reproduction/' + p.name] = p
inventory = {name: pin(p) for name, p in selected.items()}
cap = B / 'padded-clocked-bank-native-physical.tar.xz'
with tarfile.open(cap, 'w:xz', preset=6) as t:
    for name, p in selected.items():
        t.add(p, arcname=name, recursive=False)
with tarfile.open(cap) as t:
    assert set(t.getnames()) == set(selected)
    for m in t:
        assert m.isfile()
        data = t.extractfile(m).read()
        assert len(data) == inventory[m.name]['bytes'] and hashlib.sha256(data).hexdigest() == inventory[m.name]['sha256']
r = dict(
    status=n['status'], utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), sources=sources, parents=PARENTS,
    geometry=dict(top=TOP, bbox_um=g['bbox_um'], ports=sorted(g['ports']), serial_connections=g['serial_connections'], literal_parent_body='Frozen v4: 122 HBT, 81 resistors, 6 MIM, 1 PMOS, 108 ptaps, 1 ntap; all conductive/device layers retained by native zero-XOR. Added 16 bondpads and 32 ESD devices.', native_parent_placements=n['native_geometry']['lvs']['record']['placements']),
    native=dict(result=pin(N / 'result.json'), drc_categories=560, drc_violations=0, deep_and_flat='PASS', native_compared_devices=232, native_hbt_records=110, expanded_hbt_instances=122, esd_devices=32, serial_bondpads=16, finite_ptaps=108, native_geometry=n['native_geometry'], steps=[dict(name=s['name'], status=s['status']) for s in n['steps']], negative_controls=29),
    substrate_contract=dict(actual_shared_body='ESD_RETURN', original_finite_taps='108 physical SUB→ESD_RETURN contacts aggregate to A432p/P864u; one finite AVDD2V3→NWELL contact remains A4p/P8u.', actual_esd_named_terminals='diodevdd_2kv: C=ESD_RETURN/B=ESD_VDD/E=serial; diodevss_2kv: C=ESD_VDD/B=ESD_RETURN/E=serial.', distinct_public_nets=['ESD_RETURN', 'SUB', 'AVSS', 'AVDD1V8', 'AVDD2V5', 'AVDD2V3', 'ESD_VDD'], changed_body_impedance=True, additional_actual_esd_substrate_paths=True, isolated_ground=False),
    tests=dict(own_passed=46, output=(B / 'tests.log').read_text(), commands=[read(B / 'tests-execution.json'), read(B / 'ruff-execution.json')]),
    preserved_failure=dict(path='first_preflight_failure/result.json', cause='Initial checker import named reference collided with a later local variable before any native deck ran. Changed only the import alias to physical_reference; old checker and exact error/log/command are retained. No geometry, device, deck or threshold changed.'),
    capsule=dict(path=str(cap.relative_to(R)), **pin(cap), members=len(inventory), inventory=inventory),
    render=dict(path=str((B / 'padded-clocked-bank.png').relative_to(R)), **pin(B / 'padded-clocked-bank.png'), scope='Actual native KLayout-rendered GDS, no illustration.'),
    limitations=[
        'Isolated padded clocked macro connectivity/main-rule screen only; not main-chip integration, ESD stress/safe operating bias, RF, PEX, EM, or manufacturing approval.',
        'ESD_RETURN intentionally exposes the actual shared substrate. Native ESD cells introduce additional body paths; this is neither independent ground isolation nor unchanged finite body impedance.',
        '1.8 V, 2.5 V, 2.3 V and ESD supplies remain separate physical nets. External safe ESD_VDD/ESD_RETURN biases have not been transistor-level characterized here.',
        'No extracted loading, post-layout 8 GHz, fanout/skew/jitter, clock/data phase alignment, PLL/CDR, complete SERDES or PCIe compliance claim.',
        'Frozen component characterization and their existing limited margins remain applicable; geometric copying does not extend operating qualification.',
    ],
    external_material='No vendor source/runtime/model implementation included. Generated native GDS/reports, source/runtime/PDK/deck hashes and exact commands are retained.',
    reproduction=[
        'Pinned PDKc4b8b4e5, Librelane3.0.5 AppImage SHAd6a349ec65be11456e96c4981d35f63ca34d3c85daf79a51e1ccb907bb5d7466, unchanged DRC/LVS5e6d592.',
        'AppImage python hw/soc/flow/make_pcie_padded_clocked_bank.py --pdk <PDK>/ihp-sg13g2 --bank <exact v4 layout> --bank-check <exact v4 checks> --pad <exact pad layout> --pad-check <exact pad checks> --out /dev/shm/nssoc-padded-clocked-<fresh-layout>',
        'PYTHONDONTWRITEBYTECODE=1 .venv/bin/python hw/soc/flow/check_pcie_padded_clocked_bank.py --pdk <PDK>/ihp-sg13g2 --layout <layout> --out /dev/shm/nssoc-padded-clocked-<fresh-checks>',
        'Each native child RLIMIT_AS2147483648 bytes; no elapsed watchdog claimed. Capsule has every final native output plus actual preflight failure; no output selection/downsampling.',
    ], phy_complete=False, pads_integrated=True, main_chip_integrated=False, esd_qualified=False, independent_substrate_ground=False, unchanged_body_impedance=False, clock_fanout_qualified=False, post_layout_8ghz_qualified=False, qualified_pex=False, manufacturing_approval=False,
)
(B / 'validation.json').write_text(json.dumps(r, indent=2) + '\n')
print(json.dumps(dict(validation=pin(B / 'validation.json'), capsule=pin(cap), sources=sources, members=len(inventory), test_output=r['tests']['output']), indent=2))
