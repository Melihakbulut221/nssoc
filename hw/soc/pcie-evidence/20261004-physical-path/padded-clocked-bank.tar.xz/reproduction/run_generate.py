# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
B=Path('/dev/shm/nssoc-padded-clocked-generation-01');B.mkdir();P=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
x=execute([R/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage','python',R/'hw/soc/flow/make_pcie_padded_clocked_bank.py','--pdk',P,'--bank','/dev/shm/nssoc-clocked-bank-v4-01','--bank-check','/dev/shm/nssoc-clocked-bank-v4-checks-02','--pad','/dev/shm/nssoc-pad-boundary-03','--pad-check','/dev/shm/nssoc-pad-check-final','--out','/dev/shm/nssoc-padded-clocked-layout-01'],B,'generate');(B/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(x);raise SystemExit(x['returncode'])
