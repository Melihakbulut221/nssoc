import json,hashlib,tarfile,io,datetime,sys
sys.path.insert(0,'scripts')
from cocotb_results import count_results
from pathlib import Path
repo=Path.cwd(); out=repo/'hw/soc/out/pcie-tx-path-20261004'; dst=repo/'hw/soc/pcie-evidence/20261004-physical-path';members={}
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def pin(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def add_tree(root,label):
 for p in root.rglob('*'):
  if p.is_file() and 'sim' not in p.relative_to(root).parts and '__pycache__' not in p.parts:
   members[label+'/'+str(p.relative_to(root))]=p.read_bytes()
positive=[]
for label in ['rtl','native']:
 root=Path('/dev/shm/nssoc-gen3-tx-path-'+label+'-groupfix');r=json.loads((root/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_PCIE_GEN3_TX_PATH';assert r['tests']=={'passed':3,'failed':0,'skipped':0}
 for path,want in r['inputs'].items():assert pin(Path(path))==want
 for path,want in r['runtime'].items():assert pin(Path(path))==want
 for path,want in r['outputs'].items():assert pin(root/path)==want
 add_tree(root,label);positive.append({'mode':label,'tests':r['tests'],'mapped_cells':r.get('mapped_cells'),'result_sha256':sha(root/'result.json')})
root=Path('/dev/shm/nssoc-tx-path-mutations-groupfix'); runs=[p for p in root.glob('test_real*/run/result.json') if not p.parent.parent.is_symlink()];assert len(runs)==8
negative=[]
for p in runs:
 r=json.loads(p.read_text());assert r['status']=='FAIL';c=count_results([p.parent/'results.xml']);assert c[0]+c[1]==3 and c[1]>0 and c[2]==0;negative.append({'path':str(p.parent.parent.name),'result_sha256':sha(p)})
add_tree(root,'mutations')
add_tree(Path('/dev/shm/nssoc-gen3-tx-path-native-01'),'history/timeout')
add_tree(Path('/dev/shm/nssoc-gen3-tx-path-native-final'),'history/leader-only-cleanup')
add_tree(out/'peer','peer')
for name in ['timeout-runner.py','leader-only-cleanup-runner.py']:
 members['history/'+name]=(out/name).read_bytes()
for name in ['scripts/check_pcie_gen3_tx_path.py','scripts/check_pcie_integrity.py','scripts/check_pcie_integrity_native.py','scripts/cocotb_results.py','hw/soc/rtl/pcie/soc_pcie_gen3_tx_path.v','hw/soc/rtl/pcie/soc_pcie_gen3_gearbox.v','hw/soc/tb/cocotb/Makefile.soc_pcie_gen3_tx_path','hw/soc/tb/cocotb/test_soc_pcie_gen3_tx_path.py','sw/tests/test_pcie_gen3_tx_path.py','.github/workflows/pcie-buffered-soc.yml']:
 members['sources/'+name]=(repo/name).read_bytes()
members['review/seal.py']=Path(__file__).read_bytes()
r={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'PASS_SOURCE_BOUND_TX_PATH_PORT_CONTROLS','positive':positive,'actual_source_mutants_rejected':negative,'inputs_unchanged':True,'runtime_unchanged':True,'raw_outputs_rehashed':True,'scope':'Four-lane128payloadbits with caller-owned per-byte policies, actual scrambling then fixed130/32 gearbox, headers bypassstate. Three port cases at4ns plus8actualmutants and3process-lifetime tests. Independent bit-cell oracle and per-lane serialqueues; saturatedtest494blocks/2006words withoutwordbubbles. No extracted/SDF/timing-check signoff, fullorderedsetpolicy, SKP, LTSSM, PMA, CDC or mainchip integration.','preserved_failures':['First300swatchdog failed although all3childcases finished300.36s; late child output retained, notaccepted.','First cleanup implementation let a SIGTERM-ignoring descendant survive afterleaderexit. Independently reproduced, preserved, fixed and independently retested. FreshexactsourceRTL/native executions follow.'],'members':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())}}
members['manifest.json']=json.dumps(r,indent=2).encode()
p=dst/'tx_path.tar.xz';assert not p.exists()
with tarfile.open(p,'w:xz',preset=3) as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
r['capsule']={'path':str(p.relative_to(repo)),**pin(p)}
(dst/'tx_path.json').write_text(json.dumps(r,indent=2)+'\n');print(r['capsule'])
