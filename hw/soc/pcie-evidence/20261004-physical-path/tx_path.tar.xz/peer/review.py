from pathlib import Path
import hashlib,json,re,sys
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');sys.path.insert(0,str(ROOT/'scripts'))
from cocotb_results import count_results
B=ROOT/'hw/soc/out/pcie-tx-path-20261004/peer'
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
rows=[]
for kind in ('rtl','native'):
 p=Path('/dev/shm/nssoc-gen3-tx-path-'+kind+'-final');r=json.loads((p/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_PCIE_GEN3_TX_PATH'
 for n,h in r['outputs'].items():assert pin(p/n)==h,(kind,n)
 changed=[]
 for n,h in r['inputs'].items():
  if pin(Path(n))!=h:changed.append(n)
 assert all(n.endswith('/scripts/check_pcie_gen3_tx_path.py') for n in changed),changed
 assert count_results([p/'results.xml'])==(3,0,0)
 counts=re.findall(r'blocks=(\d+) words=(\d+) stalls=(\d+)',(p/'simulation.log').read_text());assert len(counts)==3
 if kind=='native':
  cells=json.loads((p/'mapped.json').read_text())['modules'][r['top']]['cells'];assert len(cells)==r['mapped_cells']==16498 and all(c['type'].startswith('sg13g2_') for c in cells.values())
 rows.append({'mode':kind,'result':pin(p/'result.json'),'recorded_inputs':r['inputs'],'exact_outputs_rehashed':len(r['outputs']),'port_xml_counts':[3,0,0],'mapped_cells':r.get('mapped_cells'),'blocks_words_stalls':[list(map(int,c)) for c in counts],'source_changed_after_original_capture':changed})
rec={'status':'RTL_ORACLE_REVIEW_CLEAN_WATCHDOG_FIX_REQUIRED','scope':'Read-only RTL, per-cell serial oracle, Makefile and runner inspection plus raw saved RTL/native outputs. No new HDL native run and no conformance claim.','reviewed_sources':{n:pin(ROOT/n) for n in ['hw/soc/rtl/pcie/soc_pcie_gen3_tx_path.v','hw/soc/rtl/pcie/soc_pcie_gen3_gearbox.v','hw/soc/tb/cocotb/test_soc_pcie_gen3_tx_path.py','hw/soc/tb/cocotb/Makefile.soc_pcie_gen3_tx_path']},'raw_replay':rows,'checked_behaviors':['Accepted-only LFSR state progression and after-block reseeding.','Held scrambled block can transfer to gearbox while being replaced; stalls preserve state/data.','All512 payload bits and64 per-byte policies reach independent lane queues; headers do not advance LFSR.','Flush/reset clear partial bit queues and seed state; saturated continuous word throughput is asserted.','Bitstream conservation and non-vacuous accepted block/word/stall/reseed counts enforced.'],'finding':{'location':'scripts/check_pcie_gen3_tx_path.py execute_command','old_runner_sha256':'27171cd852a46e3ec7c646bfafb555a41df3e0fdb57aaf57e5b8567fdd03578f','description':'If process leader exits after SIGTERM but a child ignores it, leader wait returns and SIGKILL is skipped; late child output survives rejected watchdog.','actual_reproduction':pin(B/'result.json'),'late_output':pin(B/'late-child-output'),'root_notified':True,'source_edited_by_reviewer':False,'default_native_pass_invalidated':False},'limitations':['Fixed-block logical transport with caller policy. No classifier/variableSKP/LTSSM/CDC/PMA or physical timing qualification.','Review does not replace independent normative protocol review or full formal proof.','Root owns narrow watchdog correction and fresh post-fix captures.']}
(B/'independent-review.json').write_text(json.dumps(rec,indent=2)+'\n');print(pin(B/'independent-review.json'))
