import hashlib,io,json,tarfile,datetime
from pathlib import Path
root=Path.cwd();b=root/'hw/soc/out/pcie-tx-path-20261004';d=root/'hw/soc/pcie-evidence/20261004-physical-path'
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
files=[p for p in b.glob('*') if p.is_file() and (p.name.startswith(('sta-','cell-only-','preplacement-')) or p.name=='seal-sta.py')]
files +=[Path('/dev/shm/nssoc-gen3-tx-path-native-groupfix')/x for x in ['result.json','mapped.json','mapped.v']]
members={('experiment/'+p.name if p.parent==b else 'native-source/'+p.name):p.read_bytes() for p in files}
lib=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell')
r={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'FAIL_4NS_CELL_ONLY_SETUP_WITH_PREPLACEMENT_IMPROVEMENT','scope':'Exact native functional netlist, constant nonport loop-index label normalization structurally proven. Unplaced TT cell-only4ns ideal-clock development screen with0.2ns I/O delays,0.1ns inputtransition and0.01pF outputloads. Preplacement repair inserts/sizes real IHP buffers; no propagated clocks, placement, routed parasitics or signoff.','baseline_max_slack_ns':-46.198986,'preplacement_max_slack_ns':-11.278424,'baseline_and_repaired_min_slack_report_ns':0.26,'inserted_buffers':2301,'repaired_nets':1539,'critical_path_after_repair':'advance_i[16] through conditional feedback to payload register','preserved_failures':['Original signed constant wire declaration unsupported by STA frontend.','Initial Tcl omitted technology LEF; no linked design.'],'acceptance':False,'inputs':{str(p):pin(p) for p in [lib/'lib/sg13g2_stdcell_typ_1p20V_25C.lib',lib/'lef/sg13g2_tech.lef',lib/'lef/sg13g2_stdcell.lef',root/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage']},'members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in members.items()}}
members['manifest.json']=json.dumps(r,indent=2).encode();p=d/'tx-path-timing-baseline.tar.xz';assert not p.exists()
with tarfile.open(p,'w:xz',preset=3) as t:
 for n,v in sorted(members.items()):
  i=tarfile.TarInfo(n);i.size=len(v);t.addfile(i,io.BytesIO(v))
r['capsule']={'path':str(p.relative_to(root)),**pin(p)};(d/'tx-path-timing-baseline.json').write_text(json.dumps(r,indent=2)+'\n');print(r['capsule'])
