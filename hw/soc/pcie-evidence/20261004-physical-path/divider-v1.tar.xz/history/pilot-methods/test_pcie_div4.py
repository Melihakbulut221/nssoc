# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Physical cascade binding and fail-closed capture controls; no ideal divider."""

import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "scripts"))
import characterize_pcie_div4 as d  # noqa: E402


@pytest.mark.parametrize("case", d.cases("finite"), ids=lambda x: x["name"])
def test_all_real_devices_are_bound_and_initialized(case):
    h, r = d.device_contract(case)
    assert len(h) == 60 and len(r) == 35
    assert sum(n.startswith("xosc.") for n in h) == 30
    assert sum(n.startswith("xdiv.xfirst.") for n in h) == 15
    assert sum(n.startswith("xdiv.xsecond.") for n in h) == 15
    assert all(1 <= nx <= 10 for _, nx in h.values())
    vectors = d.vectors(case)
    assert len(vectors) == len(set(vectors)) == 215
    for n in h:
        assert "@q." + n + ".qnpn13g2[ic]" in vectors
        assert "v(" + n + ".t)" in vectors
    text = d.deck(case, Path("/models"), [Path("/real.osdi")])
    assert text.count("alter @q.") == 60
    assert "PULSE" not in text and ".ic " not in text and "uic" not in text
    assert "tran " + format(case["step_s"], ".12g") + " 2e-08 0 " in text
    assert text.count("PWL(0 0 ") == 3
    assert ".options reltol=1e-4 abstol=1e-12" in text


@pytest.mark.parametrize(
    "name",
    ["second_no_toggle", "second_same_phase", "second_no_bias", "second_same_clock"],
)
def test_real_fault_only_changes_second_core(name):
    baseline = dict(d.old.BASE)
    clean, _ = d.device_contract(baseline)
    bad, _ = d.device_contract(dict(baseline, fault=name))
    changed = {n for n in clean if clean[n] != bad[n]}
    if name == "second_no_bias":
        # Bias resistor terminals change; all HBT terminal names remain real.
        assert not changed
        assert (
            "XBIAS avss ref sub"
            in d.source_texts(dict(baseline, fault=name))[d.old.CIRCUIT.name]
        )
    else:
        assert changed and all(n.startswith("xdiv.xsecond.") for n in changed)
    for p in (d.VCO, d.CONDITIONER, d.old.LATCH):
        assert d.source_texts(dict(baseline, fault=name))[p.name] == p.read_text()


@pytest.mark.parametrize(
    "before,after",
    [
        ("XDP ckp avss", "XDP ckp avdd"),
        ("XSP s1p ckp", "XSP s1n ckp"),
        ("w=2u l=4u", "w=2u l=8u"),
        ("XSECOND ckp ckn", "XSECOND ckn ckp"),
    ],
)
def test_wrong_interstage_physical_topology_rejected(
    tmp_path, monkeypatch, before, after
):
    p = tmp_path / "changed.spice"
    p.write_text(d.CIRCUIT.read_text().replace(before, after, 1))
    monkeypatch.setattr(d, "CIRCUIT", p)
    with pytest.raises(ValueError, match="topology"):
        d.verify_sources()


def test_off_flags_are_native_complete_unique_and_true():
    case = dict(d.old.BASE)
    body = "".join(
        f"NSSOC_DIV4_FLAG_BEGIN {n}\n device {n[:21]}\n off 1\nNSSOC_DIV4_FLAG_END\n"
        for n in d.identities(case)
    )
    assert len(d.read_flags(body, case)) == 60
    for changed in (
        body.replace("off 1", "off 0", 1),
        body + body,
        body.replace("q.xdiv.xsecond.xref.qnpn13g2", "q.xdiv.fake.qnpn13g2"),
    ):
        with pytest.raises(ValueError):
            d.read_flags(changed, case)


def test_initial_op_covers_thermal_and_electrical_without_forced_state(tmp_path):
    case = dict(d.old.BASE)
    names = d.electrical_vectors(case)
    p = tmp_path / "initial-op.dat"
    prefix = "time " + " ".join(names) + "\n"
    zeros = ["0"] * (len(names) + 1)
    p.write_text(prefix + " ".join(zeros) + "\n")
    assert len(d.initial_op(p, case)) == 203
    for value in ("nan", "inf", "1e-8"):
        bad = zeros.copy()
        bad[-1] = value
        p.write_text(prefix + " ".join(bad) + "\n")
        with pytest.raises(ValueError):
            d.initial_op(p, case)
    p.write_text(prefix.replace(names[-1], "v(unobserved)") + " ".join(zeros) + "\n")
    with pytest.raises(ValueError):
        d.initial_op(p, case)


def test_twenty_ns_required_in_addition_to_frozen_reader(monkeypatch):
    monkeypatch.setattr(d, "_read", lambda *_: {"time": [0.0, 12e-9]})
    with pytest.raises(ValueError, match="20ns"):
        d.read_wave("unused", d.old.BASE)


def test_atomic_write_does_not_destroy_previous_receipt_on_partial_failure(
    tmp_path, monkeypatch
):
    p = tmp_path / "result.json"
    d.atomic(p, {"status": "PRESERVED"})
    original = p.read_bytes()
    original_write = Path.write_text

    def fail(path, data, *args, **kwargs):
        original_write(path, data[:8], *args, **kwargs)
        raise OSError("simulated ENOSPC")

    monkeypatch.setattr(Path, "write_text", fail)
    with pytest.raises(OSError, match="ENOSPC"):
        d.atomic(p, {"status": "INCOMPLETE"})
    assert p.read_bytes() == original
    assert json.loads(p.read_text())["status"] == "PRESERVED"
