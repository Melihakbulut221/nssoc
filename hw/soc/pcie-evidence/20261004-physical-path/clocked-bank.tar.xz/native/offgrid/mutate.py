import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-clocked-bank-v4-01/nssoc_pcie_clocked_bank4_v4.gds')
c=l.cell('nssoc_pcie_clocked_bank4_v4')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-clocked-bank-v4-checks-02/offgrid/wrong.gds')
