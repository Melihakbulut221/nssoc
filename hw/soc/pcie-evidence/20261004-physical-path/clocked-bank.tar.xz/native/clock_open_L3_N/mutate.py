import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-clocked-bank-v4-01/nssoc_pcie_clocked_bank4_v4.gds')
c=l.cell('nssoc_pcie_clocked_bank4_v4')
region=pya.Region(c.shapes(l.layer(126,0)))
region-=pya.Region(pya.DBox(70,2494.03,74,2498.03).to_itype(l.dbu))
c.shapes(l.layer(126,0)).clear()
c.shapes(l.layer(126,0)).insert(region)
l.write('/dev/shm/nssoc-clocked-bank-v4-checks-02/clock_open_L3_N/wrong.gds')
