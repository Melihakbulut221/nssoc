import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-clocked-bank-v4-01/nssoc_pcie_clocked_bank4_v4.gds')
c=l.cell('nssoc_pcie_clocked_bank4_v4')
c.shapes(l.layer(134,0)).insert(pya.DBox(1090.0,1,1110.0,3))
l.write('/dev/shm/nssoc-clocked-bank-v4-checks-02/rail_18_25_short/wrong.gds')
