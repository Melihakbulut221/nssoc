# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,tarfile,datetime,sys
R=Path.cwd();B=R/'hw/soc/out/pcie-clocked-bank-v4-20261004'
sys.path.insert(0,str(R/'hw/soc/flow'))
from check_pcie_clocked_bank_v4 import validate_lvs,REFERENCE_FAULTS,PHYSICAL_FAULTS
from make_pcie_clocked_bank_v4 import COUNTS,PARENTS
from check_pcie_rx_cell import execute

def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_text())
L=Path('/dev/shm/nssoc-clocked-bank-v4-01');N=Path('/dev/shm/nssoc-clocked-bank-v4-checks-02')
g=read(L/'result.json');n=read(N/'result.json')
assert n['status']=='PASS_CLOCKED_BANK_V4_MAIN_DRC_STRICT_DEEP_FLAT_LVS_LEF_AND_TWENTY_THREE_NEGATIVE_CONTROLS_ONLY'
assert len(n['steps'])==27
for name,h in n['outputs'].items():assert pin(N/name)['sha256']==h,name
for name,h in g['output_sha256'].items():assert pin(L/name)['sha256']==h,name
for s in n['steps']:
 if 'audit' in s:validate_lvs(s,(N/s['name']/'extracted.cir').read_text(),s['name'] in ('lvs','lvs_flat'))
assert n['steps'][0]['measurement']['category_count']==560 and n['steps'][0]['status']=='PASS'
assert set(s['name'] for s in n['steps'])=={'drc','offgrid','lvs','lvs_flat','lef','lef_missing_pin','lef_blocked_pin',*REFERENCE_FAULTS,*PHYSICAL_FAULTS}
for p,h in n['inputs'].items():assert pin(Path(p))['sha256']==h,p
own=['hw/soc/flow/make_pcie_clocked_bank_v4.py','hw/soc/flow/check_pcie_clocked_bank_v4.py','sw/tests/test_pcie_clocked_bank_v4.py']
for label,cmd in [('tests',[R/'.venv/bin/python','-m','pytest','sw/tests/test_pcie_clocked_bank_v4.py','sw/tests/test_pcie_clocked_bank_v3.py','sw/tests/test_pcie_clock_vco_v3_layout.py','sw/tests/test_pcie_clock_vco_layout.py','-q','-p','no:cacheprovider']),('ruff',[R/'hw/soc/tools/dev-env/bin/ruff','check',*own])]:
 ex=execute(cmd,B,label);(B/(label+'-execution.json')).write_text(json.dumps(ex,indent=2)+'\n');assert ex['returncode']==0
sources={p:pin(R/p) for p in own};selected={}
roots={'layout':L,'native':N,'first_internal_name_failure':Path('/dev/shm/nssoc-clocked-bank-v4-checks-01'),'generation_execution':Path('/dev/shm/nssoc-clocked-v4-generation-01'),'first_execution':Path('/dev/shm/nssoc-clocked-v4-check-execution-01'),'final_execution':Path('/dev/shm/nssoc-clocked-v4-check-execution-02')}
for label,folder in roots.items():
 for p in sorted(folder.rglob('*')):
  if p.is_file():selected[label+'/'+str(p.relative_to(folder))]=p
for p in own:selected['methods/'+p]=R/p
for p in sorted(B.iterdir()):
 if (p.is_file() and p.suffix in ('.py','.log','.png')) or p.name in ('tests-execution.json','ruff-execution.json','render-execution.json'):
  selected['reproduction/'+p.name]=p
inventory={name:pin(p) for name,p in selected.items()};cap=B/'clocked-bank-v4-native-physical.tar.xz'
with tarfile.open(cap,'w:xz',preset=6) as t:
 for name,p in selected.items():t.add(p,arcname=name,recursive=False)
with tarfile.open(cap) as t:
 assert set(t.getnames())==set(selected)
 for m in t:
  assert m.isfile();data=t.extractfile(m).read();assert len(data)==inventory[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==inventory[m.name]['sha256']
r=dict(status=n['status'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,parents=PARENTS,geometry=dict(top='nssoc_pcie_clocked_bank4_v4',bbox_um=g['bbox_um'],ports=sorted(g['ports']),literal_primitive_counts=COUNTS,unchanged_parent_geometry=g['parent_geometry'],clock_connections=g['clock_connections']),native=dict(result=pin(N/'result.json'),drc_categories=560,drc_violations=0,deep_and_flat='PASS',native_compared_devices=200,native_hbt_records=110,expanded_hbt_instances=122,parallel_combining='Exactly four m=4 groups paired on two actual internal clock nets: Nx4 followers/Nx2 sinks. Named schematic identity is established by strict native LVS, not by assuming extraction-local net names.',finite_taps='108 physical ptaps aggregate to A432p/P864u; one ntap is A4p/P8u. SUB/BULK and AVDD2V3/NWELL stay distinct.',steps=[dict(name=s['name'],status=s['status']) for s in n['steps']],negative_controls=23),tests=dict(own_passed=37,commands=[read(B/'tests-execution.json'),read(B/'ruff-execution.json')]),preserved_failure=dict(path='first_internal_name_failure/result.json',cause='Native strict LVS matched, but supplemental guard incorrectly expected schematic CLOCKP/N names on unlabelled internal extracted conductors. The corrected guard checks two actual distinct follower/sink net pairs and relies jointly on strict LVS for schematic identities. Original native failure/source kept; no geometry/deck/threshold change.'),capsule=dict(path=str(cap.relative_to(R)),**pin(cap),members=len(inventory),inventory=inventory),render=dict(path=str((B/'combined-bank-v4.png').relative_to(R)),**pin(B/'combined-bank-v4.png'),scope='Actual native KLayout-rendered GDS; no illustration.'),limitations=['Fullbank physical connectivity/main-rule screen only: no post-layout8GHz, RF/PEX/EM, clock fanout/skew, jitter/phase noise, PLL/CDR or manufacturing approval.','Pad/ESD structure remains separate; no pad integration or main-chip integration claimed.','Frozen TX/RX/sampler devices and parent geometry retained, including prior component characterization limits; this result does not extend their analog validity.','The wider 2130µm prototype has new routing capacitance, not yet extracted or included in transistor-level performance.','Finite substrate/well contacts are physically retained; mutual thermal behavior remains unqualified.'],external_material='No vendor source/runtime/model implementation included; raw native generated GDS/reports and all runtime/deck/PDK/source hashes and commands are retained.',reproduction=['Pinned PDKc4b8b4e5, Librelane3.0.5 AppImage SHAd6a349ec65be11456e96c4981d35f63ca34d3c85daf79a51e1ccb907bb5d7466, unchanged DRC/LVS5e6d592.','AppImage python hw/soc/flow/make_pcie_clocked_bank_v4.py --pdk <PDK>/ihp-sg13g2 --bank <exact frozen samplerbankv2> --vco <exact frozen VCOv3 layout> --out /dev/shm/nssoc-clocked-<new-layout>','PYTHONDONTWRITEBYTECODE=1 .venv/bin/python hw/soc/flow/check_pcie_clocked_bank_v4.py --pdk <PDK>/ihp-sg13g2 --layout <layout> --out /dev/shm/nssoc-clocked-<new-checks>','Each native child RLIMIT_AS2147483648 bytes; no elapsed watchdog claimed.'],phy_complete=False,pads_integrated=False,main_chip_integrated=False,clock_fanout_qualified=False,post_layout_8ghz_qualified=False,qualified_pex=False,manufacturing_approval=False)
(B/'validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'validation':pin(B/'validation.json'),'capsule':pin(cap),'sources':sources,'members':len(inventory),'test_output':(B/'tests.log').read_text()},indent=2))
