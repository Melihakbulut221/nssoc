# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2');OUT=Path('/dev/shm/nssoc-clocked-v4-generation-01');OUT.mkdir()
app=R/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
x=execute([app,'python',R/'hw/soc/flow/make_pcie_clocked_bank_v4.py','--pdk',PDK,'--bank','/dev/shm/nssoc-sampler-bank-v2-01','--vco','/dev/shm/nssoc-vco-v3-layout-01','--out','/dev/shm/nssoc-clocked-bank-v4-01'],OUT,'generate');(OUT/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(x);raise SystemExit(x['returncode'])
