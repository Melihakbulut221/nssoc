# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2');OUT=Path('/dev/shm/nssoc-clocked-v4-check-execution-02');OUT.mkdir()
x=execute([sys.executable,R/'hw/soc/flow/check_pcie_clocked_bank_v4.py','--pdk',PDK,'--layout','/dev/shm/nssoc-clocked-bank-v4-01','--out','/dev/shm/nssoc-clocked-bank-v4-checks-02'],OUT,'check');(OUT/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(x);raise SystemExit(x['returncode'])
