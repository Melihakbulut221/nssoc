# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,hashlib,shutil
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
import check_magic_hbt_multiplicity_v3 as h
from check_pcie_rx_cell import execute
B=R/'hw/soc/out/pcie-magic-hbt-multiplicity-v3-20261004';OLD=Path('/dev/shm/nssoc-hbt-terminal-build-02');N=Path('/dev/shm/nssoc-hbt-nx-v3-build-final');N.mkdir();S=N/'source';shutil.copytree(OLD/'source',S)
p=S/'extract/ExtBasic.c';old=p.read_bytes();p.write_bytes(h.patcher.patch(old));runs=[]
# The changed type is file-private; no headers or external ABI change.
# Clean the affected compilation module to make a genuine native rebuild explicit.
for cmd in [['make','-C',str(S/'extract'),'clean'],['make','-C',str(S/'extract'),'module'],['make','-C',str(S/'magic'),'tcl-main']]:
 x=execute(cmd,N,'build-'+str(len(runs)));runs.append(x);assert x['returncode']==0
RT=N/'runtime/lib';shutil.copytree(OLD/'runtime/lib',RT);shutil.copyfile(S/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so')
record=dict(parent_result_sha=h.pin(OLD/'result.json')['sha256'],source_before_sha=hashlib.sha256(old).hexdigest(),source_after_sha=h.pin(p)['sha256'],method_sha=h.pin(h.patcher.__file__)['sha256'],execution=runs,runtime_sha=h.pin(RT/'magic/tcl/tclmagic.so')['sha256'],qualification=False)
(N/'result.json').write_text(json.dumps(record,indent=2)+'\n')
OUT=Path('/dev/shm/nssoc-hbt-nx-v3-native-final');cmd=[sys.executable,R/'scripts/check_magic_hbt_multiplicity_v3.py','--fixture','/dev/shm/nssoc-magic-hbt-axis-01','--technology','/dev/shm/nssoc-hbt-contact-probe-06/tech','--build',N,'--faults','/dev/shm/nssoc-hbt-hybrid-geometry-negatives3','--out',OUT]
x=execute(cmd,N,'control-suite');(N/'control-execution.json').write_text(json.dumps(x,indent=2)+'\n');assert x['returncode']==0
# Opt-out behavior is tested under both complete native runtimes, with the exact
# same source GDS, labels and original v2 technology (no n1 parameter).
O=Path('/dev/shm/nssoc-hbt-nx-v3-regression-final');O.mkdir();F=Path('/dev/shm/nssoc-magic-hbt-axis-01');T=Path('/dev/shm/nssoc-hbt-contact-probe-06/tech');rows={}
for name,rt in [('v2',OLD/'runtime/lib'),('v3',RT)]:
 d=O/name;d.mkdir();script=d/'native.tcl';script.write_text(h.native_tcl(F/'fixture.gds',json.loads((F/'result.json').read_text()),d))
 x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',script],d,'native');assert x['returncode']==0
 rows[name]=dict(execution=x,runtime=h.pin(rt/'magic/tcl/tclmagic.so'),outputs={p.name:h.pin(p) for p in d.iterdir() if p.is_file()})
def stable_ext(p):
 lines=p.read_text().splitlines();assert len([s for s in lines if s.startswith('timestamp ')])==1
 return sorted(s for s in lines if not s.startswith('timestamp '))
assert h.spice_lines((O/'v2/hbt.spice').read_text())==h.spice_lines((O/'v3/hbt.spice').read_text())
assert stable_ext(O/'v2/hbt_axis_flat.ext')==stable_ext(O/'v3/hbt_axis_flat.ext')
(O/'result.json').write_text(json.dumps(dict(status='PASS_NO_OPT_IN_NATIVE_EXT_AND_SPICE_UNCHANGED',cases=rows,normalization='Exclude one generation timestamp and sort complete EXT lines, retaining every token and duplicate. SPICE only joins continuation lines and skips comments, all records/order unchanged.',inputs={str(F/n):h.pin(F/n) for n in h.FIXTURE_PINS},technology={p.name:h.pin(p) for p in T.iterdir() if p.is_file()}),indent=2)+'\n')
print(json.dumps(dict(native_result=h.pin(OUT/'result.json'),regression=h.pin(O/'result.json'),build=h.pin(N/'result.json')),indent=2))
