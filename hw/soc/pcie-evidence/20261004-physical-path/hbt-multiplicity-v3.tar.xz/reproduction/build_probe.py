# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import shutil,sys,json,hashlib
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from patch_magic_hbt_multiplicity_v3 import patch
from check_pcie_rx_cell import execute
BASE=Path('/dev/shm/nssoc-hbt-terminal-build-02');O=Path('/dev/shm/nssoc-hbt-nx-v3-build-01');O.mkdir();S=O/'source';shutil.copytree(BASE/'source',S)
p=S/'extract/ExtBasic.c';before=p.read_bytes();p.write_bytes(patch(before))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();runs=[]
for args in [['-C',str(S/'extract'),'module'],['-C',str(S/'magic'),'tcl-main']]:
 ex=execute(['make',*args],O,'build'+str(len(runs)));runs.append(ex)
 if ex['returncode']:
  (O/'failed.json').write_text(json.dumps(runs,indent=2)+'\n');raise SystemExit(ex)
RT=O/'runtime/lib';shutil.copytree(BASE/'runtime/lib',RT);shutil.copyfile(S/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so')
r=dict(parent_result_sha=sha(BASE/'result.json'),source_before_sha=hashlib.sha256(before).hexdigest(),source_after_sha=sha(p),method_sha=sha(R/'scripts/patch_magic_hbt_multiplicity_v3.py'),execution=runs,runtime_sha=sha(RT/'magic/tcl/tclmagic.so'),qualification=False)
(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
