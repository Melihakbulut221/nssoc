# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,shutil,sys,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
O=Path('/dev/shm/nssoc-hbt-nx-v3-probe-01');O.mkdir();T=O/'tech';BASE=Path('/dev/shm/nssoc-hbt-contact-probe-06');shutil.copytree(BASE/'tech',T)
p=T/'ihp-sg13g2-extract.tech';s=p.read_text();a='npn13g2 npn gec *ndiff space/w error w1=le l1=we';assert s.count(a)==2;p.write_text(s.replace(a,a+' n1=Nx'))
RT=Path('/dev/shm/nssoc-hbt-nx-v3-build-01/runtime/lib');N=O/'native';N.mkdir();script=N/'extract.tcl';s=(BASE/'native/extract.tcl').read_text().replace(str(BASE/'native'),str(N));s='puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"\n'+s;script.write_text(s)
x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',script],N,'native')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();r=dict(execution=x,inputs={str(p):sha(p) for p in [Path(__file__).resolve(),RT/'magic/tcl/tclmagic.so',Path('/dev/shm/nssoc-magic-hbt-axis-01/fixture.gds')]},technology={p.name:sha(p) for p in T.iterdir() if p.is_file()},outputs={p.name:sha(p) for p in N.iterdir() if p.is_file()},qualified=False)
(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(x)
