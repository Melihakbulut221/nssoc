# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,shutil,json
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
B=Path('/dev/shm/nssoc-hbt-nx-v3-build-01');p=B/'source/extract/ExtBasic.c';s=p.read_text();(B/'ExtBasic.before-debug.c').write_text(s)
s=s.replace('data->invalid = 1;','data->invalid = 1;')
s=s.replace('    data->count++;','    data->count++;\n    TxError("NSSOC DEBUG a=%d p=%d w=%d l=%d count=%d invalid=%d\\n", a,p,w,l,data->count,data->invalid);')
s=s.replace('    if (data.invalid || data.count == 0)','    TxError("NSSOC DEBUG final count=%d invalid=%d\\n",data.count,data.invalid);\n    if (data.invalid || data.count == 0)');p.write_text(s)
for name,args in [('extract',['make','-C',str(B/'source/extract'),'module']),('link',['make','-C',str(B/'source/magic'),'tcl-main'])]:
 x=execute(args,B,'debug-'+name);assert x['returncode']==0
shutil.copyfile(B/'source/magic/tclmagic.so',B/'runtime/lib/magic/tcl/tclmagic.so')
f=R/'hw/soc/out/pcie-magic-hbt-multiplicity-v3-20261004/probe.py';s=f.read_text().replace('probe-01','probe-debug');exec(compile(s,str(f),'exec'))
