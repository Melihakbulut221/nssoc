# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,tarfile,hashlib,datetime,difflib
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-hbt-multiplicity-v3-20261004';sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
import check_magic_hbt_multiplicity_v3 as h
from check_pcie_rx_cell import execute
N=Path('/dev/shm/nssoc-hbt-nx-v3-native-final');G=Path('/dev/shm/nssoc-hbt-nx-v3-regression-final');C=Path('/dev/shm/nssoc-hbt-nx-v3-build-final');OLD=Path('/dev/shm/nssoc-hbt-terminal-build-02')
n=json.loads((N/'result.json').read_text());g=json.loads((G/'result.json').read_text());c=json.loads((C/'result.json').read_text())
assert n['status']=='PASS_NATIVE_24_HBT_NX_FIVE_GEOMETRY_FAULTS_WITH_FINITE_TAP_MODEL_BLOCKER'
assert g['status']=='PASS_NO_OPT_IN_NATIVE_EXT_AND_SPICE_UNCHANGED'
for name,pin in n['inputs'].items():assert h.pin(name)==pin,name
for name,row in n['cases'].items():
 for filename,pin in row['outputs'].items():assert h.pin(N/name/filename)==pin
 x=h.assess((N/name/'hbt.spice').read_text(),(N/name/'hbt_axis_flat.ext').read_text(),(N/name/'native.log').read_text());assert x==row['measurement']
for name,row in g['cases'].items():
 for filename,pin in row['outputs'].items():assert h.pin(G/name/filename)==pin
assert c['method_sha']==h.pin(h.patcher.__file__)['sha256']
assert c['source_after_sha']==h.pin(C/'source/extract/ExtBasic.c')['sha256']
assert c['runtime_sha']==h.pin(C/'runtime/lib/magic/tcl/tclmagic.so')['sha256']
source_inventory={};changed=[]
for p in sorted((OLD/'source').rglob('*')):
 if p.is_file() and p.suffix in ('.c','.h'):
  rel=p.relative_to(OLD/'source');q=C/'source'/rel;source_inventory[str(rel)]={'before':h.pin(p),'after':h.pin(q)}
  if p.read_bytes()!=q.read_bytes():changed.append(str(rel))
assert changed==['extract/ExtBasic.c'] and len(source_inventory)==559
(B/'private-source-build-audit.json').write_text(json.dumps(dict(status='PASS_559_C_HEADER_INVENTORY_ONLY_ONE_PRIVATE_C_FILE_CHANGED',source_inventory=source_inventory,changed=changed,abi='Only ExtBasic.c file-local struct grows; no header/exported ABI changed. Affected extract module cleaned/recompiled and final runtime relinked.',build=c),indent=2)+'\n')
a=(OLD/'source/extract/ExtBasic.c').read_text();b=(C/'source/extract/ExtBasic.c').read_text();assert b.encode()==h.patcher.patch(a.encode())
(B/'native-extractor.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='v2-private/extract/ExtBasic.c',tofile='v3-private/extract/ExtBasic.c')))
(B/'UPSTREAM-NOTICES.txt').write_text('Native Magic source excerpts/copies retain the original University of California notice. Full notice follows.\n\n'+(OLD/'source/LICENSE').read_text()+'\nThe modified IHP extraction technology retains Copyright 2025 IHP PDK Authors and Apache-2.0. Included LICENSE-Apache-2.0.txt is the exact repository license text. No vendor runtime/OSDI/model implementation binary is distributed.\n')
(B/'LICENSE-Apache-2.0.txt').write_bytes((R/'LICENSES/Apache-2.0.txt').read_bytes())
commands=[('tests',[R/'.venv/bin/python','-m','pytest','sw/tests/test_magic_hbt_multiplicity_v3.py','sw/tests/test_magic_hbt_contract_v2.py','sw/tests/test_magic_hbt_axis_v1.py','sw/tests/test_magic_coupled_cap_v2.py','-q','-p','no:cacheprovider']),('ruff',[R/'hw/soc/tools/dev-env/bin/ruff','check','scripts/patch_magic_hbt_multiplicity_v3.py','scripts/check_magic_hbt_multiplicity_v3.py','sw/tests/test_magic_hbt_multiplicity_v3.py'])]
for label,cmd in commands:
 ex=execute(cmd,B,label);(B/(label+'-execution.json')).write_text(json.dumps(ex,indent=2)+'\n');assert ex['returncode']==0
selected={}
for label,folder in [('native',N),('regression',G),('fixture',Path('/dev/shm/nssoc-magic-hbt-axis-01')),('native-klayout-golden',Path('/dev/shm/nssoc-magic-hbt-axis-native-01/klayout'))]:
 for p in sorted(folder.rglob('*')):
  if p.is_file() and not ('tech' in p.relative_to(folder).parts):selected[label+'/'+str(p.relative_to(folder))]=p
selected['technology/ihp-sg13g2-extract.tech']=N/'tech/ihp-sg13g2-extract.tech'
selected['build/ExtBasic.c.before']=OLD/'source/extract/ExtBasic.c'
selected['build/ExtBasic.c.after']=C/'source/extract/ExtBasic.c'
for p in C.iterdir():
 if p.is_file():selected['build/'+p.name]=p
for label in ['01','02','03','04','05']:
 folder=Path('/dev/shm/nssoc-hbt-nx-v3-final-'+label)
 for p in sorted(folder.rglob('*')):
  if p.is_file() and not ('tech' in p.relative_to(folder).parts):selected['draft-capture-'+label+'/'+str(p.relative_to(folder))]=p
for label in ['01','02','debug']:
 folder=Path('/dev/shm/nssoc-hbt-nx-v3-probe-'+label)
 for p in sorted(folder.rglob('*')):
  if p.is_file() and not ('tech' in p.relative_to(folder).parts):selected['probe-'+label+'/'+str(p.relative_to(folder))]=p
for name in ['01','02','03']:
 folder=Path('/dev/shm/nssoc-hbt-nx-v3-build-'+name)
 for p in folder.iterdir():
  if p.is_file():selected['draft-build-'+name+'/'+p.name]=p
for p in Path('/dev/shm/nssoc-hbt-hybrid-geometry-negatives3').iterdir():
 if p.is_file() and p.suffix in ('.json','.gds'):selected['actual-geometry-faults/'+p.name]=p
own=['scripts/patch_magic_hbt_multiplicity_v3.py','scripts/check_magic_hbt_multiplicity_v3.py','sw/tests/test_magic_hbt_multiplicity_v3.py']
for name in own:selected['methods/'+name]=R/name
for p in sorted(B.iterdir()):
 if p.is_file() and p.name not in ('validation.json','hbt-multiplicity-v3-native.tar.xz'):selected['reproduction/'+p.name]=p
inventory={name:h.pin(p) for name,p in selected.items()};cap=B/'hbt-multiplicity-v3-native.tar.xz'
with tarfile.open(cap,'w:xz',preset=6) as t:
 for name,p in selected.items():t.add(p,arcname=name,recursive=False)
with tarfile.open(cap) as t:
 assert set(t.getnames())==set(inventory)
 for m in t:
  assert m.isfile();data=t.extractfile(m).read();assert len(data)==inventory[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==inventory[m.name]['sha256']
r=dict(status=n['status'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources={name:h.pin(R/name) for name in own},tests=dict(passed=124,own=44,log=h.pin(B/'tests.log'),ruff='PASS'),native_result=h.pin(N/'result.json'),build=c,build_audit=h.pin(B/'private-source-build-audit.json'),native_runtime_distributed=False,fixture_geometry_unchanged=h.FIXTURE_PINS,native_cases={name:dict(execution=x['execution'],measurement=x['measurement']) for name,x in n['cases'].items()},regression=g,physical_control_source='Reused exact hierarchy-preserving native PCell geometry faults whose independent KLayout LVS mismatches and zero-XOR clone positive are frozen in pcie-magic-hbt-contract-v2-20261004; each input GDS hash is bound by final native result. No replacement geometry or instance-name-derived Nx.',failures_preserved=['Initial draft counted contact residues across multiple planes; all24 invalid, corrected to native terminal geometry plane.','First metadata checker incorrectly expected missing tap to leave the same substrate label; actual native substrate name changes and correctly rejects it. Finite impedance remains omitted.','Raw EXT/SPICE bridge first failed on global-off exclamation marker and native equivalent port naming. Now only source-recorded equivalences/standard global marker removal are used for bridge equality; golden graph is never collapsed.'],scope=['Native 24 HBTs across eight orientations and Nx1/2/4, exact C/B/E, measured 70nm/900nm and counts. Missing-finger control measures3, narrowed width30nm, C/B short72ports, emitter-via open explicit incompatible-node error.','No PCell parameter/property/name is used by C measurement; technology n1=Nx opts into same-plane equal rectangular connected component enumeration.','The output retains native Magic substrate behavior: intact ptap is shorted, not a finite device. This remains a separate blocker; no complete25-device-network, hybrid waiver, fullbank PEX, RF or manufacturing approval.','No generic all-Magic-device qualification. Opt-out extraction equality tested on the same24-HBT fixture under exactv2/v3 runtimes.','No GDS mask changes in positive fixture; native commands add explicit labels/ports only.','Every native child has2GiB address-space cap; no fullchip/nativeboot/large extraction.'],external_sources=dict(magic='Copied source C retains UC Regents1985/1990 permissive notice; exact before/after and private build logs included.',technology='Only modified extraction tech file included, Apache2.0 with original IHP notice; all other dependency files referenced/pinned.',notices=h.pin(B/'UPSTREAM-NOTICES.txt')),archive=dict(path=str(cap.relative_to(R)),**h.pin(cap),members=len(inventory),inventory=inventory),reproduction=dict(driver='reproduction/run_final.py reconstructs private clean/relink from exact frozenv2build; explicit final command is in build/control-execution.json.',native='PYTHONDONTWRITEBYTECODE=1 .venv/bin/python scripts/check_magic_hbt_multiplicity_v3.py --fixture EXACT_FIXTURE --technology EXACT_V2_CONTACT_TECH --build NEW_PRIVATE_BUILD --faults EXACT_GEOMETRY_FAULTS --out FRESH_OUTPUT',review='assess(raw SPICE, raw EXT, raw log) independently checks all parameters and terminals; every case/output/native library pinned before/after.'),finite_tap_model_correct=False,qualified_pex=False,physical_adoption=False,original_runtime_modified=False)
(B/'validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(validation=h.pin(B/'validation.json'),capsule=h.pin(cap),sources=r['sources'],members=len(inventory)),indent=2))
