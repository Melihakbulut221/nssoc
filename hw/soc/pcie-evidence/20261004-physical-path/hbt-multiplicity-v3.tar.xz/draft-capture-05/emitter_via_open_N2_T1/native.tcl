puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-hbt-nx-v3-final-05/emitter_via_open_N2_T1}
drc off
gds readonly true
gds read {/dev/shm/nssoc-hbt-hybrid-geometry-negatives3/emitter_via_open_N2_T1.gds}
load nssoc_hbt_axis
flatten hbt_axis_flat
load hbt_axis_flat
select top cell
box values 19.075um 31.01um 20.925um 31.25um
label C_N1_T0 center metal1
port C_N1_T0 make 1
port C_N1_T0 class inout
port C_N1_T0 use signal
box values 19.025um 28.74um 20.975um 28.98um
label B_N1_T0 center metal1
port B_N1_T0 make 2
port B_N1_T0 class inout
port B_N1_T0 use signal
box values 19.255um 29.215um 20.745um 30.77um
label E_N1_T0 center metal2
port E_N1_T0 make 3
port E_N1_T0 class inout
port E_N1_T0 use signal
box values 58.75um 29.075um 58.99um 30.925um
label C_N1_T1 center metal1
port C_N1_T1 make 4
port C_N1_T1 class inout
port C_N1_T1 use signal
box values 61.02um 29.025um 61.26um 30.975um
label B_N1_T1 center metal1
port B_N1_T1 make 5
port B_N1_T1 class inout
port B_N1_T1 use signal
box values 59.23um 29.255um 60.785um 30.745um
label E_N1_T1 center metal2
port E_N1_T1 make 6
port E_N1_T1 class inout
port E_N1_T1 use signal
box values 99.075um 28.75um 100.925um 28.99um
label C_N1_T2 center metal1
port C_N1_T2 make 7
port C_N1_T2 class inout
port C_N1_T2 use signal
box values 99.025um 31.02um 100.975um 31.26um
label B_N1_T2 center metal1
port B_N1_T2 make 8
port B_N1_T2 class inout
port B_N1_T2 use signal
box values 99.255um 29.23um 100.745um 30.785um
label E_N1_T2 center metal2
port E_N1_T2 make 9
port E_N1_T2 class inout
port E_N1_T2 use signal
box values 141.01um 29.075um 141.25um 30.925um
label C_N1_T3 center metal1
port C_N1_T3 make 10
port C_N1_T3 class inout
port C_N1_T3 use signal
box values 138.74um 29.025um 138.98um 30.975um
label B_N1_T3 center metal1
port B_N1_T3 make 11
port B_N1_T3 class inout
port B_N1_T3 use signal
box values 139.215um 29.255um 140.77um 30.745um
label E_N1_T3 center metal2
port E_N1_T3 make 12
port E_N1_T3 class inout
port E_N1_T3 use signal
box values 179.075um 28.75um 180.925um 28.99um
label C_N1_T4 center metal1
port C_N1_T4 make 13
port C_N1_T4 class inout
port C_N1_T4 use signal
box values 179.025um 31.02um 180.975um 31.26um
label B_N1_T4 center metal1
port B_N1_T4 make 14
port B_N1_T4 class inout
port B_N1_T4 use signal
box values 179.255um 29.23um 180.745um 30.785um
label E_N1_T4 center metal2
port E_N1_T4 make 15
port E_N1_T4 class inout
port E_N1_T4 use signal
box values 221.01um 29.075um 221.25um 30.925um
label C_N1_T5 center metal1
port C_N1_T5 make 16
port C_N1_T5 class inout
port C_N1_T5 use signal
box values 218.74um 29.025um 218.98um 30.975um
label B_N1_T5 center metal1
port B_N1_T5 make 17
port B_N1_T5 class inout
port B_N1_T5 use signal
box values 219.215um 29.255um 220.77um 30.745um
label E_N1_T5 center metal2
port E_N1_T5 make 18
port E_N1_T5 class inout
port E_N1_T5 use signal
box values 259.075um 31.01um 260.925um 31.25um
label C_N1_T6 center metal1
port C_N1_T6 make 19
port C_N1_T6 class inout
port C_N1_T6 use signal
box values 259.025um 28.74um 260.975um 28.98um
label B_N1_T6 center metal1
port B_N1_T6 make 20
port B_N1_T6 class inout
port B_N1_T6 use signal
box values 259.255um 29.215um 260.745um 30.77um
label E_N1_T6 center metal2
port E_N1_T6 make 21
port E_N1_T6 class inout
port E_N1_T6 use signal
box values 298.75um 29.075um 298.99um 30.925um
label C_N1_T7 center metal1
port C_N1_T7 make 22
port C_N1_T7 class inout
port C_N1_T7 use signal
box values 301.02um 29.025um 301.26um 30.975um
label B_N1_T7 center metal1
port B_N1_T7 make 23
port B_N1_T7 class inout
port B_N1_T7 use signal
box values 299.23um 29.255um 300.785um 30.745um
label E_N1_T7 center metal2
port E_N1_T7 make 24
port E_N1_T7 class inout
port E_N1_T7 use signal
box values 19.075um 71.02um 22.775um 71.46um
label C_N2_T0 center metal1
port C_N2_T0 make 25
port C_N2_T0 class inout
port C_N2_T0 use signal
box values 19.025um 68.74um 22.825um 68.98um
label B_N2_T0 center metal1
port B_N2_T0 make 26
port B_N2_T0 class inout
port B_N2_T0 use signal
box values 19.255um 69.215um 22.595um 70.77um
label E_N2_T0 center metal2
port E_N2_T0 make 27
port E_N2_T0 class inout
port E_N2_T0 use signal
box values 58.54um 69.075um 58.98um 72.775um
label C_N2_T1 center metal1
port C_N2_T1 make 28
port C_N2_T1 class inout
port C_N2_T1 use signal
box values 61.02um 69.025um 61.26um 72.825um
label B_N2_T1 center metal1
port B_N2_T1 make 29
port B_N2_T1 class inout
port B_N2_T1 use signal
box values 59.23um 69.255um 60.785um 72.595um
label E_N2_T1 center metal2
port E_N2_T1 make 30
port E_N2_T1 class inout
port E_N2_T1 use signal
box values 97.225um 68.54um 100.925um 68.98um
label C_N2_T2 center metal1
port C_N2_T2 make 31
port C_N2_T2 class inout
port C_N2_T2 use signal
box values 97.175um 71.02um 100.975um 71.26um
label B_N2_T2 center metal1
port B_N2_T2 make 32
port B_N2_T2 class inout
port B_N2_T2 use signal
box values 97.405um 69.23um 100.745um 70.785um
label E_N2_T2 center metal2
port E_N2_T2 make 33
port E_N2_T2 class inout
port E_N2_T2 use signal
box values 141.02um 67.225um 141.46um 70.925um
label C_N2_T3 center metal1
port C_N2_T3 make 34
port C_N2_T3 class inout
port C_N2_T3 use signal
box values 138.74um 67.175um 138.98um 70.975um
label B_N2_T3 center metal1
port B_N2_T3 make 35
port B_N2_T3 class inout
port B_N2_T3 use signal
box values 139.215um 67.405um 140.77um 70.745um
label E_N2_T3 center metal2
port E_N2_T3 make 36
port E_N2_T3 class inout
port E_N2_T3 use signal
box values 179.075um 68.54um 182.775um 68.98um
label C_N2_T4 center metal1
port C_N2_T4 make 37
port C_N2_T4 class inout
port C_N2_T4 use signal
box values 179.025um 71.02um 182.825um 71.26um
label B_N2_T4 center metal1
port B_N2_T4 make 38
port B_N2_T4 class inout
port B_N2_T4 use signal
box values 179.255um 69.23um 182.595um 70.785um
label E_N2_T4 center metal2
port E_N2_T4 make 39
port E_N2_T4 class inout
port E_N2_T4 use signal
box values 221.02um 69.075um 221.46um 72.775um
label C_N2_T5 center metal1
port C_N2_T5 make 40
port C_N2_T5 class inout
port C_N2_T5 use signal
box values 218.74um 69.025um 218.98um 72.825um
label B_N2_T5 center metal1
port B_N2_T5 make 41
port B_N2_T5 class inout
port B_N2_T5 use signal
box values 219.215um 69.255um 220.77um 72.595um
label E_N2_T5 center metal2
port E_N2_T5 make 42
port E_N2_T5 class inout
port E_N2_T5 use signal
box values 257.225um 71.02um 260.925um 71.46um
label C_N2_T6 center metal1
port C_N2_T6 make 43
port C_N2_T6 class inout
port C_N2_T6 use signal
box values 257.175um 68.74um 260.975um 68.98um
label B_N2_T6 center metal1
port B_N2_T6 make 44
port B_N2_T6 class inout
port B_N2_T6 use signal
box values 257.405um 69.215um 260.745um 70.77um
label E_N2_T6 center metal2
port E_N2_T6 make 45
port E_N2_T6 class inout
port E_N2_T6 use signal
box values 298.54um 67.225um 298.98um 70.925um
label C_N2_T7 center metal1
port C_N2_T7 make 46
port C_N2_T7 class inout
port C_N2_T7 use signal
box values 301.02um 67.175um 301.26um 70.975um
label B_N2_T7 center metal1
port B_N2_T7 make 47
port B_N2_T7 class inout
port B_N2_T7 use signal
box values 299.23um 67.405um 300.785um 70.745um
label E_N2_T7 center metal2
port E_N2_T7 make 48
port E_N2_T7 class inout
port E_N2_T7 use signal
box values 19.075um 111.02um 26.475um 111.46um
label C_N4_T0 center metal1
port C_N4_T0 make 49
port C_N4_T0 class inout
port C_N4_T0 use signal
box values 19.025um 108.74um 26.525um 108.98um
label B_N4_T0 center metal1
port B_N4_T0 make 50
port B_N4_T0 class inout
port B_N4_T0 use signal
box values 19.255um 109.215um 26.295um 110.77um
label E_N4_T0 center metal2
port E_N4_T0 make 51
port E_N4_T0 class inout
port E_N4_T0 use signal
box values 58.54um 109.075um 58.98um 116.475um
label C_N4_T1 center metal1
port C_N4_T1 make 52
port C_N4_T1 class inout
port C_N4_T1 use signal
box values 61.02um 109.025um 61.26um 116.525um
label B_N4_T1 center metal1
port B_N4_T1 make 53
port B_N4_T1 class inout
port B_N4_T1 use signal
box values 59.23um 109.255um 60.785um 116.295um
label E_N4_T1 center metal2
port E_N4_T1 make 54
port E_N4_T1 class inout
port E_N4_T1 use signal
box values 93.525um 108.54um 100.925um 108.98um
label C_N4_T2 center metal1
port C_N4_T2 make 55
port C_N4_T2 class inout
port C_N4_T2 use signal
box values 93.475um 111.02um 100.975um 111.26um
label B_N4_T2 center metal1
port B_N4_T2 make 56
port B_N4_T2 class inout
port B_N4_T2 use signal
box values 93.705um 109.23um 100.745um 110.785um
label E_N4_T2 center metal2
port E_N4_T2 make 57
port E_N4_T2 class inout
port E_N4_T2 use signal
box values 141.02um 103.525um 141.46um 110.925um
label C_N4_T3 center metal1
port C_N4_T3 make 58
port C_N4_T3 class inout
port C_N4_T3 use signal
box values 138.74um 103.475um 138.98um 110.975um
label B_N4_T3 center metal1
port B_N4_T3 make 59
port B_N4_T3 class inout
port B_N4_T3 use signal
box values 139.215um 103.705um 140.77um 110.745um
label E_N4_T3 center metal2
port E_N4_T3 make 60
port E_N4_T3 class inout
port E_N4_T3 use signal
box values 179.075um 108.54um 186.475um 108.98um
label C_N4_T4 center metal1
port C_N4_T4 make 61
port C_N4_T4 class inout
port C_N4_T4 use signal
box values 179.025um 111.02um 186.525um 111.26um
label B_N4_T4 center metal1
port B_N4_T4 make 62
port B_N4_T4 class inout
port B_N4_T4 use signal
box values 179.255um 109.23um 186.295um 110.785um
label E_N4_T4 center metal2
port E_N4_T4 make 63
port E_N4_T4 class inout
port E_N4_T4 use signal
box values 221.02um 109.075um 221.46um 116.475um
label C_N4_T5 center metal1
port C_N4_T5 make 64
port C_N4_T5 class inout
port C_N4_T5 use signal
box values 218.74um 109.025um 218.98um 116.525um
label B_N4_T5 center metal1
port B_N4_T5 make 65
port B_N4_T5 class inout
port B_N4_T5 use signal
box values 219.215um 109.255um 220.77um 116.295um
label E_N4_T5 center metal2
port E_N4_T5 make 66
port E_N4_T5 class inout
port E_N4_T5 use signal
box values 253.525um 111.02um 260.925um 111.46um
label C_N4_T6 center metal1
port C_N4_T6 make 67
port C_N4_T6 class inout
port C_N4_T6 use signal
box values 253.475um 108.74um 260.975um 108.98um
label B_N4_T6 center metal1
port B_N4_T6 make 68
port B_N4_T6 class inout
port B_N4_T6 use signal
box values 253.705um 109.215um 260.745um 110.77um
label E_N4_T6 center metal2
port E_N4_T6 make 69
port E_N4_T6 class inout
port E_N4_T6 use signal
box values 298.54um 103.525um 298.98um 110.925um
label C_N4_T7 center metal1
port C_N4_T7 make 70
port C_N4_T7 class inout
port C_N4_T7 use signal
box values 301.02um 103.475um 301.26um 110.975um
label B_N4_T7 center metal1
port B_N4_T7 make 71
port B_N4_T7 class inout
port B_N4_T7 use signal
box values 299.23um 103.705um 300.785um 110.745um
label E_N4_T7 center metal2
port E_N4_T7 make 72
port E_N4_T7 class inout
port E_N4_T7 use signal
box values -1.8um 0.2um -0.2um 1.8um
label SUB center metal1
port SUB make 73
port SUB class inout
port SUB use signal
save hbt_axis_flat
extract style ngspice()
extract all
feedback save feedback.tcl
ext2spice lvs
ext2spice global off
ext2spice cthresh infinite
ext2spice extresist off
ext2spice -o hbt.spice
quit -noprompt
