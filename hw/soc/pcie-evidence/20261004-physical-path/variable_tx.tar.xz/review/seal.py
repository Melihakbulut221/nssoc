from pathlib import Path
import ast,hashlib,json,tarfile,io,sys,xml.etree.ElementTree as ET
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');sys.path.insert(0,str(ROOT/'scripts'));from cocotb_results import count_results
B=ROOT/'hw/soc/out/pcie-variable-tx-20261004';DEST=ROOT/'hw/soc/pcie-evidence/20261004-physical-path';DEST.mkdir(exist_ok=True)
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
payload={};records=[];native_maps=[]
current=['hw/soc/rtl/pcie/soc_pcie_gen3_variable_tx.v','hw/soc/tb/cocotb/test_soc_pcie_gen3_variable_tx.py','hw/soc/tb/cocotb/Makefile.soc_pcie_gen3_variable_tx','scripts/check_pcie_gen3_variable_tx.py','sw/tests/test_pcie_gen3_variable_tx.py','scripts/check_pcie_integrity.py','scripts/check_pcie_integrity_native.py','scripts/cocotb_results.py']
for name in current:payload['source/'+name]=(ROOT/name).read_bytes()
for p in B.glob('*.py'):payload['review/'+p.name]=p.read_bytes()
for p in [B/'independent-review.json',Path('/dev/shm/nssoc-variable-tx-mutations-selector-final.log'),Path('/dev/shm/nssoc-variable-tx-selector-final.log')]:payload['review/'+p.name]=p.read_bytes()
bench=ast.parse((ROOT/current[1]).read_text());oldbench=ast.parse((B/'first-three-case-bench.py').read_text());assert ast.dump(ast.Module(body=[n for n in bench.body if getattr(n,'name',None)!='drain_all_even_remainders'],type_ignores=[]))==ast.dump(oldbench)
oldnames=['mixed_lengths_and_invalid_codes','sustained_variable_block_stream','flush_discards_partial_reservoir'];allnames=oldnames+['drain_all_even_remainders']

def collect(label,p,expected,status):
 r=json.loads((p/'result.json').read_text());assert r['status']==status;assert count_results([p/'results.xml'])==expected
 payload[label+'/result.json']=(p/'result.json').read_bytes()
 for n,h in r['outputs'].items():assert pin(p/n)==h;payload[label+'/'+n]=(p/n).read_bytes()
 nodes=ET.parse(p/'results.xml').getroot().findall('.//testcase');names=[n.get('name') for n in nodes];assert len(names)==len(set(names));skips=[n.get('name') for n in nodes if n.find('skipped') is not None]
 if expected==(1,0,3):assert names==allnames and skips==oldnames
 elif expected[2]==0:assert not skips
 for path,h in r['inputs'].items():
  source=Path(path)
  if str(source).startswith('/dev/shm/') and source.parent.name=='rtl':assert pin(source)==h;payload[label+'/mutated-rtl/'+source.name]=source.read_bytes()
 if 'mapped.v' in r['outputs'] and status.startswith('PASS'):
  native_maps.append(r['outputs']['mapped.v']);cells=json.loads((p/'mapped.json').read_text())['modules'][r['top']]['cells'];assert len(cells)==r['mapped_cells']==13107 and all(c['type'].startswith('sg13g2_') for c in cells.values())
 rec={'label':label,'native_root':str(p),'result_pin':pin(p/'result.json'),'status':status,'counts':list(expected),'names':names,'explicit_exclusions':skips,'mapped_cells':r.get('mapped_cells'),'recorded_source_inputs':r['inputs'],'runtime_pins':r['runtime']};records.append(rec);return r

collect('current/rtl-four',Path('/dev/shm/nssoc-gen3-variable-tx-rtl-selector-final'),(4,0,0),'PASS_PORT_ONLY_PCIE_GEN3_VARIABLE_TX')
collect('native/original-three',Path('/dev/shm/nssoc-gen3-variable-tx-native-final'),(3,0,0),'PASS_PORT_ONLY_PCIE_GEN3_VARIABLE_TX')
selected=collect('native/additional-drain',Path('/dev/shm/nssoc-gen3-variable-tx-native-drain-selected'),(1,0,3),'PASS_PORT_ONLY_PCIE_GEN3_VARIABLE_TX');assert selected['explicit_filter_excluded_cases']==sorted(oldnames);assert native_maps[0]==native_maps[1]
for i in range(8):
 p=Path('/dev/shm/nssoc-variable-tx-mutations-selector-final')/f'test_real_port_counterexample_{i}'/'run';counts=count_results([p/'results.xml']);assert counts[0]+counts[1]==4 and counts[1]>0 and counts[2]==0;assert 'AssertionError' in (p/'simulation.log').read_text();collect(f'current/mutant-{i}',p,counts,'FAIL')
# These historical passes are genuine captured escapes, never counted as rejected faults.
collect('history/equivalent-count-ge31',Path('/dev/shm/nssoc-variable-tx-mutations-01/test_real_port_counterexample_2/run'),(3,0,0),'PASS_PORT_ONLY_PCIE_GEN3_VARIABLE_TX')
collect('history/escaped-count-ge30-before-drain',Path('/dev/shm/nssoc-variable-tx-mutations-final/test_real_port_counterexample_2/run'),(3,0,0),'PASS_PORT_ONLY_PCIE_GEN3_VARIABLE_TX')
selector=collect('history/selector-skip-guard-failure',Path('/dev/shm/nssoc-gen3-variable-tx-native-drain-final'),(1,0,3),'FAIL');assert 'Missing, failed or skipped port cases' in selector['error']
# Exact process-lifetime test artifacts, including the installed signal-handler marker.
pytestroot=Path('/dev/shm/nssoc-variable-tx-mutations-selector-final');lifetimes=[]
for folder in sorted(pytestroot.iterdir()):
 if folder.is_symlink() or not folder.is_dir() or folder.name.startswith('test_real_port'):continue
 files=[]
 for p in folder.iterdir():
  assert p.is_file() and not p.is_symlink();payload['current/process-controls/'+folder.name+'/'+p.name]=p.read_bytes();files.append(p.name)
 lifetimes.append({'case_directory':folder.name,'files':files})
assert len(lifetimes)==3 and '11 passed' in Path('/dev/shm/nssoc-variable-tx-mutations-selector-final.log').read_text()
# Every recorded project or mutated source body must have exact bytes in the capsule;
# external model and executable inventories are rehashed but not redistributed.
by_hash={hashlib.sha256(b).hexdigest():n for n,b in payload.items()};bridges=[]
for row in records:
 for name,h in row['recorded_source_inputs'].items():
  p=Path(name)
  if h['sha256'] in by_hash:
   bridges.append({'capture':row['label'],'input':name,'member':by_hash[h['sha256']],'sha256':h['sha256']});continue
  if str(p).startswith(str(ROOT)) and '/tools/' not in str(p):raise AssertionError(('Missing recorded source body',name,h))
  assert pin(p)==h,(name,'external input changed')
 for name,h in row['runtime_pins'].items():assert pin(Path(name))==h
notice='Copyright2026 Hasan Melih Akbulut. Project RTL: CERN-OHL-W-2.0. Python methods/benches: Apache-2.0. Reports: CC-BY-4.0. Generated mapped netlists derive from project RTL and refer to IHP standard cells. Foundry library/model and executable binaries are not redistributed. This corpus is port-only logical transport evidence, not SDF timing, physical layout, full PCS, PMA or PCIe conformance. Historical equivalent/escaped mutants and selector-method FAIL remain unchanged.\n';payload['NOTICES.txt']=notice.encode()
for name in ['CERN-OHL-W-2.0','Apache-2.0','CC-BY-4.0']:payload['LICENSES/'+name+'.txt']=(ROOT/'LICENSES'/f'{name}.txt').read_bytes()
inv={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in payload.items()};payload['inventory.json']=(json.dumps(inv,indent=2)+'\n').encode();cp=DEST/'variable_tx.tar.xz';assert not cp.exists()
with tarfile.open(cp,'w:xz') as tf:
 for n,b in sorted(payload.items()):ti=tarfile.TarInfo(n);ti.size=len(b);ti.mtime=0;tf.addfile(ti,io.BytesIO(b))
with tarfile.open(cp) as tf:
 assert len(tf.getmembers())==len(payload) and set(tf.getnames())==set(payload)
 for n,h in inv.items():b=tf.extractfile(n).read();assert len(b)==h['bytes'] and hashlib.sha256(b).hexdigest()==h['sha256']
rec={'schema':1,'status':'PASS_SOURCE_BOUND_VARIABLE_TX_PORT_SUITE_WITH_FAILURE_HISTORY','source_pins':{n:pin(ROOT/n) for n in current},'current_rtl_counts':{'passed':4,'failed':0,'skipped':0},'native_case_union':{'original_cases':oldnames,'additional_case':'drain_all_even_remainders','total_distinct_actual_passes':4,'selected_capture_excluded_cases':oldnames,'single_run_all_four_native':False,'original_three_and_helper_ast_identical':True,'exact_mapped_netlist':native_maps[0],'mapped_ihp_cells':13107},'fault_controls':{'eight_actual_hdl_mutants_rejected':True,'three_actual_process_lifetime_controls_pass':True,'pytest_total':11,'process_artifacts':lifetimes},'preserved_history':['count>=31 mutation is equivalent under reachable even-count invariant; original mistaken rejection expectation remains captured.','count>=30 initially escaped three random tests; new explicit sixteen-residue drain case now rejects it.','First selected native drain run actually passed1/excluded3 but original blanket skip guard emitted FAIL; exact named-filter guard fix preserved that prior FAIL.'],'raw_captures':records,'source_body_bridges':bridges,'capsule':{'path':str(cp.relative_to(ROOT)),'members':len(payload),**pin(cp),'all_member_hashes_replayed':True},'independent_source_capture_review':{'path':'hw/soc/out/pcie-variable-tx-20261004/independent-review.json',**pin(B/'independent-review.json')},'scope':'Four synchronous logical lanes with explicit66/98/130/162/194-bit blocks, low-bit-first transport and common sync header. Caller owns ordered-set validity and scrambling. Does not insert/remove SKP, compensate rates, implement RX PCS, LTSSM, CDC, serializer or PMA.','source_changes_by_sealer':False,'full_native_rerun_by_sealer':False,'chip_adoption_or_physical_signoff':False}
out=DEST/'variable_tx.json';assert not out.exists();out.write_text(json.dumps(rec,indent=2)+'\n');print('SEALED',pin(out),pin(cp),len(payload))
