from pathlib import Path
import ast,json,hashlib,sys,xml.etree.ElementTree as ET
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');B=ROOT/'hw/soc/out/pcie-variable-tx-20261004';sys.path.insert(0,str(ROOT/'scripts'))
from cocotb_results import count_results

def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
bench=ROOT/'hw/soc/tb/cocotb/test_soc_pcie_gen3_variable_tx.py';tree=ast.parse(bench.read_text());old=B/'first-three-case-bench.py';without=ast.Module(body=[n for n in tree.body if getattr(n,'name',None)!='drain_all_even_remainders'],type_ignores=[]);assert ast.dump(without)==ast.dump(ast.parse(old.read_text()))
oldnames=['mixed_lengths_and_invalid_codes','sustained_variable_block_stream','flush_discards_partial_reservoir'];newname='drain_all_even_remainders'
rows=[];hashes=[]
for label,dirname,expected in [('old_three_native','nssoc-gen3-variable-tx-native-final',(3,0,0)),('all_four_rtl','nssoc-gen3-variable-tx-rtl-drain-final',(4,0,0)),('new_drain_native','nssoc-gen3-variable-tx-native-drain-selected',(1,0,3))]:
 p=Path('/dev/shm')/dirname;r=json.loads((p/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_PCIE_GEN3_VARIABLE_TX';assert count_results([p/'results.xml'])==expected
 for n,h in r['outputs'].items():assert pin(p/n)==h
 assert r['inputs'][str(ROOT/'hw/soc/rtl/pcie/soc_pcie_gen3_variable_tx.v')]==pin(ROOT/'hw/soc/rtl/pcie/soc_pcie_gen3_variable_tx.v')
 nodes=ET.parse(p/'results.xml').getroot().findall('.//testcase');names=[n.get('name') for n in nodes];assert len(names)==len(set(names))
 skips=[n.get('name') for n in nodes if n.find('skipped') is not None]
 if label=='new_drain_native':assert names==oldnames+[newname] and skips==oldnames and r['explicit_filter_excluded_cases']==sorted(oldnames)
 if 'mapped.v' in r['outputs']:
  hashes.append(r['outputs']['mapped.v']);cells=json.loads((p/'mapped.json').read_text())['modules'][r['top']]['cells'];assert len(cells)==r['mapped_cells']==13107 and all(c['type'].startswith('sg13g2_') for c in cells.values())
 rows.append({'scope':label,'result':pin(p/'result.json'),'counts':list(expected),'actual_case_names':names,'explicitly_excluded':skips,'output_pins_rehashed':len(r['outputs']),'mapped_cells':r.get('mapped_cells')})
assert hashes[0]==hashes[1]
mutations=[]
for p in sorted(Path('/dev/shm/nssoc-variable-tx-mutations-drain-final').glob('*/run')):
 if p.parent.is_symlink():continue
 r=json.loads((p/'result.json').read_text());assert r['status']=='FAIL';counts=count_results([p/'results.xml']);assert counts[0]+counts[1]==4 and counts[1]>0 and counts[2]==0
 assert 'AssertionError' in (p/'simulation.log').read_text()
 for n,h in r['outputs'].items():assert pin(p/n)==h
 mutations.append({'path':str(p),'result':pin(p/'result.json'),'counts':list(counts)})
assert len(mutations)==8
for count in range(0,257,2):
 assert (count>=31)==(count>=32)
 for ready in (False,True):
  left=count-(32 if ready and count>=32 else 0)
  for n in (0,66,98,130,162,194):
   after=left+(n if left+n<=256 else 0);assert 0<=after<=256 and after%2==0
record={'status':'CLEAN_BOUNDED_SOURCE_AND_CAPTURE_REVIEW','source_pins':{n:pin(ROOT/n) for n in ['hw/soc/rtl/pcie/soc_pcie_gen3_variable_tx.v','hw/soc/tb/cocotb/test_soc_pcie_gen3_variable_tx.py','scripts/check_pcie_gen3_variable_tx.py','sw/tests/test_pcie_gen3_variable_tx.py']},'old_three_bench':pin(old),'old_three_case_plus_helper_ast_unchanged':True,'identical_original_and_selected_mapped_netlist':hashes[0],'raw_replays':rows,'actual_eight_port_mutants':mutations,'reviewed_invariants':['Ten-bit capacity sum rejects overflow before storing a nine-bit0..256 count.','Mask removes all unused high payload bits before append; previously unused reservoir bits remain zero.','Simultaneous pop/push appends after the remaining serial queue; stalls preserve oldest word.','Invalid length codes are rejected and cannot advance count; reset/flush discard the reservoir.','Every accepted length and pop length is even, making reachable count even. Thus>=31 is equivalent to>=32; >=30 is observably wrong at residue30.','New drain case exercises all16 even residues. All old three native cases have unchanged AST and exact same mapped netlist.','Selected native run has exactly one new pass and three named exclusions; no exclusions are counted as passes.'],'scope':'Read-only review and saved raw XML/output/hash replay. No HDL/native rerun, full formal proof, ordered-set policy, full PCS or PHY qualification.','source_edits_by_reviewer':False,'no_remaining_blocker':True}
(B/'independent-review.json').write_text(json.dumps(record,indent=2)+'\n');print(pin(B/'independent-review.json'))
