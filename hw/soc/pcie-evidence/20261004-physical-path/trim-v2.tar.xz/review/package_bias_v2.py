# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,io,json,tarfile
from pathlib import Path
B=Path(__file__).resolve().parent;ROOT=B.parents[3];root=Path('/dev/shm/nssoc-clock-trim-bias-v2-fast')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files={}
for p in root.rglob('*'):
 if p.is_file() and p.name!='wave.dat.xz':files['native/'+root.name+'/'+str(p.relative_to(root))]=p
for n in ['scripts/characterize_pcie_clock_trim_bias_v2.py','sw/tests/test_pcie_clock_trim_bias_v2.py','scripts/characterize_pcie_clock_trim_v1.py','sw/tests/test_pcie_clock_trim_v1.py']:files['methods/'+n]=ROOT/n
for n in ['validation-bias-v2.json','bias-v2-period-diagnosis.json','review_bias_v2.py','review-bias-v2.log','tests-both.log','package_bias_v2.py','validation-v1.json']:files['review/'+n]=B/n
files['NOTICES.txt']=B/'NOTICES-v1.txt'
for n in ('Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0'):files['LICENSES/'+n+'.txt']=ROOT/'LICENSES'/f'{n}.txt'
inv={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()};path=B/'clock-trim-bias-v2-native-compact.tar.xz'
with tarfile.open(path,'w:xz') as tar:
 for n,p in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=p.stat().st_size;i.mode=0o644;i.mtime=0
  with p.open('rb') as f:tar.addfile(i,f)
 b=(json.dumps(inv,indent=2)+'\n').encode();i=tarfile.TarInfo('inventory.json');i.size=len(b);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(b))
with tarfile.open(path) as tar:
 for n,r in inv.items():
  with tar.extractfile(n) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==r['sha256']
out=dict(compact_capsule=dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path),members=len(inv)+1,roundtrip_verified=True),validation_sha256=sha(B/'validation-bias-v2.json'),root_native_result_sha256=sha(root/'result.json'),independent_peer_review=False)
(B/'package-bias-v2.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
