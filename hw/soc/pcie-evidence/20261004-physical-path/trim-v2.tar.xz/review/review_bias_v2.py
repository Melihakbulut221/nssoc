# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,tempfile,lzma,shutil
sys.path.insert(0,'scripts');import characterize_pcie_clock_trim_bias_v2 as v2
B=Path(__file__).resolve().parent;root=Path('/dev/shm/nssoc-clock-trim-bias-v2-fast');r=json.loads((root/'result.json').read_text());assert r['status']=='COMPLETE_NATIVE_BIAS_REVISION' and r['source_bytes_unchanged']
assert [x['case'] for x in r['cases']]==v2.cases('fast_pilot')
for p,h in r['source_sha256'].items():assert v2.old.sha(Path(p))==h
models=next(Path(p).parent for p in r['source_sha256'] if Path(p).name=='cornerHBT.lib');baseline=Path('/dev/shm/nssoc-clock-vco-full-20261004')
for row in r['cases']:
 c=row['case'];d=root/c['name'];text=v2.circuit(c);assert (d/v2.FILE).read_text()==text;hbts=v2.prior.driver.contract(text,4)
 assert (d/'bench.cir').read_text()==v2.deck(c,models,[baseline/n for n in v2.prior.driver.parent.init.MODELS],r['load_p_f'],r['load_n_f'],hbts)
 assert set(row['outputs'])=={p.name for p in d.iterdir()}
 for n,h in row['outputs'].items():assert v2.old.sha(d/n)==h
 log=(d/'run.log').read_text();assert v2.old.diagnostics(log)==row['numerical'] and row['numerical']['clean'];assert v2.prior.driver.flags(log,hbts)==row['flags_observed']
 op=v2.prior.driver.parent.init.startup.initial_op(d/'initial-op.dat',v2.prior.vectors(hbts));assert op==row['initial_op'] and max(map(abs,op.values()))<=1e-10
 assert row['execution']['returncode']==0 and row['execution']['address_space_limit_bytes']==2*1024**3 and row['execution']['cpu_affinity_count']==1
 with tempfile.TemporaryDirectory(prefix='nssoc-trim-bias-review-',dir='/dev/shm') as td:
  wave=Path(td)/'wave.dat'
  with lzma.open(d/'wave.dat.xz','rb') as src,wave.open('wb') as dst:shutil.copyfileobj(src,dst)
  assert v2.old.sha(wave)==row['uncompressed_wave_sha256'];data=v2.prior.read_wave(wave,hbts,c);assert v2.prior.measure(data,hbts,c)==row['measurement'];del data
sources=[Path(v2.__file__).resolve(),v2.old.ROOT/'sw/tests/test_pcie_clock_trim_bias_v2.py']
summary=dict(status='FROZEN_BOUNDED_BIAS_V2_WITH_REAL_REMAINING_FAILURE',source_sha256={str(p.relative_to(v2.old.ROOT)):v2.old.sha(p) for p in sources},result_sha256=v2.old.sha(root/'result.json'),native_cases=2,all_raw_waves_remeasured=2,focused_combined_tests=54,ruff='PASS',results=[dict(case=x['case']['name'],native_clean=x['clean_initialization'],screen_pass=x['measurement']['screen_pass'],frequency_hz=x['measurement']['frequency_hz'],period_spread=x['measurement']['period_spread'],failed_checks=[k for k,v in x['measurement']['checks'].items() if not v]) for x in r['cases']],conclusion='Doubling14 realbiasresistorwidths doesnot close the remaining fastcorner full4–12ns stability failure. Native thermal and bias trajectories are retained for diagnosis; no limits/window/model modifications. No7/7 orPLL/PEX acceptance.')
(B/'validation-bias-v2.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
