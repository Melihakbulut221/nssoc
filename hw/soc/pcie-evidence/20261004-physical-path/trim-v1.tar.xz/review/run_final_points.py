# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import sys
sys.path.insert(0,'scripts')
import characterize_pcie_clock_trim_v1 as t
corners=dict(t.driver.parent.TUNING)
plans=[('hot_bcs_ss',1,.90),('cold_bcs_ff',1,.80),('cold_bcs_ff',1,1.20),('high_supply_res_bcs_cap_bcs',2,.95)]
rows=[dict(t.old.BASE,**corners[name],name=f'{name}_code{code}_v{v:.2f}_halfstep',code=code,control=v,step_s=.5e-12) for name,code,v in plans]
rows += [dict(t.old.BASE,name=f'negative_{f}_code2',code=2,**({'trim_fault':'stuck_off'} if f=='stuck_off' else {'fault':f})) for f in ('stuck_off','no_feedback','same_clock')]
t.run('/dev/shm/nssoc-clock-vco-full-20261004','/dev/shm/nssoc-vco-zero-v2-full','hw/soc/out/pcie-clocked-bank-v3-20261004/capacitance-and-rc-review.json','/dev/shm/nssoc-clock-trim-final-points',64,'four_brackets_and_three_faults',rows,bias_factor=4)
