# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import sys
from pathlib import Path
sys.path.insert(0,'scripts')
import characterize_pcie_clock_trim_v1 as t
corners=dict(t.driver.parent.TUNING)
plans=[('nominal',1,.60),('nominal',1,1.00),('hot_bcs_ss',1,.60),('hot_bcs_ss',1,1.00),('cold_wcs_ss',1,.60),('cold_wcs_ss',1,1.00),('cold_bcs_ff',2,.80),('cold_bcs_ff',2,1.20),('hot_wcs_ff',0,1.10),('high_supply_res_bcs_cap_bcs',2,.85),('high_supply_res_bcs_cap_bcs',2,1.00)]
# Last two samples explicitly check the marginal highcorner1ps result at0.5ps.
rows=[dict(t.old.BASE,**corners[name],name=f'{name}_code{code}_v{v:.2f}_halfstep',code=code,control=v,step_s=.5e-12) for name,code,v in plans]
t.run('/dev/shm/nssoc-clock-vco-full-20261004','/dev/shm/nssoc-vco-zero-v2-full','hw/soc/out/pcie-clocked-bank-v3-20261004/capacitance-and-rc-review.json','/dev/shm/nssoc-clock-trim-targeted',64,'targeted_halfstep_brackets',rows,bias_factor=4)
