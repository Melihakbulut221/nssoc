# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import importlib.util,json,lzma,sys,tempfile,shutil,hashlib,statistics
sys.path.insert(0,'scripts');import characterize_pcie_clock_trim_v1 as final
B=Path(__file__).resolve().parent;base=Path('/dev/shm/nssoc-clock-vco-full-20261004')
modules={4:final}
for i in (1,2,3):
 p=B/f'phase{i}-method/characterize_pcie_clock_trim_v1.py';sp=importlib.util.spec_from_file_location('trim_phase'+str(i),p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);modules[i]=m
roots=[('pilot00',1),('pilot01',1),('pilot02',2),('gaps',3),('targeted',4),('final-points',4)]
review=[];allrows=[];waves=[];inputs={};native_files={}
canonical=str(Path(final.__file__).resolve())
for label,epoch in roots:
 root=Path('/dev/shm/nssoc-clock-trim-'+label);r=json.loads((root/'result.json').read_text());m=modules[epoch]
 assert r['status']=='COMPLETE_NATIVE_TRIM_EXPLORATION' and r['source_bytes_unchanged']
 for name,h in r['source_sha256'].items():
  p=Path(m.__file__) if name==canonical else Path(name)
  assert final.old.sha(p)==h,(str(p),h);inputs[str(p.resolve())]=h
 modelroot=next(Path(p).parent for p in r['source_sha256'] if Path(p).name=='cornerHBT.lib')
 for row in r['cases']:
  c=row['case'];d=root/c['name'];text=m.circuit(c,r['width_um']) if epoch==1 else m.circuit(c,r['width_um'],r['bias_factor'])
  assert (d/m.FILE).read_text()==text
  hbts=m.driver.contract(text,4)
  assert (d/'bench.cir').read_text()==m.deck(c,modelroot,[base/n for n in m.driver.parent.init.MODELS],r['load_p_f'],r['load_n_f'],hbts)
  assert set(row['outputs'])=={p.name for p in d.iterdir()}
  for n,h in row['outputs'].items():assert final.old.sha(d/n)==h,(str(d/n),h)
  assert row['clean_initialization'] and row['execution']['returncode']==0
  assert row['execution']['address_space_limit_bytes']==2*1024**3 and row['execution']['cpu_affinity_count']==1
  log=(d/'run.log').read_text();assert m.old.diagnostics(log)==row['numerical'] and row['numerical']['clean'];assert m.driver.flags(log,hbts)==row['flags_observed']
  op=m.driver.parent.init.startup.initial_op(d/'initial-op.dat',m.vectors(hbts));assert op==row['initial_op'] and max(map(abs,op.values()))<=1e-10
  with tempfile.TemporaryDirectory(prefix='nssoc-trim-replay-',dir='/dev/shm') as td:
   wave=Path(td)/'wave.dat'
   with lzma.open(d/'wave.dat.xz','rb') as src,wave.open('wb') as dst:shutil.copyfileobj(src,dst)
   assert final.old.sha(wave)==row['uncompressed_wave_sha256']
   data=m.read_wave(wave,hbts,c);assert m.measure(data,hbts,c)==row['measurement']
   if c.get('trim_fault')=='stuck_off':
    golden=dict(c);golden.pop('trim_fault');proof=m.measure(data,hbts,golden)
    assert row['measurement']['functional_clock_pass'] and not proof['checks']['native_trim_gate_rails'] and not proof['screen_pass']
   if c['fault']:assert not row['measurement']['functional_clock_pass']
   del data
  waves.append(str(d/'wave.dat.xz'))
  allrows.append(dict(dataset=label,epoch=epoch,case=c,measurement=row['measurement']))
  print(label,c['name'],'PASS_RAW_REPLAY',flush=True)
 review.append(dict(dataset=label,cases=len(r['cases']),numerically_clean=len(r['cases']),result_sha256=final.old.sha(root/'result.json')))
 for p in root.rglob('*'):
  if p.is_file():native_files['native/'+root.name+'/'+str(p.relative_to(root))]=str(p)
# Strict same-code, same-corner, passing-endpoint brackets only. No claim of lock
# or continuous safe coverage across the interval, nor full factorial corners.
brackets=[]
for label,mods in final.driver.parent.TUNING:
 matched=[]
 for row in allrows:
  c=row['case']
  if row['epoch']==1 or c['fault'] or c.get('trim_fault') or not row['measurement']['screen_pass']:continue
  if not c['name'].startswith(label+'_'):continue
  if not all(c[k]==v for k,v in mods.items()):continue
  matched.append(row)
 found=[]
 for code in (0,1,2):
  same=sorted([r for r in matched if r['case']['code']==code],key=lambda r:r['case']['control'])
  for a,b in zip(same,same[1:]):
   if a['case']['control']==b['case']['control']:continue
   fa,fb=[r['measurement']['frequency_hz'] for r in (a,b)]
   if min(fa,fb)<=8e9<=max(fa,fb):found.append(dict(code=code,control_v=[a['case']['control'],b['case']['control']],frequency_hz=[fa,fb],step_s=[a['case']['step_s'],b['case']['step_s']],evidence=[dict(dataset=r['dataset'],case=r['case']['name']) for r in (a,b)]))
 brackets.append(dict(corner=label,measured_brackets=found))
summary=dict(status='FINITE_NATIVE_SWITCHED_MIM_EXPERIMENT',source_sha256={str(p.relative_to(final.old.ROOT)):final.old.sha(p) for p in [Path(final.__file__).resolve(),final.old.ROOT/'sw/tests/test_pcie_clock_trim_v1.py']},datasets=review,total_native_executions=len(allrows),retained_full_waves_remeasured=len(waves),passing_positive_cases=sum(r['measurement']['screen_pass'] and not r['case']['fault'] and not r['case'].get('trim_fault') for r in allrows),failed_positive_cases=[dict(dataset=r['dataset'],case=r['case']['name'],checks=[k for k,v in r['measurement']['checks'].items() if not v]) for r in allrows if not r['case']['fault'] and not r['case'].get('trim_fault') and not r['measurement']['screen_pass']],seven_selected_corner_brackets=brackets,selected_corners_bracketed=sum(bool(r['measured_brackets']) for r in brackets),physical_qualification=False,pll_implemented=False,gen3_compliance=False,limitations=['All native MOS switches and MIM/resistor geometries are real model instances. Static control rails are external0/AVDD; no trim-controller or voltage-level-shifter implementation.', 'Every endpoint retains original4–12ns clock/minimumVCE limits and0–12ns maximumVCE/current constraints. Numerical clean initialization and all30OFF/zeroOP are separate mandatory evidence.', 'Pointwise1ps or0.5ps transients are not thermal steady state, phase-noise, jitter/lock or safe continuous VCTRL coverage. Rejected points remain explicit.', 'Old-bank opposed-aggressor collapsed capacitance only; no newbank layout/R/L, full PEX, actual receive load or full factorial PVT acceptance.', 'The bias conductance1 prototype fails period spread; accepted explored conductance4 candidate changes realrppdwidths, no thresholds or windows.', 'Same-code passing endpoints bracketing8GHz do not proveexact8GHz lock or PCIeppmcompliance.'])
(B/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(B/'audit-inventory.json').write_text(json.dumps(dict(inputs=inputs,native_files=native_files,waves=waves),indent=2)+'\n')
print('BRACKETED',summary['selected_corners_bracketed'],'OF7',flush=True)
