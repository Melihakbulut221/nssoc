# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,shutil,time
from pathlib import Path
B=Path(__file__).resolve().parent;target=B/'retained-waves';target.mkdir(exist_ok=True)
receipt=B/'wave-relocation.json';rows=json.loads(receipt.read_text()) if receipt.exists() else []
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for root in sorted(Path('/dev/shm').glob('nssoc-clock-trim-*')):
 if not (root/'result.json').exists():continue
 try:r=json.loads((root/'result.json').read_text())
 except json.JSONDecodeError:continue
 for c in r['cases']:
  if 'wave.dat.xz' not in c.get('outputs',{}):continue
  p=root/c['case']['name']/'wave.dat.xz'
  if p.is_symlink():continue
  assert sha(p)==c['outputs']['wave.dat.xz']
  dest=target/(root.name+'__'+c['case']['name']+'.dat.xz')
  assert not dest.exists()
  shutil.copyfile(p,dest);assert sha(dest)==sha(p);size=p.stat().st_size
  p.unlink();p.symlink_to(dest.resolve())
  rows.append(dict(original_path=str(p),storage_path=str(dest),bytes=size,sha256=c['outputs']['wave.dat.xz'],record_logical_output_bytes_unchanged=True))
receipt.write_text(json.dumps(rows,indent=2)+'\n');print(len(rows),sum(x['bytes'] for x in rows),flush=True)
