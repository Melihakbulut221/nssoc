# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,io,json,tarfile
from pathlib import Path
B=Path(__file__).resolve().parent;ROOT=B.parents[3]
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pack(path,members):
 inventory={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(members.items())}
 with tarfile.open(path,'w:xz',preset=6) as tar:
  for name,p in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
   with p.open('rb') as f:tar.addfile(info,f)
  data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 with tarfile.open(path) as tar:
  for name,row in inventory.items():
   h=hashlib.sha256();count=0
   with tar.extractfile(name) as f:
    while b:=f.read(1024*1024):h.update(b);count+=len(b)
   assert h.hexdigest()==row['sha256'] and count==row['bytes']
 return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path),members=len(inventory)+1,roundtrip_verified=True)
r=json.loads((B/'audit-inventory.json').read_text());compact={};waves={}
for name,text in r['native_files'].items():
 p=Path(text);(waves if p.name=='wave.dat.xz' else compact)[name]=p
for p,h in r['inputs'].items():
 path=Path(p);assert sha(path)==h
 if '/libs.tech/' in p:compact['inputs/libs.tech/'+p.split('/libs.tech/',1)[1]]=path
 elif path.suffix in ('.py','.json','.spice') and path.is_relative_to(ROOT):compact['inputs/project/'+str(path.relative_to(ROOT))]=path
for p in [ROOT/'scripts/characterize_pcie_clock_trim_v1.py',ROOT/'sw/tests/test_pcie_clock_trim_v1.py']:
 compact['methods/'+str(p.relative_to(ROOT))]=p
for p in B.glob('phase*-method/*.py'):compact['methods/'+str(p.relative_to(B))]=p
for name in ('summary.json','audit-inventory.json','prior-range.json','review_native.py','review-native.log','tests.log','run_targeted.py','run_final_points.py','resource-pause.json','resource-resume.json','wave-relocation.json','relocate_complete_waves.py','package_v1.py'):
 compact['review/'+name]=B/name
notices='''Switched-MIM clock-trim finite native experiment v1.\nProject Python/tests: Copyright2026 HasanMelihAkbulut, Apache-2.0.\nProject generated circuits: Copyright2026 HasanMelihAkbulut, CERN-OHL-W-2.0.\nIHP exactc4 PDK model/Verilog-A inputs retain their original source notices; IHP PDK Authors, Apache-2.0, with upstream PSP/R3 notices where present.\nNative logs, measurement receipts and review reports:2026 HasanMelihAkbulut, CC-BY-4.0.\nNo simulator/compiler executable is redistributed. Exact runtime hashes remain in every native result.\nFull retained waveforms are a separate source-bound archive. This compact capsule does not imply full-chip/PLL/PEX/PCIe qualification.\n'''
(B/'NOTICES-v1.txt').write_text(notices);compact['NOTICES.txt']=B/'NOTICES-v1.txt'
for license in ('Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0','BSD-3-Clause'):
 p=ROOT/'LICENSES'/f'{license}.txt'
 if p.exists():compact['LICENSES/'+p.name]=p
waveinv={n:dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for n,p in waves.items()}
(B/'wave-inventory-v1.json').write_text(json.dumps(waveinv,indent=2)+'\n');compact['review/wave-inventory-v1.json']=B/'wave-inventory-v1.json'
capsule=pack(B/'clock-trim-v1-native-compact.tar.xz',compact)
summary=json.loads((B/'summary.json').read_text());val=dict(status='FROZEN_FINITE_NATIVE_TRIM_V1',source_sha256=summary['source_sha256'],summary_sha256=sha(B/'summary.json'),compact_capsule=capsule,native_executions=42,all_retained_waves_author_remeasured=42,selected_corner_samecode8GHz_brackets=6,total_selected_corners=7,focused_tests=50,ruff='PASS',wave_bytes=sum(x['bytes'] for x in waveinv.values()),wave_manifest_sha256=sha(B/'wave-inventory-v1.json'),waves_publicly_archived=False,independent_peer_review=False)
(B/'validation-v1.json').write_text(json.dumps(val,indent=2)+'\n');print(json.dumps(val,indent=2))
