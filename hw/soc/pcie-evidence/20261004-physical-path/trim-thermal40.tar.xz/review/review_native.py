#!/usr/bin/env python3
"""Author raw-wave replay; explicitly not independent or new simulation."""
import hashlib,json,lzma,pathlib,shutil,sys,tempfile
sys.path.insert(0,'scripts')
import characterize_pcie_clock_trim_thermal_v1 as m
P=pathlib.Path('/dev/shm/nssoc-clock-trim-thermal40-v1')
B=pathlib.Path(__file__).resolve().parent
R=json.loads((P/'result.json').read_text())
assert m.old.sha(pathlib.Path(m.__file__))=='663d50d2f7efd2f611792d305ce03813f8c1d0ca1f21fd0d52866adb801aa324'
assert all(m.old.sha(pathlib.Path(p))==h for p,h in R['source_sha256'].items())
assert [r['case'] for r in R['cases']]==m.cases()
oldrow,oldpins=m.previous_failure('/dev/shm/nssoc-clock-trim-targeted')
assert R['previous12ns_native_failure']==oldrow
models=[pathlib.Path(p).parent for p in R['source_sha256'] if pathlib.Path(p).name=='cornerHBT.lib']
assert len(models)==1
checked=[]
for row in R['cases']:
 d=P/row['case']['name'];c=row['case']
 assert {p.name:m.old.sha(p) for p in d.iterdir() if p.is_file()}==row['outputs']
 assert (d/m.prior.FILE).read_text()==m.circuit(c)
 h=m.driver.contract(m.circuit(c),4)
 assert (d/'bench.cir').read_text()==m.deck(c,models[0],[pathlib.Path('/dev/shm/nssoc-clock-vco-full-20261004')/n for n in m.driver.parent.init.MODELS],R['load_p_f'],R['load_n_f'],h)
 log=(d/'run.log').read_text()
 assert m.old.diagnostics(log)==row['numerical']
 assert m.driver.flags(log,h)==row['flags_observed']
 assert m.driver.parent.init.startup.initial_op(d/'initial-op.dat',m.prior.vectors(h))==row['initial_op']
 assert row['zero_initial_op']==(max(map(abs,row['initial_op'].values()))<=1e-10)
 assert shutil.disk_usage('/dev/shm').free>=1100*1024**2
 with tempfile.TemporaryDirectory(prefix='nssoc-trim-thermal-replay-',dir='/dev/shm') as scratch:
  raw=pathlib.Path(scratch)/'wave.dat'
  with lzma.open(d/'wave.dat.xz','rb') as src,raw.open('wb') as dst:shutil.copyfileobj(src,dst)
  assert m.old.sha(raw)==row['uncompressed_wave_sha256']
  data=m.read_wave(raw,h,c);actual=m.measure(data,h,c);del data
  assert actual==row['measurement']
 checked.append(dict(case=c['name'],raw_replayed=True,clean=row['clean_initialization'],limited_thermal_screen_pass=actual['limited_thermal_screen_pass'],frequency_hz=actual['final_clock_window']['frequency_hz'],frequency_span_ppm=actual['convergence']['frequency_span_ppm'],max_final_thermal_rate_v_per_ns=actual['convergence']['max_final_thermal_rate_v_per_ns']))
 print('REPLAYED',c['name'],flush=True)
assert m.pair_agreement(R['cases'])==R['pair_agreement']
expected=all(r['clean_initialization'] and r['measurement']['limited_thermal_screen_pass'] for r in R['cases']) and R['pair_agreement']['pass_pair']
assert R['status']==('PASS_LIMITED40NS_THERMAL_SCREEN' if expected else 'FAIL_LIMITED40NS_THERMAL_SCREEN')
receipt=dict(status='PASS_EXACT_AUTHOR_RAW_REPLAY',native_status=R['status'],result_sha256=m.old.sha(P/'result.json'),producer_sha256=m.old.sha(pathlib.Path(m.__file__)),cases=checked,pair_agreement=R['pair_agreement'],independent_peer=False,old12ns_failure_preserved=True,physical_or_pll_acceptance=False)
(B/'raw-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
