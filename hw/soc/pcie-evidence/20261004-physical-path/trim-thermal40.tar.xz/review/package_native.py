#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import csv,hashlib,io,json,pathlib,tarfile
ROOT=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent
N=pathlib.Path('/dev/shm/nssoc-clock-trim-thermal40-v1')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((N/'result.json').read_text());replay=json.loads((B/'raw-replay.json').read_text())
assert replay['status']=='PASS_EXACT_AUTHOR_RAW_REPLAY' and replay['result_sha256']==sha(N/'result.json')
summary=dict(native_status=r['status'],actual_native_executions=2,all_raw_waves_author_replayed=2,independent_native_replay=False,independent_source_review=sha(B/'independent-preflight-review.json'),sources={p:sha(ROOT/p) for p in ('scripts/characterize_pcie_clock_trim_thermal_v1.py','sw/tests/test_pcie_clock_trim_thermal_v1.py')},pair_agreement=r['pair_agreement'],cases=[],prior12ns_failures_preserved=True,pll_or_pcie_acceptance=False)
for row in r['cases']:
 m=row['measurement'];summary['cases'].append(dict(name=row['case']['name'],clean_native=row['clean_initialization'],all_safety_checks_pass=all(m['safety_checks'].values()),original12ns_period_spread=m['original_4_to12ns_clock_window']['period_spread'],final32_to40ns_clock=m['final_clock_window'],convergence=m['convergence'],full_max_vce_v=max(x['full_capture_max_vce_v'] for x in m['full_capture']['devices'].values()),min_operating_vce_v=min(x['min_vce_v'] for x in m['full_capture']['devices'].values())))
 with (B/(row['case']['name']+'-trajectory.csv')).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['start_ns','end_ns','frequency_GHz','period_spread','max_abs_thermal_endpoint_rate_V_per_ns','XREF_thermal_start_V','XREF_thermal_end_V','XRB_thermal_start_V','XRB_thermal_end_V'])
  for win in m['consecutive2ns_windows']:
   w.writerow([x*1e9 for x in win['declared_window_s']]+[win['frequency_hz']/1e9 if win['frequency_hz'] else None,win['period_spread'],max(abs(n['signed_rate_v_per_ns']) for n in win['thermal_nodes'].values()),*[win['thermal_nodes'][node][key] for node in ('v(xosc.xref.t)','v(xosc.xrb.dt)') for key in ('start_v','end_v')]])
(B/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
notices='''Forty-nanosecond switched-MIM clock thermal diagnostic.\nCopyright 2026 Hasan Melih Akbulut. Project Python/tests: Apache-2.0. Generated native circuit/netlist sources: CERN-OHL-W-2.0. Native logs, waveforms, measurements, and evidence reports: CC-BY-4.0.\nNo executable or modified PDK is redistributed. Exact runtime and original IHP model hashes are recorded in result.json. Unchanged model sources are preserved in the separately pinned clock-trim-v1-native-compact.tar.xz (SHA cd0f6357d2dc3d2ef10c9e645f525caac274763d88ee3adea950bacd3e1a4f8f), retaining upstream IHP/PSP/R3 source notices.\nFull raw waveforms are retained separately, with their exact hashes in native result.json and the wave inventory. This diagnostic FAIL does not grant a PLL, PCIe, steady-state, physical-layout, or extracted-parasitic acceptance.\n'''
(B/'NOTICES.txt').write_text(notices)
members={}
for p in N.rglob('*'):
 if p.is_file() and p.name!='wave.dat.xz':members['native/'+str(p.relative_to(N))]=p
for p in B.iterdir():
 if p.is_file() and p.suffix in ('.json','.py','.log','.txt','.csv') and p.name not in ('validation.json','package.json','wave-inventory.json'):
  members['review/'+p.name]=p
for p,h in r['source_sha256'].items():
 p=pathlib.Path(p);assert sha(p)==h
 if p.is_relative_to(ROOT) and p.suffix in ('.py','.spice'):members['methods/'+str(p.relative_to(ROOT))]=p
for name in ('sw/tests/test_pcie_clock_trim_thermal_v1.py',):members['methods/'+name]=ROOT/name
for name in ('Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0'):
 p=ROOT/'LICENSES'/f'{name}.txt';members['LICENSES/'+p.name]=p
waves={str(p.relative_to(N)):dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in N.rglob('wave.dat.xz')}
(B/'wave-inventory.json').write_text(json.dumps(waves,indent=2)+'\n');members['review/wave-inventory.json']=B/'wave-inventory.json'
inventory={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(members.items())}
cap=B/'clock-trim-thermal40-v1-native-compact.tar.xz'
with tarfile.open(cap,'w:xz',preset=6) as t:
 for name,p in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
  with p.open('rb') as f:t.addfile(info,f)
 data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(data))
with tarfile.open(cap) as t:
 for name,pin in inventory.items():
  with t.extractfile(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==pin['sha256']
val=dict(status='FROZEN_NATIVE40NS_THERMAL_DIAGNOSTIC_FAIL',sources=summary['sources'],native_result_sha256=sha(N/'result.json'),author_replay_sha256=sha(B/'raw-replay.json'),compact_capsule=dict(path=str(cap),bytes=cap.stat().st_size,sha256=sha(cap),members=len(inventory)+1,roundtrip_verified=True),native_executions=2,native_clean=2,safety_pass=2,final_functional_pass=2,thermal_convergence_pass=0,tests=82,ruff='PASS',wave_bytes=sum(x['bytes'] for x in waves.values()),wave_inventory_sha256=sha(B/'wave-inventory.json'),independent_source_peer_only=True,old12ns_failure_preserved=True)
(B/'validation.json').write_text(json.dumps(val,indent=2)+'\n');print(json.dumps(val,indent=2))
