from pathlib import Path
import sys,json,hashlib,tarfile,io,gzip
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');sys.path.insert(0,str(ROOT/'scripts'))
import characterize_pcie_div4_v2 as d
B=ROOT/'hw/soc/out/pcie-div4-20261004';sha=lambda p:d.prior.old.sha(p)
roots={'pilot':Path('/dev/shm/nssoc-div4-v2-pilot'),'finite':Path('/dev/shm/nssoc-div4-v2-native-final')}
results={n:json.loads((p/'result.json').read_text()) for n,p in roots.items()};final=results['finite']
assert final['status'] in ('PASS_FINITE_DIV4_SCREEN','FAIL_FINITE_DIV4_SCREEN','FAIL_PRESERVED'),final['status']
assert final['complete_inputs_rechecked'] is True
assert [r['case'] for r in final['cases']]==d.cases('finite') and len(final['cases'])==12
assert len({r['case']['name'] for r in final['cases']})==12
d.verify_sources()
for p,h in final['source_sha256'].items():assert sha(Path(p))==h,p
replays=[]
for label in ('pilot','finite'):
 for row in results[label]['cases']:
  case=row['case'];p=roots[label]/case['name'];assert row['returncode']==0
  assert {x.name for x in p.iterdir()}==set(row['outputs'])
  for n,h in row['outputs'].items():assert sha(p/n)==h
  for n,txt in d.source_texts(case).items():assert (p/n).read_text()==txt
  pins=results[label]['source_sha256'];models=[Path(x).parent for x in pins if Path(x).name=='cornerHBT.lib'];osdi=[[Path(x) for x in pins if Path(x).name==n] for n in ('r3_cmc.osdi','psp103.osdi','psp103_nqs.osdi')];assert len(models)==1 and all(len(x)==1 for x in osdi)
  assert (p/'bench.cir').read_text()==d.deck(case,models[0],[x[0] for x in osdi])
  log=(p/'run.log').read_text();assert d.prior.old.diagnostics(log)==row['numerical'];assert row['numerical']['clean'];assert d.read_flags(log,case)==row['flags_observed'];assert d.initial_op(p/'initial-op.dat',case)==row['zero_initial_op']
  h=hashlib.sha256()
  with gzip.open(p/'wave.dat.gz','rb') as stream:
   while part:=stream.read(1048576):h.update(part)
  assert h.hexdigest()==row['uncompressed_wave_sha256']
  data=d.read_wave(p/'wave.dat.gz',case);measured=d.measure(data,case);del data
  assert json.loads(json.dumps(measured))==row['measurement'];assert d.accepted(row)==row['expected_outcome_observed']
  replays.append({'capture':label,'case':case,'raw_sha256':h.hexdigest(),'actual_native_result_pass':row['expected_outcome_observed'],'all60_flags_zero_op_and_full_measurement_replayed':True,'failed_checks':[k for k,v in measured['checks'].items() if not v]});print(label,case['name'],row['expected_outcome_observed'],'replayed',flush=True)
waves={};compact={}
for label,root in roots.items():
 compact['native/'+label+'/result.json']=(root/'result.json').read_bytes();compact['native/'+label+'/spinit']=(root/'spinit').read_bytes()
 for row in results[label]['cases']:
  p=root/row['case']['name']
  for n,h in row['outputs'].items():
   path=p/n;name='native/'+label+'/'+row['case']['name']+'/'+n
   if n=='wave.dat.gz':waves[name]={'path':str(path),'bytes':path.stat().st_size,'sha256':h}
   else:compact[name]=path.read_bytes()
for p in (d.CIRCUIT,Path(d.__file__),ROOT/'sw/tests/test_pcie_div4_v2.py',*d.FROZEN):compact['source/'+str(p.relative_to(ROOT))]=p.read_bytes()
for p in [B/'v2-tests-adjacent-final.log',B/'v2-tests-01.log',B/'v2-pilot.log',B/'v2-native-final.log',Path(__file__).resolve(),B/'validation.json',B/'full-waves-release.json',B/'native-wave-duplicate-cleanup.json']:
 compact['review/'+p.name]=p.read_bytes()
notice='Project native schematic/circuit files: Copyright 2026 Hasan Melih Akbulut, CERN-OHL-W-2.0. Python methods: Apache-2.0. Reports: CC-BY-4.0. Finite native schematic screens do not establish layout, PLL, CDR or PCIe qualification. Foundry model/runtime hashes are recorded; no runtime executable or compiled OSDI is redistributed. Original v1 failed pilot, two hot-corner failures and resource-stopped attempt remain preserved by their independently pinned capsule and public wave archive. V2 changes only four native resistor geometries and two native capacitor geometries.\n'.encode()
for license in ('Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0'):compact['LICENSES/'+license+'.txt']=(ROOT/'LICENSES'/f'{license}.txt').read_bytes()
compact['NOTICES.txt']=notice
wave_inventory={n:{k:v for k,v in item.items() if k!='path'} for n,item in waves.items()};(B/'v2-full-wave-member-manifest.json').write_text(json.dumps(waves,indent=2)+'\n')
archive=Path('/dev/shm/pcie-div4-v2-native-full-waves-20261004.tar');assert not archive.exists()
with tarfile.open(archive,'w') as tf:
 for name,item in sorted(waves.items()):
  p=Path(item['path']);assert sha(p)==item['sha256'];tf.add(p,arcname=name,recursive=False)
 for name,blob in [('inventory.json',(json.dumps(wave_inventory,indent=2)+'\n').encode()),('NOTICES.txt',notice)]:
  ti=tarfile.TarInfo(name);ti.size=len(blob);ti.mtime=0;tf.addfile(ti,io.BytesIO(blob))
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(waves)+2
 for n,item in wave_inventory.items():
  s=tf.extractfile(n);h=hashlib.sha256();size=0
  while part:=s.read(1048576):h.update(part);size+=len(part)
  assert h.hexdigest()==item['sha256'] and size==item['bytes']
compact['wave-manifest.json']=(json.dumps(wave_inventory,indent=2)+'\n').encode();inv={n:{'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()} for n,blob in compact.items()};compact['inventory.json']=(json.dumps(inv,indent=2)+'\n').encode();cp=B/'div4-v2-native-compact.tar.xz'
with tarfile.open(cp,'w:xz') as tf:
 for n,blob in sorted(compact.items()):ti=tarfile.TarInfo(n);ti.size=len(blob);ti.mtime=0;tf.addfile(ti,io.BytesIO(blob))
with tarfile.open(cp) as tf:
 assert len(tf.getmembers())==len(compact)
 for n,item in inv.items():blob=tf.extractfile(n).read();assert len(blob)==item['bytes'] and hashlib.sha256(blob).hexdigest()==item['sha256']
m={r['case']['name']:r['measurement'] for r in final['cases']};positives=[r for r in final['cases'] if not r['case']['fault']];negative=[r for r in final['cases'] if r['case']['fault']];delta=abs(m['nominal']['output_frequency_hz']/m['half_step']['output_frequency_hz']-1);assert delta<0.001
record={'schema':1,'status':final['status'],'sources':{str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (d.CIRCUIT,Path(d.__file__),ROOT/'sw/tests/test_pcie_div4_v2.py')},'frozen_reuse_sources':{str(p.relative_to(ROOT)):h for p,h in d.FROZEN.items()},'inputs':final['source_sha256'],'all_inputs_rechecked_by_author_after_capture':True,'native_results':{k:{'bytes':(p/'result.json').stat().st_size,'sha256':sha(p/'result.json'),'status':results[k]['status'],'case_count':len(results[k]['cases'])} for k,p in roots.items()},'exact_final_case_count':12,'clean_positive_passes':[r['case']['name'] for r in positives if r['expected_outcome_observed']],'clean_positive_failures':[r['case']['name'] for r in positives if not r['expected_outcome_observed']],'clean_actual_functional_negative_count':sum(r['expected_outcome_observed'] for r in negative),'full_waveform_author_replay_count':len(replays),'all_positive_and_negative_startups_clean':True,'native_census':{'hbt':60,'rppd':35,'cmim':12,'hv_pmos':1},'nominal':m['nominal'],'positive_metrics':{k:m[k] for k in [r['case']['name'] for r in positives]},'half_step_output_frequency_relative_delta':delta,'raw_replay':replays,'tests':{'focused_v2':19,'v1_plus_v2':48,'adjacent_total':104,'ruff_pass':True},'full_wave_capsule':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'wave_members':len(waves),'members':len(waves)+2,'roundtrip_member_hashes_verified':True},'compact_capsule':{'path':str(cp),'bytes':cp.stat().st_size,'sha256':sha(cp),'members':len(compact),'roundtrip_member_hashes_verified':True},'independent_peer_review':False,'limitations':['Finite schematic cases only, not full Cartesian PVT, mismatch, phase noise/jitter, extracted layout, frequency lock, PLL, CDR or PCIe qualification.','V2 changes four actual rppd and two actual CMIM geometries; all frozen HBT equations, VCO, latches, startup, native limits and metrology are preserved.','Minimum HBT0.4V applies only4–20ns operation. Upper1.6V/current3mA perNx checked full0–20ns.','Native faults retain correct first-stage divide and break second-stage behavior; numerical/electrical-only failures cannot count as functional-negative evidence.','Source-private reuse namespace is explicit; no imported frozen globals are modified.'],'physical_acceptance':False,'pll_implemented':False,'cdr_implemented':False}
(B/'v2-validation.json').write_text(json.dumps(record,indent=2)+'\n');print('SEALED',sha(B/'v2-validation.json'),archive.stat().st_size,cp.stat().st_size,flush=True)
