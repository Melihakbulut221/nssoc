#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Independent literal topology replay plus read-only native receipt/inventory audit."""
import collections,hashlib,json,pathlib,sys,tarfile
R=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent;A=B.parent
sys.path[:0]=[str(R/'hw/soc/flow'),str(R/'scripts')]
import make_pcie_clock_div4_v6 as gen
import check_pcie_clock_div4_v6 as check
import characterize_pcie_div4_v5 as analog

def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p):return dict(bytes=pathlib.Path(p).stat().st_size,sha256=sha(p))
source_paths=['hw/soc/flow/make_pcie_clock_div4_v6.py','hw/soc/flow/check_pcie_clock_div4_v6.py','sw/tests/test_pcie_clock_div4_v6_layout.py']
source_pins={p:pin(R/p) for p in source_paths}
assert source_pins[source_paths[0]]['sha256']=='c6ee777f3400325faba54fe6094fcdca137cd56bc33d32d8653d86355a1d2a84'
assert source_pins[source_paths[1]]['sha256']=='19879877f2e2a95ad04b90f097190c357a158d12e7770f80a004fcb7fe5bb718'
# Separate literal parser: preserve all four HBT pins, all resistor/capacitor
# geometries and every hierarchical formal/actual binding, not just census.
definitions={}
for path,h in gen.SOURCES.items():
 assert sha(R/path)==h
 active=None
 for line in (R/path).read_text().splitlines():
  w=line.lower().split()
  if not w or w[0].startswith('*'):continue
  if w[0]=='.subckt':
   assert active is None and w[1] not in definitions
   active=w[1];definitions[active]=(w[2:],[])
  elif w[0]=='.ends':assert w==['.ends',active];active=None
  else:assert active is not None;definitions[active][1].append(w)
 assert active is None
models={'npn13g2':('hbt',4),'rppd':('resistor',3),'cap_cmim':('capacitor',2),'sg13_hv_pmos':('pmos',4)}
expected={}
def descend(name,prefix,ports,stack=()):
 assert name not in stack
 formal,body=definitions[name];assert len(formal)==len(ports)
 env=dict(zip(formal,ports))
 def node(s):return env.get(s,prefix+'__'+s.upper())
 for w in body:
  ident=prefix+'__'+w[0].upper()
  if w[-1] in definitions:descend(w[-1],ident,[node(s) for s in w[1:-1]],stack+(name,));continue
  model=next(m for m,(_,n) in models.items() if len(w)>n+1 and w[n+1]==m)
  kind,n=models[model];params=dict(t.split('=') for t in w[n+2:])
  e=dict(kind=kind,name=ident,nets=[node(s) for s in w[1:n+1]],source_subcircuit=name.upper(),source_instance=w[0].upper())
  if kind=='hbt':e['nx']=int(params['nx'])
  else:
   e.update(width_um=float(params['w'][:-1]),length_um=float(params['l'][:-1]))
   if kind=='pmos':e['ng']=int(params['ng'])
  assert ident not in expected;expected[ident]=e
descend('nssoc_clock_vco_hbt_v3','OSC',['CLKP','CLKN','VCTRL','VCO_AVDD','AVSS','SUB'])
descend('nssoc_clock_div4_hbt_v5','DIV',['CLKP','CLKN','QP','QN','DIV_AVDD','AVSS','SUB'])
actual={r['name']:r for r in gen.devices(R)};assert actual==expected
assert collections.Counter(r['kind'] for r in expected.values())==dict(hbt=64,resistor=42,capacitor=12,pmos=1)
L=pathlib.Path('/dev/shm/nssoc-div4-v6-layout-01');N=pathlib.Path('/dev/shm/nssoc-div4-v6-checks-01')
l=json.loads((L/'result.json').read_text());n=json.loads((N/'result.json').read_text())
assert n['status']=='PASS_DIV4_V6_COMPOSITE_MAIN_DRC_STRICT_DEEP_FLAT_LVS_LEF_NEGATIVE_CONTROLS_ONLY'
assert len(l['instances'])==150 and len(expected)==119
for row in l['instances']:
 if row['name'] in expected:assert {k:row[k] for k in expected[row['name']]}==expected[row['name']]
assert collections.Counter(row['kind'] for row in l['instances'])==dict(hbt=64,resistor=42,capacitor=12,pmos=1,substrate_tap=30,well_tap=1)
assert l['bbox_um']==[0,0,1520.0,1317.03] and len(l['ports'])==9
reference=(L/'schematic.cir').read_text();assert reference==gen.physical_reference(R)
rows={w[0]:w for line in reference.splitlines() if (w:=line.split()) and not w[0].startswith(('*','.'))}
for ident,e in expected.items():
 prefix={'hbt':'Q','resistor':'R','capacitor':'C','pmos':'M'}[e['kind']]
 w=rows[prefix+ident];nets=['BULK' if s=='SUB' else s for s in e['nets']]
 if e['kind']=='pmos':assert nets[-1]=='VCO_AVDD';nets[-1]='NWELL'
 assert w[1:1+len(nets)]==nets
 assert not any(n=='VCO_AVDD' for n in nets) if ident.startswith('DIV__') else True
assert len(rows)==150
assert all(rows[f'RTAP{i}'][1:]==['SUB','BULK','ptap1','A=4p','P=8u'] for i in range(30))
assert rows['RNTAP'][1:]==['VCO_AVDD','NWELL','ntap1','A=4p','P=8u']
# Crosscheck reached HBT C/B/E and Nx against the frozen simulation producer.
analog.verify_sources();hbt,rpaths=analog.device_contract(analog.cases('finite')[0])
def native_name(s):return s.replace('OSC__','xosc.',1).replace('DIV__','xdiv.',1).replace('__','.').lower()
def simnode(s):return {'VCO_AVDD':'avdd','DIV_AVDD':'dvdd','AVSS':'0','SUB':'0'}.get(s,native_name(s))
assert {native_name(k):(tuple(simnode(x) for x in e['nets'][:3]),e['nx']) for k,e in expected.items() if e['kind']=='hbt'}==hbt
assert {native_name(k) for k,e in expected.items() if e['kind']=='resistor'}==set(rpaths)
for path,h in n['inputs'].items():assert sha(path)==h,path
assert {str(p.relative_to(N)) for p in N.rglob('*') if p.is_file() and p!=N/'result.json'}==set(n['outputs'])
for path,h in n['outputs'].items():assert sha(N/path)==h
for path,h in l['output_sha256'].items():assert sha(L/path)==h
steps={s['name']:s for s in n['steps']};assert len(steps)==21
for name in ['lvs','lvs_flat',*check.REFERENCE_FAULTS,*check.PHYSICAL_FAULTS]:
 s=steps[name];assert s['execution']['returncode']==0
 assert s['audit']==json.loads((N/name/'audit.json').read_text())
 check.validate_lvs(s,(N/name/'extracted.cir').read_text(),name in ['lvs','lvs_flat'])
assert steps['drc']['measurement']['category_count']==560 and steps['drc']['measurement']['status']=='PASS'
assert steps['offgrid']['measurement']['categories']['metal1_drw_Offgrid']>0
assert steps['lef']['execution']['returncode']==0
assert all(steps[k]['execution']['returncode']!=0 for k in ['lef_missing_pin','lef_blocked_pin'])
# Independent native geometry replay is separate from the producer/checker.
geometrical=json.loads((B/'geometry-audit.json').read_text())
assert geometrical['exact_primitive_instances']==150 and geometrical['all_primitive_layer_xor_zero'] and geometrical['all_ports_on_real_conductors'] and geometrical['whole_obstruction_regions_exact']
assert geometrical['gds_sha256']==sha(L/(gen.TOP+'.gds')) and geometrical['lef_sha256']==sha(L/(gen.TOP+'.lef'))
for p,h in geometrical['sources'].items():assert sha(p)==h
for name,info in geometrical['peripheral_fault_geometry'].items():
 assert info['exact_intended_geometric_difference'] and info['gds_sha256']==sha(N/name/'wrong.gds')
 assert steps[name]['audit']['circuit_status_counts']=={'NoMatch':1}
 assert not steps[name]['audit']['extraction_diagnostics']
 assert steps[name]['audit']['circuits'][0]['layout_devices_recursive']==(109 if name=='row_trunk_open' else 108)
 assert steps[name]['audit']['circuits'][0]['schematic_devices_recursive']==109
# The real short joins two Nx2 m4 sink groups into one m8 group, not lost devices.
for name in ('lvs','row_trunk_open','row_trunk_short'):
 q=[line.split() for line in (N/name/'extracted.cir').read_text().splitlines() if line.startswith('Q')]
 expanded=collections.Counter()
 for w in q:
  p=dict(x.split('=') for x in w[6:]);expanded[int(p['Nx'])]+=int(p['m'])
 assert expanded==collections.Counter({1:5,2:35,4:24})
 if name=='row_trunk_short':
  joined=[w for w in q if 'm=8' in w]
  assert len(joined)==1 and joined[0][1]=='CLKN|CLKP' and joined[0][3]=='AVSS' and 'Nx=2' in joined[0]
for name in ('lvs','lvs_flat'):
 a=steps[name]['audit'];assert a['circuit_status_counts']=={'Match':1} and not a['reasons'] and not a['extraction_diagnostics']
# Reference change is only physical top name, not an analog modification.
import make_pcie_clock_div4_v5 as old
assert old.devices(R)==gen.devices(R)
assert old.physical_reference(R).replace(old.TOP,gen.TOP)==reference
assert source_pins=={p:pin(R/p) for p in source_paths}
result=dict(status='CLEAN_BOUNDED_INDEPENDENT_DIV4_V6_NATIVE_GEOMETRY_TOPOLOGY_REVIEW',sources=source_pins,layout_result=pin(L/'result.json'),native_result=pin(N/'result.json'),independent_literal_primitive_count=len(expected),all_primitive_parameters_and_nets_match=True,analog_HBT_CBE_Nx_exact=True,analog_resistor_identities_exact=True,unchanged_frozen_v5_analog_and_reference=True,separate_VCO_DIV_rails=True,finite_substrate_and_nwell_contacts=True,native_input_count=len(n['inputs']),native_output_count=len(n['outputs']),saved_native_deep_flat_lvs=True,comparison_devices=109,expanded_HBTs=64,saved_main_DRC_rule_categories=560,reference_faults=len(check.REFERENCE_FAULTS),physical_faults=len(check.PHYSICAL_FAULTS),additional_offgrid_and_lef_negatives=3,geometry_audit=pin(B/'geometry-audit.json'),peripheral_trunk_faults=geometrical['peripheral_fault_geometry'],bbox_um=l['bbox_um'],blockers=[],reviewer_history=dict(first_attempt_source=pin(B/'review-first.py'),first_attempt_log=pin(B/'review-first.log'),cause='Reviewer expected109 devices for short as well as open; actual native short correctly merges two m4 sinks into one m8,108 comparisonrecords. Raw failure retained; production method unchanged.'),review_scope=['Independent recursive parse of all119 native primitives and every formal/actual net/geometry; exact original v5 circuit/reference comparison','Rehashed all210 native inputs and141 complete native outputs; reparsed bothpositive and14LVSnegatives plusDRC/LEF results','Actually reran150 nativePCell all-layer zero-XOR readback,9 conductor/pin/label checks and exact7-layerLEF obstruction union','Independently measured actual cross-row clock-trunk open/short GDS differences, only Metal4 changed and exact intended geometric regions; open has109 comparisondevices, short108 after exact two Nx2 m4 sink groups merge to m8; expanded64HBT census remains unchanged'],limitations=['No native DRC/LVS or functional simulation rerun by this reviewer','Reviewer authored earlier analog divider source, not newphysical v6 generator/checker','1520x1317.03um route footprint remains unqualified for extracted clock/load/performance/current','No PLL/CDR/mainchip/fullPHY/PEX/manufacturing acceptance'],review_script=pin(__file__))
(B/'independent-review.json').write_text(json.dumps(result,indent=2)+'\n');print(pin(B/'independent-review.json'))
