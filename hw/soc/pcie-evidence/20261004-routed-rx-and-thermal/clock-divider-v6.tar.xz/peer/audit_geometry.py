#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Native read-only exact PCell geometry and complete seven-layer obstruction audit."""
import hashlib,json,pathlib,re,sys,xml.etree.ElementTree as ET
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT/'hw/soc/flow'))
import make_pcie_clock_div4_v6 as m
pdk=pathlib.Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
source=pdk/'libs.tech/klayout/python';sys.path[:0]=[str(source),str(source/'pycell4klayout-api/source/python')];sys.dont_write_bytecode=True
import pya
import sg13g2_pycell_lib
folder=pathlib.Path('/dev/shm/nssoc-div4-v6-layout-01');generated=json.loads((folder/'result.json').read_text())
assert all(m.sha(p)==h for p,h in generated['input_sha256'].items())
assert all(m.sha(folder/p)==h for p,h in generated['output_sha256'].items())
l=pya.Layout();l.read(str(folder/(m.TOP+'.gds')));top=l.cell(m.TOP);expected=pya.Layout()
assert l.dbu==expected.dbu
models=dict(hbt='npn13G2',resistor='rppd',capacitor='cmim',pmos='pmosHV',substrate_tap='ptap1',well_tap='ntap1')
dx,dy=generated['origin_translation_um'];rows=[]
for row in generated['instances']:
 model=models[row['kind']]
 if row['kind']=='hbt':params={'Nx':row['nx']}
 elif row['kind'] in ('substrate_tap','well_tap'):params={'w':'2u','l':'2u'}
 else:
  params={'w':f"{row['width_um']:g}u",'l':f"{row['length_um']:g}u"}
  if row['kind']=='pmos':params['ng']=row['ng']
 cell=expected.create_cell(model,'SG13_dev',params);assert cell and not cell.is_empty()
 x,y=row['placement_um'];trans=pya.Trans(round((x+dx)/l.dbu),round((y+dy)/l.dbu))
 matches=[i for i in top.each_inst() if i.trans==trans and i.cell.name.startswith(model)]
 assert len(matches)==1,(row['name'],model,str(trans),len(matches));actual=matches[0].cell
 layerkeys={(l.get_info(i).layer,l.get_info(i).datatype) for i in l.layer_indices()}|{(expected.get_info(i).layer,expected.get_info(i).datatype) for i in expected.layer_indices()}
 for layer,datatype in layerkeys:
  a=pya.Region(actual.begin_shapes_rec(l.layer(layer,datatype)));b=pya.Region(cell.begin_shapes_rec(expected.layer(layer,datatype)))
  assert (a^b).is_empty(),(row['name'],layer,datatype)
 rows.append(dict(name=row['name'],kind=row['kind'],native_cell=actual.name,exact_all_layer_xor_zero=True))
layers={prop.findtext('name')[:-8]:int(prop.findtext('source').split('/')[0]) for prop in ET.parse(source.parent/'tech/sg13g2.lyp').getroot().iter('properties') if prop.findtext('name','').endswith('.drawing')}
for name,pin in generated['ports'].items():
 layer=layers[pin['layer']];box=pya.DBox(*pin['rect_um']).to_itype(l.dbu)
 assert (pya.Region(box)-pya.Region(top.begin_shapes_rec(l.layer(layer,0)))).is_empty()
 pinregion=pya.Region(top.shapes(l.layer(layer,2)))
 assert (pya.Region(box)-pinregion).is_empty()
 labels=[s.dtext for s in top.shapes(l.layer(layer,25)).each() if s.is_text() and s.dtext.string==name]
 assert len(labels)==1 and box.contains(labels[0].trans.disp.to_itype(l.dbu))
text=(folder/(m.TOP+'.lef')).read_text();obs=text.split('  OBS\n')[1].split('  END\n')[0]
parsed={};current=None
for line in obs.splitlines():
 w=line.split()
 if w[0]=='LAYER':current=w[1];assert current not in parsed;parsed[current]=pya.Region()
 elif w[0]=='RECT':parsed[current].insert(pya.DBox(*map(float,w[1:5])).to_itype(l.dbu))
 else:raise AssertionError(line)
assert set(parsed)=={'Metal1','Metal2','Metal3','Metal4','Metal5','TopMetal1','TopMetal2'}
for metal,region in parsed.items():
 desired=pya.Region(pya.DBox(*generated['bbox_um']).to_itype(l.dbu))
 for pin in generated['ports'].values():
  if pin['layer']==metal:desired-=pya.Region(pya.DBox(*pin['rect_um']).to_itype(l.dbu))
 assert (region^desired).is_empty(),metal
faults={}
for fault in ('row_trunk_open','row_trunk_short'):
 f=pathlib.Path('/dev/shm/nssoc-div4-v6-checks-01')/fault/'wrong.gds'
 ml=pya.Layout();ml.read(str(f));mt=ml.cell(m.TOP)
 delta_layers=[]
 for layer,datatype in {(l.get_info(i).layer,l.get_info(i).datatype) for i in l.layer_indices()}|{(ml.get_info(i).layer,ml.get_info(i).datatype) for i in ml.layer_indices()}:
  ar=pya.Region(top.begin_shapes_rec(l.layer(layer,datatype)));br=pya.Region(mt.begin_shapes_rec(ml.layer(layer,datatype)))
  if not (ar^br).is_empty(): delta_layers.append([layer,datatype])
 assert delta_layers==[[50,0]],(fault,delta_layers)
 ar=pya.Region(top.begin_shapes_rec(l.layer(50,0)));br=pya.Region(mt.begin_shapes_rec(ml.layer(50,0)))
 p,n=(generated['peripheral_trunks'][k] for k in ('CLKP','CLKN'))
 low=max(p['lower_y_um'],n['lower_y_um']);high=min(p['upper_y_um'],n['upper_y_um'])
 assert high-low>10
 y=round((low+high)/2/.005)*.005+dy;x=p['x_um']+dx;xn=n['x_um']+dx
 if fault=='row_trunk_open':
  expected_delta=ar&pya.Region(pya.DBox(x-.8,y-.1,x+.8,y+.1).to_itype(l.dbu))
  actual_delta=ar-br;assert (br-ar).is_empty()
 else:
  box=pya.Region(pya.DBox(min(x,xn)-.1,y-.3,max(x,xn)+.1,y+.3).to_itype(l.dbu))
  expected_delta=box-ar;actual_delta=br-ar;assert (ar-br).is_empty()
 assert not actual_delta.is_empty() and (expected_delta^actual_delta).is_empty()
 faults[fault]=dict(only_changed_layer=[50,0],exact_intended_geometric_difference=True,changed_area_um2=actual_delta.area()*l.dbu*l.dbu,gds_sha256=m.sha(f))
result=dict(peripheral_fault_geometry=faults,status='PASS_EXACT_NATIVE_PCELL_PORT_AND_OBSTRUCTION_GEOMETRY',sources={str(pathlib.Path(__file__).resolve()):m.sha(__file__),str(pathlib.Path(m.__file__).resolve()):m.sha(m.__file__)},generated_result_sha256=m.sha(folder/'result.json'),gds_sha256=m.sha(folder/(m.TOP+'.gds')),lef_sha256=m.sha(folder/(m.TOP+'.lef')),instances=rows,exact_primitive_instances=len(rows),physical_ports=len(generated['ports']),obstruction_layers=sorted(parsed),all_primitive_layer_xor_zero=True,all_ports_on_real_conductors=True,whole_obstruction_regions_exact=True,no_drc_lvs_or_performance_rerun=True)
B=pathlib.Path(__file__).resolve().parent;(B/'geometry-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'])
