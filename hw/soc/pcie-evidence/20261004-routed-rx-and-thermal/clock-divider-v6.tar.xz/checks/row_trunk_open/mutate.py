import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v6-layout-01/nssoc_clock_div4_v6_layout.gds')
c=l.cell('nssoc_clock_div4_v6_layout')
region=pya.Region(c.shapes(l.layer(50,0)))
region-=pya.Region(pya.DBox(1507.2,480.92999999999995,1508.8,481.13).to_itype(l.dbu))
c.shapes(l.layer(50,0)).clear()
c.shapes(l.layer(50,0)).insert(region)
l.write('/dev/shm/nssoc-div4-v6-checks-01/row_trunk_open/wrong.gds')
