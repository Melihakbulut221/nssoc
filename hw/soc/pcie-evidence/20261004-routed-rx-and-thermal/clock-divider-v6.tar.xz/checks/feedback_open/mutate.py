import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v6-layout-01/nssoc_clock_div4_v6_layout.gds')
c=l.cell('nssoc_clock_div4_v6_layout')
region=pya.Region(c.shapes(l.layer(30,0)))
region-=pya.Region(pya.DBox(1077.3600000000001,1094.55,1077.56,1095.1499999999999).to_itype(l.dbu))
c.shapes(l.layer(30,0)).clear()
c.shapes(l.layer(30,0)).insert(region)
l.write('/dev/shm/nssoc-div4-v6-checks-01/feedback_open/wrong.gds')
