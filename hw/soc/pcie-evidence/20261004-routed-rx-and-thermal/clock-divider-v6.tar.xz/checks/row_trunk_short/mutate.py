import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v6-layout-01/nssoc_clock_div4_v6_layout.gds')
c=l.cell('nssoc_clock_div4_v6_layout')
c.shapes(l.layer(50,0)).insert(pya.DBox(1503.9,480.72999999999996,1508.1,481.33))
l.write('/dev/shm/nssoc-div4-v6-checks-01/row_trunk_short/wrong.gds')
