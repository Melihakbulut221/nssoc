import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v6-layout-01/nssoc_clock_div4_v6_layout.gds')
c=l.cell('nssoc_clock_div4_v6_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(0.5,96.03,1.5,616.03))
l.write('/dev/shm/nssoc-div4-v6-checks-01/rails_short/wrong.gds')
