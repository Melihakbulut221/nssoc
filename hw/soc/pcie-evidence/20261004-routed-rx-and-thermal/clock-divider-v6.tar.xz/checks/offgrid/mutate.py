import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-div4-v6-layout-01/nssoc_clock_div4_v6_layout.gds')
c=l.cell('nssoc_clock_div4_v6_layout')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-div4-v6-checks-01/offgrid/wrong.gds')
