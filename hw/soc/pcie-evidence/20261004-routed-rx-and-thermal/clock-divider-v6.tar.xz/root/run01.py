# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import subprocess,resource,json,hashlib,time,sys
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');B=Path(__file__).parent;APP=ROOT/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage';PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2');OUT=Path('/dev/shm/nssoc-div4-v6-layout-01')
GEN=ROOT/'hw/soc/flow/make_pcie_clock_div4_v6.py';CHECK=ROOT/'hw/soc/flow/check_pcie_clock_div4_v6.py'
def pin(p):
 with p.open('rb') as f:return {'bytes':p.stat().st_size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()}
def limit():resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
r={'status':'RUNNING','inputs':{str(p):pin(p) for p in [Path(__file__),GEN,CHECK,APP]},'steps':[],'acceptance':False}
def save():(B/'result01.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 for name,cmd in [('generate',[str(APP),'python',str(GEN),'--pdk',str(PDK),'--out',str(OUT)]),('check',[sys.executable,str(CHECK),'--pdk',str(PDK),'--layout',str(OUT),'--out','/dev/shm/nssoc-div4-v6-checks-01'])]:
  t=time.monotonic();row={'name':name,'command':cmd};r['steps'].append(row);save()
  with (B/(name+'01.log')).open('x') as f:row['returncode']=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=limit).returncode
  row['seconds']=time.monotonic()-t;row['log']=pin(B/(name+'01.log'));save();assert row['returncode']==0,(name,row['returncode'])
 assert r['inputs']=={p:pin(Path(p)) for p in r['inputs']};r['status']='NATIVE_COMPLETE_REVIEW_REQUIRED'
except BaseException as e:r.update(status='FAILED_RETAINED',error=repr(e));raise
finally:save()
