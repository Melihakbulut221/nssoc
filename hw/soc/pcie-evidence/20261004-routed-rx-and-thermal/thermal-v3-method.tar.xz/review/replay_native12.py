#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,io,json,lzma,pathlib,struct,sys,tarfile,urllib.request
ROOT=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import characterize_pcie_clock_trim_stream_v3 as m
u='https://github.com/Melihakbulut221/nssoc/releases/download/evidence-20260927-chip-io/clock-trim-longstream-v2-source-native-controls.tar.xz'
packed=urllib.request.urlopen(u,timeout=60).read();assert len(packed)==20307204 and hashlib.sha256(packed).hexdigest()=='ab547ab5274d4753d84dace499df580ef83f4a5e04c958a8d7141d7770dc8978'
with tarfile.open(fileobj=io.BytesIO(packed)) as tar:
 inventory=json.load(tar.extractfile('inventory.json'))
 for n,p in inventory.items():
  with tar.extractfile(n) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==p['sha256']
 result=json.load(tar.extractfile('native-final/result.json'));cap=result['capture'];ledger=json.load(tar.extractfile('native-final/backpressure/capture/parts/parts.json'))
 circuit=tar.extractfile('native-final/backpressure/'+m.base.prior.FILE).read().decode();hbts=m.base.driver.contract(circuit,4);case=m.base.cases()[0]
 meter=m.Meter(cap['columns'],hbts,case,12e-9);payload=hashlib.sha256();count=0
 for p in ledger['parts']:
  b=tar.extractfile('native-final/backpressure/capture/parts/'+p['name']).read();assert hashlib.sha256(b).hexdigest()==p['sha256']
  raw=lzma.decompress(b);assert hashlib.sha256(raw).hexdigest()==p['uncompressed_sha256'] and len(raw)==p['rows']*167*8
  for row in struct.iter_unpack('<'+'d'*167,raw):meter.push(row);count+=1
  payload.update(raw)
 measure=meter.finish();legacy={k:v for k,v in measure.items() if k not in ('phase_convergence','phase_invariant_screen_pass')}
 assert legacy==cap['measurement'];assert count==24011 and payload.hexdigest()==cap['payload_sha256']
 log=tar.extractfile('native-final/backpressure/run.log').read().decode();native=m.classify_log(log,cap,hbts,m.NG47_SHA,.5e-12,0)
 assert native['original_strict_diagnostics']['clean'] and not native['informational_memory_advisories']
 record=dict(status='PASS_EXACT_ACTUAL12NS_CAPTURE_REPLAY_OLD_FAILURE_PRESERVED',source_sha256=m.sha(m.__file__),capsule=dict(url=u,sha256=hashlib.sha256(packed).hexdigest(),bytes=len(packed),all_members_rehashed=len(inventory)),rows=count,values=count*167,all_old_measurements_identical=True,legacy_screen_pass=measure['limited_thermal_screen_pass'],new_phase_screen_pass=measure['phase_invariant_screen_pass'],native=native,external_uploads=0,native_runs=0,all_phase_states=len(measure['phase_convergence']['thermal_nodes']))
 (B/'native12-measurements.json').write_text(json.dumps(measure,indent=2)+'\n');(B/'native12-review.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2)[:2000])
