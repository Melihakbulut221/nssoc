#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import pathlib,json,hashlib,sys
ROOT=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import characterize_pcie_clock_trim_stream_v3 as m
N=pathlib.Path('/dev/shm/nssoc-clock-trim-thermal1us-stream-v2-20261004');r=json.loads((N/'result.json').read_text());c=r['cases'][0];f=N/c['case']['name'];log=(f/'run.log').read_text();h=m.base.driver.contract((f/m.base.prior.FILE).read_text(),4)
positive=m.classify_log(log,c['capture'],h,m.NG47_SHA,.5e-12,0)
assert not positive['original_strict_diagnostics']['clean'] and len(positive['informational_memory_advisories'])==1
mutations={'extra_warning':log+'\nWarning: physical model voltage out of range\n','late_error':log+'\nError: transient failed\n','nan':log+'\nNaN in thermal model\n','wrong_estimate':log.replace('2.4885 GB','2.5000 GB'),'wrong_count':log.replace('167 nodes and','168 nodes and'),'duplicate_advisory':log+positive['informational_memory_advisories'][0]['literal'],'incomplete_count':log.replace('No. of Data Rows : 2000011','No. of Data Rows : 2000010'),'wrong_off':log.replace('off                     1','off                     0',1),'resident_transient':log.replace('Current op1','Current tran1'),'nonzero_initial_plot':log.replace('real, 1 long','real, 2 long',1)}
negative={}
for name,text in mutations.items():
 try:m.classify_log(text,c['capture'],h,m.NG47_SHA,.5e-12,0)
 except ValueError as e:negative[name]=str(e)
 else:raise AssertionError(name)
record=dict(status='PASS_ACTUAL_LOG_CLASSIFICATION_AND10_MUTATIONS',source_sha256=m.sha(m.__file__),raw_log_sha256=m.sha(f/'run.log'),original_result_sha256=m.sha(N/'result.json'),positive=positive,negatives=negative,source_warning_proof=m.WARNING_SOURCE,original_file_unchanged=True,original_controller_error_unchanged=r['error'],native_rerun=False)
(B/'actual-warning-review.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'])
