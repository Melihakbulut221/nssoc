import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')
c=l.cell('nssoc_pcie_padded_clocked_bank4_v1')
matches=[i for i in c.each_inst() if i.dbbox().center()==pya.DPoint(2890.0,220.0) and not pya.Region(l.cell(i.cell_index).begin_shapes_rec(l.layer(133,0))).is_empty()]
if len(matches)!=1:raise ValueError('Native via witness does not bind once')
native=matches[0]
for xx in [2890.0, 1530.0]:
 t=native.dtrans; t.disp=pya.DVector(t.disp.x+xx-2890.0,t.disp.y+3430.0-220.0); c.insert(pya.DCellInstArray(native.cell_index,t))
c.shapes(l.layer(67,0)).insert(pya.DBox(1530.0,3429.0,2890.0,3431.0))
l.write('/dev/shm/nssoc-padded-clocked-checks-02/return_avss_short/wrong.gds')
