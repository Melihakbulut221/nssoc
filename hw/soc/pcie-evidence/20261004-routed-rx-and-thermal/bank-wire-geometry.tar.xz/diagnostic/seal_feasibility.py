# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Seal native geometry feasibility, explicitly excluding any Magic R/C claim."""
from pathlib import Path
import hashlib,json,tarfile
B=Path(__file__).parent
ROOT=Path.cwd()
def pin(p):
 p=Path(p);return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files={}
for p in B.iterdir():
 if p.suffix in ('.py','.json','.log') and p.name not in ('validation.json',):files['diagnostic/'+p.name]=p
for label,folder in [('initial_no_ports','nssoc-bank-wire-native-unsimplified-v1'),('complete_native','nssoc-bank-wire-native-unsimplified-v2'),('wire_geometry','nssoc-bank-wire-geometry-probe-v2')]:
 folder=Path('/dev/shm')/folder
 for p in folder.iterdir():
  if p.is_file():files[label+'/'+p.name]=p
for name in ['nssoc_pcie_padded_clocked_bank4_v1.gds','schematic.cir','result.json']:
 files['parent/'+name]=Path('/dev/shm/nssoc-padded-clocked-layout-01')/name
files['parent/native-parent-check.json']=Path('/dev/shm/nssoc-padded-clocked-checks-02/result.json')
for case in ('open_L1_TX_OUTN','return_avss_short','return_sub_short'):
 for name in ('wrong.gds','mutate.py'):
  files['actual_geometry_faults/'+case+'/'+name]=Path('/dev/shm/nssoc-padded-clocked-checks-02')/case/name
native=Path('/dev/shm/nssoc-bank-wire-native-unsimplified-v2')
run=json.loads((native/'result.json').read_text())
for name,expected in run['outputs'].items():assert pin(native/name)==expected
for name,expected in run['inputs'].items():assert pin(name)==expected
wg=json.loads((B/'wire-component-geometry.json').read_text());tr=json.loads((B/'terminal-reference-planes.json').read_text())
assert wg['native_device_count']==351 and len(wg['native_ports'])==56 and wg['wire_component_count']==128
assert set(wg['native_ports'])==set(json.loads(Path('/dev/shm/nssoc-padded-clocked-layout-01/result.json').read_text())['ports'])
assert pin('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')['sha256']=='a6973418f56cb907d263854cc735466e0f8706b883f0247d9d398c4e39df0616'
assert pin('/dev/shm/nssoc-padded-clocked-layout-01/schematic.cir')['sha256']=='1521b7b9dd8a3d463c121300a386d762ec0da1239cc4043781298920dc44912d'
assert not tr['unresolved'] and tr['declared_terminal_count']==1061
assert tr['dispositions']=={'ACTUAL_METAL_POINT_REFERENCE':748,'UNCHANGED_INTRINSIC_BODY_TERMINAL_NO_ADDED_SUBSTRATE_R':313}
for name,expected in tr['inputs'].items():assert pin(name)==expected
for p in tr['inputs']:
 if p.endswith('_code.py'):files['upstream_pcell/'+Path(p).name]=Path(p)
deck=ROOT/'hw/soc/tools/ihp-lvs-5e6d592/ihp-sg13g2/libs.tech/klayout/tech/lvs'
for p in deck.rglob('*'):
 if p.is_file() and p.suffix in ('.lvs','.rb'):files['native_lvs_source/'+str(p.relative_to(deck))]=p
for name in ('Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0'):
 files['LICENSES/'+name+'.txt']=ROOT/'LICENSES'/(name+'.txt')
notice=B/'UPSTREAM-NOTICES.txt'
notice.write_text('Native bank wire-bridge feasibility evidence\n\nProject diagnostic scripts: Copyright 2026 Hasan Melih Akbulut, Apache-2.0.\nProject circuit/layout source: CERN-OHL-W-2.0; generated evidence: CC-BY-4.0.\nIncluded IHP SG13G2 LVS and seven native PCell source excerpts retain their upstream copyright/license headers (Copyright 2024 IHP PDK Authors, Apache-2.0).\nPinned upstream repository: https://github.com/IHP-GmbH/IHP-Open-PDK ; native LVS revision 5e6d592 and installed PDK c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c.\nExact source bytes and complete geometry are inventoried in validation.json.\nNo simulator/Magic/KLayout binary or SPICE compact-model implementation is redistributed here.\nNo substrate resistance, complete PEX, RF, ESD stress, or 8 GHz qualification is claimed.\n')
files['UPSTREAM-NOTICES.txt']=notice
records={n:pin(p) for n,p in files.items()}
archive=B/'bank-wire-geometry-feasibility.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n,recursive=False)
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(records)
 for member in tar:
  raw=tar.extractfile(member).read();assert len(raw)==records[member.name]['bytes'] and hashlib.sha256(raw).hexdigest()==records[member.name]['sha256']
result=dict(status='PASS_WIRE_GEOMETRY_TERMINAL_FEASIBILITY_ONLY_MAGIC_RC_PENDING',
 method=pin(__file__),source_pins={str(p):pin(p) for p in B.glob('*.py')},capsule=pin(archive),members=records,
 source_geometry=pin('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds'),
 source_reference=pin('/dev/shm/nssoc-padded-clocked-layout-01/schematic.cir'),
 native_unsimplified_run=run,native_device_count=351,native_port_count=56,native_terminal_count=1061,
 exact_material_layers=7,exact_via_cut_layers=6,wire_components=128,metal_terminal_point_references=748,
 unchanged_intrinsic_body_well_terminals=313,finite_ptaps=108,finite_ntaps=1,
 observed_complete_native_deck_match=True,source_gds_and_circuit_unchanged=True,
 actual_controls=json.loads((B/'actual-wire-geometry-controls.json').read_text()),
 final_executions=json.loads((B/'final-probe-executions.json').read_text()),
 rejected_initial_recipe='no_simplify=true alone yields zero top pins even with deck MATCH; retained initial capture is not accepted. Final recipe adds the existing native top_lvl_pins=true switch and independently requires exact56 pins.',
 architecture=['Keep all351 unsimplified native devices and all1061 ordered terminals; do not replace them with ideal functional blocks.',
 'Extract only unchanged7metal/6via geometry; place748 actual metal terminal probes and56 physical public-port probes.',
 'Preserve313 body/well terminals and109 finite modeled contacts explicitly. No guessed3D substrate R or body-net union.',
 'Next native Magic stage must prove complete R-component and alias closure, intrinsic ground-C conservation, unchanged mutual anchors and full collapsed C matrix.',
 'Keep the wire network and source-bound intrinsic graph separate until that audit passes; no simulator-ready hybrid netlist is supplied by this feasibility stage.'],
 limitations=['Metal points are explicit terminal reference planes, not a calibrated distributed intrinsic-terminal or contact spreading model.',
 'Native LVS device enclosures alone do not prove terminal mapping; the terminal audit additionally checks actual physical pin/material and native net ownership.',
 'Semiconductor/body spreading, device-wire coupling, RF, electromigration, ESD stress and post-layout8GHz performance remain unqualified.',
 'No Magic wire-RC run has occurred in this stage; its outputs are not accepted R/C values.'],
 magic_rc_executed=False,hybrid_simulator_netlist_ready=False,qualified_pex=False,rf_qualified=False)
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print('CAPSULE',pin(archive),'VALIDATION',pin(B/'validation.json'),'MEMBERS',len(records))
