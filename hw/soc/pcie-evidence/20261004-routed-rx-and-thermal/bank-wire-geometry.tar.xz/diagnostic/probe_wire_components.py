# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Exact metal/via-only component census bound to native unsimplified LVS."""
from pathlib import Path
from collections import Counter,defaultdict
import pya,json,hashlib,time
B=Path(__file__).parent
GDS=Path('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')
DB=Path('/dev/shm/nssoc-bank-wire-native-unsimplified-v2/result.lvsdb')
OUT=Path('/dev/shm/nssoc-bank-wire-geometry-probe-v2');OUT.mkdir()
METALS=[8,10,30,50,67,126,134];VIAS=[19,29,49,66,125,133]
def pin(p):
 p=Path(p);return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
g=pya.Layout();g.read(str(GDS));top=g.top_cell()
l=pya.LayoutVsSchematic();l.read(str(DB));c=l.netlist().top_circuit()
assert c.pin_count()==56
classes=Counter(d.device_class().name for d in c.each_device())
assert classes==dict(npn13G2=122,ptap1=108,ntap1=1,rppd=57,rsil=24,cap_cmim=6,sg13_hv_pmos=1,diodevdd_2kv=16,diodevss_2kv=16),classes
wire=pya.Layout();wire.dbu=g.dbu;wt=wire.create_cell('bank_wires')
regions={};mapping={};layers={}
for layer in METALS+VIAS:
 r=pya.Region(top.begin_shapes_rec(g.layer(layer,0))).merged();assert not r.is_empty();regions[layer]=r
 wt.shapes(wire.layer(layer,0)).insert(r);assert (r^pya.Region(wt.begin_shapes_rec(wire.layer(layer,0)))).is_empty()
 layers[layer]=dict(area_dbu2=r.area(),polygons=r.count(),bbox=str(r.bbox()),source_union_sha256=hashlib.sha256('\n'.join(sorted(poly.to_s() for poly in r.each())).encode()).hexdigest())
for metal in METALS:
 r=regions[metal];a=r.area();box=r.bbox();candidates=[]
 for i in l.layer_indexes():
  lr=l.layer_by_index(i)
  if lr.bbox()==box and lr.area()==a and (lr^r).is_empty():candidates.append(i)
 assert len(candidates)==1,(metal,candidates)
 mapping[metal]=candidates[0]
e=pya.LayoutToNetlist('BANKWIRES',g.dbu)
for layer,r in regions.items():e.register(r,'gds_'+str(layer));e.connect(r)
for a,v,b in zip(METALS,VIAS,METALS[1:]):e.connect(regions[a],regions[v]);e.connect(regions[v],regions[b])
e.extract_netlist();ec=e.netlist().top_circuit()
assert len(list(ec.each_device()))==0
rows=[];owners=defaultdict(list);cache={}
for n in ec.each_net():
 pieces={m:e.shapes_of_net(n,regions[m],True) for m in METALS}
 first=next((m,r) for m,r in pieces.items() if not r.is_empty());m,r=first
 # A native interior point obtained from exact rectangular decomposition.
 boxes=[poly.bbox() for poly in r.decompose_trapezoids_to_region().each() if poly.area()==poly.bbox().area() and poly.bbox().width()>2 and poly.bbox().height()>2]
 assert boxes,'No exact rectangular interior for conductor probe'
 point=boxes[0].center();native=l.probe_net(l.layer_by_index(mapping[m]),point)
 assert native is not None
 nid=native.cluster_id
 checks={}
 for metal,piece in pieces.items():
  key=(nid,metal)
  if key not in cache:cache[key]=l.shapes_of_net(native,l.layer_by_index(mapping[metal]),True)
  assert (piece-cache[key]).is_empty(),('Wire component crosses native device/net boundary',n.cluster_id,nid,metal)
  checks[metal]=dict(area_dbu2=piece.area(),polygons=piece.count())
 owners[nid].append(n.cluster_id)
 rows.append(dict(component=n.cluster_id,native_cluster=nid,native_name=native.name,probe_metal=m,probe_dbu=[point.x,point.y],layers=checks))
assert all(len(v)==1 for v in owners.values()), 'One native metal net split into multiple physical conductors'
# Complete native metal coverage, including nets that are not public ports.
coverage=[]
for n in c.each_net():
 a=sum(l.shapes_of_net(n,l.layer_by_index(mapping[m]),True).area() for m in METALS)
 if a:assert n.cluster_id in owners,(n.name,n.cluster_id,a)
 coverage.append(dict(native_cluster=n.cluster_id,name=n.name,metal_area_dbu2=a,wire_components=owners.get(n.cluster_id,[])))
wire.write(str(OUT/'wires.gds'));e.write(str(OUT/'wires.l2n'))
result=dict(status='GEOMETRY_ONLY_ALL_METAL_VIA_COMPONENTS_BOUND_TO_NATIVE_LVS_NO_RC_YET',method=pin(__file__),inputs={str(p):pin(p) for p in [GDS,DB]},
 native_devices=dict(classes),native_device_count=sum(classes.values()),native_ports=[p.name() for p in c.each_pin()],
 native_layer_mapping=mapping,layers=layers,wire_components=rows,native_net_coverage=coverage,
 wire_component_count=len(rows),native_net_count=len(coverage),native_metal_net_count=sum(bool(r['metal_area_dbu2']) for r in coverage),
 no_wire_geometry_change=True,no_component_union_by_native_label=True,no_device_deleted_from_native_graph=True,
 rc_qualified=False,full_pex_qualified=False,substrate_r_modeled=False,
 outputs={p.name:pin(p) for p in OUT.iterdir() if p.is_file()})
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');(B/'wire-component-geometry.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],len(rows),len(coverage),[(r['name'],len(r['wire_components'])) for r in coverage if len(r['wire_components'])>1])
