# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Read-only native flat-LVS geometry capability probe."""
import pya
l=pya.LayoutVsSchematic();l.read('/dev/shm/nssoc-padded-clocked-checks-02/lvs_flat/result.lvsdb')
c=l.netlist().top_circuit()
print('TOP',c.name,c.pin_count())
print('LAYER_INFO',[(x,str(l.layer_info(x))) for x in l.layer_indexes()])
seen=set()
for d in c.each_device():
 name=d.device_class().name
 if name in seen:continue
 seen.add(name)
 print('DEVICE',d.id(),name,d.trans,d.device_abstract.name)
 for t in d.device_class().terminal_definitions():
  try:shapes=l.shapes_of_terminal(d,t.id())
  except Exception as e:print('ERROR',str(e));raise
  print('TERMINAL',t.name,d.net_for_terminal(t.id()).name,[(i,str(r.bbox()),r.count(),r.area()) for i,r in shapes.items()])
