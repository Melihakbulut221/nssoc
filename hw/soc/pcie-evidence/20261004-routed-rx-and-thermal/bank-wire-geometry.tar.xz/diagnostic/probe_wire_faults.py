# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Actual unchanged and previously fabricated native geometry controls."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,pya
B=Path(__file__).parent
l=pya.LayoutVsSchematic();l.read('/dev/shm/nssoc-bank-wire-native-unsimplified-v2/result.lvsdb')
base=json.loads((B/'wire-component-geometry.json').read_text());mapping={int(k):v for k,v in base['native_layer_mapping'].items()}
METALS=[8,10,30,50,67,126,134];VIAS=[19,29,49,66,125,133]
files={'unchanged':Path('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')}
for n in ('open_L1_TX_OUTN','return_avss_short','return_sub_short'):files[n]=Path('/dev/shm/nssoc-padded-clocked-checks-02')/n/'wrong.gds'
results={}
def pin(p):
 p=Path(p);return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for name,path in files.items():
 g=pya.Layout();g.read(str(path));t=g.top_cell();e=pya.LayoutToNetlist('WIRE',g.dbu)
 regs={m:pya.Region(t.begin_shapes_rec(g.layer(m,0))).merged() for m in METALS+VIAS}
 for m,r in regs.items():e.register(r,'L'+str(m));e.connect(r)
 for a,v,b in zip(METALS,VIAS,METALS[1:]):e.connect(regs[a],regs[v]);e.connect(regs[v],regs[b])
 e.extract_netlist();nets=list(e.netlist().top_circuit().each_net());owners=defaultdict(list);failures=[]
 for n in nets:
  rs={m:e.shapes_of_net(n,regs[m],True) for m in METALS}
  m,r=next((m,r) for m,r in rs.items() if not r.is_empty())
  boxes=[p.bbox() for p in r.decompose_trapezoids_to_region().each() if p.area()==p.bbox().area() and p.bbox().width()>2 and p.bbox().height()>2]
  assert boxes
  native=l.probe_net(l.layer_by_index(mapping[m]),boxes[0].center())
  if native is None:failures.append('No original native net at actual conductor probe');continue
  nid=native.cluster_id;owners[nid].append(n.cluster_id)
  if any(not (part-l.shapes_of_net(native,l.layer_by_index(mapping[metal]),True)).is_empty() for metal,part in rs.items()):failures.append('Actual conductor crosses original native net/geometry boundary')
 for nid,components in owners.items():
  if len(components)!=1:failures.append(f'Original native conductor {nid} split into {len(components)} actual wire components')
 if len(nets)!=128:failures.append(f'Physical conductor census {len(nets)} differs from128')
 assert (not failures)==(name=='unchanged'),(name,failures)
 results[name]=dict(gds=pin(path),wire_components=len(nets),errors=failures,status='PASS_UNCHANGED_WIRE_GRAPH' if not failures else 'REJECTED_ACTUAL_GEOMETRY',
  original_geometry_control_method=pin(path.with_name('mutate.py')) if name!='unchanged' else None)
result=dict(status='PASS_ACTUAL_WIRE_OPEN_AND_TWO_BODY_RAIL_SHORT_REJECTION_CONTROLS',cases=results,method=pin(__file__),
 inputs={str(p):pin(p) for p in [B/'wire-component-geometry.json',Path('/dev/shm/nssoc-bank-wire-native-unsimplified-v2/result.lvsdb')]},
 native_magic_rc_executed=False,full_pex_qualified=False)
(B/'actual-wire-geometry-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(results,indent=2))
