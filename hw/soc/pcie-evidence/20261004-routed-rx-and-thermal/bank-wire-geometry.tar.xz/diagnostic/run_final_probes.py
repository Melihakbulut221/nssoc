# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Source-bound final read-only extraction/geometry probes."""
from pathlib import Path
import subprocess,resource,time,json,hashlib
B=Path(__file__).parent
APP=Path('hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage')
def pin(p):
 p=Path(p);return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(2147483648,)*2);resource.setrlimit(resource.RLIMIT_CORE,(0,0))
results=[]
for name in ('probe_native_cells','probe_wire_components','probe_device_locations','probe_terminal_anchors','probe_wire_faults'):
 path=B/(name+'.py');pins={str(p):pin(p) for p in [APP,path]};command=[str(APP),'python',str(path)]
 start=time.monotonic()
 with (B/(name+'-final.log')).open('w') as log:
  run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits,timeout=60)
 assert all(pin(p)==v for p,v in pins.items())
 results.append(dict(command=command,returncode=run.returncode,seconds=time.monotonic()-start,inputs=pins,
                     log=pin(B/(name+'-final.log')),core_limit_bytes=0,address_space_bytes=2147483648))
 assert run.returncode==0,name
(B/'final-probe-executions.json').write_text(json.dumps(dict(method=pin(__file__),runs=results),indent=2)+'\n')
print('ALL5_FINAL_GEOMETRY_PROBES_PASS',sum(r['seconds'] for r in results))
