# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import pya,json
from pathlib import Path
GDS=Path('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds')
l=pya.LayoutVsSchematic();l.read('/dev/shm/nssoc-padded-clocked-checks-02/lvs_flat/result.lvsdb')
g=pya.Layout();g.read(str(GDS));top=g.top_cell();rows={}
regions={x:l.layer_by_index(x) for x in l.layer_indexes() if not l.layer_by_index(x).is_empty()}
for metal in [8,10,30,50,67,126,134]:
 r=pya.Region(top.begin_shapes_rec(g.layer(metal,0))).merged();a=r.area();b=r.bbox();match=[]
 for i,reg in regions.items():
  if reg.bbox()==b and reg.area()==a and (reg^r).is_empty():match.append(i)
 rows[metal]=dict(area=a,bbox=str(b),native_layers=match)
print(json.dumps(rows,indent=2))
