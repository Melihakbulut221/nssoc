# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Existing native no_simplify switch; original deck, GDS and reference unchanged."""
from pathlib import Path
import json,subprocess,resource,hashlib,time,os
B=Path(__file__).parent
OUT=Path('/dev/shm/nssoc-bank-wire-native-unsimplified-v2');OUT.mkdir()
PARENT=Path('/dev/shm/nssoc-padded-clocked-checks-02/result.json')
p=json.loads(PARENT.read_text()); row=next(r for r in p['steps'] if r['name']=='lvs_flat')
cmd=[s.replace('/dev/shm/nssoc-padded-clocked-checks-02/lvs_flat',str(OUT)) for s in row['execution']['command']]+['-rd','no_simplify=true','-rd','top_lvl_pins=true']
def pin(p):
 p=Path(p);return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(2147483648,)*2);resource.setrlimit(resource.RLIMIT_CORE,(0,0))
inputs={str(path):pin(path) for path in [PARENT,Path(__file__),Path(cmd[0]),Path(cmd[5]),Path('/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds'),Path('/dev/shm/nssoc-padded-clocked-layout-01/schematic.cir')]}
t=time.monotonic()
with (OUT/'native.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=60,preexec_fn=limits,env={k:v for k,v in os.environ.items() if k not in ('GH_TOKEN','GITHUB_TOKEN')})
record=dict(command=cmd,returncode=r.returncode,seconds=time.monotonic()-t,inputs=inputs,outputs={p.name:pin(p) for p in OUT.iterdir() if p.is_file()},memory_limit_bytes=2147483648,core_limit_bytes=0,pex_qualified=False)
assert all(pin(n)==p for n,p in inputs.items())
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');(B/'unsimplified-native-with-ports.json').write_text(json.dumps(record,indent=2)+'\n');print(record['returncode'],record['seconds'])
