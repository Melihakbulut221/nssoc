# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Private printf-only tracing of actual prepared and copied substrate tiles."""
from pathlib import Path
import hashlib
import json
import resource
import shutil
import subprocess
import time

ROOT = Path.cwd()
B = Path(__file__).parent
PARENT = Path('/dev/shm/nssoc-magic-resis-terminals-v1-overlap')
OUT = Path('/dev/shm/nssoc-substrate-traversal-debug-v1')
OUT.mkdir()
SOURCE = OUT/'source'
shutil.copytree(PARENT/'source', SOURCE)


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2*1024**3,)*2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


source = SOURCE/'resis/ResMain.c'
text = source.read_text()
function = r'''
/* Read-only bounded native geometry diagnostic. */
int
ResTracePlaneTile(Tile *tile, TileType dinfo, char *tag)
{
    TxPrintf("NSSOC_SUBSTRATE_TILE tag=%s type=%s split=%d rect=%d,%d,%d,%d\n",
            tag, DBTypeLongNameTbl[TiGetType(tile)], IsSplit(tile),
            LEFT(tile), BOTTOM(tile), RIGHT(tile), TOP(tile));
    return 0;
}

void
ResTraceSubstrate(CellDef *def, char *tag)
{
    int plane = ExtCurStyle->exts_globSubstratePlane;
    int type = ExtCurStyle->exts_globSubstrateDefaultType;
    TxPrintf("NSSOC_SUBSTRATE_PLANE tag=%s cell=%s plane=%d default=%s bbox=%d,%d,%d,%d\n",
            tag, def->cd_name, plane, type < 0 ? "NONE" : DBTypeLongNameTbl[type],
            def->cd_bbox.r_xbot, def->cd_bbox.r_ybot,
            def->cd_bbox.r_xtop, def->cd_bbox.r_ytop);
    if (plane >= 0)
        DBSrPaintArea((Tile *)NULL, def->cd_planes[plane], &def->cd_bbox,
                &DBAllButSpaceAndDRCBits, ResTracePlaneTile, (ClientData)tag);
    TxPrintf("NSSOC_SUBSTRATE_PLANE_END tag=%s\n", tag);
}

'''
anchor='void\nResInitializeConn()'
assert text.count(anchor)==1
text=text.replace(anchor,function+anchor)
anchor='    TTMaskZero(&ResSDTypesBitMask);'
addition='''    TxPrintf("NSSOC_COPY_SOURCE name=%s type=%s location=%d,%d\\n",
            node->name, DBTypeLongNameTbl[node->type], node->location.p_x, node->location.p_y);
    ResTraceSubstrate(ResUse->cu_def, node->name);

'''
assert text.count(anchor)==1
source.write_text(text.replace(anchor, addition+anchor))
source=SOURCE/'resis/ResRex.c'
text=source.read_text()
anchor='void\nExtResisForDef(celldef, resisdata)'
assert text.count(anchor)==1
text=text.replace(anchor,'extern void ResTraceSubstrate(CellDef *, char *);\n\n'+anchor)
anchor='    savePlane = extResPrepSubstrate(mainDef);'
assert text.count(anchor)==1
text=text.replace(anchor,'''    ResTraceSubstrate(mainDef, "before-prep");
'''+anchor+'''
    TxPrintf("NSSOC_SUBSTRATE_PREP_CHANGED %d\\n", savePlane != NULL);
    ResTraceSubstrate(mainDef, "after-prep");''')
anchor='    if (extDev->gate == extNode)'
assert text.count(anchor)==1
text=text.replace(anchor,'''    TxPrintf("NSSOC_TERMINAL_VISIT net=%s type=%s slots=%d expected=%s,%s,%s,%s actual=%p,%p,%p,%p\\n",
            nodename, DBTypeLongNameTbl[layoutDev->rd_devtype], layoutDev->rd_nterms,
            extDev->gate ? extDev->gate->name : "NONE",
            extDev->source ? extDev->source->name : "NONE",
            extDev->drain ? extDev->drain->name : "NONE",
            extDev->subs ? extDev->subs->name : "NONE",
            layoutDev->rd_fet_gate, layoutDev->rd_fet_source,
            layoutDev->rd_fet_drain, layoutDev->rd_fet_subs);

'''+anchor)
source.write_text(text)
builds=[]
for label, command in [('resis',['make','-C',str(SOURCE/'resis'),'module']),
                       ('link',['make','-C',str(SOURCE/'magic'),'tcl-main'])]:
    start=time.monotonic()
    with (OUT/(label+'.log')).open('w') as log:
        proc=subprocess.run(command,preexec_fn=limits,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=False)
    builds.append(dict(command=command,returncode=proc.returncode,seconds=time.monotonic()-start,log=pin(OUT/(label+'.log'))))
    assert proc.returncode==0
RT=OUT/'runtime/lib'
shutil.copytree(PARENT/'runtime/lib',RT)
shutil.copyfile(SOURCE/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so')
result=dict(method=pin(__file__),parent_library=pin(PARENT/'runtime/lib/magic/tcl/tclmagic.so'),
            private_library=pin(RT/'magic/tcl/tclmagic.so'),runs=builds,
            changed_sources={str(p.relative_to(SOURCE)):pin(p) for p in [SOURCE/'resis/ResMain.c', SOURCE/'resis/ResRex.c']},
            diagnostic_prints_only=True,accepted_extraction=False)
(B/'trace-build.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['private_library']))
