# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Reparse bounded native geometry observations; never accept substrate RC."""
from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import shlex
import networkx as nx

B = Path(__file__).parent
ROOTS = [Path('/dev/shm') / name for name in (
    'nssoc-substrate-cases-overlap-v1', 'nssoc-substrate-cases-debug-v1',
    'nssoc-hbt-terminal-cases-debug-v1')]
AP = B.parent/'pcie-magic-resis-terminals-v1-20261004/audit_pilot.py'
spec = importlib.util.spec_from_file_location('frozen_pilot_audit', AP)
ap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ap)


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def require(ok, message):
    if not ok:
        raise ValueError(message)


def normalized(row, mapping=None):
    mapping = mapping or {}
    return dict(ports=row['ports'],
                devices=Counter((tuple(mapping.get(n, n) for n in ns), m, p)
                                for ns, m, p in row['devices']),
                resistors=Counter((tuple(sorted(mapping.get(n, n) for n in (a, b))), v)
                                  for a, b, v in row['resistors']),
                capacitors=Counter((tuple(sorted(mapping.get(n, n) for n in (a, b))), v)
                                   for a, b, v in row['capacitors']))


def equivalent(a, b):
    # Bind each native modeled device using its unchanged ordered PAD/VDD
    # terminals, then derive any internal terminal-name renaming. Never merge.
    mapping = {}
    for ns, model, params in b['devices']:
        matches = [old for old in a['devices'] if old[1:] == (model, params)
                   and all(x == y for x, y in zip(old[0][:2], ns[:2]))]
        require(len(matches) == 1, 'Ambiguous device correspondence')
        for new, old in zip(ns, matches[0][0]):
            require(mapping.get(new, old) == old, 'Conflicting native name correspondence')
            mapping[new] = old
    require(len(set(mapping.values())) == len(mapping), 'Nonbijective terminal rename')
    require(all(mapping.get(p, p) == p for p in a['ports']), 'Port rename forbidden')
    require(normalized(a) == normalized(b, mapping), 'Read-only native trace changed exact RC/device output')
    return {k: v for k, v in mapping.items() if k != v}


def tiles(log, tag):
    pattern = r'^NSSOC_SUBSTRATE_TILE tag=' + re.escape(tag) + r' type=(\w+) split=(\d+) rect=(-?\d+),(-?\d+),(-?\d+),(-?\d+)$'
    found = re.findall(pattern, log, re.M)
    require(found, 'No raw native substrate plane')
    require(all(split == '0' for _, split, *_ in found), 'Manhattan component audit cannot approximate split tiles')
    return [(kind, tuple(map(int, rect))) for kind, _, *rect in found]


def connected(a, b):
    # A shared positive-length edge or overlapping interior, never a corner.
    dx = min(a[2], b[2])-max(a[0], b[0])
    dy = min(a[3], b[3])-max(a[1], b[1])
    return (dx > 0 and dy >= 0) or (dx >= 0 and dy > 0)


def components(rows):
    boxes = [box for kind, box in rows if kind == 'pwell']
    g = nx.Graph()
    g.add_nodes_from(range(len(boxes)))
    for i, box in enumerate(boxes):
        for j in range(i):
            if connected(box, boxes[j]):
                g.add_edge(i, j)
    return [[boxes[i] for i in sorted(c)] for c in nx.connected_components(g)]


def main():
    observations = {}
    cases = json.loads((Path('/dev/shm/nssoc-substrate-traversal-fixtures-v1')/'result.json').read_text())['cases']
    for case in cases:
        comparison = []
        for filename in ('baseline.spice', 'unreduced.spice'):
            parsed = [ap.parse_spice((root/case/filename).read_text()) for root in ROOTS]
            comparison.append(dict(file=filename, exact_rc_device_equivalence=True,
                                   native_terminal_renamings=[equivalent(parsed[0], row) for row in parsed[1:]]))
        logs = [(root/case/'native.log').read_text() for root in ROOTS]
        warning_pattern = r'^(?:Missing .*|Error in extracting node .*|Total Nets:.*|Nets extracted:.*|Nets output:.*)$'
        messages = [Counter(re.findall(warning_pattern, log, re.M)) for log in logs]
        require(messages[0] == messages[1] == messages[2], 'Trace changed actual error/census outcome')
        run_pins = {}
        for root in ROOTS:
            run = json.loads((root/case/'result.json').read_text())
            require(run['returncode'] == 0 and run['core_limit_bytes'] == 0
                    and run['memory_limit_bytes'] == 2147483648, 'Wrong native resource/outcome')
            for name, expected in run['outputs'].items():
                require(pin(root/case/name) == expected, 'Native output altered')
            for name, expected in run['inputs'].items():
                require(pin(name) == expected, 'Native input altered')
            run_pins[str(root/case/'result.json')] = pin(root/case/'result.json')
        try:
            strict = ap.audit(ROOTS[-1]/case)
            strict = dict(status=strict['status'], devices=strict['modeled_devices'],
                          resistance_edges=strict['distributed_resistors'], capacitance_edges=strict['capacitance_edges'])
        except ValueError as exc:
            strict = dict(status='REJECTED_BY_UNCHANGED_PILOT_AUDITOR', reason=str(exc))
        observations[case] = dict(native_warning_census=dict(messages[0]), comparisons=comparison,
                                  run_receipts=run_pins, strict_pilot_audit=strict)
    for case, expected in [('two_pnp', 1), ('mixed_pair', 2)]:
        log = (ROOTS[-1]/case/'native.log').read_text()
        before, copied = components(tiles(log, 'after-prep')), components(tiles(log, 'SUB'))
        require(len(before) == expected and len(copied) == 1, 'Unexpected actual pwell topology')
        observations[case]['pwell_components'] = dict(prepared=before, copied= copied,
            actual_source=re.findall(r'^NSSOC_COPY_SOURCE name=SUB .*$', log, re.M),
            no_label_based_union=True, physical_3d_substrate_resistance_inferred=False)
    hbt = (ROOTS[-1]/'one_hbt_with_finite_tap'/'native.log').read_text()
    segments = {part.splitlines()[0].split()[1].removeprefix('name='): part
                for part in re.split(r'(?=NSSOC_COPY_SOURCE)', hbt)[1:]}
    e = segments['E_N1_T0']
    require('index=0 type=gemitterc' in e and 'type=gemitter device=0 sd=0 body=0' in e
            and 'NSSOC_HBT_SD_OVERLAP' not in e, 'Emitter contact/residue mismatch not reproduced')
    c = segments['C_N1_T0']
    require('type=ndiff device=0 sd=1 body=0' in c and 'rect=3815,6196,4185,6256' in c
            and 'NSSOC_HBT_SD_OVERLAP' not in c, 'Collector no-overlap observation changed')
    base = segments['B_N1_T0']
    require('lefttype=pbasec righttype=pbasec' in base and 'NSSOC_HBT_ACTUAL_TILE type=pbase' not in base
            and 'type=metal1 device=0 sd=0 body=0' in base, 'Base traversal observation changed')
    observations['one_hbt_with_finite_tap']['measured_terminal_causes'] = {
        'B': 'Actual pbasec exists before/after contact dissolution, but only M1 is traversed; no base marker reached.',
        'E': 'Native terminal mask contains gemitterc; actual post-contact gemitter tile has sd=0 and no overlap callback.',
        'C': 'Actual ndiff has sd=1 but starts at y6196, exactly the pbase maximum y; positive-area overlap callback is absent.',
        'body': 'The real psubdiff origin returns ResProcessTiles error before any tile callback. The finite tap remains in both intrinsic graphs.'}
    # Preserve the exact exporter alias counterexample. This does not waive the
    # old auditor failure or create a new whole-R acceptance claim.
    root = ROOTS[-1]/'two_pnp'
    raw = [shlex.split(line) for line in (root/'diagnostic_flat.ext').read_text().splitlines()]
    observations['two_pnp']['raw_intrinsic_equiv'] = [row for row in raw if row and row[0] == 'equiv']
    result = dict(status='REPRODUCED_NATIVE_SUBSTRATE_MODEL_BOUNDARY_AND_THREE_HBT_TERMINAL_MISSES',
                  methods={str(p): pin(p) for p in [Path(__file__), AP]}, observations=observations,
                  unchanged_native_geometry=True, diagnostic_observers_preserve_exact_rc_device_graph=True,
                  full_bank_resistance_accepted=False, substrate_rc_qualified=False, pex_qualified=False,
                  limitations=['Two-PNP absence of terminal warnings is not full RC acceptance; the frozen auditor still rejects a native/export alias mismatch.',
                               'Manhattan pwell connected-component proof applies only to ESD cases; HBT split tiles are retained verbatim, not rectangularized.',
                               'No substrate nodes joined, no guessed vertical resistivity/depth, no geometry/device/model changes.'])
    (B/'analysis.json').write_text(json.dumps(result, indent=2)+'\n')
    print(result['status'])


if __name__ == '__main__':
    main()
