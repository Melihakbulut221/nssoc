# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Freeze compact native diagnostics, not a resistance-acceptance result."""
from pathlib import Path
import hashlib
import json
import tarfile

B=Path(__file__).parent

def pin(p):
 p=Path(p); return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files={}
for p in B.iterdir():
 if p.suffix in ('.py','.json') and p.name!='validation.json':files['methods/'+p.name]=p
for label,root in [('overlap','nssoc-substrate-cases-overlap-v1'),('substrate_trace','nssoc-substrate-cases-debug-v1'),('hbt_trace','nssoc-hbt-terminal-cases-debug-v1')]:
 for p in (Path('/dev/shm')/root).rglob('*'):
  if p.is_file():files['native/'+label+'/'+str(p.relative_to(Path('/dev/shm')/root))]=p
fixture=Path('/dev/shm/nssoc-substrate-traversal-fixtures-v1')
for p in fixture.iterdir():
 if p.is_file():files['geometry/'+p.name]=p
for label,path in [('esd','/dev/shm/nssoc-magic-esd-fixture-final02'),('hbt','/dev/shm/nssoc-magic-hbt-axis-01')]:
 for name in ('result.json','fixture.gds'):
  files['geometry/parent_'+label+'/'+name]=Path(path)/name
for label,name in [('parent','nssoc-magic-resis-terminals-v1-overlap'),('substrate_trace','nssoc-substrate-traversal-debug-v1'),('hbt_trace','nssoc-hbt-terminal-traversal-debug-v1')]:
 root=Path('/dev/shm')/name
 for name in ('resis/ResMain.c','resis/ResRex.c','resis/ResBasic.c','resis/ResUtils.c','resis/ResJunct.c','resis/resis.h','extract/ExtCell.c','database/DBcellcopy.c','LICENSE'):
  files['sources/'+label+'/'+name]=root/'source'/name
 if label!='parent':
  for name in ('resis.log','link.log'):files['build/'+label+'/'+name]=root/name
for p in Path('/dev/shm/nssoc-magic-pad-stack-tech-v1').iterdir():
 if p.is_file():files['technology/'+p.name]=p
files['UPSTREAM-NOTICES.txt']=B.parent/'pcie-magic-pad-stack-v1-20261004/UPSTREAM-NOTICES.txt'
archive=B/'substrate-terminal-traversal-native.tar.xz'
records={name:pin(p) for name,p in files.items()}
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(records)
 for m in tar:
  data=tar.extractfile(m).read(); assert len(data)==records[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==records[m.name]['sha256']
result=dict(status='DIAGNOSTIC_COMPLETE_FULL_RC_ACCEPTANCE_FALSE',analysis=json.loads((B/'analysis.json').read_text()),
 source_pins={str(p):pin(p) for p in B.glob('*.py')},capsule=pin(archive),members=records,
 native_run_count=15,readonly_instrumentation_variants=2,private_builds_not_installed=True,
 native_execution_limits=dict(address_space_bytes=2147483648,core_bytes=0),
 full_bank_rc_accepted=False,substrate_rc_qualified=False,rf_qualified=False,
 reproduction=['python '+str(B/'build_trace.py'),'python '+str(B/'build_hbt_trace.py'),
 'python '+str(B/'run_cases.py')+' --runtime PRIVATE_RUNTIME_LIB --out NEW_DIRECTORY',
 'python '+str(B/'audit_traversal.py')],
 limitations=['Fresh runtime/output directories required; exact parent runtime/build sources are separately pinned in prior terminal-pilot receipt.',
 'No runtime binary redistributed. Original upstream C source snapshots/notices included only for exact diagnostic reproduction.',
 'This reproduces failures and isolates conductor geometry. It does not qualify full-bank wire RC or substrate resistance.'])
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print('CAPSULE',pin(archive),'VALIDATION',pin(B/'validation.json'),'MEMBERS',len(records))
