# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Read-only pre/post contact and actual traversal diagnostics, private build."""
from pathlib import Path
import hashlib
import json
import resource
import shutil
import subprocess
import time

B = Path(__file__).parent
PARENT = Path('/dev/shm/nssoc-substrate-traversal-debug-v1')
OUT = Path('/dev/shm/nssoc-hbt-terminal-traversal-debug-v1')
OUT.mkdir()
SOURCE = OUT / 'source'
shutil.copytree(PARENT / 'source', SOURCE)


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2*1024**3,)*2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


path = SOURCE / 'resis/ResMain.c'
source = path.read_text()
anchor = 'void\nResInitializeConn()'
assert source.count(anchor) == 1
source = source.replace(anchor, r'''
int
ResTraceHbtTile(Tile *tile, TileType dinfo, char *tag)
{
    TxPrintf("NSSOC_HBT_TILE tag=%s lefttype=%s righttype=%s split=%d direction=%d side=%d rect=%d,%d,%d,%d\n",
        tag, DBTypeLongNameTbl[TiGetLeftType(tile)], DBTypeLongNameTbl[TiGetRightType(tile)],
        IsSplit(tile), SplitDirection(tile), (dinfo & TT_SIDE) != 0,
        LEFT(tile), BOTTOM(tile), RIGHT(tile), TOP(tile));
    return 0;
}

void
ResTraceHbtPlanes(CellDef *def, char *tag)
{
    int plane;
    for (plane = PL_TECHDEPBASE; plane < DBNumPlanes; plane++)
    {
        TxPrintf("NSSOC_HBT_PLANE tag=%s plane=%d\n", tag, plane);
        DBSrPaintArea((Tile *)NULL, def->cd_planes[plane], &def->cd_bbox,
            &DBAllButSpaceAndDRCBits, ResTraceHbtTile, (ClientData)tag);
    }
}

''' + anchor)
anchor = '\tdevptr = tptr->thisDev->rs_devptr;'
assert source.count(anchor) == 1
source = source.replace(anchor, anchor + r'''
        {
            int type, terminal;
            for (type = 0; type < DBNumUserLayers; type++)
            {
                for (terminal = 0; terminal < devptr->exts_deviceSDCount; terminal++)
                    if (TTMaskHasType(&devptr->exts_deviceSDTypes[terminal], type))
                        TxPrintf("NSSOC_HBT_SD_MASK net=%s model=%s index=%d type=%s\n",
                            node->name, devptr->exts_deviceName, terminal, DBTypeLongNameTbl[type]);
                if (TTMaskHasType(&devptr->exts_deviceSubstrateTypes, type))
                    TxPrintf("NSSOC_HBT_BODY_MASK net=%s model=%s type=%s\n",
                        node->name, devptr->exts_deviceName, DBTypeLongNameTbl[type]);
            }
        }
''')
anchor = '    /* To avoid issues with overlapping stacked contact types and'
assert source.count(anchor) == 1
source = source.replace(anchor, '    ResTraceHbtPlanes(ResUse->cu_def, "before-shave");\n\n' + anchor)
anchor = '    ResDissolveContacts(ResContactList);'
assert source.count(anchor) == 1
source = source.replace(anchor, anchor + '\n    ResTraceHbtPlanes(ResUse->cu_def, "after-dissolve");')
anchor = '\t    return 1;'
# Record the actual rejected starting tile, without changing the branch.
old = '''    if (startTile == (Tile *) NULL)
'''
# The full existing function is preserved; the caller records its status below.
anchor = '    if (ResProcessTiles(resisdata, &startpoint) != 0) return TRUE;'
assert source.count(anchor) == 1
source = source.replace(anchor, '''    {
        int trace_result = ResProcessTiles(resisdata, &startpoint);
        TxPrintf("NSSOC_HBT_PROCESS_RESULT net=%s start=%d,%d result=%d\\n",
            node->name, startpoint.p_x, startpoint.p_y, trace_result);
        if (trace_result != 0) return TRUE;
    }''')
path.write_text(source)

path = SOURCE / 'resis/ResBasic.c'
source = path.read_text()
anchor = '    if (startpoint != (Point *) NULL)'
assert source.count(anchor) == 1
source = source.replace(anchor, r'''
    TxPrintf("NSSOC_HBT_ACTUAL_TILE type=%s device=%d sd=%d body=%d split=%d rect=%d,%d,%d,%d\n",
        DBTypeLongNameTbl[t1], TTMaskHasType(&ExtCurStyle->exts_deviceMask, t1) != 0,
        TTMaskHasType(&ResSDTypesBitMask, t1) != 0,
        TTMaskHasType(&ResSubTypesBitMask, t1) != 0,
        IsSplit(tile), LEFT(tile), BOTTOM(tile), RIGHT(tile), TOP(tile));
''' + anchor)
anchor = '    ResNewSDDevice(tp, tile, xj, yj, OTHERPLANE, &ResNodeQueue);'
assert source.count(anchor) == 1
source = source.replace(anchor, r'''
    TxPrintf("NSSOC_HBT_SD_OVERLAP conductor=%s device=%s point=%d,%d\n",
        DBTypeLongNameTbl[TiGetTypeExact(tp)], DBTypeLongNameTbl[TiGetTypeExact(tile)], xj, yj);
''' + anchor)
path.write_text(source)

builds = []
for label, command in [('resis', ['make', '-C', str(SOURCE/'resis'), 'module']),
                       ('link', ['make', '-C', str(SOURCE/'magic'), 'tcl-main'])]:
    start = time.monotonic()
    with (OUT/(label+'.log')).open('w') as log:
        proc = subprocess.run(command, preexec_fn=limits, stdout=log, stderr=subprocess.STDOUT,
                              timeout=120, check=False)
    builds.append(dict(command=command, returncode=proc.returncode,
                       seconds=time.monotonic()-start, log=pin(OUT/(label+'.log'))))
    assert proc.returncode == 0
runtime = OUT/'runtime/lib'
shutil.copytree(PARENT/'runtime/lib', runtime)
shutil.copyfile(SOURCE/'magic/tclmagic.so', runtime/'magic/tcl/tclmagic.so')
result = dict(method=pin(__file__), parent_library=pin(PARENT/'runtime/lib/magic/tcl/tclmagic.so'),
              private_library=pin(runtime/'magic/tcl/tclmagic.so'), builds=builds,
              changed_sources={str(p.relative_to(SOURCE)): pin(p)
                               for p in (SOURCE/'resis/ResMain.c', SOURCE/'resis/ResBasic.c')},
              diagnostic_reads_and_prints_only=True, accepted_extraction=False)
(B/'hbt-trace-build.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result['private_library']))
