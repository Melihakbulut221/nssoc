# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Unchanged native PCell subsets for terminal traversal diagnostics only."""
from pathlib import Path
import hashlib
import json
import pya

ROOT = Path.cwd()
OUT = Path('/dev/shm/nssoc-substrate-traversal-fixtures-v1')
OUT.mkdir()
ESD = Path('/dev/shm/nssoc-magic-esd-fixture-final02')
HBT = Path('/dev/shm/nssoc-magic-hbt-axis-01')
record = json.loads((ESD / 'result.json').read_text())
source = pya.Layout()
source.read(str(ESD / 'fixture.gds'))
old_top = source.cell('nssoc_esd_fixture')
results = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def insert_copy(layout, top, source_layout, instance, suffix):
    old = source_layout.cell(instance.cell_index)
    new = layout.create_cell(old.name + '_' + suffix)
    new.copy_tree(old)
    top.insert(pya.DCellInstArray(new.cell_index(), instance.dtrans))
    masks = {}
    for layer in source_layout.layer_indices():
        info = source_layout.get_info(layer)
        before = pya.Region(old.begin_shapes_rec(layer)).merged()
        after = pya.Region(new.begin_shapes_rec(layout.layer(info))).merged()
        assert (before ^ after).is_empty()
        if not before.is_empty():
            masks[str(info)] = hashlib.sha256(before.to_s().encode()).hexdigest()
    return dict(native_cell=old.name, transform=str(instance.dtrans), all_masks_sha256=masks)


def ports_and_save(layout, top, name, ports, cells, input_root):
    for port, boxes in ports.items():
        for box in boxes:
            rectangle = pya.DBox(*box['box'])
            top.shapes(layout.layer(box['layer'], 2)).insert(rectangle)
            top.shapes(layout.layer(box['layer'], 25)).insert(pya.DText(port, pya.DTrans(rectangle.center().x, rectangle.center().y)))
    path = OUT / (name + '.gds')
    layout.write(str(path))
    results[name] = dict(top=top.name, ports=ports, cells=cells,
                         geometry_sha256=sha(path), parent_geometry_sha256=sha(input_root / 'fixture.gds'),
                         parent_record_sha256=sha(input_root / 'result.json'))


for name, indices in [('one_pnp_0', [0]), ('one_pnp_8', [8]), ('two_pnp', [0, 8]), ('mixed_pair', [0, 16])]:
    layout = pya.Layout()
    layout.dbu = source.dbu
    top = layout.create_cell(name)
    ports, cells = {}, []
    for index in indices:
        transform = pya.DTrans(0, False, 60.0, 60.0 + (index // 8) * 80)
        instances = [item for item in old_top.each_inst() if item.dtrans == transform]
        assert len(instances) == 1
        cells.append(insert_copy(layout, top, source, instances[0], str(index)))
        for port in (f'PAD{index:02d}', f'VDD{index:02d}'):
            ports[port] = record['ports'][port]
        ports.setdefault('SUB', []).append(record['ports']['SUB'][index])
    ports_and_save(layout, top, name, ports, cells, ESD)

source_hbt = pya.Layout()
source_hbt.read(str(HBT / 'fixture.gds'))
old_top = source_hbt.cell('nssoc_hbt_axis')
hbt_record = json.loads((HBT / 'result.json').read_text())
layout = pya.Layout()
layout.dbu = source_hbt.dbu
top = layout.create_cell('one_hbt_with_finite_tap')
trans = pya.DTrans(0, False, 20, 30)
transistors = [item for item in old_top.each_inst() if item.dtrans == trans]
taps = [item for item in old_top.each_inst() if source_hbt.cell(item.cell_index).name.startswith('ptap1')]
assert len(transistors) == len(taps) == 1
cells = [insert_copy(layout, top, source_hbt, transistors[0], 'hbt'),
         insert_copy(layout, top, source_hbt, taps[0], 'tap')]
ports = {name: [hbt_record['ports'][name]] for name in ('C_N1_T0', 'B_N1_T0', 'E_N1_T0', 'SUB')}
ports_and_save(layout, top, 'one_hbt_with_finite_tap', ports, cells, HBT)
(OUT / 'result.json').write_text(json.dumps(dict(cases=results, method_sha256=sha(__file__),
    no_mask_or_native_cell_changes=True, accepted_bank_reduction=False), indent=2)+'\n')
print('FIVE_UNCHANGED_NATIVE_GEOMETRY_SUBSETS_GENERATED')
