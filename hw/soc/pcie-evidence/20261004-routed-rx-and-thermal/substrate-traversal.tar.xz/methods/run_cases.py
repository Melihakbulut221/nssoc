# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Run geometry-preserving small native cases with a caller-pinned private library."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import resource
import subprocess
import time

FIXTURE = Path('/dev/shm/nssoc-substrate-traversal-fixtures-v1')
TECH = Path('/dev/shm/nssoc-magic-pad-stack-tech-v1')


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2*1024**3,)*2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir()
    cases = json.loads((FIXTURE / 'result.json').read_text())['cases']
    results = {}
    for name, case in cases.items():
        output = args.out / name
        output.mkdir()
        gds = FIXTURE / (name+'.gds')
        assert pin(gds)['sha256'] == case['geometry_sha256']
        lines = ['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"', f'cd {{{output}}}',
                 'drc off', 'scalegrid 1 1', 'gds readonly true', f'gds read {{{gds}}}',
                 f'load {case["top"]}', 'flatten diagnostic_flat', 'load diagnostic_flat', 'select top cell']
        for ordinal, (port, boxes) in enumerate(case['ports'].items(), 1):
            for box in boxes:
                lines += ['box values '+' '.join(f'{v}um' for v in box['box']),
                          f'label {port} center '+{8:'metal1', 10:'metal2'}[box['layer']]]
            lines += [f'port {port} make {ordinal}', f'port {port} class inout', f'port {port} use signal']
        lines += ['save diagnostic_flat', 'extract unique all', 'extract style ngspice()', 'extract all',
                  'ext2spice lvs', 'ext2spice merge none', 'ext2spice global off',
                  'ext2spice cthresh 0', 'ext2spice rthresh 0', 'ext2spice extresist off',
                  'ext2spice -o baseline.spice', 'puts NSSOC_BASELINE_COMPLETE', 'ext2sim labels on',
                  'ext2sim', 'extresist threshold 0', 'extresist tolerance 0.000001',
                  'extresist simplify off', 'extresist all', 'ext2spice extresist on',
                  'ext2spice -o unreduced.spice', 'puts NSSOC_DIAGNOSTIC_UNREDUCED_COMPLETE', 'quit -noprompt']
        script = output / 'native.tcl'
        script.write_text('\n'.join(lines)+'\n')
        inputs = {str(p): pin(p) for p in [Path(__file__), FIXTURE/'result.json', gds, script,
                  args.runtime/'magic/tcl/tclmagic.so', *TECH.iterdir()] if p.is_file()}
        command = ['/usr/bin/tclsh8.6', str(args.runtime/'magic/tcl/magic.tcl'), '-dnull', '-noconsole',
                   '-rcfile', str(TECH/'ihp-sg13g2.magicrc'), str(script)]
        environment = {k:v for k,v in os.environ.items() if k not in ('LD_PRELOAD', 'PYTHONPATH', 'PYTHONHOME', 'GH_TOKEN', 'GITHUB_TOKEN')}
        environment['CAD_ROOT'] = str(args.runtime)
        started = time.monotonic()
        with (output/'native.log').open('w') as log:
            try:
                process = subprocess.run(command, cwd=output, env=environment, preexec_fn=limits,
                                         stdout=log, stderr=subprocess.STDOUT, timeout=30, check=False)
                code = process.returncode
            except subprocess.TimeoutExpired:
                code = None
        assert all(pin(path)==value for path,value in inputs.items())
        result = dict(command=command, returncode=code, seconds=time.monotonic()-started,
                      inputs=inputs, outputs={p.name:pin(p) for p in output.iterdir() if p.is_file()},
                      core_limit_bytes=0, memory_limit_bytes=2*1024**3, accepted_extraction=False)
        (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        results[name]=result
        print(name, code, result['seconds'], flush=True)
    (args.out/'result.json').write_text(json.dumps(results,indent=2)+'\n')


if __name__ == '__main__':
    main()
