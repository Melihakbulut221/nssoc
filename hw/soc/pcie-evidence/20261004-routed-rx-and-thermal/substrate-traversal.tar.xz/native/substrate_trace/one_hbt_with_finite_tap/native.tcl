puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-substrate-cases-debug-v1/one_hbt_with_finite_tap}
drc off
scalegrid 1 1
gds readonly true
gds read {/dev/shm/nssoc-substrate-traversal-fixtures-v1/one_hbt_with_finite_tap.gds}
load one_hbt_with_finite_tap
flatten diagnostic_flat
load diagnostic_flat
select top cell
box values 19.075um 31.01um 20.925um 31.25um
label C_N1_T0 center metal1
port C_N1_T0 make 1
port C_N1_T0 class inout
port C_N1_T0 use signal
box values 19.025um 28.74um 20.975um 28.98um
label B_N1_T0 center metal1
port B_N1_T0 make 2
port B_N1_T0 class inout
port B_N1_T0 use signal
box values 19.255um 29.215um 20.745um 30.77um
label E_N1_T0 center metal2
port E_N1_T0 make 3
port E_N1_T0 class inout
port E_N1_T0 use signal
box values -1.8um 0.2um -0.2um 1.8um
label SUB center metal1
port SUB make 4
port SUB class inout
port SUB use signal
save diagnostic_flat
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o baseline.spice
puts NSSOC_BASELINE_COMPLETE
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice extresist on
ext2spice -o unreduced.spice
puts NSSOC_DIAGNOSTIC_UNREDUCED_COMPLETE
quit -noprompt
