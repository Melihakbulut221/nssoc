puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-substrate-cases-overlap-v1/one_pnp_8}
drc off
scalegrid 1 1
gds readonly true
gds read {/dev/shm/nssoc-substrate-traversal-fixtures-v1/one_pnp_8.gds}
load one_pnp_8
flatten diagnostic_flat
load diagnostic_flat
select top cell
box values 57.88um 147.755um 61.48um 169.315um
label PAD08 center metal2
port PAD08 make 1
port PAD08 class inout
port PAD08 use signal
box values 67.34um 143.735um 70.94um 173.335um
label VDD08 center metal2
port VDD08 make 2
port VDD08 class inout
port VDD08 use signal
box values 60.0um 140.0um 69.72um 141.35um
label SUB center metal1
port SUB make 3
port SUB class inout
port SUB use signal
save diagnostic_flat
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o baseline.spice
puts NSSOC_BASELINE_COMPLETE
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice extresist on
ext2spice -o unreduced.spice
puts NSSOC_DIAGNOSTIC_UNREDUCED_COMPLETE
quit -noprompt
