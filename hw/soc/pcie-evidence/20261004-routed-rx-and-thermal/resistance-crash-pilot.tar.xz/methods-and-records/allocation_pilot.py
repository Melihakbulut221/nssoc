# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Private fixed-index allocation diagnostic; no terminal acceptance waiver."""
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import subprocess
import time

ROOT = Path.cwd()
B = ROOT / 'hw/soc/out/pcie-magic-resis-terminals-v1-20261004'
PARENT = Path('/dev/shm/nssoc-magic-esd-v1-build-final')
OUT = Path('/dev/shm/nssoc-magic-resis-terminals-v1-pilot')
OUT.mkdir()
SOURCE = OUT / 'source'
shutil.copytree(PARENT / 'source', SOURCE)


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


source = SOURCE / 'resis/ResUtils.c'
assert pin(source)['sha256'] == '332d1e116c33bdf2578c11f16c3f33fa554f3f8de01344249de44a6ff222659b'
original = source.read_text()
edits = [
    ('int i, nterms, pNum;', 'int i, nterms, pNum, sdterms;'),
    ('\t    nterms += 2;', '''\t    sdterms = nterms;
\t    nterms += 2;
            /* Fixed legacy terminal positions include RT_SUBS even when
             * only one SD terminal exists. Preserve the SD geometry count.
             */
            if (nterms <= RT_SUBS) nterms = RT_SUBS + 1;
            TxPrintf("NSSOC_TERMINAL_ALLOCATION type=%s sd=%d slots=%d\\n",
                    DBTypeLongNameTbl[loctype], sdterms, nterms);'''),
    ('for (i = 0; i < nterms - 2; i++)', 'for (i = 0; i < sdterms; i++)'),
]
changed = original
for old, new in edits:
    assert changed.count(old) == 1
    changed = changed.replace(old, new)
source.write_text(changed)
logruns = []
for label, command in [('build_resis', ['make', '-C', str(SOURCE / 'resis'), 'module']),
                       ('link', ['make', '-C', str(SOURCE / 'magic'), 'tcl-main'])]:
    start = time.monotonic()
    with (OUT / (label + '.log')).open('w') as log:
        process = subprocess.run(command, preexec_fn=limits, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=120, check=False)
    logruns.append(dict(command=command, returncode=process.returncode,
                        seconds=time.monotonic()-start, log=pin(OUT / (label + '.log'))))
    assert process.returncode == 0
RUNTIME = OUT / 'runtime/lib'
shutil.copytree(PARENT / 'runtime/lib', RUNTIME)
shutil.copyfile(SOURCE / 'magic/tclmagic.so', RUNTIME / 'magic/tcl/tclmagic.so')
cases = {}
for name in ('pnp', 'npn'):
    old = Path('/dev/shm/nssoc-rc-single-' + name + '-01')
    target = OUT / name
    target.mkdir()
    script = target / 'native.tcl'
    script.write_text((old / 'native.tcl').read_text().replace(str(old), str(target)))
    command = ['/usr/bin/tclsh8.6', str(RUNTIME / 'magic/tcl/magic.tcl'), '-dnull',
               '-noconsole', '-rcfile', '/dev/shm/nssoc-magic-pad-stack-tech-v1/ihp-sg13g2.magicrc', str(script)]
    env = {k: v for k, v in os.environ.items()
           if k not in ('GH_TOKEN', 'GITHUB_TOKEN', 'PYTHONPATH', 'PYTHONHOME', 'LD_PRELOAD')}
    env['CAD_ROOT'] = str(RUNTIME)
    start = time.monotonic()
    with (target / 'native.log').open('w') as log:
        try:
            process = subprocess.run(command, cwd=target, env=env, preexec_fn=limits,
                                     stdout=log, stderr=subprocess.STDOUT, timeout=30, check=False)
            code = process.returncode
        except subprocess.TimeoutExpired:
            code = None
    cases[name] = dict(command=command, returncode=code, seconds=time.monotonic()-start,
                       outputs={p.name: pin(p) for p in target.iterdir() if p.is_file()})
    print(name, code, flush=True)
result = dict(method=pin(__file__), parent_library=pin(PARENT / 'runtime/lib/magic/tcl/tclmagic.so'),
              parent_source=pin(PARENT / 'source/resis/ResUtils.c'), changed_source=pin(source),
              private_library=pin(RUNTIME / 'magic/tcl/tclmagic.so'), builds=logruns, cases=cases,
              accepted_resistance=False)
(B / 'allocation-pilot.json').write_text(json.dumps(result, indent=2) + '\n')
