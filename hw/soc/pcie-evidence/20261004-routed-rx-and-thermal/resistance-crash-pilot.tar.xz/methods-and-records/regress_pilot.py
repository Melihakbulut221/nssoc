# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Run unchanged existing geometry under the isolated terminal pilot."""
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import subprocess
import time

ROOT = Path.cwd()
B = ROOT / 'hw/soc/out/pcie-magic-resis-terminals-v1-20261004'
RT = Path('/dev/shm/nssoc-magic-resis-terminals-v1-overlap/runtime/lib')
TECH = Path('/dev/shm/nssoc-magic-pad-stack-tech-v1')


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


cases = {}
for name, old in [('esd32', Path('/dev/shm/nssoc-rc-isolation-esd32')),
                  ('hbt24', Path('/dev/shm/nssoc-rc-isolation-hbt24_finite_tap')),
                  ('bank351', Path('/dev/shm/nssoc-bank-conservation-v1-02'))]:
    output = Path('/dev/shm/nssoc-resis-terminal-regression-' + name + '-01')
    output.mkdir()
    text = (old / 'native.tcl').read_text().replace(str(old), str(output))
    for initial in ('esd.spice', 'hbt.spice'):
        text = text.replace(initial, 'baseline.spice')
    text = text.replace(' -o rc.spice', ' -o unreduced.spice')
    script = output / 'native.tcl'
    script.write_text(text)
    copies = []
    if name == 'bank351':
        source = old / 'nssoc_padded_clocked_pad_stack_flat.mag'
        shutil.copyfile(source, output / source.name)
        copies.append(source)
    inputs = {str(p): pin(p) for p in [Path(__file__), old / 'native.tcl', script,
              RT / 'magic/tcl/tclmagic.so', *TECH.iterdir(), *copies] if p.is_file()}
    command = ['/usr/bin/tclsh8.6', str(RT / 'magic/tcl/magic.tcl'), '-dnull',
               '-noconsole', '-rcfile', str(TECH / 'ihp-sg13g2.magicrc'), str(script)]
    env = {k: v for k, v in os.environ.items()
           if k not in ('GH_TOKEN', 'GITHUB_TOKEN', 'PYTHONPATH', 'PYTHONHOME', 'LD_PRELOAD')}
    env['CAD_ROOT'] = str(RT)
    start = time.monotonic()
    with (output / 'native.log').open('w') as log:
        try:
            process = subprocess.run(command, cwd=output, env=env, preexec_fn=limits,
                                     stdout=log, stderr=subprocess.STDOUT, timeout=90, check=False)
            code = process.returncode
        except subprocess.TimeoutExpired:
            code = None
    assert all(pin(p) == expected for p, expected in inputs.items())
    cases[name] = dict(command=command, returncode=code, seconds=time.monotonic()-start,
                       memory_limit_bytes=2*1024**3, core_limit_bytes=0, inputs=inputs,
                       outputs={p.name: pin(p) for p in output.iterdir() if p.is_file()},
                       accepted_resistance=False)
    (output / 'result.json').write_text(json.dumps(cases[name], indent=2)+'\n')
    print(name, code, cases[name]['seconds'], flush=True)
(B / 'regression-pilot.json').write_text(json.dumps(cases, indent=2)+'\n')
