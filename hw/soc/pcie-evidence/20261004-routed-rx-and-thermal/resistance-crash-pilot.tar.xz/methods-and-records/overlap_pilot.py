# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Private native conductor/device-overlap terminal diagnostic."""
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import subprocess
import time

ROOT = Path.cwd()
B = ROOT / 'hw/soc/out/pcie-magic-resis-terminals-v1-20261004'
PARENT = Path('/dev/shm/nssoc-magic-resis-terminals-v1-pilot')
OUT = Path('/dev/shm/nssoc-magic-resis-terminals-v1-overlap')
OUT.mkdir()
SOURCE = OUT / 'source'
shutil.copytree(PARENT / 'source', SOURCE)


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


source = SOURCE / 'resis/ResBasic.c'
original = source.read_text()
function = r'''
/* Native subcircuit identifier on another plane: connect its fixed gate
 * terminal at one actual overlapping conductor point. This does not paint,
 * rename or union any node; the caller requires native electrical adjacency.
 * Unlike a conducting MOS gate, a separate device marker is not itself
 * traversed as a resistive conductor.
 */
int
ResGatePlaneFunc(Tile *tile, TileType dinfo, Tile **tpptr)
{
    Tile *conductor = *tpptr;
    resInfo *info = (resInfo *)TiGetClientPTR(tile);
    resDevice *device = info->deviceList;
    resNode *node;
    tElement *element;
    int left, right, bottom, top, x, y;

    /* Split geometry requires a separate exact point-inside treatment. */
    if (IsSplit(tile) || IsSplit(conductor)) return 0;
    if (device == NULL || device->rd_fet_gate != NULL) return 0;
    left = MAX(LEFT(tile), LEFT(conductor));
    right = MIN(RIGHT(tile), RIGHT(conductor));
    bottom = MAX(BOTTOM(tile), BOTTOM(conductor));
    top = MIN(TOP(tile), TOP(conductor));
    if (left >= right || bottom >= top) return 0;
    x = (left + right) / 2;
    y = (bottom + top) / 2;
    node = (resNode *)mallocMagic(sizeof(resNode));
    InitializeResNode(node, x, y, RES_NODE_DEVICE);
    element = (tElement *)mallocMagic(sizeof(tElement));
    element->te_nextt = NULL;
    element->te_thist = device;
    node->rn_te = element;
    device->rd_fet_gate = node;
    ResAddToQueue(node, &ResNodeQueue);
    NEWBREAK(node, conductor, x, y, NULL);
    TxPrintf("NSSOC_NATIVE_GATE_OVERLAP device=%s conductor=%s point=%d,%d overlap=%d,%d,%d,%d\n",
            DBTypeLongNameTbl[TiGetTypeExact(tile)],
            DBTypeLongNameTbl[TiGetTypeExact(conductor)], x, y,
            left, bottom, right, top);
    return 0;
}

'''
anchor = 'bool\nResEachTile(tile, startpoint)'
assert original.count(anchor) == 1
changed = original.replace(anchor, function + anchor)
block = r'''
    /* Direct electrical adjacency between a subcircuit marker and a
     * conductor on another plane. SD/substrate masks remain separate.
     */
    if (!TTMaskHasType(&ExtCurStyle->exts_deviceMask, t1))
    {
        Rect r;
        int pNum;
        TileTypeBitMask gateMask;
        TiToRect(tile, &r);
        TTMaskZero(&gateMask);
        for (t2 = TT_TECHDEPBASE; t2 < DBNumUserLayers; t2++)
            for (devptr = ExtCurStyle->exts_device[t2]; devptr;
                    devptr = devptr->exts_next)
                if (devptr->exts_deviceClass == DEV_SUBCKT &&
                        TTMaskHasType(&ExtCurStyle->exts_nodeConn[t2], t1))
                    TTMaskSetType(&gateMask, t2);
        for (pNum = PL_TECHDEPBASE; pNum < DBNumPlanes; pNum++)
        {
            if (DBTypeOnPlane(t1, pNum)) continue;
            if (!TTMaskIntersect(&DBPlaneTypes[pNum], &gateMask)) continue;
            DBSrPaintArea((Tile *)NULL, ResUse->cu_def->cd_planes[pNum],
                    &r, &gateMask, ResGatePlaneFunc, (ClientData)&tile);
        }
    }

'''
anchor = '    /* Check for source/drain on other planes (e.g., capacitors, bipolars, ...) */'
assert changed.count(anchor) == 1
source.write_text(changed.replace(anchor, block + anchor))
builds = []
for label, command in [('build_resis', ['make', '-C', str(SOURCE / 'resis'), 'module']),
                       ('link', ['make', '-C', str(SOURCE / 'magic'), 'tcl-main'])]:
    start = time.monotonic()
    with (OUT / (label + '.log')).open('w') as log:
        process = subprocess.run(command, preexec_fn=limits, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=120, check=False)
    builds.append(dict(command=command, returncode=process.returncode,
                       seconds=time.monotonic()-start, log=pin(OUT / (label + '.log'))))
    assert process.returncode == 0
RUNTIME = OUT / 'runtime/lib'
shutil.copytree(PARENT / 'runtime/lib', RUNTIME)
shutil.copyfile(SOURCE / 'magic/tclmagic.so', RUNTIME / 'magic/tcl/tclmagic.so')
cases = {}
for name in ('pnp', 'npn'):
    old = Path('/dev/shm/nssoc-rc-single-' + name + '-01')
    target = OUT / name
    target.mkdir()
    script = target / 'native.tcl'
    script.write_text((old / 'native.tcl').read_text().replace(str(old), str(target)))
    command = ['/usr/bin/tclsh8.6', str(RUNTIME / 'magic/tcl/magic.tcl'), '-dnull',
               '-noconsole', '-rcfile', '/dev/shm/nssoc-magic-pad-stack-tech-v1/ihp-sg13g2.magicrc', str(script)]
    env = {k: v for k, v in os.environ.items()
           if k not in ('GH_TOKEN', 'GITHUB_TOKEN', 'PYTHONPATH', 'PYTHONHOME', 'LD_PRELOAD')}
    env['CAD_ROOT'] = str(RUNTIME)
    start = time.monotonic()
    with (target / 'native.log').open('w') as log:
        try:
            process = subprocess.run(command, cwd=target, env=env, preexec_fn=limits,
                                     stdout=log, stderr=subprocess.STDOUT, timeout=30, check=False)
            code = process.returncode
        except subprocess.TimeoutExpired:
            code = None
    cases[name] = dict(command=command, returncode=code, seconds=time.monotonic()-start,
                       outputs={p.name: pin(p) for p in target.iterdir() if p.is_file()})
    print(name, code, flush=True)
result = dict(method=pin(__file__), parent_library=pin(PARENT / 'runtime/lib/magic/tcl/tclmagic.so'),
              parent_source=pin(PARENT / 'source/resis/ResBasic.c'), changed_source=pin(source),
              private_library=pin(RUNTIME / 'magic/tcl/tclmagic.so'), builds=builds, cases=cases,
              accepted_resistance=False)
(B / 'overlap-pilot.json').write_text(json.dumps(result, indent=2) + '\n')
