# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Native-output mutations only; not physical geometry fault controls."""
from pathlib import Path
import importlib.util
import json
import re
import shutil
import tempfile

B = Path(__file__).parent
spec = importlib.util.spec_from_file_location('pilot_auditor', B / 'audit_pilot.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
source = Path('/dev/shm/nssoc-magic-resis-terminals-v1-overlap/pnp')
mutations = {
    'device_body_to_vdd': ('unreduced.spice', lambda t: t.replace('PAD00.t0 SUB.t0 diode', 'PAD00.t0 VDD00.t0 diode')),
    'device_value_changed': ('unreduced.spice', lambda t: t.replace('ea=35.0028p', 'ea=36.0028p')),
    'device_removed': ('unreduced.spice', lambda t: '\n'.join(l for l in t.splitlines() if not l.startswith('X0 '))+'\n'),
    'body_anchor_open': ('unreduced.spice', lambda t: '\n'.join(l for l in t.splitlines() if not (l.startswith('R') and 'SUB' in l.split()[1:3]))+'\n'),
    'body_vdd_short': ('unreduced.spice', lambda t: t.replace('.ends', 'Rbad SUB VDD00 0.1\n.ends')),
    'resistor_value_changed': ('unreduced.spice', lambda t: t.replace('R0 PAD00 PAD00.n63 0.0435111', 'R0 PAD00 PAD00.n63 1.0435111')),
    'extra_capacitance': ('unreduced.spice', lambda t: t.replace('.ends', 'Cbad PAD00 SUB 1e-12\n.ends')),
    'missing_capacitance': ('unreduced.spice', lambda t: '\n'.join(l for l in t.splitlines() if not l.startswith('C0 '))+'\n'),
    'port_relabel': ('unreduced.spice', lambda t: t.replace('.subckt single_flat PAD00', '.subckt single_flat WRONG')),
    'incomplete_net_census': ('native.log', lambda t: t.replace('Nets output: 3 ', 'Nets output: 2 ')),
    'missing_native_completion': ('native.log', lambda t: t.replace('NSSOC_SINGLE_UNREDUCED_COMPLETE', 'NOT_COMPLETE')),
    'native_terminal_error': ('native.log', lambda t: t+'\nMissing substrate connection of device\n'),
}
outputs = {}
for name, (filename, change) in mutations.items():
    with tempfile.TemporaryDirectory(prefix='nssoc-resis-audit-', dir='/dev/shm') as tmp:
        target = Path(tmp)
        for sourcefile in source.iterdir():
            if sourcefile.suffix in ('.ext', '.spice', '.log'):
                shutil.copyfile(sourcefile, target / sourcefile.name)
        path = target / filename
        original = path.read_text()
        altered = change(original)
        assert altered != original, name
        path.write_text(altered)
        try:
            module.audit(target)
        except ValueError as error:
            outputs[name] = str(error)
        else:
            raise AssertionError('Accepted altered raw control: '+name)
for name in ('pnp', 'npn'):
    result = module.audit(Path('/dev/shm/nssoc-magic-resis-terminals-v1-overlap') / name)
    (B / (name+'-raw-review-sealed.json')).write_text(json.dumps(result, indent=2)+'\n')
(B / 'raw-control-results.json').write_text(json.dumps(dict(scope='Native-output parser controls only; no physical geometry control claim.',
    rejected=outputs, positive_raw_replays=2), indent=2)+'\n')
print(len(outputs), 'raw mutations rejected; 2 actual native positives reparsed')
