# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Preserve the crash repair and its failing composite regressions separately."""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import tarfile

ROOT = Path.cwd()
B = Path(__file__).parent
PARENT = Path('/dev/shm/nssoc-magic-esd-v1-build-final')
ALLOC = Path('/dev/shm/nssoc-magic-resis-terminals-v1-pilot')
OVERLAP = Path('/dev/shm/nssoc-magic-resis-terminals-v1-overlap')
spec = importlib.util.spec_from_file_location('audit_pilot', B / 'audit_pilot.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def pin(path):
    path = Path(path)
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def normalized(text):
    value = m.parse_spice(text)
    return dict(ports=value['ports'], devices=Counter(value['devices']),
                resistors=Counter((tuple(sorted((a, b))), v) for a, b, v in value['resistors']),
                capacitors=Counter((tuple(sorted((a, b))), v) for a, b, v in value['capacitors']))


files = {}


def add(name, path):
    assert name not in files and Path(path).is_file()
    files[name] = Path(path)


for path in B.iterdir():
    if path.is_file() and path.suffix in ('.py', '.json') and path.name != 'validation.json':
        add('methods-and-records/' + path.name, path)
cases = {}
roots = [('allocation/pnp', ALLOC / 'pnp'), ('allocation/npn', ALLOC / 'npn'),
         ('overlap/pnp', OVERLAP / 'pnp'), ('overlap/npn', OVERLAP / 'npn'),
         ('esd32', Path('/dev/shm/nssoc-resis-terminal-regression-esd32-01')),
         ('hbt24', Path('/dev/shm/nssoc-resis-terminal-regression-hbt24-01')),
         ('bank351', Path('/dev/shm/nssoc-resis-terminal-regression-bank351-01'))]
for name, directory in roots:
    log = (directory / 'native.log').read_text()
    errors = Counter()
    for line in log.splitlines():
        if line.startswith('Missing '):
            errors[line.split('connection')[0].strip()] += 1
        if line.startswith('Error in extracting node'):
            errors['Error in extracting node'] += 1
    cases[name] = dict(errors=dict(errors), native_census=[line for line in log.splitlines()
                      if line.startswith(('Total Nets:', 'Nets extracted:', 'Nets output:'))],
                      accepted_resistance=False)
    for path in directory.iterdir():
        if path.is_file() and path.suffix in ('.tcl', '.log', '.ext', '.spice', '.json', '.sim', '.nodes'):
            add('native/' + name + '/' + path.name, path)
bridges = {}
for name, old, new in [
    ('pnp', Path('/dev/shm/nssoc-rc-single-pnp-01/baseline.spice'), OVERLAP / 'pnp/baseline.spice'),
    ('npn', Path('/dev/shm/nssoc-rc-single-npn-01/baseline.spice'), OVERLAP / 'npn/baseline.spice'),
    ('bank351', Path('/dev/shm/nssoc-bank-conservation-v1-02/baseline.spice'),
     Path('/dev/shm/nssoc-resis-terminal-regression-bank351-01/baseline.spice'))]:
    assert normalized(old.read_text()) == normalized(new.read_text())
    bridges[name] = dict(old=pin(old), new=pin(new), exact_device_terms_values_and_C_edge_multiset_equal=True,
                         capacitor_name_order_and_endpoint_order_not_semantic=True)
for name, directory in [('parent', PARENT), ('allocation', ALLOC), ('overlap', OVERLAP)]:
    for relative in ('resis/ResUtils.c', 'resis/ResBasic.c', 'resis/resis.h', 'resis/ResRex.c', 'LICENSE'):
        add('source/' + name + '/' + relative, directory / 'source' / relative)
    if name != 'parent':
        for filename in ('build_resis.log', 'link.log'):
            add('build/' + name + '/' + filename, directory / filename)
add('UPSTREAM-NOTICES.txt', ROOT / 'hw/soc/out/pcie-magic-pad-stack-v1-20261004/UPSTREAM-NOTICES.txt')
inventory = {name: dict(source=str(path), **pin(path)) for name, path in files.items()}
capsule = B / 'resis-terminal-pilot.tar.xz'
with tarfile.open(capsule, 'x:xz', preset=6) as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
with tarfile.open(capsule, 'r:xz') as archive:
    assert len(archive.getmembers()) == len(inventory)
    for member in archive.getmembers():
        data = archive.extractfile(member).read()
        assert len(data) == inventory[member.name]['bytes']
        assert hashlib.sha256(data).hexdigest() == inventory[member.name]['sha256']
assert all(pin(path) == {k: inventory[name][k] for k in ('bytes', 'sha256')} for name, path in files.items())
result = dict(status='FAIL_REQUIRED_COMPOSITE_RESISTANCE_REGRESSIONS_CRASH_REPAIR_DIAGNOSTIC_ONLY',
    capsule=dict(path=str(capsule), **pin(capsule), members=len(inventory)), inventory=inventory,
    methods={p.name: pin(p) for p in sorted(B.glob('*.py'))}, cases=cases, exact_baseline_bridges=bridges,
    ancestor=pin(ROOT / 'hw/soc/out/pcie-magic-bank-conservation-v1-20261004/validation.json'),
    runtime_pins={name: pin(directory / 'runtime/lib/magic/tcl/tclmagic.so') for name, directory in
                  [('parent_unchanged', PARENT), ('allocation_private', ALLOC), ('overlap_private', OVERLAP)]},
    findings=[
        'One-SD ESD subcircuits allocated three slots while fixed legacy substrate index3 was read out of bounds. Both polarity crashes reproduced; allocation witness confirms sd1/slots4 in private repair.',
        'Allocation repair reserves the fixed four positions while SD iteration retains its original count; it does not invent a fourth electrical terminal.',
        'Allocation-only pilot exposes real missing VDD/gate-terminal connection for both polarities and remains rejected.',
        'Native cross-plane subcircuit gate callback uses exact native connectivity mask and positive-area overlap with an actual conducting tile. The point lies inside that intersection, with no node-name inference or body union.',
        'Both single polarity outputs preserve full three-terminal device contraction through1104/1091 actual positive native resistor edges and all collapsed capacitance, but this is not device attachment-point or RF validation.',
        '32-ESD,24-HBT and full351-device regressions all exit0 yet remain rejected for actual missing-terminal/extraction errors and/or incomplete output.',
        '32-ESD retains31 substrate misses; HBT24 retains24 gate and24 terminal misses plus1 failed net; full351 retains122 substrate,72 gate,98 terminal misses plus64 failed nets.',
        'No installed or previously frozen runtime, technology, original device geometry, netlist or thresholds changed.',
        'Only ResUtils.c and ResBasic.c change; no header or ABI changes. Their resis objects and module were rebuilt and the isolated runtime relinked.',
        'Split-tile cross-plane gate attachment is intentionally unsupported and will retain a terminal failure; no point approximated outside an actual rectangle.'],
    validation=dict(actual_native_positive_raw_reviews=2, raw_mutations_rejected=12,
                    mutation_scope='Edited native output/schema controls, not geometry fault controls.',
                    all_three_composite_raw_reviews_rejected=True,
                    native_baselines_exactly_preserved=True, inherited_frozen_geometry_faults_not_replayed_on_pilot=True),
    next_step='Smallest two-ESD shared substrate geometry case and one-HBT C/B/E/SUB case, trace actual substrate/conductor traversal before any further private repair.',
    accepted_resistance=False, full_bank_pex_qualified=False, rf_qualified=False)
(B / 'validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(validation=pin(B / 'validation.json'), capsule=pin(capsule), members=len(inventory)), indent=2))
