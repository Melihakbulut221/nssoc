puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-magic-resis-terminals-v1-pilot/npn}
drc off
scalegrid 1 1
gds readonly true
gds read {/dev/shm/nssoc-rc-single-esd-fixtures/npn.gds}
load single_npn
flatten single_flat
load single_flat
select top cell
box values 67.38um 223.725um 70.98um 253.325um
label SUB center metal2
port SUB make 1
port SUB class inout
port SUB use signal
box values 57.92um 227.745um 61.52um 249.305um
label PAD16 center metal2
port PAD16 make 2
port PAD16 class inout
port PAD16 use signal
box values 60.0um 255.7um 69.72um 257.05um
label VDD16 center metal1
port VDD16 make 3
port VDD16 class inout
port VDD16 use signal
save single_flat
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o baseline.spice
puts NSSOC_SINGLE_BASELINE_COMPLETE
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice extresist on
ext2spice -o unreduced.spice
puts NSSOC_SINGLE_UNREDUCED_COMPLETE
quit -noprompt
