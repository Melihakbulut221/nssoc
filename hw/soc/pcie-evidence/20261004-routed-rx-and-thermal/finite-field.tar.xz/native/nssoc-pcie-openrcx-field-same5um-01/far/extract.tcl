set_thread_count 1
read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_def {/dev/shm/nssoc-pcie-openrcx-field-same5um-01/far/wires.def}
define_process_corner -ext_model_index 0 typical
extract_parasitics -ext_model_file {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/librelane/IHP_rcx_patterns.rules} -coupling_threshold 0 -cc_model 10 -context_depth 5 -no_merge_via_res
write_spef {/dev/shm/nssoc-pcie-openrcx-field-same5um-01/far/wires.spef}
write_db {/dev/shm/nssoc-pcie-openrcx-field-same5um-01/far/wires.odb}
write_def {/dev/shm/nssoc-pcie-openrcx-field-same5um-01/far/native.def}
