# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import odb
import json
from pathlib import Path
rows=[]
for name in ['near','far']:
 p=Path('/dev/shm/nssoc-pcie-openrcx-field-same5um-01')/name/'wires.odb'
 db=odb.dbDatabase.create();odb.read_db(db,str(p));block=db.getChip().getBlock()
 print(name,db.getTech().findLayer('Metal2').getWidth())
 for net in block.getNets():
  wire=net.getWire();print(net.getName(),[x for x in dir(wire) if 'box' in x.lower() or 'shape' in x.lower()]);print(wire.getBBox())
