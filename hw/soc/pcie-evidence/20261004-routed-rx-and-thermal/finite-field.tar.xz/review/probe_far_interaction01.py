# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Finite actual GDS field controls; no calibrated RC or complete-chip acceptance."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import sys
import time
import argparse
import shutil
import klayout.db as db
from klayout_pex.pex25d.artifact import infer_artifact_spec
from klayout_pex.pex25d.codec import load_artifact
from klayout_pex.pex25d.resolver import resolve
from klayout_pex.pex25d.diagnostics import DiagnosticsReport
from klayout_pex.pex25d.exporters import ExporterOptions
from klayout_pex.fastercap.pex25d_exporter import Pex25DFasterCapExporter

ROOT = Path('/home/hasanmelih/Documents/ChatGPT/nnsoc')
OLD = ROOT/'hw/soc/out/external-review-20260919/route-closure-20260923'
sys.path[:0] = [str(OLD), str(ROOT/'hw/soc/flow')]
from fast_surface_check import closure_errors
from check_fastercap_completion import check as check_solver

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--tolerance', type=float, choices=[.005], required=True)
parser.add_argument('--margin', type=float, choices=[8], required=True)
args = parser.parse_args()
assert (args.tolerance, args.margin) == (.005, 8)
assert shutil.disk_usage('/dev/shm').free > 512 * 1024**2 + 1024**2
OUT = args.out
OUT.mkdir()
APP = ROOT/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
KPEX = ROOT/'hw/soc/tools/kpex-env/bin/kpex'
SOLVER = ROOT/'hw/soc/tools/fastercap-6.0.7/FasterCap_6.0.7/FasterCap'
COMPAT = ROOT/'hw/soc/tools/fastercap-6.0.7/compat/lib/x86_64-linux-gnu'
WRAPPER = OUT/'klayout-cli'
WRAPPER.write_text('#!/bin/sh\nexec "'+str(APP)+'" klayout "$@"\n')
WRAPPER.chmod(0o755)

def pin(path):
    path = Path(path)
    with path.open('rb') as f:
        return dict(bytes=path.stat().st_size, sha256=hashlib.file_digest(f,'sha256').hexdigest())

FILES = [Path(__file__), ROOT/'hw/soc/out/pcie-openrcx-contract-20261004/field_probe06.py', APP, KPEX, SOLVER, OLD/'fast_surface_check.py', ROOT/'hw/soc/flow/check_fastercap_completion.py']
RECORD = dict(requested_tolerance=args.tolerance, requested_margin_um=args.margin, baseline_preserved=True, interaction_ratio=.01,reference='https://www.fastfieldsolvers.com/forum/topic.asp?TOPIC_ID=1286',status='RUNNING', input_pins={str(p):pin(p) for p in FILES}, cases=[], qualified_rc=False)
def save():
    (OUT/'result.json').write_text(json.dumps(RECORD,indent=2)+'\n')
def limit():
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_AS,(2048*1024**2,2048*1024**2))
def execute(command,folder,name,environment):
    start=time.monotonic()
    with (folder/name).open('x') as log:
        process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,
                                 env=environment,preexec_fn=limit,start_new_session=True)
        try:
            code=process.wait()
        except BaseException:
            import signal
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            process.wait()
            raise
    return dict(command=list(map(str,command)),returncode=code,elapsed_seconds=time.monotonic()-start,
                memory_limit_bytes=2048*1024**2,elapsed_watchdog_seconds=None)
def mesh_check(g,triangles):
    return closure_errors([((e.p0.x,e.p0.y,e.p0.z),(e.p1.x,e.p1.y,e.p1.z))
                           for e in g._normed_edges(triangles)])

save()
try:
    for name,edge_gap in [('far',2.0)]:
        assert shutil.disk_usage('/dev/shm').free > 512 * 1024**2 + 1024**2
        d=OUT/name;d.mkdir()
        # Two isolated actual rectangles match full native DEF wire polygons:
        # centerline length5um, width0.2um, halfwidth end extension0.1um.
        layout=db.Layout();layout.dbu=0.001;top=layout.create_cell('PCIE_WIRE_FIELD')
        for net,y in [('A',0.0),('B',0.2+edge_gap)]:
            top.shapes(layout.layer(10,0)).insert(db.DBox(-.1,y-.1,5.1,y+.1))
            top.shapes(layout.layer(10,2)).insert(db.DBox(.1,y-.05,.2,y+.05))
            top.shapes(layout.layer(10,25)).insert(db.DText(net,db.DTrans(.15,y)))
        gds=d/'input.gds';layout.write(str(gds))
        row=dict(name=name,edge_gap_um=edge_gap,centerline_length_um=5,width_um=.2,
                 ground_plane='KPEX nominal IHP stack substrate, not calibrated foundry model')
        RECORD['cases'].append(row);save()
        command=[str(KPEX),'pex25d','--pdk','ihp-sg13g2','--gds',str(gds),'--cell','PCIE_WIRE_FIELD',
                 '--out_dir',str(d/'extraction'),'--cache-lvs','false','--blackbox','true',
                 '--output_file',str(d/'model.pex25d'),'--output_scene',str(d/'model.pex25d.scene.pb'),'--strict']
        row['kpex']=execute(command,d,'kpex.log',{**os.environ,'KPEX_KLAYOUT_EXE':str(WRAPPER),
                              'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'});save()
        assert row['kpex']['returncode']==0
        report=DiagnosticsReport()
        artifact=load_artifact(infer_artifact_spec(str(d/'model.pex25d')),report=report)
        scene=resolve(artifact,report=report,strict=True);assert int(report.exit_code)==0
        exporter=Pex25DFasterCapExporter(scene,ExporterOptions(field_margin_um=args.margin))
        geometry=exporter.build()
        assert set(geometry.net_names)=={'A','B','subs'},geometry.net_names
        checks={}
        for material in geometry.materials:
            checks['material:'+material]=mesh_check(geometry,geometry._collect_diel_tris(material))
        for net in geometry.net_names:
            checks['net:'+net]=mesh_check(geometry,geometry._collect_cond_tris(net))
        row['mesh_closure_errors']=checks;assert sum(checks.values())==0
        row['removed_actual_A_triangle_errors']=mesh_check(geometry,geometry._collect_cond_tris('A')[1:])
        assert row['removed_actual_A_triangle_errors']>0
        bbox=exporter.field.bbox()
        row['actual_field_bbox_um']=[v*exporter.dbu for v in [bbox.left,bbox.bottom,bbox.right,bbox.top]]
        row['requested_field_margin_um']=args.margin
        row['model_pin']=pin(d/'model.pex25d')
        mesh_dir=d/'mesh';mesh_dir.mkdir()
        mesh=geometry.write_fastcap(output_dir_path=str(mesh_dir),prefix='mesh')
        row['mesh_pins']={p.name:pin(p) for p in mesh_dir.iterdir() if p.is_file()};save()
        command=[str(SOLVER),'-b','-i',f'-a{args.tolerance}','-d0.01','-g','-v','-ap',str(mesh)]
        row['solver']=execute(command,d,'solver.log',{**os.environ,'LD_LIBRARY_PATH':str(COMPAT),
                             'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1'});save()
        row['numerics']=check_solver((d/'solver.log').read_text(),row['solver']['returncode'],args.tolerance)
        row['raw_pins']={p.name:pin(p) for p in d.iterdir() if p.is_file()};save()
    assert RECORD['input_pins']=={str(p):pin(p) for p in FILES}
    RECORD['status']='COMPLETE_NUMERICAL_CONTROLS_REVIEW_REQUIRED'
except BaseException as error:
    RECORD.update(status='FAILED_RETAINED',error=repr(error));raise
finally:
    save()
