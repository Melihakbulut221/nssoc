# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Native finite 5um RCX comparison; no field/model accuracy qualification."""
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / 'scripts'))
from audit_pcie_openrcx_fixture_v1 import audit

OUT = Path('/dev/shm/nssoc-pcie-openrcx-field-same5um-01')
PDK = Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
LEF = PDK / 'libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef'
RULES = PDK / 'libs.tech/librelane/IHP_rcx_patterns.rules'
APP = ROOT / 'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'


def pin(p):
    with p.open('rb') as f:
        return dict(bytes=p.stat().st_size, sha256=hashlib.file_digest(f, 'sha256').hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def main():
    assert shutil.disk_usage('/dev/shm').free >= 512 * 1024**2 + 1024**2
    OUT.mkdir()
    inputs = {str(p): pin(p) for p in [Path(__file__), LEF, RULES, APP,
              ROOT / 'scripts/audit_pcie_openrcx_fixture_v1.py']}
    result = dict(status='RUNNING', inputs=inputs, cases=[], qualified_rc=False)
    def save():
        p = OUT / 'result.tmp'
        p.write_text(json.dumps(result, indent=2) + '\n')
        os.replace(p, OUT / 'result.json')
    save()
    try:
        for name, gap in [('near', 220), ('far', 2000)]:
            d = OUT / name
            d.mkdir()
            ys = (10000, 10200 + gap)
            pins = '\n'.join(
                f'- {p} + NET {n} + DIRECTION {direction} + USE SIGNAL\n'
                f' + LAYER Metal2 ( -100 -100 ) ( 100 100 ) + FIXED ( {x} {y} ) N ;'
                for p, n, direction, x, y in [
                    ('A', 'wire', 'INPUT', 10000, ys[0]),
                    ('B', 'wire', 'OUTPUT', 15000, ys[0]),
                    ('C', 'coupled', 'INPUT', 10000, ys[1]),
                    ('D', 'coupled', 'OUTPUT', 15000, ys[1])])
            text = f'''VERSION 5.8 ;
DIVIDERCHAR "/" ;
BUSBITCHARS "[]" ;
DESIGN nssoc_rcx_wire_5um ;
UNITS DISTANCE MICRONS 1000 ;
DIEAREA ( 0 0 ) ( 30000 30000 ) ;
PINS 4 ;
{pins}
END PINS
NETS 2 ;
- wire ( PIN A ) ( PIN B )
 + ROUTED Metal2 ( 10000 {ys[0]} ) ( 15000 {ys[0]} ) ;
- coupled ( PIN C ) ( PIN D )
 + ROUTED Metal2 ( 10000 {ys[1]} ) ( 15000 {ys[1]} ) ;
END NETS
END DESIGN
'''
            (d / 'wires.def').write_text(text)
            tcl = f'''set_thread_count 1
read_lef {{{LEF}}}
read_def {{{d / 'wires.def'}}}
define_process_corner -ext_model_index 0 typical
extract_parasitics -ext_model_file {{{RULES}}} -coupling_threshold 0 -cc_model 10 -context_depth 5 -no_merge_via_res
write_spef {{{d / 'wires.spef'}}}
write_db {{{d / 'wires.odb'}}}
write_def {{{d / 'native.def'}}}
'''
            (d / 'extract.tcl').write_text(tcl)
            command = [str(APP), 'openroad', '-exit', str(d / 'extract.tcl')]
            start = time.monotonic()
            with (d / 'native.log').open('x') as log:
                p = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                     preexec_fn=limits, start_new_session=True)
                try:
                    rc = p.wait()
                except BaseException:
                    import signal
                    try:
                        os.killpg(p.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    p.wait()
                    raise
            assert rc == 0
            geom = [dict(net=n, ports=ps, layer='Metal2', length_um=5, width_um=.2)
                    for n, ps in [('wire', ['A', 'B']), ('coupled', ['C', 'D'])]]
            observed = audit(d / 'wires.spef', geom, coupling=name == 'near')
            result['cases'].append(dict(name=name, edge_gap_um=gap / 1000,
                geometry=geom, translated_rectangles_um=[
                    [-.1, (y - 10000) / 1000 - .1, 5.1, (y - 10000) / 1000 + .1]
                    for y in ys], command=command, returncode=rc,
                elapsed_seconds=time.monotonic() - start, memory_limit_bytes=1024**3,
                audit=observed, outputs={p.name: pin(p) for p in d.iterdir() if p.is_file()}))
            save()
        assert inputs == {p: pin(Path(p)) for p in inputs}
        result['status'] = 'COMPLETE_FINITE_SAME_GEOMETRY_RCX_COMPARISON_NOT_QUALIFIED'
    except BaseException as e:
        result.update(status='FAILED_RETAINED', error=repr(e))
        raise
    finally:
        save()


if __name__ == '__main__':
    main()
