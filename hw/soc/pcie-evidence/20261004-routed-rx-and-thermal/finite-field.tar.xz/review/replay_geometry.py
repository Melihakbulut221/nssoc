# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Read-only native GDS/model/mesh replay. No field solver is executed."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import resource
import sys
import tempfile

import klayout.db as db
from klayout_pex.pex25d.artifact import infer_artifact_spec
from klayout_pex.pex25d.codec import load_artifact
from klayout_pex.pex25d.resolver import resolve
from klayout_pex.pex25d.diagnostics import DiagnosticsReport
from klayout_pex.pex25d.exporters import ExporterOptions
from klayout_pex.fastercap.pex25d_exporter import Pex25DFasterCapExporter

ROOT = Path(__file__).resolve().parents[5]
OLD = ROOT / 'hw/soc/out/external-review-20260919/route-closure-20260923'
sys.path.insert(0, str(OLD))
from fast_surface_check import closure_errors


def pin(p):
    with p.open('rb') as f:
        return dict(bytes=p.stat().st_size, sha256=hashlib.file_digest(f, 'sha256').hexdigest())


def mesh_check(g, triangles):
    return closure_errors([((e.p0.x, e.p0.y, e.p0.z), (e.p1.x, e.p1.y, e.p1.z))
                           for e in g._normed_edges(triangles)])


def run(folder):
    r = json.loads((folder / 'result.json').read_text())
    assert r['status'] in ('COMPLETE_NUMERICAL_CONTROLS_REVIEW_REQUIRED', 'FAILED_RETAINED')
    rows = []
    for row in r['cases']:
        d = folder / row['name']
        gap = row['edge_gap_um']
        assert gap in (.22, 2) and row['centerline_length_um'] == 5 and row['width_um'] == .2
        expected = [db.DBox(-.1, -.1, 5.1, .1), db.DBox(-.1, .1 + gap, 5.1, .3 + gap)]
        l = db.Layout()
        l.read(str(d / 'input.gds'))
        assert len(l.top_cells()) == 1
        top = l.top_cell()
        assert top.name == 'PCIE_WIRE_FIELD' and not list(top.each_inst()) and l.dbu == .001
        assert {(l.get_info(i).layer, l.get_info(i).datatype) for i in l.layer_indices()
                if not top.shapes(i).is_empty()} == {(10, 0), (10, 2), (10, 25)}
        actual = db.Region(top.shapes(l.layer(10, 0)))
        desired = db.Region()
        for box in expected:
            desired.insert(box.to_itype(l.dbu))
        assert (actual ^ desired).is_empty() and actual.count() == 2
        labels = sorted(s.text.string for s in top.shapes(l.layer(10, 25)).each())
        assert labels == ['A', 'B']
        text = (d / 'model.pex25d').read_text()
        matches = re.findall(r'^BOX CONDUCTOR (\S+) LAYER (\S+) LL (\S+) (\S+) UR (\S+) (\S+)$', text, re.M)
        assert len(matches) == 2 and {x[0] for x in matches} == {'A', 'B'}
        for values, box in zip(matches, expected):
            assert values[1] == 'Metal2'
            assert db.DBox(*map(float, values[2:])).to_itype(l.dbu) == box.to_itype(l.dbu)
        assert 'METAL Metal2 Z_OFFSETS 2.0 2.49' in text
        assert re.findall(r'^CONDUCTOR (\S+) (\S+)$', text, re.M) == [('A', 'A'), ('B', 'B')]
        assert 'GROUND_PLANE subs Z_OFFSETS -0.28 0.0' in text
        report = DiagnosticsReport()
        scene = resolve(load_artifact(infer_artifact_spec(str(d / 'model.pex25d')), report=report),
                        report=report, strict=True)
        assert int(report.exit_code) == 0
        exporter = Pex25DFasterCapExporter(scene, ExporterOptions(field_margin_um=row['requested_field_margin_um']))
        geometry = exporter.build()
        assert set(geometry.net_names) == {'A', 'B', 'subs'}
        checks = {f'material:{m}': mesh_check(geometry, geometry._collect_diel_tris(m))
                  for m in geometry.materials}
        checks.update({f'net:{n}': mesh_check(geometry, geometry._collect_cond_tris(n))
                       for n in geometry.net_names})
        assert checks == row['mesh_closure_errors'] and not any(checks.values())
        negative = mesh_check(geometry, geometry._collect_cond_tris('A')[1:])
        assert negative == row['removed_actual_A_triangle_errors'] > 0
        with tempfile.TemporaryDirectory(prefix='field-mesh-replay-', dir='/dev/shm') as tmp:
            geometry.write_fastcap(output_dir_path=tmp, prefix='mesh')
            inventory = {p.name: pin(p) for p in Path(tmp).iterdir() if p.is_file()}
            assert inventory == row['mesh_pins']
        rows.append(dict(name=row['name'], exact_gds_boxes=True, exact_model_boxes=True,
                         exact_mesh_files=len(inventory), all_closure_errors=checks,
                         removed_triangle_rejected=negative, margin_um=row['requested_field_margin_um']))
    modules = {}
    for module in list(sys.modules.values()):
        p = getattr(module, '__file__', None)
        if p and ('klayout' in p or 'fast_surface_check' in p) and Path(p).is_file():
            modules[str(Path(p).resolve())] = pin(Path(p))
    return dict(source=pin(Path(__file__)), parent_result=pin(folder / 'result.json'),
                status='PASS_SAVED_GDS_MODEL_AND_EXACT_MESH_REPLAY_ONLY', cases=rows,
                loaded_modules=modules, no_native_field_solver_rerun=True, qualified_rc=False)


if __name__ == '__main__':
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    p = argparse.ArgumentParser()
    p.add_argument('--folder', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    assert not a.out.exists()
    a.out.write_text(json.dumps(run(a.folder), indent=2) + '\n')
