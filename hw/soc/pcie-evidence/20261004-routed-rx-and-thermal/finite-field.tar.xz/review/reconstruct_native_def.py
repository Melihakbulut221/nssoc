# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Native DEF/LEF bridge for the exact two straight-route fixtures only."""
import hashlib,json,re
from pathlib import Path
out=Path(__file__).resolve().parent
rows=[]
log=(out/'native-wire-api.log').read_text()
assert 'near 200\n' in log and 'far 200\n' in log
for name,gap in [('near',220),('far',2000)]:
 root=Path('/dev/shm/nssoc-pcie-openrcx-field-same5um-01')/name
 text=(root/'native.def').read_text()
 assert 'UNITS DISTANCE MICRONS 1000 ;' in text and 'COMPONENTS 0 ;' in text
 blocks=text.split('NETS 2 ;')[1].split('END NETS')[0]
 routes=re.findall(r'- (wire|coupled) .*?\+ ROUTED Metal2 \( (\d+) (\d+) \) \( (\d+) \* \) ;',blocks,re.S)
 assert len(routes)==2
 boxes={name:[int(x1)-100,int(y)-100,int(x2)+100,int(y)+100] for name,x1,y,x2 in routes}
 expected={'wire':[9900,9900,15100,10100],'coupled':[9900,10100+gap,15100,10300+gap]}
 assert boxes==expected
 translated={k:[v-10000 for v in vals] for k,vals in boxes.items()}
 field=Path('/dev/shm/nssoc-pcie-coupled-field-06')/name/'model.pex25d'
 modelboxes=re.findall(r'^BOX CONDUCTOR (\w+) LAYER Metal2 LL (\S+) (\S+) UR (\S+) (\S+)$',field.read_text(),re.M)
 parsed={key:[round(float(v)*1000) for v in vals] for key,*vals in modelboxes}
 assert parsed=={'A':translated['wire'],'B':translated['coupled']}
 rows.append(dict(name=name,native_def_sha256=hashlib.sha256((root/'native.def').read_bytes()).hexdigest(),model_sha256=hashlib.sha256(field.read_bytes()).hexdigest(),native_lef_width_dbu=200,model_boxes_dbu=parsed,translation_dbu=[10000,10000]))
result=dict(status='PASS_FINITE_NATIVE_DEF_AND_WIDTH_TO_FIELD_MODEL_BRIDGE',cases=rows,
 source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 scope='Straight DEF routes plus native technology width use half-width end extensions. This is a representation bridge, not independent direct OpenDB shape iteration.',
 api_limitations='getBBox returns an opaque optional Rect and dbWireShapeItr is absent in pinned Python bindings; those two diagnostic attempts are retained, not passed.')
(out/'native-def-geometry.json').write_text(json.dumps(result,indent=2)+'\n')
