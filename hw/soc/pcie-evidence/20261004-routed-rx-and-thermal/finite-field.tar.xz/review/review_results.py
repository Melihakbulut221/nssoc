# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Reparse preserved finite native results, retaining every failed disposition."""
from pathlib import Path
import hashlib
import json
import math
import re
import sys

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT / 'scripts'))
from audit_pcie_finite_field_v1 import audit


def pin(p):
    with p.open('rb') as f:
        return dict(bytes=p.stat().st_size, sha256=hashlib.file_digest(f, 'sha256').hexdigest())


def observe_spef(path):
    """Exact fixture-only observation, not acceptance of zero mutual C."""
    text = path.read_text()
    assert '*C_UNIT 1 PF\n' in text and '*R_UNIT 1 OHM\n' in text
    assert re.findall(r'^\*\d+ (\w+)$', text, re.M) == ['wire', 'coupled']
    rows = []
    for block, terminals in zip(text.split('*D_NET ')[1:], [{'A', 'B'}, {'C', 'D'}]):
        lines = block.splitlines()
        total = float(lines[0].split()[1])
        cap = block.split('*CAP\n')[1].split('*RES\n')[0].splitlines()
        entries = [x.split() for x in cap if x.strip()]
        assert [x[0] for x in entries] == ['1', '2', '3']
        assert all(len(x) == 3 for x in entries[:2]) and len(entries[2]) == 4
        assert {x[1] for x in entries[:2]} == terminals
        assert set(entries[2][1:3]) == {'B', 'D'}
        values = [float(x[-1]) for x in entries]
        assert all(math.isfinite(v) and v >= 0 for v in values)
        assert abs(sum(values) - total) <= 1e-9
        res = block.split('*RES\n')[1].split('*END')[0].strip().split()
        assert len(res) == 4 and set(res[1:3]) == terminals and float(res[3]) == 2.288
        rows.append(dict(ground_F=sum(values[:2]) * 1e-12,
                         mutual_F=values[2] * 1e-12, diagonal_F=total * 1e-12,
                         resistance_ohm=float(res[3])))
    assert len(text.split('*D_NET ')[1:]) == len(rows) == 2 and rows[0] == rows[1]
    return dict(terminals_unchanged=True, each_wire=rows[0], input=pin(path),
                observation_only=True, zero_mutual_is_not_accepted=True)


def main():
    out = Path(__file__).parent
    folders = [Path('/dev/shm/nssoc-pcie-coupled-field-' + x)
               for x in ['06', 'tight-01', 'domain12-01', 'interaction05-01',
                         'far-tight-01', 'far-interaction01-01']]
    reports = []
    for folder in folders:
        r = json.loads((folder / 'result.json').read_text())
        assert r['status'] != 'RUNNING'
        for p, value in r['input_pins'].items():
            assert pin(Path(p)) == value
        cases = []
        for case in r['cases']:
            d = folder / case['name']
            for p, value in case['mesh_pins'].items():
                assert pin(d / 'mesh' / p) == value
            for p, value in case.get('raw_pins', {}).items():
                assert pin(d / p) == value
            solver = case['solver']
            tolerance = float(next(x[2:] for x in solver['command'] if x.startswith('-a') and x != '-ap'))
            try:
                result = audit((d / 'solver.log').read_text(), solver['returncode'], tolerance)
            except ValueError as error:
                result = dict(status='REJECTED_NATIVE_RESULT', reason=str(error), qualified_rc=False)
                assert 'numerics' not in case
            else:
                assert result['native'] == case['numerics']
            result['name'] = case['name']
            result['raw_inventory'] = {str(p.relative_to(d)): pin(p) for p in d.rglob('*') if p.is_file()}
            cases.append(result)
        reports.append(dict(folder=str(folder), source_result=pin(folder / 'result.json'),
                            original_status=r['status'], cases=cases))
    comparison = []
    for name in ['near', 'far']:
        rcx = Path('/dev/shm/nssoc-pcie-openrcx-field-same5um-01') / name
        native = observe_spef(rcx / 'wires.spef')
        field = next(c for c in reports[0]['cases'] if c['name'] == name)
        a = field['matrix']['raw_matrix_F']
        # Holding explicit substrate and infinity at zero selects this principal
        # block; it is not a floating-substrate Schur complement or symmetrization.
        grounded_block = [a[1][1:], a[2][1:]]
        comparison.append(dict(name=name, centerline_um=5, width_um=.2,
            field_baseline_status=field['status'], raw_grounded_substrate_block_F=grounded_block,
            raw_field_ground_F=[sum(row) for row in grounded_block],
            raw_field_mutual_F=[-a[1][2], -a[2][1]], openrcx=native,
            comparison_is_descriptive_not_accuracy_validation=True))
    result = dict(status='COMPLETE_FINITE_NATIVE_AUDIT_WITH_FAILURES_RETAINED', fields=reports,
        same_geometry_comparison=comparison, qualified_rc=False, physical_accuracy_proved=False,
        source_pins={str(p): pin(p) for p in [Path(__file__), ROOT / 'scripts/audit_pcie_finite_field_v1.py']})
    (out / 'raw-review.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
