# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,json
from pathlib import Path
import odb
out=Path(__file__).resolve().parent
rows=[]
for name,gap in [('near',220),('far',2000)]:
 p=Path('/dev/shm/nssoc-pcie-openrcx-field-same5um-01')/name/'wires.odb'
 db=odb.dbDatabase.create();odb.read_db(db,str(p));block=db.getChip().getBlock()
 assert db.getTech().findLayer('Metal2').getWidth()==200
 observed={}
 for net in block.getNets():
  wire=net.getWire();it=odb.dbWireShapeItr();it.begin(wire);shape=odb.dbShape();boxes=[]
  while it.next(shape):
   assert not shape.isVia();boxes.append([shape.xMin(),shape.yMin(),shape.xMax(),shape.yMax()])
  observed[net.getName()]=boxes
 expected={'wire':[[9900,9900,15100,10100]],'coupled':[[9900,10100+gap,15100,10300+gap]]}
 assert observed==expected,(observed,expected)
 rows.append(dict(name=name,native_shapes_dbu=observed,dbu_per_um=1000,metal2_width_dbu=200,
                  odb_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
result=dict(status='PASS_ACTUAL_NATIVE_ODB_WIRE_POLYGONS_MATCH_FIELD_TRANSLATION',cases=rows,
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(out/'native-wire-geometry.json').write_text(json.dumps(result,indent=2)+'\n')
