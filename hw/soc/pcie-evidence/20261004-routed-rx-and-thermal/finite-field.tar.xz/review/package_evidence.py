# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Seal finite field/RCX evidence without changing any prior producer."""
import hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[5];B=Path(__file__).resolve().parent

def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())

review=json.loads((B/'raw-review.json').read_text());assert review['status']=='COMPLETE_FINITE_NATIVE_AUDIT_WITH_FAILURES_RETAINED'
for x in ['geometry-baseline.json','geometry-domain12.json','native-def-geometry.json']:
 assert json.loads((B/x).read_text())['status'].startswith('PASS_')
assert '22 passed' in (B/'tests-final.log').read_text()
folders=[Path('/dev/shm/nssoc-pcie-coupled-field-'+s) for s in ['05','06','tight-01','domain12-01','interaction05-01','far-tight-01','far-interaction01-01']]
folders += [Path('/dev/shm/nssoc-pcie-openrcx-field-same5um-'+s) for s in ['01','02']]
files={}
for folder in folders:
 for p in folder.rglob('*'):
  if p.is_file():files['native/'+folder.name+'/'+str(p.relative_to(folder))]=p
for p in B.iterdir():
 if p.is_file() and p.suffix in {'.py','.json','.log','.txt'} and p.name not in {'validation.json','manifest.json','package.log'}:files['review/'+p.name]=p
for n in ['field_probe05.py','field_probe06.py','field05-06-independent-review.json']:
 files['prior/'+n]=B.parent/n
for n in ['scripts/audit_pcie_finite_field_v1.py','sw/tests/test_pcie_finite_field_v1.py','hw/soc/flow/check_fastercap_completion.py','scripts/audit_pcie_openrcx_fixture_v1.py']:
 files['methods/'+n]=ROOT/n
for n in ['Apache-2.0.txt','LGPL-2.1-or-later.txt','GPL-3.0-or-later.txt','BSD-3-Clause.txt']:
 files['licenses/'+n]=ROOT/'LICENSES'/n
pdk=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
for n in ['libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef','libs.tech/librelane/IHP_rcx_patterns.rules']:
 files['pdk/'+n]=pdk/n
pkg=ROOT/'hw/soc/tools/kpex-env/lib/python3.12/site-packages'
for n in ['klayout_pex_protobuf/ihp-sg13g2_tech.pb.json','klayout_pex-0.4.4.dist-info/METADATA','klayout_pex-0.4.4.dist-info/licenses/LICENSE']:
 files['kpex/'+n]=pkg/n
notice='''Finite field/RCX evidence, copyright 2026 Hasan Melih Akbulut.
Authored scripts retain Apache-2.0 headers. Existing upstream source and PDK headers/licenses remain applicable.
KLayout PEX 0.4.4: Martin Koehler, GPL-3.0-or-later; exact nominal technology JSON and metadata included.
FasterCap 6.0.7 and OpenROAD binaries are hash identified, not redistributed here.
Raw generated finite geometry, solver logs and numerical matrices are evidence only.
No calibrated process model, full-chip extraction, field-domain convergence, or RC accuracy qualification.
Original driver captured six runtime/source pins. Imported-module hashes were additionally captured at review-time mesh replay, not retroactively at original execution.
'''
(B/'NOTICES.txt').write_text(notice);files['NOTICES.txt']=B/'NOTICES.txt'
manifest={name:pin(p) for name,p in sorted(files.items())}
(B/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=B/'finite-field-rcx-native-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
 blob=(json.dumps(manifest,indent=2)+'\n').encode();i=tarfile.TarInfo('manifest.json');i.size=len(blob);tar.addfile(i,io.BytesIO(blob))
with tarfile.open(archive,'r:xz') as tar:
 observed={}
 for m in tar.getmembers():
  assert m.isfile()
  data=tar.extractfile(m).read()
  if m.name!='manifest.json':observed[m.name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 assert observed==manifest
sources={str(ROOT/n):pin(ROOT/n) for n in ['scripts/audit_pcie_finite_field_v1.py','sw/tests/test_pcie_finite_field_v1.py']}
summary=[]
for f in review['fields']:
 for c in f['cases']:
  summary.append(dict(folder=f['folder'],case=c['name'],status=c['status'],max_pairwise_reciprocity=(max(v['relative_difference'] for v in c['matrix']['pairwise_reciprocity']) if 'matrix' in c else None)))
result=dict(status='SEALED_FINITE_FIELD_AUDIT_WITH_UNRESOLVED_CONVERGENCE',sources=sources,
 capsule=dict(path=str(archive),**pin(archive),members=len(manifest)+1,local_roundtrip=True),
 tests=22,field_cases=summary,same_geometry_comparison=review['same_geometry_comparison'],
 reports={p.name:pin(p) for p in [B/'raw-review.json',B/'geometry-baseline.json',B/'geometry-domain12.json',B/'native-def-geometry.json',B.parent/'field05-06-independent-review.json']},
 limits=dict(reciprocity_limit=.005,original_solver_tolerance=.005,no_tolerance_relaxation=True,native_address_space_limit_bytes=2*1024**3,core_limit_bytes=0),
 limitations=['Raw far reciprocity remains failed; no field-domain convergence; domain12 and tighter far runs ended SIGSEGV under2GiB cap, causal OOM not proved.','No symmetrization of raw matrix for acceptance. SPD diagnostic concerns symmetric part only.','Native DEF+width representation bridge, not unavailable direct OpenDB shape-iterator proof.','Original imported module provenance is review-time replay; not a retrospective complete original-runtime capture.','Same-geometry capacitance comparison is descriptive, not calibration or foundry-qualified PEX.'],qualified_rc=False)
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
