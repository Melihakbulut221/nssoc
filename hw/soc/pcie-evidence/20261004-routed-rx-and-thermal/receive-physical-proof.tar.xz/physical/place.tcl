set_thread_count 2
define_corners slow typical fast
read_liberty -corner slow {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_slow_1p08V_125C.lib}
read_liberty -corner typical {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib}
read_liberty -corner fast {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_fast_1p32V_m40C.lib}
read_db {/dev/shm/nssoc-rx-v2-tied-place-02/rx/cts.odb}
read_sdc {/dev/shm/nssoc-rx-v2-tied-place-02/rx/cts.sdc}
set_wire_rc -signal -layer Metal2
set_wire_rc -clock -layer Metal4
set_propagated_clock [all_clocks]
set_routing_layers -signal Metal2-Metal5 -clock Metal2-Metal5
set_global_routing_layer_adjustment Metal2-Metal5 0.30
global_route -congestion_iterations 100 -guide_file {/dev/shm/nssoc-rx-v2-tied-grt-02/rx/initial.guide}
estimate_parasitics -global_routing
puts GLOBAL_ROUTE_BEFORE_REPAIR
report_worst_slack -max
report_worst_slack -min
report_tns
report_check_types -max_slew -max_capacitance -violators
puts GLOBAL_ROUTE_BEFORE_REPAIR_slow_max
report_checks -corner slow -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_BEFORE_REPAIR_slow_min
report_checks -corner slow -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_BEFORE_REPAIR_typical_max
report_checks -corner typical -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_BEFORE_REPAIR_typical_min
report_checks -corner typical -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_BEFORE_REPAIR_fast_max
report_checks -corner fast -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_BEFORE_REPAIR_fast_min
report_checks -corner fast -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
detailed_placement
global_route -start_incremental
repair_design -slew_margin 5 -cap_margin 5
repair_timing -setup -setup_margin 0.10 -repair_tns 100
repair_timing -hold -hold_margin 0.05
detailed_placement
check_placement -verbose
global_route -end_incremental -congestion_iterations 100 -guide_file {/dev/shm/nssoc-rx-v2-tied-grt-02/rx/repaired.guide}
estimate_parasitics -global_routing
puts GLOBAL_ROUTE_REPAIRED
report_worst_slack -max
report_worst_slack -min
report_tns
report_check_types -max_slew -max_capacitance -violators
puts GLOBAL_ROUTE_REPAIRED_slow_max
report_checks -corner slow -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_REPAIRED_slow_min
report_checks -corner slow -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_REPAIRED_typical_max
report_checks -corner typical -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_REPAIRED_typical_min
report_checks -corner typical -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_REPAIRED_fast_max
report_checks -corner fast -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts GLOBAL_ROUTE_REPAIRED_fast_min
report_checks -corner fast -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
write_db {/dev/shm/nssoc-rx-v2-tied-grt-02/rx/repaired.odb}
write_verilog {/dev/shm/nssoc-rx-v2-tied-grt-02/rx/repaired.v}
write_def {/dev/shm/nssoc-rx-v2-tied-grt-02/rx/repaired.def}
write_sdc {/dev/shm/nssoc-rx-v2-tied-grt-02/rx/repaired.sdc}
