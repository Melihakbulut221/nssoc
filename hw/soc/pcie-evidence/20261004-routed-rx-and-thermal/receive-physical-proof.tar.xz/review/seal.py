# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,json,pathlib,re,tarfile,xml.etree.ElementTree as E
import compare as m
R=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent;P=m.ROOT
physical=pathlib.Path('/dev/shm/nssoc-rx-v2-tied-grt-02/rx');replay=pathlib.Path('/dev/shm/nssoc-rx-v2-tied-physical-replay-02');old=pathlib.Path('/dev/shm/nssoc-rxv2-physical-equivalence-peer-01')
def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
norm=json.loads((P/'normalization.json').read_text())
assert norm['returncode']==0 and norm['all_inputs_rechecked']
for name,value in norm['inputs'].items():assert pin(name)==value,name
gold,gate=m.read('gold'),m.read('gate');proof=m.compare(gold,gate);assert not proof['mismatches'] and proof['states']==1796 and proof['targets']==5419
mut=json.loads((P/'mutation-controls.json').read_text());assert mut['positive']==proof and len(mut['controls'])==10
assert all(c['status'].startswith('REJECTED_') for c in mut['controls'])
r=json.loads((replay/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_GEN3_RECEIVE_FRAMING' and r['tests']==dict(passed=6,failed=0,skipped=0)
for section in ('inputs','runtime'):
 for name,value in r[section].items():assert pin(name)==value,(section,name)
for name,value in r['outputs'].items():assert pin(replay/name)==value,name
assert r['inputs'][str(physical/'repaired.v')]==pin(physical/'repaired.v')
cases=list(E.parse(replay/'results.xml').getroot().iter('testcase'));assert len(cases)==6 and all(not any(c.find(k) is not None for k in ('failure','error','skipped')) for c in cases)
pr=json.loads((physical.parent/'result.json').read_text());case=pr['cases'][0];assert case['returncode']==0
for path,value in case['source_pins'].items():assert pin(path)==value,path
for name,value in case['outputs'].items():assert pin(physical/name)==value,name
# Reparse the final GRT snapshot only. No independent physical rerun or SDF claim.
log=(physical/'native.log').read_text();final=log.split('\nGLOBAL_ROUTE_REPAIRED\n');assert len(final)==2;final=final[1]
assert 'tns max 0.00' in final and '(VIOLATED)' not in final
checks=[]
for block in final.split('Startpoint:')[1:]:
 corner=re.search(r'\nCorner: (slow|typical|fast)\n',block).group(1)
 mode=re.search(r'\nPath Type: (max|min)\n',block).group(1)
 group=re.search(r'\nPath Group: ([^\n]+)\n',block).group(1)
 slack=float(re.search(r'\n\s*([\d.+-]+)\s+slack \(MET\)',block).group(1))
 checks.append(dict(corner=corner,path_type=mode,group=group,slack_ns=slack))
assert len(checks)==12
corners={c:{kind:min(x['slack_ns'] for x in checks if x['corner']==c and x['path_type']==kind) for kind in ('max','min')} for c in ('slow','typical','fast')}
assert corners=={'slow':{'max':.099031,'min':.050644},'typical':{'max':1.442430,'min':.081384},'fast':{'max':2.238742,'min':.114237}}
sdc=(physical/'repaired.sdc').read_text();assert 'create_clock -name development_clock -period 4.0000' in sdc
assert not re.search(r'(?m)^set_(?:false_path|multicycle_path|clock_uncertainty)\b',sdc)
counts=collections.Counter(l.split()[0] for l in sdc.splitlines() if l.strip() and not l.startswith('#'))
assert counts==dict(current_design=1,create_clock=1,set_propagated_clock=1,set_input_delay=527,set_output_delay=31,set_input_transition=527,set_load=31)
for cmd,value in [('set_input_delay','0.2000'),('set_output_delay','0.2000'),('set_input_transition','0.1000')]:assert all(l.split()[1]==value for l in sdc.splitlines() if l.startswith(cmd+' '))
state={}
for label,path in [('gold',pathlib.Path('/dev/shm/nssoc-rx-v2-output-native-01/mapped.v')),('gate',physical/'repaired.v')]:
 rows=re.findall(r'(?m)^\s*(sg13g2_dfrbpq_\d+)\s+(_[0-9]+_)\s*\(',path.read_text());assert len(rows)==1796 and len({n for t,n in rows})==1796;state[label]={n:t for t,n in rows}
assert state['gold'].keys()==state['gate'].keys();resized={n:[t,state['gate'][n]] for n,t in state['gold'].items() if t!=state['gate'][n]};assert len(resized)==22
assert len(re.findall(r'(?m)^\s*sg13g2_tiehi\s+', (physical/'repaired.v').read_text()))==1200
(B/'state-map.json').write_text(json.dumps(dict(map=state,resized=resized),indent=2)+'\n')
(B/'final-three-corner.log').write_text(final)
# Exact comparator reuse: only top and capture default differ from the sealed TX kernel.
tx=R/'hw/soc/out/pcie-tx-path-v3-20261004/physical-peer/compare.py'
assert (B/'compare.py').read_text()==tx.read_text().replace('/dev/shm/nssoc-txv3-physical-equivalence-peer-02','/dev/shm/nssoc-rxv2-physical-equivalence-peer-01').replace('soc_pcie_gen3_tx_path_v3','soc_pcie_gen3_framer_rx')
files={}
def add(name,p):assert name not in files;files[name]=p
for p in P.iterdir():
 if p.is_file():add('native-functions/'+p.name,p)
for p in B.iterdir():
 if p.is_file() and p.suffix in ('.py','.log','.json') and p.name not in ('independent-review.json','seal.log'):add('review/'+p.name,p)
add('prior-kernel/compare.py',tx)
for name in ('gold.log','gold.ys','normalization.json','gate.log','gate.ys'):add('history-failed01/'+name,old/name)
add('history-failed01/physical-01-connectivity-failure.tar.xz',B/'physical-01-connectivity-failure.tar.xz')
for p in replay.rglob('*'):
 if p.is_file() and 'sim' not in p.relative_to(replay).parts:add('physical-port-replay/'+str(p.relative_to(replay)),p)
for name in ('repaired.v','repaired.sdc','place.tcl','native.log'):add('physical/'+name,physical/name)
add('physical/result.json',physical.parent/'result.json')
add('original-mapped.v',pathlib.Path('/dev/shm/nssoc-rx-v2-output-native-01/mapped.v'))
add('LICENSES/Apache-2.0.txt',R/'LICENSES/Apache-2.0.txt')
manifest={n:pin(p) for n,p in files.items()};arc=B/'physical-function-proof.tar.xz'
with tarfile.open(arc,'w:xz',preset=3) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(arc) as t:
 assert len(t.getmembers())==len(files)
 for member in t.getmembers():
  with t.extractfile(member) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==manifest[member.name]['sha256']
record=dict(status='PASS_COMPLETE_BINARY_STATE_FUNCTION_EQUIVALENCE_AND_RECORDED_PHYSICAL_PORT_REPLAY',proof=proof,method='Native Yosys Liberty functional expansion and collision-free canonical Boolean DAG comparison. Same native FF instances form a complete state bijection; all D/clock/reset and all external output functions are equal under every binary input/state valuation.',comparison_kernel=dict(prior=pin(tx),current=pin(B/'compare.py'),only_top_and_capture_default_changed=True),state_map=pin(B/'state-map.json'),resized_ff_count=22,actual_tiehi_instances=1200,blackboxes=0,unknown_used_functions=0,unconstrained_omitted_boundaries=0,initial_state_restrictions=0,normalization=norm,mutations=mut,physical_source={n:pin(physical/n) for n in ('repaired.v','repaired.odb','repaired.sdc')},native_port_replay=dict(result=pin(replay/'result.json'),tests=[c.attrib for c in cases],all_inputs_runtime_outputs_rehashed=True,new_simulation_by_reviewer=False),timing=dict(corners=corners,raw_paths=checks,command_counts=dict(counts),source_report=pin(physical/'native.log'),scope='Reparsed original final global-route estimated-RC development4ns reports, not a new timing run. Max/min path slack groups retained; no signoff timing acceptance.'),history=dict(failed01=pin(B/'physical-01-connectivity-failure.json'),cause='1200 lost constant-one RESET_B loads; no proof acceptance or artificial tie assumption. Corrected02 has real native tie cells and fresh full physical flow.'),limits=['Binary functional equivalence under explicit bijective state relation; not four-state X/glitch, metastability or analog delay equivalence.','No SDF, extracted-RC signoff, detailed-route/DRC/LVS, fullPHY/LTSSM or mainchip acceptance.','Native6-case physical replay was executed by root and independently rehashed/XML checked here.','All ten negative controls are graph-level mutations of exact native-expanded candidate: four Boolean complements and six coverage/connectivity rejections.'],capsule=dict(path=str(arc.relative_to(R)),**pin(arc),all_members_readback_verified=True,members=manifest))
for n,v in norm['inputs'].items():assert pin(n)==v
p=B/'independent-review.json';p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(receipt=pin(p),capsule=pin(arc),proof=proof,corners=corners),indent=2))
