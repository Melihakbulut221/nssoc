# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Preserve exact original gold expansion; normalize a corrected physical artifact."""
import argparse,hashlib,json,os,pathlib,resource,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--gate',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
root=pathlib.Path.cwd();prior=pathlib.Path('/dev/shm/nssoc-rxv2-physical-equivalence-peer-01');out=a.out.resolve();gate=a.gate.resolve()
def pin(path):
 with path.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=path.stat().st_size,sha256=sha)
old=json.loads((prior/'normalization.json').read_text());old_inputs={pathlib.Path(k):v for k,v in old['inputs'].items()}
for path,value in old_inputs.items():assert pin(path)==value
lib,yosys,real_yosys,goldnet,failednet=old_inputs
assert old['runs'][0]['returncode']==0
assert pin(prior/'gold.log')['sha256']==old['runs'][0]['log_sha256']
assert pin(prior/'gold.ys')['sha256']==old['runs'][0]['script_sha256']
inputs={str(path):pin(path) for path in [lib,yosys,real_yosys,goldnet,gate,prior/'gold.json',prior/'normalization.json',pathlib.Path(__file__).resolve()]}
out.mkdir(exist_ok=False)
# A hardlink shares immutable gold bytes; before/after SHA check detects drift.
os.link(prior/'gold.json',out/'gold.json')
script=out/'gate.ys';script.write_text(f'read_liberty -ignore_miss_func {lib}\nread_verilog {gate}\nhierarchy -check -top soc_pcie_gen3_framer_rx\nflatten\nproc\nopt_clean\ncheck -assert\nstat\nwrite_json {out}/gate.json\n')
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
started=time.monotonic()
with (out/'gate.log').open('w') as f:
 process=subprocess.run([str(yosys),'-T','-s',str(script)],stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits,timeout=90)
record=dict(inputs=inputs,reused_exact_gold=pin(out/'gold.json'),prior_failed_normalization=pin(prior/'normalization.json'),returncode=process.returncode,elapsed_seconds=time.monotonic()-started,script=pin(script),log=pin(out/'gate.log'),all_inputs_rechecked=all(pin(pathlib.Path(k))==v for k,v in inputs.items()))
(out/'normalization.json').write_text(json.dumps(record,indent=2)+'\n');assert record['all_inputs_rechecked'];assert process.returncode==0;print(json.dumps(record,indent=2))
