// SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
// SPDX-License-Identifier: CERN-OHL-W-2.0
// Literal verification adapter: no storage, logic, timing or policy changes.
module soc_pcie_gen3_framer_rx #(parameter integer MAX_ENCODED_BYTES=150)(
 input wire clk_i,rst_ni,flush_i,stream_start_i,stream_abort_i,
 input wire block_valid_i,output wire block_ready_o,
 input wire [7:0] headers_i,input wire [511:0] payload_i,input wire block_error_i,
 output wire valid_o,input wire ready_i,output wire [7:0] data_o,
 output wire sop_o,eop_o,dllp_o,packet_good_o,packet_nullified_o,
 output wire [11:0] sequence_o,
 output wire framing_error_o,stream_end_o,active_o,halted_o
);
 soc_pcie_gen3_framer_rx_v2 #(.MAX_ENCODED_BYTES(MAX_ENCODED_BYTES)) dut(
 .clk_i(clk_i),.rst_ni(rst_ni),.flush_i(flush_i),
 .stream_start_i(stream_start_i),.stream_abort_i(stream_abort_i),
 .block_valid_i(block_valid_i),.block_ready_o(block_ready_o),
 .headers_i(headers_i),.payload_i(payload_i),.block_error_i(block_error_i),
 .valid_o(valid_o),.ready_i(ready_i),.data_o(data_o),.sop_o(sop_o),.eop_o(eop_o),
 .dllp_o(dllp_o),.packet_good_o(packet_good_o),.packet_nullified_o(packet_nullified_o),
 .sequence_o(sequence_o),.framing_error_o(framing_error_o),.stream_end_o(stream_end_o),
 .active_o(active_o),.halted_o(halted_o));
endmodule
