// Generated actual-port control; no internal-register references.
module tb;
 reg clk_i=0,rst_ni=0,flush_i=0,stream_start_i=0,stream_abort_i=0;
 reg block_valid_i=0,block_error_i=0,ready_i=0;
 reg [7:0] headers_i=8'haa;reg [511:0] payload_i=0;
 wire block_ready_o,valid_o,sop_o,eop_o,dllp_o,packet_good_o,packet_nullified_o;
 wire [7:0] data_o;wire [11:0] sequence_o;
 wire framing_error_o,stream_end_o,active_o,halted_o;
 soc_pcie_gen3_framer_rx_v2 #(.MAX_ENCODED_BYTES(33)) dut(.*);
 reg [7:0] expected[0:53];reg [511:0] blocks[0:1];
 integer received=0,goods=0,errors=0,nulls=0,cycles=0,i,j;
 reg held=0;reg [10:0] held_value;
 task tick;
 begin
   ready_i=(cycles%7==0 || cycles%7==3 || cycles%7==4);
   #5;
   if(rst_ni && !stream_start_i && !flush_i) begin
     if(held && (!valid_o || {data_o,sop_o,eop_o,dllp_o}!==held_value))
       $fatal(1,"held packet changed");
     held=valid_o && !ready_i;held_value={data_o,sop_o,eop_o,dllp_o};
     if(valid_o && ready_i) begin
       if(received>=54) $fatal(1,"unexpected packet delivery/header alias");
       if(data_o!==expected[received]) $fatal(1,"byte or sequence mismatch at%0d",received);
       if(sop_o !== (received==0 || received==30 || received==36))
         $fatal(1,"SOP mismatch");
       if(eop_o !== (received==29 || received==35 || received==53))
         $fatal(1,"EOP/count mismatch");
       if(dllp_o !== (received>=30 && received<36))
         $fatal(1,"packet kind mismatch");
       received=received+1;
     end
   end
   clk_i=1;#5;
   if(rst_ni) begin
     goods=goods+packet_good_o;errors=errors+framing_error_o;nulls=nulls+packet_nullified_o;
   end
   clk_i=0;cycles=cycles+1;
   if(cycles>60000) $fatal(1,"bounded port progress timeout");
 end
 endtask
 initial begin
 expected[0]=8'h0f;
 expected[1]=8'hed;
 expected[2]=8'h40;
 expected[3]=8'h00;
 expected[4]=8'h00;
 expected[5]=8'h03;
 expected[6]=8'h12;
 expected[7]=8'h34;
 expected[8]=8'h56;
 expected[9]=8'h78;
 expected[10]=8'h01;
 expected[11]=8'h02;
 expected[12]=8'h03;
 expected[13]=8'h04;
 expected[14]=8'h09;
 expected[15]=8'h28;
 expected[16]=8'h47;
 expected[17]=8'h66;
 expected[18]=8'h85;
 expected[19]=8'ha4;
 expected[20]=8'hc3;
 expected[21]=8'he2;
 expected[22]=8'h01;
 expected[23]=8'h20;
 expected[24]=8'h3f;
 expected[25]=8'h5e;
 expected[26]=8'h7a;
 expected[27]=8'h11;
 expected[28]=8'hbc;
 expected[29]=8'h83;
 expected[30]=8'h00;
 expected[31]=8'h11;
 expected[32]=8'h22;
 expected[33]=8'h33;
 expected[34]=8'h44;
 expected[35]=8'h55;
 expected[36]=8'h01;
 expected[37]=8'h23;
 expected[38]=8'h00;
 expected[39]=8'h00;
 expected[40]=8'h00;
 expected[41]=8'h01;
 expected[42]=8'h12;
 expected[43]=8'h34;
 expected[44]=8'h56;
 expected[45]=8'h78;
 expected[46]=8'h01;
 expected[47]=8'h02;
 expected[48]=8'h03;
 expected[49]=8'h04;
 expected[50]=8'h7a;
 expected[51]=8'h11;
 expected[52]=8'hbc;
 expected[53]=8'h83;
 blocks[0]=512'h66047803ed000000000000000000000047035600ef000000000000000000000028023400000000000000000000000000090112408f0000000000000000000000;
 blocks[1]=512'h00000000000083047801235511835ee2000000000000bc035600614400bc3fc3000000000000110234000033ac1120a40000000000007a0112005f22f07a0185;
   tick;tick;rst_ni=1;stream_start_i=1;tick;stream_start_i=0;
   for(i=0;i<2;i=i+1) begin
     if(!halted_o) begin
       payload_i=blocks[i];block_valid_i=1;#1;
       while(!block_ready_o && !halted_o) tick;
       if(!halted_o) tick;
       block_valid_i=0;tick;
     end
   end
   for(j=0;j<60000 && received<54 && !halted_o;j=j+1) tick;
   for(j=0;j<100;j=j+1) tick;
   if(0) begin
     if(errors!=1 || goods!=0 || received!=0 || !halted_o)
       $fatal(1,"wide header-length alias was not rejected");
   end else begin
     if(errors!=0 || nulls!=0 || goods!=3 || received!=54 || halted_o)
       $fatal(1,"boundary/consume mismatch received%0d good%0d error%0d",received,goods,errors);
   end
   $display("PASS_BOUNDED_RX_V2_PORTS capacity=33 alias=0");$finish;
 end
endmodule
