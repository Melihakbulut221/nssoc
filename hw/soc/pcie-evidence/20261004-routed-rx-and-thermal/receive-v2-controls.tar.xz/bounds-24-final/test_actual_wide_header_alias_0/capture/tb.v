// Generated actual-port control; no internal-register references.
module tb;
 reg clk_i=0,rst_ni=0,flush_i=0,stream_start_i=0,stream_abort_i=0;
 reg block_valid_i=0,block_error_i=0,ready_i=0;
 reg [7:0] headers_i=8'haa;reg [511:0] payload_i=0;
 wire block_ready_o,valid_o,sop_o,eop_o,dllp_o,packet_good_o,packet_nullified_o;
 wire [7:0] data_o;wire [11:0] sequence_o;
 wire framing_error_o,stream_end_o,active_o,halted_o;
 soc_pcie_gen3_framer_rx_v2 #(.MAX_ENCODED_BYTES(150)) dut(.*);
 reg [7:0] expected[0:0];reg [511:0] blocks[0:3];
 integer received=0,goods=0,errors=0,nulls=0,cycles=0,i,j;
 reg held=0;reg [10:0] held_value;
 task tick;
 begin
   ready_i=(cycles%7==0 || cycles%7==3 || cycles%7==4);
   #5;
   if(rst_ni && !stream_start_i && !flush_i) begin
     if(held && (!valid_o || {data_o,sop_o,eop_o,dllp_o}!==held_value))
       $fatal(1,"held packet changed");
     held=valid_o && !ready_i;held_value={data_o,sop_o,eop_o,dllp_o};
     if(valid_o && ready_i) begin
       if(received>=0) $fatal(1,"unexpected packet delivery/header alias");
       if(data_o!==expected[received]) $fatal(1,"byte or sequence mismatch at%0d",received);
       if(sop_o !== (received==0 || received==146 || received==152))
         $fatal(1,"SOP mismatch");
       if(eop_o !== (received==145 || received==151 || received==-1))
         $fatal(1,"EOP/count mismatch");
       if(dllp_o !== (received>=146 && received<152))
         $fatal(1,"packet kind mismatch");
       received=received+1;
     end
   end
   clk_i=1;#5;
   if(rst_ni) begin
     goods=goods+packet_good_o;errors=errors+framing_error_o;nulls=nulls+packet_nullified_o;
   end
   clk_i=0;cycles=cycles+1;
   if(cycles>60000) $fatal(1,"bounded port progress timeout");
 end
 endtask
 initial begin

 blocks[0]=512'h66047860ed000000000000000000000047035600cf000000000000000000000028023400820000000000000000000000090112405f0000000000000000000000;
 blocks[1]=512'h26aa2eb236ba3ec246ca4ed256da5ee2078b0f93179b1fa327ab2fb337bb3fc3e86cf074f87c0084088c1094189c20a4c94dd155d95de165e96df175f97d0185;
 blocks[2]=512'h836aee72f67afe82068a0e92169a1ea2bc4bcf53d75bdf63e76bef73f77bff83112cb034b83cc044c84cd054d85ce0647a0d9115991da125a92db135b93dc145;
 blocks[3]=512'h00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
   tick;tick;rst_ni=1;stream_start_i=1;tick;stream_start_i=0;
   for(i=0;i<4;i=i+1) begin
     if(!halted_o) begin
       payload_i=blocks[i];block_valid_i=1;#1;
       while(!block_ready_o && !halted_o) tick;
       if(!halted_o) tick;
       block_valid_i=0;tick;
     end
   end
   for(j=0;j<60000 && received<0 && !halted_o;j=j+1) tick;
   for(j=0;j<100;j=j+1) tick;
   if(1) begin
     if(errors!=1 || goods!=0 || received!=0 || !halted_o)
       $fatal(1,"wide header-length alias was not rejected");
   end else begin
     if(errors!=0 || nulls!=0 || goods!=3 || received!=0 || halted_o)
       $fatal(1,"boundary/consume mismatch received%0d good%0d error%0d",received,goods,errors);
   end
   $display("PASS_BOUNDED_RX_V2_PORTS capacity=150 alias=1");$finish;
 end
endmodule
