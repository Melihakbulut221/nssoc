// Generated actual-port control; no internal-register references.
module tb;
 reg clk_i=0,rst_ni=0,flush_i=0,stream_start_i=0,stream_abort_i=0;
 reg block_valid_i=0,block_error_i=0,ready_i=0;
 reg [7:0] headers_i=8'haa;reg [511:0] payload_i=0;
 wire block_ready_o,valid_o,sop_o,eop_o,dllp_o,packet_good_o,packet_nullified_o;
 wire [7:0] data_o;wire [11:0] sequence_o;
 wire framing_error_o,stream_end_o,active_o,halted_o;
 soc_pcie_gen3_framer_rx_v2 #(.MAX_ENCODED_BYTES(127)) dut(.*);
 reg [7:0] expected[0:149];reg [511:0] blocks[0:3];
 integer received=0,goods=0,errors=0,nulls=0,cycles=0,i,j;
 reg held=0;reg [10:0] held_value;
 task tick;
 begin
   ready_i=(cycles%7==0 || cycles%7==3 || cycles%7==4);
   #5;
   if(rst_ni && !stream_start_i && !flush_i) begin
     if(held && (!valid_o || {data_o,sop_o,eop_o,dllp_o}!==held_value))
       $fatal(1,"held packet changed");
     held=valid_o && !ready_i;held_value={data_o,sop_o,eop_o,dllp_o};
     if(valid_o && ready_i) begin
       if(received>=150) $fatal(1,"unexpected packet delivery/header alias");
       if(data_o!==expected[received]) $fatal(1,"byte or sequence mismatch at%0d",received);
       if(sop_o !== (received==0 || received==126 || received==132))
         $fatal(1,"SOP mismatch");
       if(eop_o !== (received==125 || received==131 || received==149))
         $fatal(1,"EOP/count mismatch");
       if(dllp_o !== (received>=126 && received<132))
         $fatal(1,"packet kind mismatch");
       received=received+1;
     end
   end
   clk_i=1;#5;
   if(rst_ni) begin
     goods=goods+packet_good_o;errors=errors+framing_error_o;nulls=nulls+packet_nullified_o;
   end
   clk_i=0;cycles=cycles+1;
   if(cycles>60000) $fatal(1,"bounded port progress timeout");
 end
 endtask
 initial begin
 expected[0]=8'h0f;
 expected[1]=8'hed;
 expected[2]=8'h40;
 expected[3]=8'h00;
 expected[4]=8'h00;
 expected[5]=8'h1b;
 expected[6]=8'h12;
 expected[7]=8'h34;
 expected[8]=8'h56;
 expected[9]=8'h78;
 expected[10]=8'h01;
 expected[11]=8'h02;
 expected[12]=8'h03;
 expected[13]=8'h04;
 expected[14]=8'h09;
 expected[15]=8'h28;
 expected[16]=8'h47;
 expected[17]=8'h66;
 expected[18]=8'h85;
 expected[19]=8'ha4;
 expected[20]=8'hc3;
 expected[21]=8'he2;
 expected[22]=8'h01;
 expected[23]=8'h20;
 expected[24]=8'h3f;
 expected[25]=8'h5e;
 expected[26]=8'h7d;
 expected[27]=8'h9c;
 expected[28]=8'hbb;
 expected[29]=8'hda;
 expected[30]=8'hf9;
 expected[31]=8'h18;
 expected[32]=8'h37;
 expected[33]=8'h56;
 expected[34]=8'h75;
 expected[35]=8'h94;
 expected[36]=8'hb3;
 expected[37]=8'hd2;
 expected[38]=8'hf1;
 expected[39]=8'h10;
 expected[40]=8'h2f;
 expected[41]=8'h4e;
 expected[42]=8'h6d;
 expected[43]=8'h8c;
 expected[44]=8'hab;
 expected[45]=8'hca;
 expected[46]=8'he9;
 expected[47]=8'h08;
 expected[48]=8'h27;
 expected[49]=8'h46;
 expected[50]=8'h65;
 expected[51]=8'h84;
 expected[52]=8'ha3;
 expected[53]=8'hc2;
 expected[54]=8'he1;
 expected[55]=8'h00;
 expected[56]=8'h1f;
 expected[57]=8'h3e;
 expected[58]=8'h5d;
 expected[59]=8'h7c;
 expected[60]=8'h9b;
 expected[61]=8'hba;
 expected[62]=8'hd9;
 expected[63]=8'hf8;
 expected[64]=8'h17;
 expected[65]=8'h36;
 expected[66]=8'h55;
 expected[67]=8'h74;
 expected[68]=8'h93;
 expected[69]=8'hb2;
 expected[70]=8'hd1;
 expected[71]=8'hf0;
 expected[72]=8'h0f;
 expected[73]=8'h2e;
 expected[74]=8'h4d;
 expected[75]=8'h6c;
 expected[76]=8'h8b;
 expected[77]=8'haa;
 expected[78]=8'hc9;
 expected[79]=8'he8;
 expected[80]=8'h07;
 expected[81]=8'h26;
 expected[82]=8'h45;
 expected[83]=8'h64;
 expected[84]=8'h83;
 expected[85]=8'ha2;
 expected[86]=8'hc1;
 expected[87]=8'he0;
 expected[88]=8'hff;
 expected[89]=8'h1e;
 expected[90]=8'h3d;
 expected[91]=8'h5c;
 expected[92]=8'h7b;
 expected[93]=8'h9a;
 expected[94]=8'hb9;
 expected[95]=8'hd8;
 expected[96]=8'hf7;
 expected[97]=8'h16;
 expected[98]=8'h35;
 expected[99]=8'h54;
 expected[100]=8'h73;
 expected[101]=8'h92;
 expected[102]=8'hb1;
 expected[103]=8'hd0;
 expected[104]=8'hef;
 expected[105]=8'h0e;
 expected[106]=8'h2d;
 expected[107]=8'h4c;
 expected[108]=8'h6b;
 expected[109]=8'h8a;
 expected[110]=8'ha9;
 expected[111]=8'hc8;
 expected[112]=8'he7;
 expected[113]=8'h06;
 expected[114]=8'h25;
 expected[115]=8'h44;
 expected[116]=8'h63;
 expected[117]=8'h82;
 expected[118]=8'ha1;
 expected[119]=8'hc0;
 expected[120]=8'hdf;
 expected[121]=8'hfe;
 expected[122]=8'h7a;
 expected[123]=8'h11;
 expected[124]=8'hbc;
 expected[125]=8'h83;
 expected[126]=8'h00;
 expected[127]=8'h11;
 expected[128]=8'h22;
 expected[129]=8'h33;
 expected[130]=8'h44;
 expected[131]=8'h55;
 expected[132]=8'h01;
 expected[133]=8'h23;
 expected[134]=8'h00;
 expected[135]=8'h00;
 expected[136]=8'h00;
 expected[137]=8'h01;
 expected[138]=8'h12;
 expected[139]=8'h34;
 expected[140]=8'h56;
 expected[141]=8'h78;
 expected[142]=8'h01;
 expected[143]=8'h02;
 expected[144]=8'h03;
 expected[145]=8'h04;
 expected[146]=8'h7a;
 expected[147]=8'h11;
 expected[148]=8'hbc;
 expected[149]=8'h83;
 blocks[0]=512'h6604781bed000000000000000000000047035600af000000000000000000000028023400820000000000000000000000090112400f0000000000000000000000;
 blocks[1]=512'h26aa2eb236ba3ec246ca4ed256da5ee2078b0f93179b1fa327ab2fb337bb3fc3e86cf074f87c0084088c1094189c20a4c94dd155d95de165e96df175f97d0185;
 blocks[2]=512'h780123551183fe82068a0e92169a1ea25600614400bcdf63e76bef73f77bff8334000033ac11c044c84cd054d85ce06412005f22f07aa125a92db135b93dc145;
 blocks[3]=512'h000000000000000000000000000083040000000000000000000000000000bc030000000000000000000000000000110200000000000000000000000000007a01;
   tick;tick;rst_ni=1;stream_start_i=1;tick;stream_start_i=0;
   for(i=0;i<4;i=i+1) begin
     if(!halted_o) begin
       payload_i=blocks[i];block_valid_i=1;#1;
       while(!block_ready_o && !halted_o) tick;
       if(!halted_o) tick;
       block_valid_i=0;tick;
     end
   end
   for(j=0;j<60000 && received<150 && !halted_o;j=j+1) tick;
   for(j=0;j<100;j=j+1) tick;
   if(0) begin
     if(errors!=1 || goods!=0 || received!=0 || !halted_o)
       $fatal(1,"wide header-length alias was not rejected");
   end else begin
     if(errors!=0 || nulls!=0 || goods!=3 || received!=150 || halted_o)
       $fatal(1,"boundary/consume mismatch received%0d good%0d error%0d",received,goods,errors);
   end
   $display("PASS_BOUNDED_RX_V2_PORTS capacity=127 alias=0");$finish;
 end
endmodule
