from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as E
R=Path.cwd();B=R/'hw/soc/out/pcie-gen3-receive-v2-20261004/independent-controls'
def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);n+=len(b)
 return dict(bytes=n,sha256=h.hexdigest())
srcs=['hw/soc/rtl/pcie/soc_pcie_gen3_framer_rx_v2.v','scripts/check_pcie_gen3_receive_v2.py','sw/tests/test_pcie_gen3_receive_v2.py']
sources={s:pin(R/s) for s in srcs}
assert sources[srcs[0]]['sha256']=='d5224140137d1b5ff1a6b142bf09bbbfb2a866ca354977280a5dfc048729afe8'
assert sources[srcs[1]]['sha256']=='54ec12c57b496308218b06b6773269649202ee660ffa4c98284022bcf0af83c5'
assert (B/'production-final.log').read_text().strip().endswith('28 passed in 2.72s')
files={}
def add(n,p):
 assert n not in files,n
 files[n]=p
for s in srcs:add('sources/'+s,R/s)
records=[]
for label,directory in [('rtl-frozen-oracle',Path('/dev/shm/nssoc-gen3-receive-v2-wrapper-output-01')),('native-root',Path('/dev/shm/nssoc-rx-v2-output-native-01'))]:
 r=json.loads((directory/'result.json').read_text())
 assert r['status']=='PASS_GEN3_RECEIVE_V2_PORTS' and r['tests']==dict(passed=6,failed=0,skipped=0)
 for section in ('inputs','runtime'):
  for p,v in r[section].items():assert pin(Path(p))==v,(section,p)
 assert pin(Path(next(p for p in r['inputs'] if p.endswith('candidate-output-v2-name.v'))))==sources[srcs[0]]
 cases=list(E.parse(directory/'ports/results.xml').getroot().iter('testcase'))
 assert len(cases)==6 and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
 verified=[];unavailable=[]
 for rel,v in r['outputs'].items():
  p=directory/rel
  if p.exists():assert pin(p)==v,rel;verified.append(rel)
  else:unavailable.append(rel)
 assert not unavailable,unavailable
 for p in directory.rglob('*'):
  if p.is_file() and 'sim' not in p.relative_to(directory).parts:add(label+'/'+str(p.relative_to(directory)),p)
 for p in r['inputs']:
  path=Path(p)
  if path.is_relative_to(R) and str(path.relative_to(R)) not in srcs:
   n='inputs/'+str(path.relative_to(R))
   if n not in files:add(n,path)
 records.append(dict(label=label,path=str(directory/'result.json'),result=pin(directory/'result.json'),tests=r['tests'],mapped_cells=r.get('mapped_cells'),all_recorded_inputs_runtime_outputs_rehashed=True,output_count=len(verified),authorship='root executed native; reviewer independently rehashed/reparsed existing result' if label=='native-root' else 'reviewer executed frozen RTL port oracle'))
controls=[]
for label,directory in [('production-final',Path('/dev/shm/nssoc-gen3-receive-v2-production-final')),('candidate-output-final',Path('/dev/shm/nssoc-gen3-receive-v2-output-final'))]:
 rows=[]
 for case in sorted(directory.iterdir()):
  if not case.is_dir() or case.is_symlink():continue
  p=case/'capture/result.json'
  if not p.exists():continue
  r=json.loads(p.read_text());assert r['inputs_rechecked']
  for n,v in r['inputs'].items():assert pin(Path(n))==v,n
  log=(p.parent/'simulation.log').read_text();negative=r['returncode']!=0
  assert ('FATAL:' in log and 'PASS_BOUNDED_RX_V2_PORTS' not in log) if negative else ('PASS_BOUNDED_RX_V2_PORTS' in log)
  rows.append(dict(case=case.name,result=pin(p),negative=negative,capacity=r['capacity'],header_alias=r['header_alias']))
  for f in case.rglob('*'):
   if f.is_file() and f.name!='sim.vvp':add(label+'/'+str(f.relative_to(directory)),f)
 assert len(rows)==27 and sum(x['negative'] for x in rows)==11
 controls.append(dict(label=label,actual_processes=27,positive=16,actual_fault_rejections=11,rows=rows))
# Preserve exact previous methods, actual author anchor failure, and old24 controls.
for label,directory in [('bounds-first',Path('/dev/shm/nssoc-gen3-receive-v2-bounds-01')),('bounds-24-final',Path('/dev/shm/nssoc-gen3-receive-v2-bounds-final')),('output-27-review',Path('/dev/shm/nssoc-gen3-receive-v2-output-controls-01'))]:
 for p in directory.rglob('*'):
  if p.is_file() and not any(x.is_symlink() for x in [p,*p.parents] if x!=directory.parent) and p.name!='sim.vvp':add(label+'/'+str(p.relative_to(directory)),p)
for p in B.rglob('*'):
 if p.is_file() and p.suffix in ('.log','.py','.v') and p.name!='seal.py':add('review-methods/'+str(p.relative_to(B)),p)
add('seal.py',Path(__file__).resolve())
a=B/'receive-v2-controls-native.tar.xz'
with tarfile.open(a,'w:xz',preset=3) as t:
 for n,p in files.items():t.add(p,arcname=n,recursive=False)
with tarfile.open(a) as t:
 assert len(t.getmembers())==len(files)
 for m in t.getmembers():
  d=t.extractfile(m).read();assert dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest())==pin(files[m.name])
receipt=dict(status='PASS_BOUNDED_RX_V2_SOURCE_PORT_CONTROLS',sources=sources,source_frozen=True,root_native_and_reviewer_rtl=records,focused_tests=dict(passed=28,failed=0,skipped=0,log=pin(B/'production-final.log'),capacities=[18,30,31,32,33,126,127,128,129,150,254,255,256,257,4118],reachable_capacity_length_pairs=2104326),controls=controls,reasoning=[
'Accepted STP L>=5 has N=4L-2<=capacity. Write starts2, final four-byte write starts2+4*(L-2), its highest index N-1, and postincrementN is representable by clog2(capacity+1). EMIT stops on read_pos=N-1 before another increment. Header-derived expected length stays13 bits, so overlong headers cannot alias the bounded packet count.',
'After j consumes each lane is its original128-bit value shifted right8*j. Constant low-byte selectors therefore equal the old word_index selectors. Payload acquisition needs !block_pending while consumption needs block_pending; shifts do not occur in LOOK acceptance or held EMIT. The successor is processed after output drains.',
'Registered first byte is loaded at LOOK acceptance or DLLP end after packet[0] was stored in earlier cycles. Nonlast accepted output loads exactly packet[read_pos+1]. No ready handshake means no data or pointer update. Last output never indexes beyond packet length. Flush/start/abort masks stale data and the next packet reloads it.',
'clog2(capacity) at power-of-two capacities is not necessarily a fault because accepted TLP counts are2mod4. Whole512-bit shift-right8 is observationally equivalent for the16 words; spill reaches each byte only after its last use. Duplicate consume task calls within one NBA cycle also do not prove double advancement. Those were not mislabeled rejected faults.'
],history=dict(first_attempt='23 PASS/1 author mutation-anchor failure; exact source/raw retained, not a DUT failure',bounded_before_output='24 PASS exact prior bounded-only source retained',candidate_controls='27 actual processes plus28 final pytest controls; candidate bytes equal promoted public source',frozen_v1_unchanged=pin(R/'hw/soc/rtl/pcie/soc_pcie_gen3_framer_rx.v')),limitations=['No temporal formal equivalence or full state-space proof; reachable arithmetic induction plus exhaustive accepted capacity/length pairs and actual port controls.','Native SG13G2 default150 only, six frozen port cases with unmodified model. Max4118 supported RTL controls do not include unsupported4122-byte4DW+4096payload+digest.','No SDF, STA/physical closure, main-chip integration, line-rate PMA, OS/LTSSM or complete PCIe acceptance.','Raw native GPI diagnostic retained. No new independent native execution by reviewer; root executed native capture.'],capsule=dict(path=str(a.relative_to(R)),**pin(a),members=len(files),all_members_readback_verified=True))
p=B/'independent-review.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(receipt=pin(p),capsule=pin(a),members=len(files),sources=sources),indent=2))
