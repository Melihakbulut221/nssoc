from pathlib import Path
import importlib.util,hashlib,json
ROOT=Path.cwd();B=ROOT/'hw/soc/out/pcie-gen3-receive-v2-20261004/independent-controls';OUT=Path('/dev/shm/nssoc-gen3-receive-v2-output-controls-01');OUT.mkdir()
source=ROOT/'hw/soc/out/pcie-gen3-receive-v2-20261004/candidate-output-v2-name.v';test=ROOT/'sw/tests/test_pcie_gen3_receive_v2.py'
def pin(p):d=p.read_bytes();return {'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
original=source.read_text();before={str(p):pin(p) for p in (source,test,Path(__file__).resolve())}
s=importlib.util.spec_from_file_location('ports',test);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
rows=[]
for capacity in [18,30,31,32,33,126,127,128,129,150,254,255,256,257,4118]:
 p=m.run_ports(OUT/f'capacity-{capacity}',original,capacity);assert p.returncode==0 and 'PASS_BOUNDED_RX_V2_PORTS' in p.stdout
 rows.append(dict(name=f'capacity-{capacity}',role='positive',returncode=p.returncode))
p=m.run_ports(OUT/'header-alias',original,header_alias=True);assert p.returncode==0 and 'PASS_BOUNDED_RX_V2_PORTS' in p.stdout
rows.append(dict(name='header-alias',role='positive-rejection',returncode=p.returncode))
extra=[('tlp_first_byte','               packet_good_o<=1;state<=EMIT;read_pos<=0;read_data<=packet[0];','               packet_good_o<=1;state<=EMIT;read_pos<=0;read_data<=packet[1];',False),('dllp_first_byte','consume_word();packet_good_o<=1;state<=EMIT;read_pos<=0;read_data<=packet[0];','consume_word();packet_good_o<=1;state<=EMIT;read_pos<=0;read_data<=packet[2];',False),('output_reload','read_data<=packet[read_pos+1\'b1]','read_data<=packet[read_pos]',False),('output_stall','if(valid_o && ready_i) begin','if(valid_o) begin',False)]
for name,old,new,alias in [*m.FAULTS,*extra]:
 assert original.count(old)==1,(name,original.count(old))
 p=m.run_ports(OUT/name,original.replace(old,new),header_alias=alias)
 assert p.returncode!=0 and 'FATAL:' in p.stdout and 'PASS_BOUNDED_RX_V2_PORTS' not in p.stdout
 rows.append(dict(name=name,role='actual-negative',returncode=p.returncode))
assert before=={p:pin(Path(p)) for p in before}
r={'status':'PASS_ACTUAL_REGISTERED_OUTPUT_BOUNDARY_AND_MUTATION_CONTROLS','inputs':before,'rows':rows,'counts':{'positive':16,'actual_negative':11},'outputs':{str(p.relative_to(OUT)):pin(p) for p in OUT.rglob('*') if p.is_file() and p.name!='sim.vvp'},'scope':'Actual Icarus port-only RTL controls; source unchanged, no nativecell/timing or physical acceptance claim.'}
p=OUT/'result.json';p.write_text(json.dumps(r,indent=2)+'\n');print(pin(p))
