# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Bounded native mapping and frozen port replay with live scratch reserve guard."""
import ast,hashlib,json,os,pathlib,re,runpy,shutil,signal,subprocess,sys,threading,time
ROOT=pathlib.Path.cwd();sys.path.insert(0,str(ROOT/'scripts'))
import check_pcie_gen3_duplex as d
from check_pcie_gen3_framer import execute_command
from check_pcie_integrity_native import LIB_SHA,MODEL_SHA,quote
OUT=pathlib.Path('/dev/shm/nssoc-gen3-duplex-native-02')
PDK=pathlib.Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
LIB=PDK/'libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib';MODEL=PDK/'libs.ref/sg13g2_stdcell/verilog/sg13g2_stdcell.v'
TOOLS=ROOT/'hw/soc/tools/oss-cad-suite/bin';YOSYS=TOOLS/'yosys';DONE=threading.Event();MIN=512*1024**2

def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
free=shutil.disk_usage('/dev/shm').free
assert free>900*1024**2 and not OUT.exists(),('initial900MiB/fresh output gate',free)
assert pin(LIB)['sha256']==LIB_SHA and pin(MODEL)['sha256']==MODEL_SHA
rtl=[ROOT/'hw/soc/rtl/pcie'/(n+'.v') for n in d.MODULES]
bench=ROOT/'hw/soc/tb/cocotb/test_soc_pcie_gen3_packet_duplex.py'
files=rtl+[bench,bench.with_name('Makefile.soc_pcie_gen3_packet_duplex'),pathlib.Path(d.__file__),ROOT/'scripts/check_pcie_gen3_framer.py',ROOT/'scripts/check_pcie_integrity.py',ROOT/'scripts/check_pcie_integrity_native.py',ROOT/'scripts/cocotb_results.py',pathlib.Path(__file__).resolve(),LIB,MODEL,YOSYS,ROOT/'hw/soc/tools/oss-cad-suite/libexec/yosys',TOOLS/'iverilog',TOOLS/'vvp',ROOT/'hw/soc/tools/oss-cad-suite/libexec/iverilog',ROOT/'hw/soc/tools/oss-cad-suite/libexec/vvp',pathlib.Path(sys.executable).resolve()]
pins={str(p):pin(p) for p in files}
prior=json.loads((ROOT/'hw/soc/out/pcie-gen3-duplex-20261004/validation.json').read_text())
assert all(pin(ROOT/n)==v for n,v in prior['sources'].items())
OUT.mkdir();record=dict(status='RUNNING_NATIVE_DUPLEX',inputs=pins,initial_free_bytes=free,minimum_sampled_free_bytes=free,reserve_bytes=MIN,reserve_monitor_period_seconds=.2,guard_trigger_bytes=MIN+16*1024**2,address_space_cap_per_child_bytes=2*1024**3,elapsed_watchdog_seconds=None,scope='Frozen default150 elastic duplex; independent port oracle at original4ns stimulus. No PHY/LTSSM, line rate, mainchip, SDF or timing signoff.')
def save():
 p=OUT/'result.tmp';p.write_text(json.dumps(record,indent=2)+'\n');p.replace(OUT/'result.json')
def monitor():
 while not DONE.wait(.2):
  try:
   children=pathlib.Path(f'/proc/{os.getpid()}/task/{os.getpid()}/children').read_text().split()
   for pid in children:
    try:
     status=pathlib.Path('/proc')/pid/'status';raw=status.read_text();rows=dict(re.findall(r'^(VmSize|VmRSS|Threads):\s+(\d+)',raw,re.M))
     row=record.setdefault('direct_child_observations',{}).setdefault(pid,dict(samples=0,max_vmsize_kib=0,max_rss_kib=0,max_threads=0));row['samples']+=1
     for key,field in [('VmSize','max_vmsize_kib'),('VmRSS','max_rss_kib'),('Threads','max_threads')]:row[field]=max(row[field],int(rows.get(key,0)))
    except (FileNotFoundError,ProcessLookupError):pass
  except (FileNotFoundError,ProcessLookupError):pass
  available=shutil.disk_usage('/dev/shm').free;record['minimum_sampled_free_bytes']=min(record['minimum_sampled_free_bytes'],available)
  if available<MIN+16*1024**2:
   record['reserve_failure_bytes']=available;os.kill(os.getpid(),signal.SIGINT);return
thread=threading.Thread(target=monitor,daemon=True);thread.start()
try:
 save()
 version=subprocess.check_output([str(TOOLS/'iverilog'),'-V'],stderr=subprocess.STDOUT,text=True)
 assert int(re.search(r'Icarus Verilog version (\d+)',version).group(1))>=13
 (OUT/'iverilog-version.log').write_text(version)
 recipe='read_liberty -lib '+quote(LIB)+'; read_verilog -sv '+' '.join(map(quote,rtl))+'; hierarchy -check -top '+d.TOP+'; flatten -noscopeinfo; synth -top '+d.TOP+' -noabc; dfflibmap -liberty '+quote(LIB)+'; abc -liberty '+quote(LIB)+'; clean; check -assert; stat -liberty '+quote(LIB)+'; write_json '+quote(OUT/'mapped.json')+'; write_verilog -noattr -noexpr '+quote(OUT/'mapped.v')+'\n'
 (OUT/'map.ys').write_text(recipe);start=time.monotonic()
 record['mapping_environment']={'YOSYS_MAX_THREADS':'1'}
 record['mapping_returncode']=execute_command([str(YOSYS),'-T','-s',str(OUT/'map.ys')],OUT/'map.log',dict(os.environ,YOSYS_MAX_THREADS='1'),None);record['mapping_seconds']=time.monotonic()-start
 assert record['mapping_returncode']==0,'Native mapping failed'
 doc=json.loads((OUT/'mapped.json').read_text());known=set(re.findall(r'\bcell\s*\(\s*\"?([\w]+)\"?\s*\)',LIB.read_text()));cells=doc['modules'][d.TOP]['cells']
 assert cells and all(c['type'].startswith('sg13g2_') and c['type'] in known for c in cells.values()),'Unknown/unmapped native cell'
 record['mapped_cells']=len(cells);del doc,cells;save()
 argv=[str(ROOT/'scripts/check_pcie_gen3_duplex.py'),'--out',str(OUT/'ports'),'--iverilog-dir',str(TOOLS),'--netlist',str(OUT/'mapped.v'),'--models',str(MODEL)]
 record['frozen_driver_argv']=argv;save();previous=sys.argv
 try:
  sys.argv=argv
  try:runpy.run_path(argv[0],run_name='__main__')
  except SystemExit as e:
   if e.code not in (None,0):raise RuntimeError('Frozen external native port driver failed') from e
 finally:sys.argv=previous
 ports=json.loads((OUT/'ports/result.json').read_text())
 assert ports['status']=='PASS_ELASTIC_GEN3_DUPLEX_PORTS' and ports['tests']==dict(passed=5,failed=0,skipped=0)
 assert all(pin(p)==v for p,v in pins.items()),'Source/runtime/model drift'
 record.update(status='PASS_NATIVE_ELASTIC_GEN3_DUPLEX',tests=ports['tests'],all_inputs_rechecked=True)
except BaseException as e:
 record.update(status='FAIL_NATIVE_ELASTIC_GEN3_DUPLEX',error=repr(e));raise
finally:
 DONE.set();thread.join();record['outputs']={str(p.relative_to(OUT)):pin(p) for p in OUT.rglob('*') if p.is_file() and p!=OUT/'result.json' and p.name!='result.tmp'};save()
print(json.dumps({k:record.get(k) for k in ('status','mapped_cells','tests','minimum_sampled_free_bytes')},indent=2))
