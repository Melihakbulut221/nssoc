# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import ast,hashlib,json,pathlib,tarfile,xml.etree.ElementTree as E
ROOT=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent;OUT=pathlib.Path('/dev/shm/nssoc-gen3-duplex-native-02');FAILED=pathlib.Path('/dev/shm/nssoc-gen3-duplex-native-01')
def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
r=json.loads((OUT/'result.json').read_text());assert r['status']=='PASS_NATIVE_ELASTIC_GEN3_DUPLEX' and r['tests']==dict(passed=5,failed=0,skipped=0) and r['mapped_cells']==44225
assert r['minimum_sampled_free_bytes']>=r['reserve_bytes'] and r['address_space_cap_per_child_bytes']==2*1024**3
for p,v in r['inputs'].items():assert pin(p)==v
for n,v in r['outputs'].items():assert pin(OUT/n)==v
port=json.loads((OUT/'ports/result.json').read_text());assert port['status']=='PASS_ELASTIC_GEN3_DUPLEX_PORTS' and port['mode']=='external_native'
for section in ('inputs','runtime'):
 for p,v in port[section].items():assert pin(p)==v
bench=ROOT/'hw/soc/tb/cocotb/test_soc_pcie_gen3_packet_duplex.py';expected={n.name for n in ast.parse(bench.read_text()).body if isinstance(n,ast.AsyncFunctionDef) and n.decorator_list}
cases=list(E.parse(OUT/'ports/results.xml').getroot().iter('testcase'));assert len(cases)==5 and {c.attrib['name'] for c in cases}==expected and all(not any(c.find(n) is not None for n in ('failure','error','skipped')) for c in cases)
old=json.loads((FAILED/'result.json').read_text());assert old['status']=='FAIL_NATIVE_ELASTIC_GEN3_DUPLEX' and old['mapping_returncode']==-6 and 'terminate called without an active exception' in (FAILED/'map.log').read_text()
for p,v in old['inputs'].items():assert pin(p)==v
for n,v in old['outputs'].items():assert pin(FAILED/n)==v
for p in set(r['inputs'])&set(old['inputs']):assert r['inputs'][p]==old['inputs'][p]
first_recipe=(FAILED/'map.ys').read_text().replace(str(FAILED),str(OUT));assert first_recipe==(OUT/'map.ys').read_text()
prior_path=B.parent/'validation.json';prior=json.loads(prior_path.read_text());assert prior['positive']['tests']==dict(passed=5,failed=0,skipped=0) and len(prior['actual_faults'])==10
for n,v in prior['sources'].items():assert pin(ROOT/n)==v
files={}
def add(n,p):assert n not in files;files[n]=p
for label,directory in [('native02',OUT),('failed-mapping01',FAILED)]:
 for p in directory.rglob('*'):
  if p.is_file() and 'sim' not in p.relative_to(directory).parts:add(label+'/'+str(p.relative_to(directory)),p)
for name in ('run_native.py','run_native_single_thread.py','retry-thread-contract.json','launch.log','launch-single-thread.log','seal.py'):add('method/'+name,B/name)
for p in map(pathlib.Path,r['inputs']):
 if p.is_relative_to(ROOT) and 'hw/soc/tools' not in str(p.relative_to(ROOT)) and not p.is_relative_to(B):add('sources/'+str(p.relative_to(ROOT)),p)
add('prior-rtl-control-receipt.json',prior_path)
manifest={n:pin(p) for n,p in files.items()};arc=B/'pcie-gen3-duplex-native-20261004.tar.xz'
with tarfile.open(arc,'w:xz',preset=3) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(arc) as t:
 assert len(t.getmembers())==len(files)
 for member in t.getmembers():
  with t.extractfile(member) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==manifest[member.name]['sha256']
receipt=dict(status='PASS_DEFAULT150_NATIVE_ELASTIC_GEN3_DUPLEX_PORTS',sources=prior['sources'],inherited_rtl_inputs={p:v for p,v in r['inputs'].items() if '/rtl/' in p and not p.endswith(('soc_pcie_gen3_packet_rx_path.v','soc_pcie_gen3_packet_duplex.v'))},result=pin(OUT/'result.json'),mapped_cells=r['mapped_cells'],tests=[c.attrib for c in cases],all_inputs_runtime_outputs_rehashed=True,prior_rtl_and_faults=dict(receipt=pin(prior_path),rtl_tests=5,actual_rtl_faults=10,capsule=prior['capsule']),resource={k:r[k] for k in ('initial_free_bytes','minimum_sampled_free_bytes','reserve_bytes','reserve_monitor_period_seconds','guard_trigger_bytes','address_space_cap_per_child_bytes','direct_child_observations')},mapping=dict(elapsed_seconds=r['mapping_seconds'],environment=r['mapping_environment'],unchanged_synthesis_recipe_except_output_path=True,source_supported_thread_limit='https://raw.githubusercontent.com/YosysHQ/yosys/468ba27d9/kernel/threading.cc'),historical_failure=dict(result=pin(FAILED/'result.json'),returncode=-6,stage='Yosys OPT_MERGE, before VVP',literal='terminate called without an active exception',space_floor_preserved=True,interpretation='Runtime abort, no HDL verdict. Same recipe/hardware succeeded with oneYosys thread. First attempt lacks thread/VM peak, so underlying exception cause is not proven.'),scope=['Full mapped packet TX framing/striping/scrambling/gearbox and RX descrambling/unstriping/framing at independent serialized128bit word ports; test uses bounded elastic queue.','Unchanged five port cases at4ns, unmodified SG13G2 specify-model replay, independent serial polynomial/header/lane oracle and RX-only encoded controls.','Default150encoded bytes only; frozen receivev1 deliberately retained, newreceivev2 not silently adopted.','Nullified/malformed/abort/reset/backpressure and opaque sequence/LCRC byte preservation tested; this layer does not make LCRC/DLLPCRC acceptance decisions.'],limits=['No continuous-wire PMA or line-rate acceptance, OS/SKP/LTSSM, alignment/deskew search, completePCIe/fullPHY or mainchip integration.','No full state-space functional equivalence proof for duplex, SDF, timing closure or physical acceptance.','Icarus timing-check warnings and known GPI sys.executable diagnostic retained; not a clean-log claim.','Ten actual mutants were run on RTL; no new mapped-mutant execution claimed.'],capsule=dict(path=str(arc.relative_to(ROOT)),**pin(arc),members=manifest,all_members_readback_verified=True))
p=B/'validation.json';p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(receipt=pin(p),capsule=pin(arc),mapped_cells=r['mapped_cells'],tests=r['tests']),indent=2))
