# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,pathlib,re,tarfile
import compare as m
R=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent;P=m.ROOT;physical=pathlib.Path('/dev/shm/nssoc-tx-path-v3-postroute-repair-02');old=R/'hw/soc/out/pcie-tx-path-v3-20261004/physical-peer'
def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
norm=json.loads((P/'normalization.json').read_text());assert norm['returncode']==0 and norm['all_inputs_rechecked']
for n,v in norm['inputs'].items():assert pin(n)==v
proof=m.compare(m.read('gold'),m.read('gate'));assert not proof['mismatches'] and proof['states']==2158 and proof['targets']==6604
mut=json.loads((P/'mutation-controls.json').read_text());assert mut['positive']==proof and len(mut['controls'])==10 and all(c['status'].startswith('REJECTED_') for c in mut['controls'])
prior=json.loads((old/'independent-review.json').read_text());assert prior['proof']['mismatches']==[]
assert (B/'compare.py').read_text()==(old/'compare.py').read_text().replace('/dev/shm/nssoc-txv3-physical-equivalence-peer-02',str(P))
physical_record=json.loads((physical/'result.json').read_text());assert physical_record['returncode']==0
for n,v in physical_record['inputs'].items():assert pin(n)==v
for n,v in physical_record['outputs'].items():assert pin(physical/n)==v
state={}
for label,p in [('gold',pathlib.Path('/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.v')),('gate',physical/'repaired.v')]:
 rows=re.findall(r'(?m)^\s*(sg13g2_dfrbpq_\d+)\s+(_[0-9]+_)\s*\(',p.read_text());assert len(rows)==2158 and len({n for t,n in rows})==2158;state[label]={n:t for t,n in rows}
assert state['gold'].keys()==state['gate'].keys()
resized={n:[t,state['gate'][n]] for n,t in state['gold'].items() if t!=state['gate'][n]}
(B/'state-map.json').write_text(json.dumps(dict(map=state,resized=resized),indent=2)+'\n')
files={}
def add(n,p):assert n not in files;files[n]=p
for p in P.iterdir():
 if p.is_file():add('native-functions/'+p.name,p)
for p in B.iterdir():
 if p.is_file() and p.suffix in ('.py','.json','.log') and p.name not in ('independent-review.json','seal.log'):add('review/'+p.name,p)
for n in ('compare.py','independent-review.json'):add('prior-proof/'+n,old/n)
for n in ('repaired.v','repaired.sdc','native.log','repair.tcl','result.json'):add('physical/'+n,physical/n)
add('prior-physical.v',pathlib.Path('/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.v'))
failed=pathlib.Path('/dev/shm/nssoc-tx-path-v3-postroute-repair-01')
for n in ('result.json','native.log','repair.tcl'):
 if (failed/n).exists():add('history-native-repair01/'+n,failed/n)
manifest={n:pin(p) for n,p in files.items()};arc=B/'pcie-tx-v3-postroute02-function-proof-20261004.tar.xz'
with tarfile.open(arc,'w:xz',preset=3) as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n,recursive=False)
with tarfile.open(arc) as t:
 assert len(t.getmembers())==len(files)
 for member in t.getmembers():
  with t.extractfile(member) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==manifest[member.name]['sha256']
record=dict(status='PASS_COMPLETE_BINARY_STATE_AND_OUTPUT_FUNCTION_EQUALITY',proof=proof,method='Exact previously proven native Liberty expanded GRT graph compared with freshly expanded postroute02 netlist. Collision-free canonical primitive Boolean functions under complete same-instance state bijection, covering every D/clock/reset and external output.',kernel=dict(prior=pin(old/'compare.py'),current=pin(B/'compare.py'),only_capture_default_changed=True),gold_restoration=json.loads((B/'restoration.json').read_text()),normalization=norm,mutations=mut,state_map=pin(B/'state-map.json'),resized_ff_count=len(resized),blackboxes=0,unknowns_allowed=False,omitted_boundaries=0,initial_state_restrictions=0,netlists=dict(gold=pin(pathlib.Path('/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.v')),gate=pin(physical/'repaired.v')),physical_record=pin(physical/'result.json'),all_recorded_physical_inputs_outputs_rehashed=True,limits=['Binary function proof only, not4-stateX/glitch/analog delay/SDF equivalence.','No new native port simulation by reviewer; previous gold native evidence is inherited, not a new02 execution.','Postrepair estimated timing is not fresh actual routed RC. New detailed route/extraction/timing and relevant physical checks remain required.','Native repair01 crash and EST-0027 warning are retained; no physical acceptance or fullPHY/mainchip claim.'],capsule=dict(path=str(arc.relative_to(R)),**pin(arc),all_members_readback_verified=True,members=manifest))
for n,v in norm['inputs'].items():assert pin(n)==v
p=B/'independent-review.json';p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(receipt=pin(p),capsule=pin(arc),proof=proof,resized_ff=len(resized)),indent=2))
