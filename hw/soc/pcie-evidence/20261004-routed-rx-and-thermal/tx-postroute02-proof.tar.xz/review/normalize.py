# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,os,pathlib,resource,subprocess,time
r=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;out=pathlib.Path('/dev/shm/nssoc-txv3-postroute02-equivalence')
old=r/'hw/soc/out/pcie-tx-path-v3-20261004/physical-peer';prior=json.loads((old/'independent-review.json').read_text());old_pins=prior['normalization']['inputs'];lib,yosys,real_yosys,gold_old,gate_old=map(pathlib.Path,old_pins)
def pin(p):
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
for p in (lib,yosys,real_yosys,pathlib.Path(gate_old)):assert pin(p)==old_pins[str(p)]
new=pathlib.Path('/dev/shm/nssoc-tx-path-v3-postroute-repair-02/repaired.v');inputs={str(p):pin(p) for p in (lib,yosys,real_yosys,pathlib.Path(gate_old),new,out/'gold.json',old/'independent-review.json',old/'physical-function-proof.tar.xz',b/'restoration.json',pathlib.Path(__file__).resolve())}
recipe=out/'gate.ys';recipe.write_text(f'read_liberty -ignore_miss_func {lib}\nread_verilog {new}\nhierarchy -check -top soc_pcie_gen3_tx_path_v3\nflatten\nproc\nopt_clean\ncheck -assert\nstat\nwrite_json {out}/gate.json\n')
def limit():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
started=time.monotonic()
with (out/'gate.log').open('w') as f:p=subprocess.run([str(yosys),'-T','-s',str(recipe)],stdout=f,stderr=subprocess.STDOUT,preexec_fn=limit,timeout=90)
record=dict(inputs=inputs,returncode=p.returncode,elapsed_seconds=time.monotonic()-started,script=pin(recipe),log=pin(out/'gate.log'),gold_scope='Exact native-functions/gate.json from sealed prior completeTX proof; this is original globally repaired netlist, now compared with postroute-repair02.',all_inputs_rechecked=all(pin(pathlib.Path(n))==v for n,v in inputs.items()))
(out/'normalization.json').write_text(json.dumps(record,indent=2)+'\n');assert record['all_inputs_rechecked'] and p.returncode==0;print(json.dumps(record,indent=2))
