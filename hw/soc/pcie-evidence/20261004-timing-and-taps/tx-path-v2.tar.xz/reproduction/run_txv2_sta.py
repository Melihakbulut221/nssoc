import json,hashlib,subprocess
from pathlib import Path
root=Path.cwd();b=root/'hw/soc/out/pcie-tx-path-v2-20261004';src=Path('/dev/shm/nssoc-gen3-tx-path-v2-native-transpose/mapped.json');data=json.loads(src.read_text());m=data['modules']['soc_pcie_gen3_tx_path_v2'];removed={}
for n,v in list(m['netnames'].items()):
 if v.get('signed'):
  assert n not in m['ports'] and all(x in ('0','1','x','z') for x in v['bits']),n
  removed[n]=m['netnames'].pop(n)
p=b/'sta-normalized.json';p.write_text(json.dumps(data));before=json.loads(src.read_text())['modules']['soc_pcie_gen3_tx_path_v2'];assert m['cells']==before['cells'] and m['ports']==before['ports'];assert {**m['netnames'],**removed}==before['netnames']
(b/'sta-normalization-proof.json').write_text(json.dumps({'status':'PASS_CONSTANT_NONPORT_NETNAME_ONLY_NORMALIZATION','source_sha256':hashlib.file_digest(src.open('rb'),'sha256').hexdigest(),'normalized_sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'cells':len(m['cells']),'removed':removed,'all_cells_connections_ports_and_remaining_netnames_identical':True},indent=2)+'\n')
ys=b/'sta-normalize.ys';ys.write_text('read_json "'+str(p)+'"\nwrite_verilog -noattr -noexpr "'+str(b/'sta-normalized.v')+'"\n')
with (b/'sta-normalize.log').open('w') as log:subprocess.run([str(root/'hw/soc/tools/oss-cad-suite/bin/yosys'),'-Q','-T','-s',str(ys)],stdout=log,stderr=subprocess.STDOUT,check=True)
tcl=(root/'hw/soc/out/pcie-tx-path-20261004/preplacement-repair.tcl').read_text().replace('pcie-tx-path-20261004','pcie-tx-path-v2-20261004').replace('link_design soc_pcie_gen3_tx_path\n','link_design soc_pcie_gen3_tx_path_v2\n');(b/'preplacement-repair.tcl').write_text(tcl)
with (b/'preplacement-repair.log').open('w') as log:r=subprocess.run([str(root/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'),'openroad','-exit',str(b/'preplacement-repair.tcl')],stdout=log,stderr=subprocess.STDOUT)
print('OpenROAD return',r.returncode)
