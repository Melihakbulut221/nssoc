from pathlib import Path
import hashlib,json,datetime,os,signal
p=Path('hw/soc/rtl/pcie/soc_pcie_gen3_tx_path_v2.v');b=Path('hw/soc/out/pcie-tx-path-v2-20261004');s=p.read_text();old=b/'basis-expansion-first.v';assert not old.exists();old.write_text(s)
# Independent equality of two elaboration algorithms over every used matrix row.
def oldmask(steps,ob):
 mask=0
 for ib in range(23):
  state=1<<ib
  for _ in range(steps):state=((state<<1)&0x7fffff)^(0x210125 if state>>22 else 0)
  mask|=((state>>ob)&1)<<ib
 return mask
def transpose(steps,ob):
 row=1<<ob
 for _ in range(steps):row=(row>>1)|(((row&0x210125).bit_count()&1)<<22)
 return row
for step in range(129):
 for bit in range(23):assert oldmask(step,bit)==transpose(step,bit),(step,bit)
a=s.index('   reg [22:0] basis;');z=s.index(' endfunction',a)
s=s[:a]+'''   integer step;
   begin
     power_mask=23'b1<<output_bit;
     // Apply the transpose to the output selector. This is exactly the same
     // GF(2) row as basis expansion, with no 23-way repeated elaboration.
     for(step=0;step<steps;step=step+1)
       power_mask={^(power_mask&23'h210125),power_mask[22:1]};
   end
''' +s[z:]
(b/'transpose-preview.v').write_text(s)
r={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'PASS_EXHAUSTIVE_ELABORATION_ROW_EQUALITY','rows':129*23,'original_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'new_sha256':hashlib.sha256(s.encode()).hexdigest(),'scope':'Every GF2 row through128steps; HDL simulation/native implementation still separate.','native_first':'Interrupted after about8min solely to avoid repeated expensive constant-function elaboration. No mapped netlist or pass existed; rawlogs and explicit interrupted result preserved.'}
(b/'elaboration-equality.json').write_text(json.dumps(r,indent=2)+'\n')
os.kill(763916,signal.SIGINT)
