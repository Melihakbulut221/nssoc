from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');B=ROOT/'hw/soc/out/pcie-tx-path-v2-20261004';P=B/'peer'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return dict(bytes=p.stat().st_size,sha256=sha(p))
source=[ROOT/'hw/soc/rtl/pcie/soc_pcie_gen3_tx_path_v2.v',ROOT/'hw/soc/rtl/pcie/soc_pcie_gen3_gearbox.v',ROOT/'scripts/check_pcie_gen3_tx_path_v2.py',ROOT/'hw/soc/tb/cocotb/test_soc_pcie_gen3_tx_path_v2.py',ROOT/'hw/soc/tb/cocotb/Makefile.soc_pcie_gen3_tx_path_v2',ROOT/'sw/tests/test_pcie_gen3_tx_path_v2.py']
runs=[]
for mode in ('rtl','native'):
 d=Path('/dev/shm/nssoc-gen3-tx-path-v2-'+mode+'-transpose');r=json.loads((d/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_PCIE_GEN3_TX_PATH_V2' and r['tests']==dict(passed=3,failed=0,skipped=0)
 for f,v in {**r['inputs'],**r['runtime']}.items():assert pin(Path(f))==v,(f,v)
 for f,v in r['outputs'].items():assert pin(d/f)==v,f
 cases=ET.parse(d/'results.xml').getroot().findall('.//testcase');assert len(cases)==3 and all(not c.findall('failure') and not c.findall('skipped') for c in cases)
 runs.append(dict(mode=mode,result=pin(d/'result.json'),xml=pin(d/'results.xml'),tests=[c.attrib['name'] for c in cases],mapped_cells=r.get('mapped_cells'),all_inputs_runtime_outputs_rehashed=True))
mut=Path('/dev/shm/nssoc-tx-path-v2-mutations-transpose');neg=[]
for f in sorted(mut.rglob('result.json')):
 r=json.loads(f.read_text());assert r['status']=='FAIL'
 x=f.parent/'results.xml';cases=ET.parse(x).getroot().findall('.//testcase');assert len(cases)==3 and any(c.findall('failure') for c in cases) and not any(c.findall('skipped') for c in cases)
 assert 'AssertionError' in (f.parent/'simulation.log').read_text()
 for n,v in r['outputs'].items():assert pin(f.parent/n)==v
 neg.append(dict(path=str(f),result=pin(f),xml=pin(x),failed=sum(bool(c.findall('failure')) for c in cases)))
assert len(neg)==10
log=Path('/dev/shm/nssoc-tx-path-v2-mutations-transpose.log');assert '13 passed' in log.read_text()
# Independent forward-basis versus transpose row relation, every0..128step/output.
def step(s):return ((s<<1)&((1<<23)-1)) ^ (0x210125 if s&(1<<22) else 0)
rows=0
for n in range(129):
 basis=[]
 for i in range(23):
  s=1<<i
  for _ in range(n):s=step(s)
  basis.append(s)
 for bit in range(23):
  expected=sum(((s>>bit)&1)<<i for i,s in enumerate(basis));m=1<<bit
  for _ in range(n):m=(m>>1)|(((m&0x210125).bit_count()&1)<<22)
  assert m==expected;rows+=1
assert rows==2967
# All reachable byte prefix/total counts bounded; tree dimensions are exact.
for value in range(65536):
 a=[((value>>(2*j))&1)+((value>>(2*j+1))&1) for j in range(8)]
 b=[a[2*j]+a[2*j+1] for j in range(4)];c=[b[0]+b[1],b[2]+b[3]]
 assert sum(c)==value.bit_count()<=16
orig=json.loads(Path('/dev/shm/nssoc-gen3-tx-path-v2-native-transpose/mapped.json').read_text())
norm=json.loads((B/'sta-normalized.json').read_text());top='soc_pcie_gen3_tx_path_v2';a=orig['modules'][top];b=norm['modules'][top]
assert a['cells']==b['cells'] and a['ports']==b['ports'] and len(a['cells'])==20846
removed=set(a['netnames'])-set(b['netnames']);assert len(removed)==68
assert all(all(isinstance(x,str) for x in a['netnames'][n]['bits']) and n not in a['ports'] for n in removed)
assert {n:v for n,v in a['netnames'].items() if n not in removed}==b['netnames']
record=dict(status='CLEAN_BOUNDED_INDEPENDENT_TX_V2_REVIEW',source_pins={str(p.relative_to(ROOT)):pin(p) for p in source},captures=runs,actual_fault_captures=neg,root_13_test_log=pin(log),independent_gf2_rows=rows,independent_popcount_inputs=65536,normalization=dict(cells=20846,removed_constant_nonport_aliases=68,cells_connections_ports_remaining_aliases_identical=True),findings=['No concrete correctness blocker found. Held payload and LFSR state advance only on accepted block; after-block reseed uses old state for current payload.','Non-advancing byte repeats current bit22 across its eight bits, matching serial reference. Prefix count excludes current byte; total includes all16.','Output backpressure and flush flow through original gearbox; replacement held payload is allowed only when old is accepted.','Serial oracle uses per-bit recurrence independent of GF2/popcount datapath. All10 real mutants have assertion failures, not compile-only or skipped negatives.'],limitations=['Read-only review and raw receipt/XML/hash replay; no RTL/native simulation rerun.','Three process-lifetime tests taken from exact13PASS root log; not independently rerun in this review.','Preplacement timing is not signoff; reported slow-corner setup slack remains negative. No automatic ordered-set policy, complete PCS, CDC, PMA, layout or link qualification.'])
(P/'independent-review.json').write_text(json.dumps(record,indent=2)+'\n');print(pin(P/'independent-review.json'))
