import json,hashlib,tarfile,io,datetime,sys
from pathlib import Path
sys.path.insert(0,'scripts')
from cocotb_results import count_results
repo=Path.cwd();b=repo/'hw/soc/out/pcie-tx-path-v2-20261004';dst=repo/'hw/soc/pcie-evidence/20261004-timing-and-taps';members={}
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
def add(root,label):
 for p in root.rglob('*'):
  if p.is_file() and 'sim' not in p.relative_to(root).parts and '__pycache__' not in p.parts and not p.is_symlink():members[label+'/'+str(p.relative_to(root))]=p.read_bytes()
positive=[]
for mode in ['rtl','native']:
 root=Path('/dev/shm/nssoc-gen3-tx-path-v2-'+mode+'-transpose');r=json.loads((root/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_PCIE_GEN3_TX_PATH_V2' and r['tests']=={'passed':3,'failed':0,'skipped':0}
 for p,w in r['inputs'].items():assert pin(Path(p))==w
 for p,w in r['runtime'].items():assert pin(Path(p))==w
 for p,w in r['outputs'].items():assert pin(root/p)==w
 add(root,mode);positive.append({'mode':mode,'tests':r['tests'],'mapped_cells':r.get('mapped_cells'),'result_pin':pin(root/'result.json')})
root=Path('/dev/shm/nssoc-tx-path-v2-mutations-transpose');ps=[p for p in root.glob('test_real*/run/result.json') if not p.parent.parent.is_symlink()];assert len(ps)==10
for p in ps:
 assert json.loads(p.read_text())['status']=='FAIL';counts=count_results([p.parent/'results.xml']);assert sum(counts[:2])==3 and counts[1]>0 and counts[2]==0
add(root,'mutants');members['tests.log']=Path('/dev/shm/nssoc-tx-path-v2-mutations-transpose.log').read_bytes();assert b'13 passed' in members['tests.log']
add(b,'analysis-and-peer');add(Path('/dev/shm/nssoc-gen3-tx-path-v2-native-01'),'history/interrupted-basis-elaboration');add(Path('/dev/shm/nssoc-gen3-tx-path-v2-rtl-01'),'history/basis-rtl')
for p in ['hw/soc/rtl/pcie/soc_pcie_gen3_tx_path_v2.v','hw/soc/rtl/pcie/soc_pcie_gen3_gearbox.v','scripts/check_pcie_gen3_tx_path_v2.py','scripts/check_pcie_integrity.py','scripts/check_pcie_integrity_native.py','scripts/cocotb_results.py','hw/soc/tb/cocotb/Makefile.soc_pcie_gen3_tx_path_v2','hw/soc/tb/cocotb/test_soc_pcie_gen3_tx_path_v2.py','sw/tests/test_pcie_gen3_tx_path_v2.py']:members['sources/'+p]=(repo/p).read_bytes()
for p in ['/dev/shm/run_txv2_sta.py','/dev/shm/run_txv2_corners.py','/dev/shm/optimize_txv2_elaboration.py']:members['reproduction/'+Path(p).name]=Path(p).read_bytes()
r={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'PASS_FUNCTIONAL_TX_V2_WITH_SLOW_CORNER_TIMING_FAILURE','positive':positive,'actual_source_mutants_rejected':10,'process_lifetime_tests':3,'source_runtime_output_pins_verified':True,'preplacement_setup_slack_ns':{'typical':.788329,'slow':-.932817,'fast':1.798036},'unbuffered_typical_setup_slack_ns':-33.36,'scope':'Balanced byte-prefix popcount and fixed GF2 powers replace128conditionalfeedbacksteps. Same4ns independent stream oracle. ExactnativeTTmapping; TTpreplacementrepair fixednetlist testedunchanged acrossTT/SS/FF. Idealclock,no placement/no interconnect extraction orsignoff. No fullPCS/LTSSM/PMA/mainchipacceptance.','preserved_history':'Original expensive basis elaboration interrupted with KeyboardInterrupt afterabout8minutes before netlist existed. Originalsource/RTLsuccess/logs retained; exact2967row equality and fastertranspose version verified independently.','members':{n:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for n,v in sorted(members.items())}}
members['manifest.json']=json.dumps(r,indent=2).encode();p=dst/'tx-path-v2.tar.xz';assert not p.exists()
with tarfile.open(p,'w:xz',preset=3) as t:
 for n,v in sorted(members.items()):
  i=tarfile.TarInfo(n);i.size=len(v);t.addfile(i,io.BytesIO(v))
r['capsule']={'path':str(p.relative_to(repo)),**pin(p)};(dst/'tx-path-v2.json').write_text(json.dumps(r,indent=2)+'\n');print(r['capsule'])
