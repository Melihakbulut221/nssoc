# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Full device inventory failure remains authoritative; partial graph diagnostic only."""
from pathlib import Path
from decimal import Decimal
from collections import Counter
import sys,json,re,networkx as nx
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));import check_magic_hbt_multiplicity_v3 as h
V=Path('/dev/shm/nssoc-padded-clocked-layout-01');O=Path('/dev/shm/nssoc-padded-clocked-finite-taps-01');B=R/'hw/soc/out/pcie-magic-padded-bank-finite-taps-20261004'
def rows(path):return [s.split() for s in h.spice_lines(path.read_text())]
def number(t):
 m=re.fullmatch(r'([-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)([numkp]?)',t.lower());assert m,t
 return Decimal(m[1])*{'':Decimal(1),'n':Decimal('1e-9'),'u':Decimal('1e-6'),'m':Decimal('1e-3'),'k':Decimal('1e3'),'p':Decimal('1e-12')}[m[2]]
def devs(rs):
 result=[]
 for r in rs:
  if r[0][0] not in 'XQRMDC':continue
  if r[0][0]=='C':continue # separately retained native interconnect caps, not intrinsic source devices
  i=next(i for i,t in enumerate(r) if '=' in t);result.append(dict(name=r[0],nodes=[n.upper() for n in r[1:i-1]],model=r[i-1].lower(),parameters={k.lower():number(v) for k,v in (t.split('=') for t in r[i:])}))
 return result
ref=rows(V/'schematic.cir');raw=rows(O/'capacitance.spice');gd,ad=devs(ref),devs(raw)
ports={p.upper() for p in ref[0][2:]};assert ports=={p.upper() for p in raw[0][2:]} and len(raw[0][2:])==56
rc,ac=Counter(d['model'] for d in gd),Counter(d['model'] for d in ad)
print('counts',rc,ac,flush=True)
taps=[d for d in ad if d['model']=='ptap1'];assert len(taps)==108 and all(d['nodes']==['SUB','ESD_RETURN'] and d['parameters']==dict(l=Decimal('2e-6'),w=Decimal('2e-6'),r=Decimal('81.6667')) for d in taps)
ntap=[d for d in ad if d['model']=='ntap1'];assert len(ntap)==1 and ntap[0]['nodes'][0]=='AVDD2V3' and ntap[0]['nodes'][1] not in ports
pmos=[d for d in ad if d['model']=='sg13_hv_pmos'];assert len(pmos)==1 and pmos[0]['nodes'][3]==ntap[0]['nodes'][1]
# Match remaining observed device graph only to locate additional faults. Missing
# ESD devices are NOT removed from the authoritative full inventory verdict.
allowed={'npn13g2','rppd','rsil','ptap1','ntap1','cap_cmim','sg13_hv_pmos'}
def graph(ds):
 g=nx.Graph()
 for p in ports:g.add_node(('net',p),color='port:'+p)
 for i,d in enumerate(ds):
  if d['model'] not in allowed:continue
  model=d['model'];p=d['parameters'];p=dict(p);p.pop('m',None)
  if model in ('ptap1','ntap1'):
   if 'a' in p:
    assert p==dict(a=Decimal('4e-12'),p=Decimal('8e-6'));p=dict(w=Decimal('2e-6'),l=Decimal('2e-6'))
   else:
    assert p.pop('r')==Decimal('81.6667')
  if model in ('rsil','rppd'):
   assert p.pop('b',Decimal(0))==0
  if model=='sg13_hv_pmos':p={k:p[k] for k in ('w','l')}
  color=(model,tuple(sorted(p.items())));g.add_node(('dev',i),color=color)
  for j,n in enumerate(d['nodes']):
   if ('net',n) not in g:g.add_node(('net',n),color='internal')
   role='end' if model in ('rsil','rppd') and j<2 else j
   g.add_node(('pin',i,j),color=('pin',role));g.add_edge(('dev',i),('pin',i,j));g.add_edge(('pin',i,j),('net',n))
 return g
left,right=graph(gd),graph(ad)
print('partial graph',left.number_of_nodes(),right.number_of_nodes(),flush=True)
match=nx.algorithms.isomorphism.GraphMatcher(left,right,node_match=lambda a,b:a['color']==b['color']);equivalent=match.is_isomorphic();print('partial equivalence',equivalent,flush=True)
record=dict(status='FAIL_COMPLETE_BANK_DEVICE_GRAPH_32_ESD_DEVICES_MISSING',source_gds=h.pin(V/'nssoc_pcie_padded_clocked_bank4_v1.gds'),source_reference=h.pin(V/'schematic.cir'),native_record=h.pin(O/'result.json'),method=h.pin(__file__),exact_56_ports=True,reference_counts=dict(rc),extracted_counts=dict(ac),missing_model_counts=dict(rc-ac),extra_model_counts=dict(ac-rc),native_ptap=dict(count=108,terminals=['SUB','ESD_RETURN'],each_resistance_ohm='81.6667',dimensions_um=[2,2],parallel_equivalent_ohm=str(Decimal('81.6667')/108)),ntap=ntap[0],pmos_body_bound_to_finite_well=True,partial_non_esd_graph=dict(isomorphic=equivalent,nodes=[left.number_of_nodes(),right.number_of_nodes()],normalization=['Internal conductor names are existentially matched; all56 external ports retain exact identity.','Device terminal order remains exact except symmetric resistor endpoints; all model dimensions and HBT Nx preserved.','Finite taps compare exact2x2um/A4/P8 native geometry plus measuredR; no contact removed or shorted.','m=1 and b=0 syntax defaults removed only; PMOS diffusion area/perimeter extras do not form part of this limited connectivity check.'],scope='Diagnostic of the observed non-ESD subset only; this cannot turn missing full devices into a pass.'),qualified_pex=False,full_device_graph_equal=False,original_gds_unchanged=True,limitations=['32 actual physical ESD PCells absent from Magic output; complete source graph fails.','No full RC conservation, distributed substrate impedance or RF performance acceptance.','Finite tap recovery does not fix missing ESD recognition.'],outputs={p.name:h.pin(p) for p in O.iterdir() if p.is_file()})
# JSON decimals retain exact metrology text, not lossy floats.
(B/'independent-raw-audit.json').write_text(json.dumps(record,indent=2,default=str)+'\n')
