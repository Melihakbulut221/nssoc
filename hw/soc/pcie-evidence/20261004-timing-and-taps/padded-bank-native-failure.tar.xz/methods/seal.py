# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,tarfile,io,sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));from check_magic_hbt_multiplicity_v3 import pin
B=R/'hw/soc/out/pcie-magic-padded-bank-finite-taps-20261004';O=Path('/dev/shm/nssoc-padded-clocked-finite-taps-01');V=Path('/dev/shm/nssoc-padded-clocked-layout-01')
r=json.loads((O/'result.json').read_text());a=json.loads((B/'independent-raw-audit.json').read_text())
assert r['returncode']==0 and r['source_gds_unchanged'] and a['full_device_graph_equal'] is False
for p,sha in r['inputs'].items():assert pin(p)['sha256']==sha
for p,sha in r['outputs'].items():assert pin(O/p)['sha256']==sha
entries={}
for label,d in [('native',O),('methods',B)]:
 for p in d.iterdir():
  if p.is_file() and p.suffix in ('.py','.json','.spice','.ext','.mag','.log','.tcl'):entries[label+'/'+p.name]=p.read_bytes()
for name in ('result.json','schematic.cir'):entries['reference/'+name]=(V/name).read_bytes()
entries['UPSTREAM-NOTICES.txt']=(R/'hw/soc/out/pcie-magic-finite-tap-v1-20261004/UPSTREAM-NOTICES.txt').read_bytes()
manifest={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in entries.items()};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();cap=B/'padded-bank-finite-taps-failed-native.tar.xz'
with tarfile.open(cap,'w:xz') as tf:
 for n,b in sorted(entries.items()):
  m=tarfile.TarInfo(n);m.size=len(b);tf.addfile(m,io.BytesIO(b))
with tarfile.open(cap) as tf:
 for m in tf.getmembers():assert tf.extractfile(m).read()==entries[m.name]
record=dict(status=a['status'],audit=pin(B/'independent-raw-audit.json'),native=r,frozen_isolated_method_receipt=pin(R/'hw/soc/out/pcie-magic-finite-tap-v1-20261004/validation.json'),prior_physical_lvs_receipt=pin(R/'hw/soc/out/pcie-padded-clocked-bank-20261004/validation.json'),capsule=dict(**pin(cap),members=len(entries),all_members_roundtrip_verified=True),summary=dict(recovered_literal_ptap=108,ptap_terminals=['SUB','ESD_RETURN'],each_ohm='81.6667',recovered_ntap=1,ports_preserved=56,missing_esd=32,magic_serial_ports_without_functional_terminal=16,partial_non_esd_graph_equal=False),scope='Actual complete unchanged padded GDS imported natively under2GiB. Full device graph fails. No ESD substitution, PEX qualification, geometry deletion or source reference relaxation.',qualified_pex=False,full_device_graph_equal=False)
(B/'validation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({p.name:pin(p) for p in (B/'validation.json',cap,B/'independent-raw-audit.json')},indent=2))
