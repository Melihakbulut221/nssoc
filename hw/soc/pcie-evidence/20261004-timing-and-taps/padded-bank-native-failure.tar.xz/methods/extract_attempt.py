# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Bounded unchanged-GDS native Magic capacitance/RC attempt; no qualification."""
import hashlib,json,os,resource,subprocess,time
from pathlib import Path
ROOT=Path.cwd();OUT=Path('/dev/shm/nssoc-padded-clocked-finite-taps-01')
VIEW=Path('/dev/shm/nssoc-padded-clocked-layout-01');RT=Path('/dev/shm/nssoc-finite-tap-v1-build-final/runtime/lib')
TECH=Path('/dev/shm/nssoc-finite-tap-tech-final')
BUILD=Path('/dev/shm/nssoc-finite-tap-v1-build-final/result.json')
TOP='nssoc_pcie_padded_clocked_bank4_v1';FLAT='nssoc_padded_clocked_finite_flat'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def limits():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
assert not OUT.exists();OUT.mkdir()
rec=json.loads((VIEW/'result.json').read_text());build=json.loads(BUILD.read_text())
pins={str(p):sha(p) for p in [Path(__file__).resolve(),BUILD,VIEW/'result.json',VIEW/(TOP+'.gds'),VIEW/'schematic.cir',*TECH.rglob('*.tech'),*TECH.rglob('*.tcl'),TECH/'ihp-sg13g2.magicrc']}
assert sha(RT/'magic/tcl/tclmagic.so')==build['runtime']['sha256'];pins[str(RT/'magic/tcl/tclmagic.so')]=build['runtime']['sha256']
assert all(sha(VIEW/n)==h for n,h in rec['output_sha256'].items())
lines=['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',f'cd {{{OUT}}}','drc off','gds readonly true',f'gds read {{{VIEW/(TOP+".gds")}}}',f'load {TOP}',f'flatten {FLAT}',f'load {FLAT}','select top cell']
for i,(name,port) in enumerate(rec['ports'].items(),1):
 b=port['rect_um'];metal={'TopMetal1':'metal6','TopMetal2':'metal7'}[port['layer']]
 lines += ['box values '+' '.join(str(v)+'um' for v in b),f'label {name} center {metal}',f'port {name} make {i}',f'port {name} class inout',f'port {name} use signal']
lines += [f'save {FLAT}','extract unique all','extract style ngspice()','extract all','ext2spice lvs','ext2spice merge none','ext2spice global off','ext2spice cthresh 0','ext2spice rthresh 0','ext2spice extresist off',f'ext2spice -o {{{OUT/"capacitance.spice"}}}','puts NSSOC_CAPACITANCE_EXPORT_COMPLETE','quit -noprompt']
script=OUT/'extract.tcl';script.write_text('\n'.join(lines)+'\n');pins[str(script)]=sha(script)
cmd=['/usr/bin/tclsh8.6',str(RT/'magic/tcl/magic.tcl'),'-dnull','-noconsole','-rcfile',str(TECH/'ihp-sg13g2.magicrc'),str(script)]
env={k:v for k,v in os.environ.items() if k not in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME')};env['CAD_ROOT']=str(RT)
start=time.monotonic();status='RUNNING'
with (OUT/'native.log').open('w') as log:
 try:exitcode=subprocess.run(cmd,cwd=OUT,env=env,preexec_fn=limits,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=False).returncode;status='NATIVE_ATTEMPT_COMPLETE_REQUIRES_CENSUS_AND_CONSERVATION_AUDIT'
 except subprocess.TimeoutExpired:exitcode=None;status='BOUNDED_NATIVE_TIMEOUT_PRESERVED'
result=dict(status=status,command=cmd,returncode=exitcode,seconds=time.monotonic()-start,memory_limit_bytes=2*1024**3,timeout_s=120,inputs=pins,outputs={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()},source_gds_unchanged=sha(VIEW/(TOP+'.gds'))==pins[str(VIEW/(TOP+'.gds'))],qualified_pex=False,notes='Native full flat original GDS imported unchanged; exact56 physical port rectangles only annotated as native port indices. No geometry pruning/model replacement. Device/port and capacitance conservation must be audited before using this output.')
assert all(sha(p)==h for p,h in pins.items())
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','outputs')}))
