# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');B=ROOT/'hw/soc/out/pcie-div4-20261004'
plans=json.loads((B/'v5-finite-wave-parts-plan.json').read_text());out=B/'v5-finite-waves-release.json';assert not out.exists()
def digest(f):
 h=hashlib.sha256();n=0
 while b:=f.read(1048576):h.update(b);n+=len(b)
 return dict(bytes=n,sha256=h.hexdigest())
def pin(p):
 with p.open('rb') as f:return digest(f)
record=dict(status='RUNNING',native_validation=pin(B/'v5-validation.json'),parts_plan=pin(B/'v5-finite-wave-parts-plan.json'),parts=[],physical_acceptance=False)
def save():
 t=out.with_suffix('.tmp');t.write_text(json.dumps(record,indent=2)+'\n');t.replace(out)
save()
try:
 for i,plan in enumerate(plans):
  p=Path('/dev/shm')/plan['name'];assert not p.exists()
  members={n:{k:v for k,v in x.items() if k!='path'} for n,x in plan['members'].items()}
  for x in plan['members'].values():assert pin(Path(x['path']))==dict(bytes=x['bytes'],sha256=x['sha256'])
  with tarfile.open(p,'w') as t:
   for n,x in plan['members'].items():t.add(x['path'],arcname=n,recursive=False)
   for name,blob in [('inventory.json',(json.dumps(members,indent=2)+'\n').encode()),('NOTICES.txt',b'Project native finite schematic waves; Copyright2026 Hasan Melih Akbulut; CC-BY-4.0. Not layout, PLL, CDR, fullPVT or PCIe acceptance. Exact source/runtime/model pins in separate compact capture.\n')]:
    q=tarfile.TarInfo(name);q.size=len(blob);q.mtime=0;t.addfile(q,io.BytesIO(blob))
  with tarfile.open(p) as t:
   assert set(t.getnames())==set(members)|{'inventory.json','NOTICES.txt'}
   for n,x in members.items():assert digest(t.extractfile(n))==x
  archive_pin=pin(p);receipt=B/f'v5-finite-waves-part{i+1:02d}-release.json'
  print('PUBLISH',plan['name'],archive_pin,flush=True)
  subprocess.run([sys.executable,str(ROOT/'scripts/publish_pcie_native_capture.py'),'--out',str(receipt),str(p)],check=True)
  public=json.loads(receipt.read_text());assert public['status']=='PASS_IMMUTABLE_RELEASE_ROUNDTRIPS' and len(public['assets'])==1;a=public['assets'][0]
  assert a['bytes']==archive_pin['bytes'] and a['sha256']==archive_pin['sha256'] and a['authenticated_roundtrip'] and a['anonymous_roundtrip']
  assert pin(p)==archive_pin
  cleanup=[]
  for n,x in plan['members'].items():
   q=Path(x['path']);assert pin(q)==members[n];cleanup.append(dict(path=str(q),archive_member=n,**members[n]))
  cleanup.append(dict(path=str(p),**archive_pin))
  item=dict(asset=a,members=members,independent_local_tar_members_verified=True,receipt=pin(receipt),verified_duplicates_removed=cleanup,cleanup_complete=False);record['parts'].append(item);save()
  for x in cleanup:Path(x['path']).unlink()
  item['cleanup_complete']=True;save();print('SEALED_REMOVED',plan['name'],flush=True)
 record['status']='PASS_THREE_IMMUTABLE_PARTS_AND_EXACT_DUPLICATE_CLEANUP';record['total_wave_members']=sum(len(x['members']) for x in record['parts']);assert record['total_wave_members']==12;save()
except BaseException as e:
 record.update(status='ERROR_PRESERVED',error=repr(e));save();raise
