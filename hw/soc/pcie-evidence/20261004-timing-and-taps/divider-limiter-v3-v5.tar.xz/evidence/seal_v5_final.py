from pathlib import Path
import json,hashlib,gzip,tarfile,io,sys
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');sys.path.insert(0,str(ROOT/'scripts'));import characterize_pcie_div4_v5 as d
B=ROOT/'hw/soc/out/pcie-div4-20261004';P=Path('/dev/shm/nssoc-div4-v5-native-final');sha=d.OLD.sha
r=json.loads((P/'result.json').read_text());assert r['status']=='PASS_FINITE_DIV4_SCREEN' and r['complete_inputs_rechecked'] and [x['case'] for x in r['cases']]==d.cases('finite')
d.verify_sources()
for p,h in r['source_sha256'].items():assert sha(Path(p))==h
compact={'native/result.json':(P/'result.json').read_bytes(),'native/spinit':(P/'spinit').read_bytes()};waves={};observations=[]
for row in r['cases']:
 case=row['case'];folder=P/case['name'];assert row['returncode']==0 and row['numerical']['clean']
 assert {p.name for p in folder.iterdir()}==set(row['outputs'])
 for name,h in row['outputs'].items():
  p=folder/name;assert sha(p)==h
  member='native/'+case['name']+'/'+name
  if name=='wave.dat.gz':waves[member]={'path':str(p),'bytes':p.stat().st_size,'sha256':h}
  else:compact[member]=p.read_bytes()
 for name,text in d.source_texts(case).items():assert (folder/name).read_text()==text
 models=[Path(p).parent for p in r['source_sha256'] if Path(p).name=='cornerHBT.lib'];osdi=[[Path(p) for p in r['source_sha256'] if Path(p).name==n] for n in ('r3_cmc.osdi','psp103.osdi','psp103_nqs.osdi')];assert len(models)==1 and all(len(x)==1 for x in osdi)
 assert (folder/'bench.cir').read_text()==d.deck(case,models[0],[x[0] for x in osdi])
 assert d.OLD.diagnostics((folder/'run.log').read_text())==row['numerical'];assert d.read_flags((folder/'run.log').read_text(),case)==row['flags_observed'];assert d.initial_op(folder/'initial-op.dat',case)==row['zero_initial_op']
 h=hashlib.sha256()
 with gzip.open(folder/'wave.dat.gz','rb') as f:
  while chunk:=f.read(1048576):h.update(chunk)
 assert h.hexdigest()==row['uncompressed_wave_sha256']
 data=d.read_wave(folder/'wave.dat.gz',case);measured=d.measure(data,case);del data
 assert json.loads(json.dumps(measured))==row['measurement'] and d.accepted(row)==row['expected_outcome_observed']
 observations.append({'case':case,'expected_outcome_observed':row['expected_outcome_observed'],'native_clean':True,'all64_flags_and_zero_op':True,'raw_full_wave_replayed':True,'source_wave_sha256':h.hexdigest(),'failed_checks':[k for k,v in measured['checks'].items() if not v],'interfaces':measured['interfaces'],'min_vce':min(v['min_settled_vce_v'] for v in measured['devices'].values()),'max_vce':max(v['max_capture_vce_v'] for v in measured['devices'].values()),'frequency_hz':[measured['input_frequency_hz'],measured['output_frequency_hz']]});print(case['name'],'replayed',flush=True)
for p in (Path(d.__file__),d.CIRCUIT,ROOT/'sw/tests/test_pcie_div4_v5.py',*d.FROZEN):compact['source/'+str(p.relative_to(ROOT))]=p.read_bytes()
for p in (B/'v5-source-freeze.json',B/'v5-tests-01.log',B/'v5-finite.log',B/'v5-pilot-validation.json',B/'v5-pilot-waves-release.json',B/'v4-pilot-validation.json',B/'v4-pilot-waves-release.json',B/'v3-pilot-validation.json',B/'v3-pilot-waves-release.json',B/'v2-validation.json',B/'v2-full-waves-release.json',B/'v2-followup-recommendation.json',Path(__file__).resolve()):compact['review/'+p.name]=p.read_bytes()
notice='Project native circuits: Copyright2026 Hasan Melih Akbulut, CERN-OHL-W-2.0; Python methods Apache-2.0; reports CC-BY-4.0. This finite8positive/4fault physical experiment preserves exact old devices/models and numerical thresholds. It does not establish full PVT, layout, PLL, CDR or PCIe qualification. Foundry/runtime input hashes recorded, no binaries redistributed.\n'.encode();compact['NOTICES.txt']=notice
for license in ('Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0'):compact['LICENSES/'+license+'.txt']=(ROOT/'LICENSES'/f'{license}.txt').read_bytes()
invwaves={n:{k:v for k,v in item.items() if k!='path'} for n,item in waves.items()};(B/'v5-finite-wave-member-manifest.json').write_text(json.dumps(waves,indent=2)+'\n');compact['wave-manifest.json']=(json.dumps(invwaves,indent=2)+'\n').encode()
groups=[];group={};size=0
for name,item in waves.items():
 if group and size+item['bytes']>200*1024**2:groups.append(group);group={};size=0
 group[name]=item;size+=item['bytes']
if group:groups.append(group)
plans=[{'name':f'pcie-div4-v5-finite-full-waves-20261004-part{i+1:02d}.tar','members':group} for i,group in enumerate(groups)]
(B/'v5-finite-wave-parts-plan.json').write_text(json.dumps(plans,indent=2)+'\n')
inv={n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in compact.items()};compact['inventory.json']=(json.dumps(inv,indent=2)+'\n').encode();cp=B/'div4-v5-native-compact.tar.xz'
with tarfile.open(cp,'w:xz') as tf:
 for n,blob in sorted(compact.items()):ti=tarfile.TarInfo(n);ti.size=len(blob);ti.mtime=0;tf.addfile(ti,io.BytesIO(blob))
with tarfile.open(cp) as tf:
 for n,v in inv.items():blob=tf.extractfile(n).read();assert len(blob)==v['bytes'] and hashlib.sha256(blob).hexdigest()==v['sha256']
assert len(observations)==12 and sum(bool(x['case']['fault']) for x in observations)==4 and all(x['expected_outcome_observed'] for x in observations)
record={'status':'PASS_FINITE_EIGHT_POSITIVES_FOUR_NATIVE_FAULTS_DIV4_V5','native_result':{'sha256':sha(P/'result.json'),'bytes':(P/'result.json').stat().st_size},'source_freeze_sha256':sha(B/'v5-source-freeze.json'),'source_pins':{str(p):sha(Path(p)) for p in (Path(d.__file__),d.CIRCUIT,ROOT/'sw/tests/test_pcie_div4_v5.py')},'complete_input_source_model_runtime_pins':r['source_sha256'],'all_inputs_rehashed':True,'observations':observations,'full_wave_author_replay_count':12,'half_step_frequency_relative_delta':r['half_step_frequency_relative_delta'],'tests':{'v5':11,'v1_v2_v3_v4_v5':89,'ruff_pass':True},'compact_capsule':{'path':str(cp),'bytes':cp.stat().st_size,'sha256':sha(cp)},'full_wave_manifest':{'path':str(B/'v5-finite-wave-member-manifest.json'),'sha256':sha(B/'v5-finite-wave-member-manifest.json'),'wave_members':12,'parts_plan_sha256':sha(B/'v5-finite-wave-parts-plan.json'),'planned_parts':len(plans)},'prior_failures_preserved':True,'new_native_negative_controls_run':['second_no_toggle','second_same_phase','second_no_bias','second_same_clock'],'physical_acceptance':False,'limitations':['Two selected positive pilots only: All eight selected positive cases pass actual division, all64HBT electrical guards and the unchanged0.30V clock target. Four actual physical faults cause the required functional division failures; runtime or numerical failures cannot substitute.','Only two v4 limiter collector rppd lengths4.0to4.4um change; all64 HBTs, other physical devices, core models and thresholds remain frozen.','Finite source-bound schematic evidence only; no layout, PLL, CDR or PCIe qualification.']}
(B/'v5-validation.json').write_text(json.dumps(record,indent=2)+'\n');print('SEALED',sha(B/'v5-validation.json'),cp.stat().st_size,len(plans))
