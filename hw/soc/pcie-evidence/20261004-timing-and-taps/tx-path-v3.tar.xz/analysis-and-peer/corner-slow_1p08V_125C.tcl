read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_stdcell.lef}
read_liberty {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_slow_1p08V_125C.lib}
read_verilog {/home/hasanmelih/Documents/ChatGPT/nnsoc/hw/soc/out/pcie-tx-path-v3-20261004/preplacement-repaired.v}
link_design soc_pcie_gen3_tx_path_v3
create_clock -name development_clock -period 4.0 [get_ports clk_i]
set data_inputs [get_ports {rst_ni flush_i block_valid_i header_i* payload_i* advance_i* scramble_i* reseed_after_i* word_ready_i}]
set_input_delay -clock development_clock 0.2 $data_inputs
set_input_transition 0.1 $data_inputs
set_output_delay -clock development_clock 0.2 [all_outputs]
set_load 0.01 [all_outputs]
report_worst_slack -max
report_worst_slack -min
report_tns
report_check_types -max_slew -max_capacitance -violators
report_checks -path_delay max -group_path_count 2 -fields {slew cap fanout} -digits 6
report_checks -path_delay min -group_path_count 2 -fields {slew cap fanout} -digits 6
