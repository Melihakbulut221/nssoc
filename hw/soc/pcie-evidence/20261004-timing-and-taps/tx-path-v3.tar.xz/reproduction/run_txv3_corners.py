from pathlib import Path
import subprocess
r=Path.cwd();b=r/'hw/soc/out/pcie-tx-path-v3-20261004';original=(b/'preplacement-repair.tcl').read_text();prefix=original[:original.index('initialize_floorplan')].replace(str(b/'sta-normalized.v'),str(b/'preplacement-repaired.v'))
for corner in ['slow_1p08V_125C','fast_1p32V_m40C']:
 text=prefix.replace('typ_1p20V_25C',corner)+'''report_worst_slack -max
report_worst_slack -min
report_tns
report_check_types -max_slew -max_capacitance -violators
report_checks -path_delay max -group_path_count 2 -fields {slew cap fanout} -digits 6
report_checks -path_delay min -group_path_count 2 -fields {slew cap fanout} -digits 6
''';p=b/('corner-'+corner+'.tcl');p.write_text(text)
 with p.with_suffix('.log').open('w') as log:subprocess.run([str(r/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'),'openroad','-exit',str(p)],stdout=log,stderr=subprocess.STDOUT,check=True)
