puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-finite-tap-native-03/grid_quarter}
drc off
gds readonly true
gds read {/dev/shm/nssoc-finite-tap-fixture-04/fixture.gds}
load nssoc_finite_taps
flatten finite_taps_flat
load finite_taps_flat
select top cell
box values 10.14um 10.14um 10.64um 10.64um
label T000 center metal1
port T000 make 1
port T000 class inout
port T000 use signal
box values 24.36um 10.14um 24.86um 10.64um
label T001 center metal1
port T001 make 2
port T001 class inout
port T001 use signal
box values 39.36um 9.36um 39.86um 9.86um
label T002 center metal1
port T002 make 3
port T002 class inout
port T002 use signal
box values 55.14um 9.36um 55.64um 9.86um
label T003 center metal1
port T003 make 4
port T003 class inout
port T003 use signal
box values 70.14um 9.36um 70.64um 9.86um
label T004 center metal1
port T004 make 5
port T004 class inout
port T004 use signal
box values 85.14um 10.14um 85.64um 10.64um
label T005 center metal1
port T005 make 6
port T005 class inout
port T005 use signal
box values 99.36um 10.14um 99.86um 10.64um
label T006 center metal1
port T006 make 7
port T006 class inout
port T006 use signal
box values 114.36um 9.36um 114.86um 9.86um
label T007 center metal1
port T007 make 8
port T007 class inout
port T007 use signal
box values 130.2um 10.2um 131.8um 11.8um
label T008 center metal1
port T008 make 9
port T008 class inout
port T008 use signal
box values 143.2um 10.2um 144.8um 11.8um
label T009 center metal1
port T009 make 10
port T009 class inout
port T009 use signal
box values 158.2um 8.2um 159.8um 9.8um
label T010 center metal1
port T010 make 11
port T010 class inout
port T010 use signal
box values 175.2um 8.2um 176.8um 9.8um
label T011 center metal1
port T011 make 12
port T011 class inout
port T011 use signal
box values 10.2um 23.2um 11.8um 24.8um
label T012 center metal1
port T012 make 13
port T012 class inout
port T012 use signal
box values 25.2um 25.2um 26.8um 26.8um
label T013 center metal1
port T013 make 14
port T013 class inout
port T013 use signal
box values 38.2um 25.2um 39.8um 26.8um
label T014 center metal1
port T014 make 15
port T014 class inout
port T014 use signal
box values 53.2um 23.2um 54.8um 24.8um
label T015 center metal1
port T015 make 16
port T015 class inout
port T015 use signal
box values 70.2um 25.16um 71.8um 27.84um
label T016 center metal1
port T016 make 17
port T016 class inout
port T016 use signal
box values 82.16um 25.2um 84.84um 26.8um
label T017 center metal1
port T017 make 18
port T017 class inout
port T017 use signal
box values 98.2um 22.16um 99.8um 24.84um
label T018 center metal1
port T018 make 19
port T018 class inout
port T018 use signal
box values 115.16um 23.2um 117.84um 24.8um
label T019 center metal1
port T019 make 20
port T019 class inout
port T019 use signal
box values 130.2um 22.16um 131.8um 24.84um
label T020 center metal1
port T020 make 21
port T020 class inout
port T020 use signal
box values 145.16um 25.2um 147.84um 26.8um
label T021 center metal1
port T021 make 22
port T021 class inout
port T021 use signal
box values 158.2um 25.16um 159.8um 27.84um
label T022 center metal1
port T022 make 23
port T022 class inout
port T022 use signal
box values 172.16um 23.2um 174.84um 24.8um
label T023 center metal1
port T023 make 24
port T023 class inout
port T023 use signal
box values 10.2um 40.2um 11.8um 41.8um
label T024 center metal1
port T024 make 25
port T024 class inout
port T024 use signal
box values 23.2um 40.2um 24.8um 41.8um
label T025 center metal1
port T025 make 26
port T025 class inout
port T025 use signal
box values 38.2um 38.2um 39.8um 39.8um
label T026 center metal1
port T026 make 27
port T026 class inout
port T026 use signal
box values 55.2um 38.2um 56.8um 39.8um
label T027 center metal1
port T027 make 28
port T027 class inout
port T027 use signal
box values 70.2um 38.2um 71.8um 39.8um
label T028 center metal1
port T028 make 29
port T028 class inout
port T028 use signal
box values 85.2um 40.2um 86.8um 41.8um
label T029 center metal1
port T029 make 30
port T029 class inout
port T029 use signal
box values 98.2um 40.2um 99.8um 41.8um
label T030 center metal1
port T030 make 31
port T030 class inout
port T030 use signal
box values 113.2um 38.2um 114.8um 39.8um
label T031 center metal1
port T031 make 32
port T031 class inout
port T031 use signal
box values 130.2um 40.2um 131.8um 41.8um
label T032 center metal1
port T032 make 33
port T032 class inout
port T032 use signal
box values 143.2um 40.2um 144.8um 41.8um
label T033 center metal1
port T033 make 34
port T033 class inout
port T033 use signal
box values 158.2um 38.2um 159.8um 39.8um
label T034 center metal1
port T034 make 35
port T034 class inout
port T034 use signal
box values 175.2um 38.2um 176.8um 39.8um
label T035 center metal1
port T035 make 36
port T035 class inout
port T035 use signal
box values 10.2um 53.2um 11.8um 54.8um
label T036 center metal1
port T036 make 37
port T036 class inout
port T036 use signal
box values 25.2um 55.2um 26.8um 56.8um
label T037 center metal1
port T037 make 38
port T037 class inout
port T037 use signal
box values 38.2um 55.2um 39.8um 56.8um
label T038 center metal1
port T038 make 39
port T038 class inout
port T038 use signal
box values 53.2um 53.2um 54.8um 54.8um
label T039 center metal1
port T039 make 40
port T039 class inout
port T039 use signal
box values 70.2um 55.2um 71.8um 56.8um
label T040 center metal1
port T040 make 41
port T040 class inout
port T040 use signal
box values 83.2um 55.2um 84.8um 56.8um
label T041 center metal1
port T041 make 42
port T041 class inout
port T041 use signal
box values 98.2um 53.2um 99.8um 54.8um
label T042 center metal1
port T042 make 43
port T042 class inout
port T042 use signal
box values 115.2um 53.2um 116.8um 54.8um
label T043 center metal1
port T043 make 44
port T043 class inout
port T043 use signal
box values 130.2um 53.2um 131.8um 54.8um
label T044 center metal1
port T044 make 45
port T044 class inout
port T044 use signal
box values 145.2um 55.2um 146.8um 56.8um
label T045 center metal1
port T045 make 46
port T045 class inout
port T045 use signal
box values 158.2um 55.2um 159.8um 56.8um
label T046 center metal1
port T046 make 47
port T046 class inout
port T046 use signal
box values 173.2um 53.2um 174.8um 54.8um
label T047 center metal1
port T047 make 48
port T047 class inout
port T047 use signal
box values 10.2um 70.2um 11.8um 71.8um
label T048 center metal1
port T048 make 49
port T048 class inout
port T048 use signal
box values 23.2um 70.2um 24.8um 71.8um
label T049 center metal1
port T049 make 50
port T049 class inout
port T049 use signal
box values 38.2um 68.2um 39.8um 69.8um
label T050 center metal1
port T050 make 51
port T050 class inout
port T050 use signal
box values 55.2um 68.2um 56.8um 69.8um
label T051 center metal1
port T051 make 52
port T051 class inout
port T051 use signal
box values 70.2um 68.2um 71.8um 69.8um
label T052 center metal1
port T052 make 53
port T052 class inout
port T052 use signal
box values 85.2um 70.2um 86.8um 71.8um
label T053 center metal1
port T053 make 54
port T053 class inout
port T053 use signal
box values 98.2um 70.2um 99.8um 71.8um
label T054 center metal1
port T054 make 55
port T054 class inout
port T054 use signal
box values 113.2um 68.2um 114.8um 69.8um
label T055 center metal1
port T055 make 56
port T055 class inout
port T055 use signal
box values 130.2um 70.2um 131.8um 71.8um
label T056 center metal1
port T056 make 57
port T056 class inout
port T056 use signal
box values 143.2um 70.2um 144.8um 71.8um
label T057 center metal1
port T057 make 58
port T057 class inout
port T057 use signal
box values 158.2um 68.2um 159.8um 69.8um
label T058 center metal1
port T058 make 59
port T058 class inout
port T058 use signal
box values 175.2um 68.2um 176.8um 69.8um
label T059 center metal1
port T059 make 60
port T059 class inout
port T059 use signal
box values 10.2um 83.2um 11.8um 84.8um
label T060 center metal1
port T060 make 61
port T060 class inout
port T060 use signal
box values 25.2um 85.2um 26.8um 86.8um
label T061 center metal1
port T061 make 62
port T061 class inout
port T061 use signal
box values 38.2um 85.2um 39.8um 86.8um
label T062 center metal1
port T062 make 63
port T062 class inout
port T062 use signal
box values 53.2um 83.2um 54.8um 84.8um
label T063 center metal1
port T063 make 64
port T063 class inout
port T063 use signal
box values 70.2um 85.2um 71.8um 86.8um
label T064 center metal1
port T064 make 65
port T064 class inout
port T064 use signal
box values 83.2um 85.2um 84.8um 86.8um
label T065 center metal1
port T065 make 66
port T065 class inout
port T065 use signal
box values 98.2um 83.2um 99.8um 84.8um
label T066 center metal1
port T066 make 67
port T066 class inout
port T066 use signal
box values 115.2um 83.2um 116.8um 84.8um
label T067 center metal1
port T067 make 68
port T067 class inout
port T067 use signal
box values 130.2um 83.2um 131.8um 84.8um
label T068 center metal1
port T068 make 69
port T068 class inout
port T068 use signal
box values 145.2um 85.2um 146.8um 86.8um
label T069 center metal1
port T069 make 70
port T069 class inout
port T069 use signal
box values 158.2um 85.2um 159.8um 86.8um
label T070 center metal1
port T070 make 71
port T070 class inout
port T070 use signal
box values 173.2um 83.2um 174.8um 84.8um
label T071 center metal1
port T071 make 72
port T071 class inout
port T071 use signal
box values 10.2um 100.2um 11.8um 101.8um
label T072 center metal1
port T072 make 73
port T072 class inout
port T072 use signal
box values 23.2um 100.2um 24.8um 101.8um
label T073 center metal1
port T073 make 74
port T073 class inout
port T073 use signal
box values 38.2um 98.2um 39.8um 99.8um
label T074 center metal1
port T074 make 75
port T074 class inout
port T074 use signal
box values 55.2um 98.2um 56.8um 99.8um
label T075 center metal1
port T075 make 76
port T075 class inout
port T075 use signal
box values 70.2um 98.2um 71.8um 99.8um
label T076 center metal1
port T076 make 77
port T076 class inout
port T076 use signal
box values 85.2um 100.2um 86.8um 101.8um
label T077 center metal1
port T077 make 78
port T077 class inout
port T077 use signal
box values 98.2um 100.2um 99.8um 101.8um
label T078 center metal1
port T078 make 79
port T078 class inout
port T078 use signal
box values 113.2um 98.2um 114.8um 99.8um
label T079 center metal1
port T079 make 80
port T079 class inout
port T079 use signal
box values 130.2um 100.2um 131.8um 101.8um
label T080 center metal1
port T080 make 81
port T080 class inout
port T080 use signal
box values 143.2um 100.2um 144.8um 101.8um
label T081 center metal1
port T081 make 82
port T081 class inout
port T081 use signal
box values 158.2um 98.2um 159.8um 99.8um
label T082 center metal1
port T082 make 83
port T082 class inout
port T082 use signal
box values 175.2um 98.2um 176.8um 99.8um
label T083 center metal1
port T083 make 84
port T083 class inout
port T083 use signal
box values 10.2um 113.2um 11.8um 114.8um
label T084 center metal1
port T084 make 85
port T084 class inout
port T084 use signal
box values 25.2um 115.2um 26.8um 116.8um
label T085 center metal1
port T085 make 86
port T085 class inout
port T085 use signal
box values 38.2um 115.2um 39.8um 116.8um
label T086 center metal1
port T086 make 87
port T086 class inout
port T086 use signal
box values 53.2um 113.2um 54.8um 114.8um
label T087 center metal1
port T087 make 88
port T087 class inout
port T087 use signal
box values 70.2um 115.2um 71.8um 116.8um
label T088 center metal1
port T088 make 89
port T088 class inout
port T088 use signal
box values 83.2um 115.2um 84.8um 116.8um
label T089 center metal1
port T089 make 90
port T089 class inout
port T089 use signal
box values 98.2um 113.2um 99.8um 114.8um
label T090 center metal1
port T090 make 91
port T090 class inout
port T090 use signal
box values 115.2um 113.2um 116.8um 114.8um
label T091 center metal1
port T091 make 92
port T091 class inout
port T091 use signal
box values 130.2um 113.2um 131.8um 114.8um
label T092 center metal1
port T092 make 93
port T092 class inout
port T092 use signal
box values 145.2um 115.2um 146.8um 116.8um
label T093 center metal1
port T093 make 94
port T093 class inout
port T093 use signal
box values 158.2um 115.2um 159.8um 116.8um
label T094 center metal1
port T094 make 95
port T094 class inout
port T094 use signal
box values 173.2um 113.2um 174.8um 114.8um
label T095 center metal1
port T095 make 96
port T095 class inout
port T095 use signal
box values 10.2um 130.2um 11.8um 131.8um
label T096 center metal1
port T096 make 97
port T096 class inout
port T096 use signal
box values 23.2um 130.2um 24.8um 131.8um
label T097 center metal1
port T097 make 98
port T097 class inout
port T097 use signal
box values 38.2um 128.2um 39.8um 129.8um
label T098 center metal1
port T098 make 99
port T098 class inout
port T098 use signal
box values 55.2um 128.2um 56.8um 129.8um
label T099 center metal1
port T099 make 100
port T099 class inout
port T099 use signal
box values 70.2um 128.2um 71.8um 129.8um
label T100 center metal1
port T100 make 101
port T100 class inout
port T100 use signal
box values 85.2um 130.2um 86.8um 131.8um
label T101 center metal1
port T101 make 102
port T101 class inout
port T101 use signal
box values 98.2um 130.2um 99.8um 131.8um
label T102 center metal1
port T102 make 103
port T102 class inout
port T102 use signal
box values 113.2um 128.2um 114.8um 129.8um
label T103 center metal1
port T103 make 104
port T103 class inout
port T103 use signal
box values 130.2um 130.2um 131.8um 131.8um
label T104 center metal1
port T104 make 105
port T104 class inout
port T104 use signal
box values 143.2um 130.2um 144.8um 131.8um
label T105 center metal1
port T105 make 106
port T105 class inout
port T105 use signal
box values 158.2um 128.2um 159.8um 129.8um
label T106 center metal1
port T106 make 107
port T106 class inout
port T106 use signal
box values 175.2um 128.2um 176.8um 129.8um
label T107 center metal1
port T107 make 108
port T107 class inout
port T107 use signal
box values 10.14um 145.14um 10.64um 145.64um
label T108 center metal1
port T108 make 109
port T108 class inout
port T108 use signal
box values 10.0um 145.0um 10.78um 145.78um
label W108 center nwell
port W108 make 110
port W108 class inout
port W108 use signal
box values 24.36um 145.14um 24.86um 145.64um
label T109 center metal1
port T109 make 111
port T109 class inout
port T109 use signal
box values 24.22um 145.0um 25.0um 145.78um
label W109 center nwell
port W109 make 112
port W109 class inout
port W109 use signal
box values 39.36um 144.36um 39.86um 144.86um
label T110 center metal1
port T110 make 113
port T110 class inout
port T110 use signal
box values 39.22um 144.22um 40.0um 145.0um
label W110 center nwell
port W110 make 114
port W110 class inout
port W110 use signal
box values 55.14um 144.36um 55.64um 144.86um
label T111 center metal1
port T111 make 115
port T111 class inout
port T111 use signal
box values 55.0um 144.22um 55.78um 145.0um
label W111 center nwell
port W111 make 116
port W111 class inout
port W111 use signal
box values 70.14um 144.36um 70.64um 144.86um
label T112 center metal1
port T112 make 117
port T112 class inout
port T112 use signal
box values 70.0um 144.22um 70.78um 145.0um
label W112 center nwell
port W112 make 118
port W112 class inout
port W112 use signal
box values 85.14um 145.14um 85.64um 145.64um
label T113 center metal1
port T113 make 119
port T113 class inout
port T113 use signal
box values 85.0um 145.0um 85.78um 145.78um
label W113 center nwell
port W113 make 120
port W113 class inout
port W113 use signal
box values 99.36um 145.14um 99.86um 145.64um
label T114 center metal1
port T114 make 121
port T114 class inout
port T114 use signal
box values 99.22um 145.0um 100.0um 145.78um
label W114 center nwell
port W114 make 122
port W114 class inout
port W114 use signal
box values 114.36um 144.36um 114.86um 144.86um
label T115 center metal1
port T115 make 123
port T115 class inout
port T115 use signal
box values 114.22um 144.22um 115.0um 145.0um
label W115 center nwell
port W115 make 124
port W115 class inout
port W115 use signal
box values 130.2um 145.2um 131.8um 146.8um
label T116 center metal1
port T116 make 125
port T116 class inout
port T116 use signal
box values 130.0um 145.0um 132.0um 147.0um
label W116 center nwell
port W116 make 126
port W116 class inout
port W116 use signal
box values 143.2um 145.2um 144.8um 146.8um
label T117 center metal1
port T117 make 127
port T117 class inout
port T117 use signal
box values 143.0um 145.0um 145.0um 147.0um
label W117 center nwell
port W117 make 128
port W117 class inout
port W117 use signal
box values 158.2um 143.2um 159.8um 144.8um
label T118 center metal1
port T118 make 129
port T118 class inout
port T118 use signal
box values 158.0um 143.0um 160.0um 145.0um
label W118 center nwell
port W118 make 130
port W118 class inout
port W118 use signal
box values 175.2um 143.2um 176.8um 144.8um
label T119 center metal1
port T119 make 131
port T119 class inout
port T119 use signal
box values 175.0um 143.0um 177.0um 145.0um
label W119 center nwell
port W119 make 132
port W119 class inout
port W119 use signal
box values 10.2um 158.2um 11.8um 159.8um
label T120 center metal1
port T120 make 133
port T120 class inout
port T120 use signal
box values 10.0um 158.0um 12.0um 160.0um
label W120 center nwell
port W120 make 134
port W120 class inout
port W120 use signal
box values 25.2um 160.2um 26.8um 161.8um
label T121 center metal1
port T121 make 135
port T121 class inout
port T121 use signal
box values 25.0um 160.0um 27.0um 162.0um
label W121 center nwell
port W121 make 136
port W121 class inout
port W121 use signal
box values 38.2um 160.2um 39.8um 161.8um
label T122 center metal1
port T122 make 137
port T122 class inout
port T122 use signal
box values 38.0um 160.0um 40.0um 162.0um
label W122 center nwell
port W122 make 138
port W122 class inout
port W122 use signal
box values 53.2um 158.2um 54.8um 159.8um
label T123 center metal1
port T123 make 139
port T123 class inout
port T123 use signal
box values 53.0um 158.0um 55.0um 160.0um
label W123 center nwell
port W123 make 140
port W123 class inout
port W123 use signal
box values 70.2um 160.16um 71.8um 162.84um
label T124 center metal1
port T124 make 141
port T124 class inout
port T124 use signal
box values 70.0um 160.0um 72.0um 163.0um
label W124 center nwell
port W124 make 142
port W124 class inout
port W124 use signal
box values 82.16um 160.2um 84.84um 161.8um
label T125 center metal1
port T125 make 143
port T125 class inout
port T125 use signal
box values 82.0um 160.0um 85.0um 162.0um
label W125 center nwell
port W125 make 144
port W125 class inout
port W125 use signal
box values 98.2um 157.16um 99.8um 159.84um
label T126 center metal1
port T126 make 145
port T126 class inout
port T126 use signal
box values 98.0um 157.0um 100.0um 160.0um
label W126 center nwell
port W126 make 146
port W126 class inout
port W126 use signal
box values 115.16um 158.2um 117.84um 159.8um
label T127 center metal1
port T127 make 147
port T127 class inout
port T127 use signal
box values 115.0um 158.0um 118.0um 160.0um
label W127 center nwell
port W127 make 148
port W127 class inout
port W127 use signal
box values 130.2um 157.16um 131.8um 159.84um
label T128 center metal1
port T128 make 149
port T128 class inout
port T128 use signal
box values 130.0um 157.0um 132.0um 160.0um
label W128 center nwell
port W128 make 150
port W128 class inout
port W128 use signal
box values 145.16um 160.2um 147.84um 161.8um
label T129 center metal1
port T129 make 151
port T129 class inout
port T129 use signal
box values 145.0um 160.0um 148.0um 162.0um
label W129 center nwell
port W129 make 152
port W129 class inout
port W129 use signal
box values 158.2um 160.16um 159.8um 162.84um
label T130 center metal1
port T130 make 153
port T130 class inout
port T130 use signal
box values 158.0um 160.0um 160.0um 163.0um
label W130 center nwell
port W130 make 154
port W130 class inout
port W130 use signal
box values 172.16um 158.2um 174.84um 159.8um
label T131 center metal1
port T131 make 155
port T131 class inout
port T131 use signal
box values 172.0um 158.0um 175.0um 160.0um
label W131 center nwell
port W131 make 156
port W131 class inout
port W131 use signal
scalegrid 1 4
save finite_taps_flat
extract style ngspice()
extract all
ext2spice lvs
ext2spice global off
ext2spice cthresh infinite
ext2spice extresist off
ext2spice -o taps.spice
puts NSSOC_FINITE_TAP_NATIVE_COMPLETE
quit -noprompt
