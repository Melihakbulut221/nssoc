Native finite tap interface
.include "/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/ngspice/models/resistors_mod.lib"
V0 n0 0 1
X0 n0 0 ptap1 R=81.6667 w=2u l=2u
V1 n1 0 1
X1 n1 0 ntap1 R=81.6667 w=2u l=2u
V2 n2 0 1
X2 n2 0 ptap1 R=262.84698 w=2u l=2u
V3 n3 0 1
X3 n3 0 ntap1 R=61.25 w=2u l=2u
.control
op
print i(v0) i(v1) i(v2) i(v3)
echo NSSOC_FOUNDARY_TAP_DC_COMPLETE
quit
.endc
.end
