# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import shutil,sys,json
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from check_pcie_rx_cell import execute
from check_magic_hbt_multiplicity_v3 import pin
from patch_magic_finite_tap_v1 import patch
BASE=Path('/dev/shm/nssoc-hbt-nx-v3-build-final');O=Path('/dev/shm/nssoc-finite-tap-v1-build-final');O.mkdir();S=O/'source';shutil.copytree(BASE/'source',S)
for name in ('ExtBasic.c','ExtTech.c'):
 p=S/'extract'/name;p.write_bytes(patch(name,p.read_bytes()))
runs=[]
for cmd in [['make','-C',str(S/'extract'),'clean'],['make','-C',str(S/'extract'),'module'],['make','-C',str(S/'magic'),'tcl-main']]:
 x=execute(cmd,O,'build'+str(len(runs)));runs.append(x);assert x['returncode']==0
RT=O/'runtime/lib';shutil.copytree(BASE/'runtime/lib',RT);shutil.copyfile(S/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so')
r=dict(parent=pin(BASE/'result.json'),method=pin(R/'scripts/patch_magic_finite_tap_v1.py'),source={n:pin(S/'extract'/n) for n in ('ExtBasic.c','ExtTech.c')},executions=runs,runtime=pin(RT/'magic/tcl/tclmagic.so'))
(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
