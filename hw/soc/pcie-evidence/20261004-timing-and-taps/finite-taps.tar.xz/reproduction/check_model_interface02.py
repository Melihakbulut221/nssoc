# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys,re
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from check_pcie_rx_cell import execute
from check_magic_hbt_multiplicity_v3 import pin
O=Path('/dev/shm/nssoc-finite-tap-foundry-model-02');O.mkdir();M=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/ngspice/models/resistors_mod.lib');N=Path('/dev/shm/nssoc-ngspice47-20261004/root/usr/bin/ngspice')
text='Native finite tap interface\n.include "'+str(M)+'"\n';expected={}
for i,(model,res) in enumerate((('ptap1',81.6667),('ntap1',81.6667),('ptap1',262.84698),('ntap1',61.25))):
 text+=f'V{i} n{i} 0 1\nX{i} n{i} 0 {model} R={res} w=2u l=2u\n';expected[f'i(v{i})']=-1/res
text+='.control\nop\nprint '+ ' '.join(expected)+'\necho NSSOC_FOUNDARY_TAP_DC_COMPLETE\nquit\n.endc\n.end\n';p=O/'bench.sp';p.write_text(text)
(O/'spinit').write_text('* No optional code models are used by native R-only taps.\n')
x=execute(['/usr/bin/env','SPICE_SCRIPTS='+str(O),N,'-b',p],O,'native');assert x['returncode']==0;log=(O/'native.log').read_text();assert 'NSSOC_FOUNDARY_TAP_DC_COMPLETE' in log and not re.search('(?i)error|warning|singular|failed',log)
actual={name:float(re.search(re.escape(name)+r'\s*=\s*([^\s]+)',log)[1]) for name in expected};assert all(abs(actual[k]-v)<1e-7 for k,v in expected.items())
(O/'result.json').write_text(json.dumps(dict(status='PASS_PINNED_FOUNDRY_TAP_SUBCIRCUIT_DC_INTERFACE',execution=x,expected=expected,actual=actual,inputs={str(p):pin(p) for p in (Path(__file__),M,N)},outputs={p.name:pin(p) for p in O.iterdir() if p.is_file()},limitations=['DC1V is an interface check, not tap stress or distributed substrate qualification.']),indent=2)+'\n')
