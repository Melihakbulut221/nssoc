# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import shutil,sys,json
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
import check_magic_hbt_multiplicity_v3 as h
from patch_magic_finite_tap_v1 import patch
from check_pcie_rx_cell import execute
F=Path('/dev/shm/nssoc-magic-hbt-axis-01');O=Path('/dev/shm/nssoc-finite-tap-repair-01');O.mkdir();T=O/'tech';shutil.copytree('/dev/shm/nssoc-hbt-nx-v3-native-final/tech',T);p=T/'ihp-sg13g2-extract.tech';p.write_bytes(patch(p.name,p.read_bytes()));RT=Path('/dev/shm/nssoc-finite-tap-v1-build-01/runtime/lib');N=O/'native';N.mkdir();script=N/'native.tcl';script.write_text(h.native_tcl(F/'fixture.gds',json.loads((F/'result.json').read_text()),N))
x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',script],N,'native')
r=dict(execution=x,inputs={str(p):h.pin(p) for p in [Path(__file__).resolve(),F/'fixture.gds',F/'result.json',RT/'magic/tcl/tclmagic.so',R/'scripts/patch_magic_finite_tap_v1.py']},technology={p.name:h.pin(p) for p in T.iterdir() if p.is_file()},outputs={p.name:h.pin(p) for p in N.iterdir() if p.is_file()},qualified=False);(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(x)
