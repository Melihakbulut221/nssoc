# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,sys,difflib,tarfile,io
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));import check_magic_hbt_multiplicity_v3 as h
B=R/'hw/soc/out/pcie-magic-finite-tap-v1-20261004';P=Path('/dev/shm/nssoc-hbt-nx-v3-build-final');F=Path('/dev/shm/nssoc-finite-tap-v1-build-final');T=Path('/dev/shm/nssoc-finite-tap-tech-final')
sources=[R/'scripts'/n for n in ('patch_magic_finite_tap_v1.py','make_magic_finite_tap_fixture_v1.py','check_magic_finite_tap_v1.py')]+[R/'sw/tests/test_magic_finite_tap_v1.py']
allc={str(p.relative_to(P/'source')):h.pin(p) for p in (P/'source').rglob('*') if p.is_file() and p.suffix in ('.c','.h')};newc={str(p.relative_to(F/'source')):h.pin(p) for p in (F/'source').rglob('*') if p.is_file() and p.suffix in ('.c','.h')};assert set(allc)==set(newc)
changed=[p for p in allc if allc[p]!=newc[p]];assert set(changed)=={'extract/ExtBasic.c','extract/ExtTech.c'}
audit=dict(checked_c_and_headers=len(allc),changed=changed,headers_and_external_abi_unchanged=True,before=allc,after=newc,build=json.loads((F/'result.json').read_text()))
(B/'private-source-build-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
patch=''.join(''.join(difflib.unified_diff((P/'source'/n).read_text().splitlines(True),(F/'source'/n).read_text().splitlines(True),fromfile='before/'+n,tofile='after/'+n)) for n in changed)
patch+=''.join(difflib.unified_diff(Path('/dev/shm/nssoc-hbt-nx-v3-native-final/tech/ihp-sg13g2-extract.tech').read_text().splitlines(True),(T/'ihp-sg13g2-extract.tech').read_text().splitlines(True),fromfile='before/ihp-sg13g2-extract.tech',tofile='after/ihp-sg13g2-extract.tech'))
(B/'native-extractor.diff').write_text(patch)
# Native results are read and all raw output pins independently replayed here.
roots={
 'native':Path('/dev/shm/nssoc-finite-tap-native-final'),
 'hbt-joint':Path('/dev/shm/nssoc-finite-tap-hbt-final'),
 'hbt-optout':Path('/dev/shm/nssoc-finite-tap-optout-final'),
 'klayout':Path('/dev/shm/nssoc-finite-tap-klayout-01'),
 'fixture':Path('/dev/shm/nssoc-finite-tap-fixture-04'),
 'foundry-model':Path('/dev/shm/nssoc-finite-tap-foundry-model-02'),
}
r=json.loads((roots['native']/'result.json').read_text());assert r['status']=='PASS_ISOLATED_NATIVE_TAP_CONTROLS'
for name,row in r['cases'].items():
 for f,pin in row['outputs'].items():assert h.pin(roots['native']/name/f)==pin
 assert row['execution']['returncode']==0
for name in ('nominal','initial_10nm'):
 row=r['cases'][name]['outcome'];assert row['ptap_count']==108 and row['ntap_count']==24 and row['port_count']==156
k=json.loads((roots['klayout']/'result.json').read_text());assert k['fixture']['audit']['returncode']==0 and all(v['audit']['returncode']==1 for n,v in k.items() if n!='fixture')
ka=json.loads((roots['klayout']/'fixture/audit.json').read_text());assert ka['status']=='PASS within comparison scope' and ka['circuits'][0]['layout_devices_recursive']==132
# Retain source notices verbatim and avoid publishing runtime binaries.
old=R/'hw/soc/out/pcie-magic-hbt-multiplicity-v3-20261004/UPSTREAM-NOTICES.txt';notice=old.read_text()+'\nFINITE TAP V1 ADDENDUM\nModified Magic ExtBasic.c and ExtTech.c retain their upstream UC Regents permissive notices. The modified IHP extraction technology and native PCell-generated geometry retain Apache-2.0. Project methods/tests retain Apache-2.0. No compiled Magic/ngspice/AppImage/OSDI binary is redistributed. The pinned PDK resistor model is referenced by hash/path; it is not copied into this capsule.\n';(B/'UPSTREAM-NOTICES.txt').write_text(notice)
entries={}
def add(name,path):
 if name in entries:raise ValueError(name)
 entries[name]=Path(path).read_bytes()
for label,d in roots.items():
 for p in d.rglob('*'):
  if p.is_file():add(label+'/'+str(p.relative_to(d)),p)
for p in sources:add('methods/'+str(p.relative_to(R)),p)
for n in changed:
 add('private-source/before/'+n,P/'source'/n);add('private-source/after/'+n,F/'source'/n)
for p in T.iterdir():
 if p.is_file():add('technology/'+p.name,p)
for p in F.iterdir():
 if p.is_file():add('build/'+p.name,p)
# Earlier real failed scope checks/native logs remain reproducible evidence.
for name in ('nssoc-finite-tap-existing-style-01','nssoc-finite-tap-repair-02','nssoc-finite-tap-native-03','nssoc-finite-tap-native-04','nssoc-finite-tap-foundry-model','nssoc-finite-tap-foundry-model-final'):
 d=Path('/dev/shm')/name
 for p in d.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.log','.ext','.spice','.tcl','.sp'):add('preserved-diagnostics/'+name+'/'+str(p.relative_to(d)),p)
for p in B.iterdir():
 if p.is_file() and p.suffix in ('.py','.json','.diff','.txt') and p.name!='validation.json':add('reproduction/'+p.name,p)
manifest={n:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for n,data in entries.items()}
entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
cap=B/'finite-tap-v1-native.tar.xz'
with tarfile.open(cap,'w:xz') as tf:
 for n,data in sorted(entries.items()):
  member=tarfile.TarInfo(n);member.size=len(data);member.mtime=0;tf.addfile(member,io.BytesIO(data))
with tarfile.open(cap) as tf:
 assert len(tf.getmembers())==len(entries)
 for m in tf.getmembers():assert tf.extractfile(m).read()==entries[m.name]
record=dict(status='PASS_ISOLATED_NATIVE_FINITE_TAP_GEOMETRY_AND_FOUNDRY_INTERFACE',sources={str(p.relative_to(R)):h.pin(p) for p in sources},build_audit=h.pin(B/'private-source-build-audit.json'),runtime=h.pin(F/'runtime/lib/magic/tcl/tclmagic.so'),technology=h.pin(T/'ihp-sg13g2-extract.tech'),native=r,klayout_audit=ka,hbt_joint=json.loads((roots['hbt-joint']/'result.json').read_text()),hbt_optout=json.loads((roots['hbt-optout']/'result.json').read_text()),foundry_dc=json.loads((roots['foundry-model']/'result.json').read_text()),tests=dict(passed=142,own=49,ruff='PASS',command='PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm .venv/bin/python -m pytest sw/tests/test_magic_finite_tap_v1.py sw/tests/test_magic_hbt_multiplicity_v3.py sw/tests/test_magic_hbt_contract_v2.py sw/tests/test_magic_hbt_axis_v1.py -q -p no:cacheprovider'),capsule=dict(**h.pin(cap),members=len(entries),all_members_roundtrip_verified=True),formula='R = 1 / (A/980 + P/980), A in square micrometers, P in micrometers; pinned native CbTapCalc, ptap1/ntap1 resistor model.2x2um =>81.6666667ohm; native%g then float32/esSIvalue export rounding checked separately.',changes=['Enable existing native finite-tap geometry and disconnect rules only in isolated ngspice technology; preserve distinct real body nodes.','Scale only existing area/perimeter devresist coefficients with native grid change; no sheet/linear coefficient change.','Use floating arithmetic in existing area/perimeter resistance computation; no fitted dimensions or values.'],limitations=['132-device isolated fixture only:108 separate substrate branches and24 well branches, three actual sizes and all8 orientations. No assertion all108 bank contacts have yet been recovered.','5nm and10nm internal-grid extractions preserve physical geometry, exact dimensions and resistance. Disallowed finer-grid attempts are preserved separately, not passing grid coverage.','Existing frozen24-HBT fixture now has one finite substrate contact and all24 correctNx/CBE/body bindings; no PDK or old producer edit.','Strict native KLayout is the independent geometry/connectivity reference; all3 actual geometry faults rejected by both engines.','DC1V is a native foundry-subcircuit interface check only, not contact stress or distributed substrate characterization.','No full-bank transistor graph, distributed body resistance, coupled wireRC, fullRFPEX, process signoff or mainchip adoption claim.','Earlier missing-spinit and host-code-model initialization failures are preserved; final resistor-only interface supplies an explicit no-optional-model spinit and is warning/error-free.'],qualified_pex=False,qualified_full_bank=False,original_pdk_unchanged=True)
(B/'validation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({p.name:h.pin(p) for p in (cap,B/'validation.json')},indent=2))
