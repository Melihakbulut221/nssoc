# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
import check_magic_hbt_multiplicity_v3 as h
from check_pcie_rx_cell import execute
F=Path('/dev/shm/nssoc-magic-hbt-axis-01');O=Path('/dev/shm/nssoc-finite-tap-existing-style-01');O.mkdir();RT=Path('/dev/shm/nssoc-hbt-nx-v3-build-final/runtime/lib');T=Path('/dev/shm/nssoc-hbt-nx-v3-native-final/tech');script=O/'native.tcl';script.write_text(h.native_tcl(F/'fixture.gds',json.loads((F/'result.json').read_text()),O).replace('extract style ngspice()','extract style ngspice(lvs)'))
x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',script],O,'native');r=dict(execution=x,inputs={str(p):h.pin(p) for p in [Path(__file__).resolve(),F/'fixture.gds',F/'result.json',T/'ihp-sg13g2-extract.tech',RT/'magic/tcl/tclmagic.so']},outputs={p.name:h.pin(p) for p in O.iterdir() if p.is_file()},qualified=False);(O/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(x)
