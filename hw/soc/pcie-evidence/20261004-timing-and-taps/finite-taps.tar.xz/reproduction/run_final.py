# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,shutil
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from check_pcie_rx_cell import execute
import check_magic_hbt_multiplicity_v3 as h
from patch_magic_finite_tap_v1 import patch
B=Path('/dev/shm/nssoc-finite-tap-v1-build-final');O=Path('/dev/shm/nssoc-finite-tap-native-final');T=Path('/dev/shm/nssoc-finite-tap-tech-final');shutil.copytree('/dev/shm/nssoc-hbt-nx-v3-native-final/tech',T)
f=T/'ihp-sg13g2-extract.tech';f.write_bytes(patch(f.name,f.read_bytes()))
x=execute([sys.executable,R/'scripts/check_magic_finite_tap_v1.py','--fixture','/dev/shm/nssoc-finite-tap-fixture-04','--runtime',B/'runtime/lib','--technology',T,'--out',O],B,'controls-final');assert x['returncode']==0
(B/'controls-final.json').write_text(json.dumps(x,indent=2)+'\n')
# Re-run unchanged actual24-HBT geometry, now with actual finite tap; no node forcing.
F=Path('/dev/shm/nssoc-magic-hbt-axis-01');A=Path('/dev/shm/nssoc-finite-tap-hbt-final');A.mkdir();script=A/'native.tcl';script.write_text(h.native_tcl(F/'fixture.gds',json.loads((F/'result.json').read_text()),A));rt=B/'runtime/lib'
x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',script],A,'native');assert x['returncode']==0
rows=[s.split() for s in h.spice_lines((A/'hbt.spice').read_text())];taps=[r for r in rows if len(r)>3 and r[3]=='ptap1'];hbts=[r for r in rows if len(r)>5 and r[5]=='npn13g2'];assert len(taps)==1 and len(hbts)==24
body=taps[0][2];assert taps[0][1]=='SUB' and body!='SUB' and dict(t.split('=') for t in taps[0][4:])==dict(w='2u',l='2u',r='81.6667')
observed=sorted((tuple(r[1:5]),tuple(sorted(dict(t.split('=') for t in r[6:]).items()))) for r in hbts)
expected=sorted(((f'C_N{n}_T{o}',f'B_N{n}_T{o}',f'E_N{n}_T{o}',body),tuple(sorted(dict(we='70n',le='0.9u',Nx=str(n)).items()))) for n in (1,2,4) for o in range(8));assert observed==expected
assert set(rows[0][2:])==set(h.PORTS) and len(rows[0][2:])==73
(A/'result.json').write_text(json.dumps(dict(status='PASS24_HBTS_BOUND_TO_FINITE_TAP_BODY_73PORTS',execution=x,inputs={str(p):h.pin(p) for p in [Path(__file__),F/'fixture.gds',F/'result.json',rt/'magic/tcl/tclmagic.so',T/'ihp-sg13g2-extract.tech']},observed=observed,tap=taps[0],outputs={p.name:h.pin(p) for p in A.iterdir() if p.is_file()},qualified_pex=False),indent=2)+'\n')
# Source-default no-tap technology must keep frozenNx outputs identical.
O=Path('/dev/shm/nssoc-finite-tap-optout-final');O.mkdir();source=Path('/dev/shm/nssoc-hbt-nx-v3-native-final/positive');print('old case dirs',[p.name for p in source.parent.iterdir() if p.is_dir()])
script=O/'native.tcl';script.write_text(h.native_tcl(F/'fixture.gds',json.loads((F/'result.json').read_text()),O))
x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile','/dev/shm/nssoc-hbt-nx-v3-native-final/tech/ihp-sg13g2.magicrc',script],O,'native');assert x['returncode']==0
r=h.assess((O/'hbt.spice').read_text(),(O/'hbt_axis_flat.ext').read_text(),(O/'native.log').read_text());(O/'result.json').write_text(json.dumps(dict(status='PASS_FROZEN_HBT_CONTRACT_WITHOUT_FINITE_OVERLAY',execution=x,assessment=r,outputs={p.name:h.pin(p) for p in O.iterdir() if p.is_file()}),indent=2)+'\n')
print('PASS native isolated132taps +24HBT finite +24HBT old contract')
