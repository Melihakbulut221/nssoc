module old_read(input[4:0]read_ptr,committed,output reg[2:0]read_count,output wire empty,output reg[127:0]read_data,output reg[15:0]read_keep,output reg[15:0]read_sop,output reg[15:0]read_eop,output reg[15:0]read_dllp,output reg[47:0]read_sequence);
localparam RING_DWORDS=16,PW=5;
reg slot_verdict[0:RING_DWORDS-1];
reg[31:0]slot_data[0:RING_DWORDS-1];
reg[3:0]slot_keep[0:RING_DWORDS-1];
reg[3:0]slot_sop[0:RING_DWORDS-1];
reg[3:0]slot_eop[0:RING_DWORDS-1];
reg[3:0]slot_dllp[0:RING_DWORDS-1];
reg[11:0]slot_sequence[0:RING_DWORDS-1]; // BEGIN V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
 // Procedural leaf flags are always known0/1, including unknown address,
 // keep or verdict. At most one physical slot matches each lane address.
 // Payload muxes preserve literal X/Z; a payload OR would convert Z to X.
 // A complete binary tree has log2(RING_DWORDS) selection levels in RTL;
 // emitted native depth must be measured separately, not inferred from RTL.
 // Static generate connections avoid dynamic procedural tree-array expansion.
 wire [59:0] read_payload_root[0:3];
 genvar read_lane,read_slot,read_node;
 generate for(read_lane=0;read_lane<4;read_lane=read_lane+1) begin: read_lane_tree
   wire [31:0] read_address=(read_ptr+read_lane)&(RING_DWORDS-1);
   wire [2*RING_DWORDS-1:0] read_eligible_tree;
   wire [59:0] read_payload_tree[0:2*RING_DWORDS-1];
   assign read_eligible_tree[0]=0;
   assign read_payload_tree[0]=0;
   for(read_slot=0;read_slot<RING_DWORDS;read_slot=read_slot+1) begin: leaf
     reg eligible;
     reg [59:0] payload;
     // Every leaf reads only this constant word. Explicit event terms avoid
     // implicit whole-array sensitivity expansion; all read fields are listed.
     always @(read_address or slot_data[read_slot] or slot_keep[read_slot] or slot_sop[read_slot] or slot_eop[read_slot] or slot_dllp[read_slot] or slot_sequence[read_slot] or slot_verdict[read_slot]) begin
       eligible=0;payload=0;
       if(read_address==read_slot && slot_keep[read_slot]!=0 && slot_verdict[read_slot]) begin
         eligible=1;
         payload={slot_data[read_slot],slot_keep[read_slot],slot_sop[read_slot],slot_eop[read_slot],slot_dllp[read_slot],slot_sequence[read_slot]};
       end
     end
     assign read_eligible_tree[RING_DWORDS+read_slot]=eligible;
     assign read_payload_tree[RING_DWORDS+read_slot]=payload;
   end
   for(read_node=1;read_node<RING_DWORDS;read_node=read_node+1) begin: branch
     assign read_eligible_tree[read_node]=read_eligible_tree[2*read_node]|read_eligible_tree[2*read_node+1];
     assign read_payload_tree[read_node]=read_eligible_tree[2*read_node]?
       read_payload_tree[2*read_node]:read_payload_tree[2*read_node+1];
   end
   assign read_payload_root[read_lane]=read_payload_tree[1];
 end endgenerate
 integer r;
 always @* begin
   read_count=(committed>=4)?3'd4:committed;
   read_data=0;read_keep=0;read_sop=0;read_eop=0;read_dllp=0;read_sequence=0;
   for(r=0;r<4;r=r+1) begin
     if(r<read_count) begin
       {read_data[r*32+:32],read_keep[r*4+:4],read_sop[r*4+:4],read_eop[r*4+:4],read_dllp[r*4+:4],read_sequence[r*12+:12]}=read_payload_root[r];
     end
   end
 end
 // END V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
assign empty=(read_keep==0);
endmodule
module new_read(input[4:0]read_ptr,committed,output reg[2:0]read_count,output wire empty,output reg[127:0]read_data,output reg[15:0]read_keep,output reg[15:0]read_sop,output reg[15:0]read_eop,output reg[15:0]read_dllp,output reg[47:0]read_sequence);
localparam RING_DWORDS=16,PW=5;
reg slot_verdict[0:RING_DWORDS-1];
reg[31:0]slot_data[0:RING_DWORDS-1];
reg[3:0]slot_keep[0:RING_DWORDS-1];
reg[3:0]slot_sop[0:RING_DWORDS-1];
reg[3:0]slot_eop[0:RING_DWORDS-1];
reg[3:0]slot_dllp[0:RING_DWORDS-1];
reg[11:0]slot_sequence[0:RING_DWORDS-1]; // BEGIN V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
 // Procedural leaf flags are always known0/1, including unknown address,
 // keep or verdict. At most one physical slot matches each lane address.
 // Payload muxes preserve literal X/Z; a payload OR would convert Z to X.
 // A complete binary tree has log2(RING_DWORDS) selection levels in RTL;
 // emitted native depth must be measured separately, not inferred from RTL.
 // Static generate connections avoid dynamic procedural tree-array expansion.
 wire [59:0] read_payload_root[0:3];
 // V20 known eligibility separates retire control from payload selection.
 wire [3:0] read_eligible_root;
 reg read_any;
 genvar read_lane,read_slot,read_node;
 generate for(read_lane=0;read_lane<4;read_lane=read_lane+1) begin: read_lane_tree
   wire [31:0] read_address=(read_ptr+read_lane)&(RING_DWORDS-1);
   wire [2*RING_DWORDS-1:0] read_eligible_tree;
   wire [59:0] read_payload_tree[0:2*RING_DWORDS-1];
   assign read_eligible_tree[0]=0;
   assign read_payload_tree[0]=0;
   for(read_slot=0;read_slot<RING_DWORDS;read_slot=read_slot+1) begin: leaf
     reg eligible;
     reg [59:0] payload;
     // Every leaf reads only this constant word. Explicit event terms avoid
     // implicit whole-array sensitivity expansion; all read fields are listed.
     always @(read_address or slot_data[read_slot] or slot_keep[read_slot] or slot_sop[read_slot] or slot_eop[read_slot] or slot_dllp[read_slot] or slot_sequence[read_slot] or slot_verdict[read_slot]) begin
       eligible=0;payload=0;
       if(read_address==read_slot && slot_keep[read_slot]!=0 && slot_verdict[read_slot]) begin
         eligible=1;
         payload={slot_data[read_slot],slot_keep[read_slot],slot_sop[read_slot],slot_eop[read_slot],slot_dllp[read_slot],slot_sequence[read_slot]};
       end
     end
     assign read_eligible_tree[RING_DWORDS+read_slot]=eligible;
     assign read_payload_tree[RING_DWORDS+read_slot]=payload;
   end
   for(read_node=1;read_node<RING_DWORDS;read_node=read_node+1) begin: branch
     assign read_eligible_tree[read_node]=read_eligible_tree[2*read_node]|read_eligible_tree[2*read_node+1];
     assign read_payload_tree[read_node]=read_eligible_tree[2*read_node]?
       read_payload_tree[2*read_node]:read_payload_tree[2*read_node+1];
   end
   assign read_payload_root[read_lane]=read_payload_tree[1];
   assign read_eligible_root[read_lane]=read_eligible_tree[1];
 end endgenerate
 integer r;
 always @* begin
   read_count=(committed>=4)?3'd4:committed;
   read_data=0;read_keep=0;read_sop=0;read_eop=0;read_dllp=0;read_sequence=0;
   read_any=0;
   for(r=0;r<4;r=r+1) begin
     if(r<read_count) begin
       if(read_eligible_root[r]) read_any=1;
       {read_data[r*32+:32],read_keep[r*4+:4],read_sop[r*4+:4],read_eop[r*4+:4],read_dllp[r*4+:4],read_sequence[r*12+:12]}=read_payload_root[r];
     end
   end
 end
 // END V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
assign empty=!read_any;
endmodule
module tb;reg[4:0]ptr=15,committed=4;wire gold_empty,gate_empty;wire[2:0]gold_count,gate_count;integer k,n=0;
wire[127:0]gold_data,gate_data;
wire[15:0]gold_keep,gate_keep;
wire[15:0]gold_sop,gate_sop;
wire[15:0]gold_eop,gate_eop;
wire[15:0]gold_dllp,gate_dllp;
wire[47:0]gold_sequence,gate_sequence;
old_read gold(.read_ptr(ptr),.committed(committed),.read_count(gold_count),.empty(gold_empty),.read_data(gold_data),.read_keep(gold_keep),.read_sop(gold_sop),.read_eop(gold_eop),.read_dllp(gold_dllp),.read_sequence(gold_sequence));
new_read gate(.read_ptr(ptr),.committed(committed),.read_count(gate_count),.empty(gate_empty),.read_data(gate_data),.read_keep(gate_keep),.read_sop(gate_sop),.read_eop(gate_eop),.read_dllp(gate_dllp),.read_sequence(gate_sequence));
task check;begin #1;if({gold_count,gold_empty,gold_data,gold_keep,gold_sop,gold_eop,gold_dllp,gold_sequence} !== {gate_count,gate_empty,gate_data,gate_keep,gate_sop,gate_eop,gate_dllp,gate_sequence})$fatal(1,"BALANCED_4STATE_MISMATCH case=%0d",n);n=n+1;end endtask
task seed;begin ptr=15;committed=4;for(k=0;k<16;k=k+1)begin
gold.slot_data[k]=32'h1;gate.slot_data[k]=gold.slot_data[k];
gold.slot_keep[k]=4'hf;gate.slot_keep[k]=gold.slot_keep[k];
gold.slot_sop[k]=4'h1;gate.slot_sop[k]=gold.slot_sop[k];
gold.slot_eop[k]=4'h1;gate.slot_eop[k]=gold.slot_eop[k];
gold.slot_dllp[k]=4'h1;gate.slot_dllp[k]=gold.slot_dllp[k];
gold.slot_sequence[k]=12'h1;gate.slot_sequence[k]=gold.slot_sequence[k];
gold.slot_verdict[k]=1;gate.slot_verdict[k]=1;end end endtask
initial begin
seed;check;
seed;gold.slot_data[15]=32'bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;gate.slot_data[15]=gold.slot_data[15];check;
seed;gold.slot_data[15]=32'bzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz;gate.slot_data[15]=gold.slot_data[15];check;
seed;gold.slot_keep[15]=4'b1xxx;gate.slot_keep[15]=gold.slot_keep[15];check;
seed;gold.slot_keep[15]=4'b1zzz;gate.slot_keep[15]=gold.slot_keep[15];check;
seed;gold.slot_sop[15]=4'bxxxx;gate.slot_sop[15]=gold.slot_sop[15];check;
seed;gold.slot_sop[15]=4'bzzzz;gate.slot_sop[15]=gold.slot_sop[15];check;
seed;gold.slot_eop[15]=4'bxxxx;gate.slot_eop[15]=gold.slot_eop[15];check;
seed;gold.slot_eop[15]=4'bzzzz;gate.slot_eop[15]=gold.slot_eop[15];check;
seed;gold.slot_dllp[15]=4'bxxxx;gate.slot_dllp[15]=gold.slot_dllp[15];check;
seed;gold.slot_dllp[15]=4'bzzzz;gate.slot_dllp[15]=gold.slot_dllp[15];check;
seed;gold.slot_sequence[15]=12'bxxxxxxxxxxxx;gate.slot_sequence[15]=gold.slot_sequence[15];check;
seed;gold.slot_sequence[15]=12'bzzzzzzzzzzzz;gate.slot_sequence[15]=gold.slot_sequence[15];check;
seed;gold.slot_data[0]=32'bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;gate.slot_data[0]=gold.slot_data[0];check;
seed;gold.slot_data[0]=32'bzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz;gate.slot_data[0]=gold.slot_data[0];check;
seed;gold.slot_keep[0]=4'b1xxx;gate.slot_keep[0]=gold.slot_keep[0];check;
seed;gold.slot_keep[0]=4'b1zzz;gate.slot_keep[0]=gold.slot_keep[0];check;
seed;gold.slot_sop[0]=4'bxxxx;gate.slot_sop[0]=gold.slot_sop[0];check;
seed;gold.slot_sop[0]=4'bzzzz;gate.slot_sop[0]=gold.slot_sop[0];check;
seed;gold.slot_eop[0]=4'bxxxx;gate.slot_eop[0]=gold.slot_eop[0];check;
seed;gold.slot_eop[0]=4'bzzzz;gate.slot_eop[0]=gold.slot_eop[0];check;
seed;gold.slot_dllp[0]=4'bxxxx;gate.slot_dllp[0]=gold.slot_dllp[0];check;
seed;gold.slot_dllp[0]=4'bzzzz;gate.slot_dllp[0]=gold.slot_dllp[0];check;
seed;gold.slot_sequence[0]=12'bxxxxxxxxxxxx;gate.slot_sequence[0]=gold.slot_sequence[0];check;
seed;gold.slot_sequence[0]=12'bzzzzzzzzzzzz;gate.slot_sequence[0]=gold.slot_sequence[0];check;
seed;gold.slot_data[1]=32'bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;gate.slot_data[1]=gold.slot_data[1];check;
seed;gold.slot_data[1]=32'bzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz;gate.slot_data[1]=gold.slot_data[1];check;
seed;gold.slot_keep[1]=4'b1xxx;gate.slot_keep[1]=gold.slot_keep[1];check;
seed;gold.slot_keep[1]=4'b1zzz;gate.slot_keep[1]=gold.slot_keep[1];check;
seed;gold.slot_sop[1]=4'bxxxx;gate.slot_sop[1]=gold.slot_sop[1];check;
seed;gold.slot_sop[1]=4'bzzzz;gate.slot_sop[1]=gold.slot_sop[1];check;
seed;gold.slot_eop[1]=4'bxxxx;gate.slot_eop[1]=gold.slot_eop[1];check;
seed;gold.slot_eop[1]=4'bzzzz;gate.slot_eop[1]=gold.slot_eop[1];check;
seed;gold.slot_dllp[1]=4'bxxxx;gate.slot_dllp[1]=gold.slot_dllp[1];check;
seed;gold.slot_dllp[1]=4'bzzzz;gate.slot_dllp[1]=gold.slot_dllp[1];check;
seed;gold.slot_sequence[1]=12'bxxxxxxxxxxxx;gate.slot_sequence[1]=gold.slot_sequence[1];check;
seed;gold.slot_sequence[1]=12'bzzzzzzzzzzzz;gate.slot_sequence[1]=gold.slot_sequence[1];check;
seed;gold.slot_data[2]=32'bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;gate.slot_data[2]=gold.slot_data[2];check;
seed;gold.slot_data[2]=32'bzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz;gate.slot_data[2]=gold.slot_data[2];check;
seed;gold.slot_keep[2]=4'b1xxx;gate.slot_keep[2]=gold.slot_keep[2];check;
seed;gold.slot_keep[2]=4'b1zzz;gate.slot_keep[2]=gold.slot_keep[2];check;
seed;gold.slot_sop[2]=4'bxxxx;gate.slot_sop[2]=gold.slot_sop[2];check;
seed;gold.slot_sop[2]=4'bzzzz;gate.slot_sop[2]=gold.slot_sop[2];check;
seed;gold.slot_eop[2]=4'bxxxx;gate.slot_eop[2]=gold.slot_eop[2];check;
seed;gold.slot_eop[2]=4'bzzzz;gate.slot_eop[2]=gold.slot_eop[2];check;
seed;gold.slot_dllp[2]=4'bxxxx;gate.slot_dllp[2]=gold.slot_dllp[2];check;
seed;gold.slot_dllp[2]=4'bzzzz;gate.slot_dllp[2]=gold.slot_dllp[2];check;
seed;gold.slot_sequence[2]=12'bxxxxxxxxxxxx;gate.slot_sequence[2]=gold.slot_sequence[2];check;
seed;gold.slot_sequence[2]=12'bzzzzzzzzzzzz;gate.slot_sequence[2]=gold.slot_sequence[2];check;
seed;ptr[0]=1'bx;check;
seed;committed[0]=1'bx;check;
seed;gold.slot_keep[15]=4'bxxxx;gate.slot_keep[15]=gold.slot_keep[15];check;
seed;gold.slot_verdict[15]=1'bx;gate.slot_verdict[15]=gold.slot_verdict[15];check;
seed;ptr[0]=1'bz;check;
seed;committed[0]=1'bz;check;
seed;gold.slot_keep[15]=4'bzzzz;gate.slot_keep[15]=gold.slot_keep[15];check;
seed;gold.slot_verdict[15]=1'bz;gate.slot_verdict[15]=gold.slot_verdict[15];check;
seed;gold.slot_data[8]=32'bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;gate.slot_data[8]=gold.slot_data[8];gold.slot_keep[8]=4'bxxxx;gate.slot_keep[8]=gold.slot_keep[8];gold.slot_sop[8]=4'bxxxx;gate.slot_sop[8]=gold.slot_sop[8];gold.slot_eop[8]=4'bxxxx;gate.slot_eop[8]=gold.slot_eop[8];gold.slot_dllp[8]=4'bxxxx;gate.slot_dllp[8]=gold.slot_dllp[8];gold.slot_sequence[8]=12'bxxxxxxxxxxxx;gate.slot_sequence[8]=gold.slot_sequence[8];gold.slot_verdict[8]=1'bx;gate.slot_verdict[8]=gold.slot_verdict[8];check;
seed;gold.slot_data[8]=32'bzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz;gate.slot_data[8]=gold.slot_data[8];gold.slot_keep[8]=4'bzzzz;gate.slot_keep[8]=gold.slot_keep[8];gold.slot_sop[8]=4'bzzzz;gate.slot_sop[8]=gold.slot_sop[8];gold.slot_eop[8]=4'bzzzz;gate.slot_eop[8]=gold.slot_eop[8];gold.slot_dllp[8]=4'bzzzz;gate.slot_dllp[8]=gold.slot_dllp[8];gold.slot_sequence[8]=12'bzzzzzzzzzzzz;gate.slot_sequence[8]=gold.slot_sequence[8];gold.slot_verdict[8]=1'bz;gate.slot_verdict[8]=gold.slot_verdict[8];check;
if(n!=59)$fatal(1,"BALANCED_4STATE_COVERAGE");$display("PASS_BALANCED_4STATE cases=%0d",n);$finish;end endmodule
