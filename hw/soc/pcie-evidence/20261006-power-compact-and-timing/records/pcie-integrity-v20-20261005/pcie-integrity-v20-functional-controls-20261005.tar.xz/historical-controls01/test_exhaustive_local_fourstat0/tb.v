module old_read(input[4:0]read_ptr,committed,output reg[2:0]read_count,output wire empty,output reg[127:0]read_data,output reg[15:0]read_keep,output reg[15:0]read_sop,output reg[15:0]read_eop,output reg[15:0]read_dllp,output reg[47:0]read_sequence);
localparam RING_DWORDS=16,PW=5;
reg slot_verdict[0:RING_DWORDS-1];
reg[31:0]slot_data[0:RING_DWORDS-1];
reg[3:0]slot_keep[0:RING_DWORDS-1];
reg[3:0]slot_sop[0:RING_DWORDS-1];
reg[3:0]slot_eop[0:RING_DWORDS-1];
reg[3:0]slot_dllp[0:RING_DWORDS-1];
reg[11:0]slot_sequence[0:RING_DWORDS-1]; // BEGIN V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
 // Procedural leaf flags are always known0/1, including unknown address,
 // keep or verdict. At most one physical slot matches each lane address.
 // Payload muxes preserve literal X/Z; a payload OR would convert Z to X.
 // A complete binary tree has log2(RING_DWORDS) selection levels in RTL;
 // emitted native depth must be measured separately, not inferred from RTL.
 // Static generate connections avoid dynamic procedural tree-array expansion.
 wire [59:0] read_payload_root[0:3];
 genvar read_lane,read_slot,read_node;
 generate for(read_lane=0;read_lane<4;read_lane=read_lane+1) begin: read_lane_tree
   wire [31:0] read_address=(read_ptr+read_lane)&(RING_DWORDS-1);
   wire [2*RING_DWORDS-1:0] read_eligible_tree;
   wire [59:0] read_payload_tree[0:2*RING_DWORDS-1];
   assign read_eligible_tree[0]=0;
   assign read_payload_tree[0]=0;
   for(read_slot=0;read_slot<RING_DWORDS;read_slot=read_slot+1) begin: leaf
     reg eligible;
     reg [59:0] payload;
     // Every leaf reads only this constant word. Explicit event terms avoid
     // implicit whole-array sensitivity expansion; all read fields are listed.
     always @(read_address or slot_data[read_slot] or slot_keep[read_slot] or slot_sop[read_slot] or slot_eop[read_slot] or slot_dllp[read_slot] or slot_sequence[read_slot] or slot_verdict[read_slot]) begin
       eligible=0;payload=0;
       if(read_address==read_slot && slot_keep[read_slot]!=0 && slot_verdict[read_slot]) begin
         eligible=1;
         payload={slot_data[read_slot],slot_keep[read_slot],slot_sop[read_slot],slot_eop[read_slot],slot_dllp[read_slot],slot_sequence[read_slot]};
       end
     end
     assign read_eligible_tree[RING_DWORDS+read_slot]=eligible;
     assign read_payload_tree[RING_DWORDS+read_slot]=payload;
   end
   for(read_node=1;read_node<RING_DWORDS;read_node=read_node+1) begin: branch
     assign read_eligible_tree[read_node]=read_eligible_tree[2*read_node]|read_eligible_tree[2*read_node+1];
     assign read_payload_tree[read_node]=read_eligible_tree[2*read_node]?
       read_payload_tree[2*read_node]:read_payload_tree[2*read_node+1];
   end
   assign read_payload_root[read_lane]=read_payload_tree[1];
 end endgenerate
 integer r;
 always @* begin
   read_count=(committed>=4)?3'd4:committed;
   read_data=0;read_keep=0;read_sop=0;read_eop=0;read_dllp=0;read_sequence=0;
   for(r=0;r<4;r=r+1) begin
     if(r<read_count) begin
       {read_data[r*32+:32],read_keep[r*4+:4],read_sop[r*4+:4],read_eop[r*4+:4],read_dllp[r*4+:4],read_sequence[r*12+:12]}=read_payload_root[r];
     end
   end
 end
 // END V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
assign empty=(read_keep==0);
endmodule
module new_read(input[4:0]read_ptr,committed,output reg[2:0]read_count,output wire empty,output reg[127:0]read_data,output reg[15:0]read_keep,output reg[15:0]read_sop,output reg[15:0]read_eop,output reg[15:0]read_dllp,output reg[47:0]read_sequence);
localparam RING_DWORDS=16,PW=5;
reg slot_verdict[0:RING_DWORDS-1];
reg[31:0]slot_data[0:RING_DWORDS-1];
reg[3:0]slot_keep[0:RING_DWORDS-1];
reg[3:0]slot_sop[0:RING_DWORDS-1];
reg[3:0]slot_eop[0:RING_DWORDS-1];
reg[3:0]slot_dllp[0:RING_DWORDS-1];
reg[11:0]slot_sequence[0:RING_DWORDS-1]; // BEGIN V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
 // Procedural leaf flags are always known0/1, including unknown address,
 // keep or verdict. At most one physical slot matches each lane address.
 // Payload muxes preserve literal X/Z; a payload OR would convert Z to X.
 // A complete binary tree has log2(RING_DWORDS) selection levels in RTL;
 // emitted native depth must be measured separately, not inferred from RTL.
 // Static generate connections avoid dynamic procedural tree-array expansion.
 wire [59:0] read_payload_root[0:3];
 // V20 known eligibility separates retire control from payload selection.
 wire [3:0] read_eligible_root;
 reg read_any;
 genvar read_lane,read_slot,read_node;
 generate for(read_lane=0;read_lane<4;read_lane=read_lane+1) begin: read_lane_tree
   wire [31:0] read_address=(read_ptr+read_lane)&(RING_DWORDS-1);
   wire [2*RING_DWORDS-1:0] read_eligible_tree;
   wire [59:0] read_payload_tree[0:2*RING_DWORDS-1];
   assign read_eligible_tree[0]=0;
   assign read_payload_tree[0]=0;
   for(read_slot=0;read_slot<RING_DWORDS;read_slot=read_slot+1) begin: leaf
     reg eligible;
     reg [59:0] payload;
     // Every leaf reads only this constant word. Explicit event terms avoid
     // implicit whole-array sensitivity expansion; all read fields are listed.
     always @(read_address or slot_data[read_slot] or slot_keep[read_slot] or slot_sop[read_slot] or slot_eop[read_slot] or slot_dllp[read_slot] or slot_sequence[read_slot] or slot_verdict[read_slot]) begin
       eligible=0;payload=0;
       if(read_address==read_slot && slot_keep[read_slot]!=0 && slot_verdict[read_slot]) begin
         eligible=1;
         payload={slot_data[read_slot],slot_keep[read_slot],slot_sop[read_slot],slot_eop[read_slot],slot_dllp[read_slot],slot_sequence[read_slot]};
       end
     end
     assign read_eligible_tree[RING_DWORDS+read_slot]=eligible;
     assign read_payload_tree[RING_DWORDS+read_slot]=payload;
   end
   for(read_node=1;read_node<RING_DWORDS;read_node=read_node+1) begin: branch
     assign read_eligible_tree[read_node]=read_eligible_tree[2*read_node]|read_eligible_tree[2*read_node+1];
     assign read_payload_tree[read_node]=read_eligible_tree[2*read_node]?
       read_payload_tree[2*read_node]:read_payload_tree[2*read_node+1];
   end
   assign read_payload_root[read_lane]=read_payload_tree[1];
   assign read_eligible_root[read_lane]=read_eligible_tree[1];
 end endgenerate
 integer r;
 always @* begin
   read_count=(committed>=4)?3'd4:committed;
   read_data=0;read_keep=0;read_sop=0;read_eop=0;read_dllp=0;read_sequence=0;
   read_any=0;
   for(r=0;r<4;r=r+1) begin
     if(r<read_count) begin
       if(read_eligible_root[r]) read_any=1;
       {read_data[r*32+:32],read_keep[r*4+:4],read_sop[r*4+:4],read_eop[r*4+:4],read_dllp[r*4+:4],read_sequence[r*12+:12]}=read_payload_root[r];
     end
   end
 end
 // END V17 STATIC BALANCED KNOWN-ELIGIBILITY PAYLOAD TREE
assign empty=!read_any;
endmodule
module tb;reg[4:0]ptr=15,committed=4;wire gold_empty,gate_empty;wire[2:0]gold_count,gate_count;integer k,v,lane,i,n=0,selected;
wire[127:0]gold_data,gate_data;
wire[15:0]gold_keep,gate_keep;
wire[15:0]gold_sop,gate_sop;
wire[15:0]gold_eop,gate_eop;
wire[15:0]gold_dllp,gate_dllp;
wire[47:0]gold_sequence,gate_sequence;
old_read gold(.read_ptr(ptr),.committed(committed),.read_count(gold_count),.empty(gold_empty),.read_data(gold_data),.read_keep(gold_keep),.read_sop(gold_sop),.read_eop(gold_eop),.read_dllp(gold_dllp),.read_sequence(gold_sequence));
new_read gate(.read_ptr(ptr),.committed(committed),.read_count(gate_count),.empty(gate_empty),.read_data(gate_data),.read_keep(gate_keep),.read_sop(gate_sop),.read_eop(gate_eop),.read_dllp(gate_dllp),.read_sequence(gate_sequence));
function[4:0] quad5;input integer value;integer bitno;begin
for(bitno=0;bitno<5;bitno=bitno+1)begin
case((value>>(2*bitno))&3)0:quad5[bitno]=0;1:quad5[bitno]=1;2:quad5[bitno]=1'bx;3:quad5[bitno]=1'bz;endcase
end end endfunction
task check;begin #1;if({gold_count,gold_empty,gold_data,gold_keep,gold_sop,gold_eop,gold_dllp,gold_sequence} !== {gate_count,gate_empty,gate_data,gate_keep,gate_sop,gate_eop,gate_dllp,gate_sequence})$fatal(1,"V20_4STATE_RETIRE_MISMATCH case=%0d",n);if(gold_empty!==1'b0&&gold_empty!==1'b1)$fatal(1,"V20_GOLD_EMPTY_UNKNOWN");n=n+1;end endtask
task seed;begin ptr=15;committed=4;for(i=0;i<16;i=i+1)begin
gold.slot_data[i]=i+1;gate.slot_data[i]=gold.slot_data[i];
gold.slot_keep[i]=0;gate.slot_keep[i]=gold.slot_keep[i];
gold.slot_sop[i]=i+1;gate.slot_sop[i]=gold.slot_sop[i];
gold.slot_eop[i]=i+1;gate.slot_eop[i]=gold.slot_eop[i];
gold.slot_dllp[i]=i+1;gate.slot_dllp[i]=gold.slot_dllp[i];
gold.slot_sequence[i]=i+1;gate.slot_sequence[i]=gold.slot_sequence[i];
gold.slot_verdict[i]=1;gate.slot_verdict[i]=1;end end endtask
initial begin
// Every four-state keep nibble and verdict value, one selected lane.
for(lane=0;lane<4;lane=lane+1)begin
 for(k=0;k<256;k=k+1)begin
  for(v=0;v<4;v=v+1)begin
   seed;selected=(15+lane)&15;
   gold.slot_keep[selected]=quad5(k);gate.slot_keep[selected]=gold.slot_keep[selected];
   gold.slot_verdict[selected]=quad5(v);gate.slot_verdict[selected]=gold.slot_verdict[selected];check;
  end
 end
end
if(n!=4096)$fatal(1,"V20_KEEP_VERDICT_COVERAGE");
// All 4^5 count words, preserving procedural unknown comparison masking.
for(lane=0;lane<4;lane=lane+1)begin
 for(k=0;k<1024;k=k+1)begin
  seed;selected=(15+lane)&15;
  gold.slot_keep[selected]=4'b1zzx;gate.slot_keep[selected]=gold.slot_keep[selected];
  committed=quad5(k);check;
 end
end
if(n!=8192)$fatal(1,"V20_COUNT_COVERAGE");
// All 4^5 pointer words, including unknown lower bits and wrap/epoch bit.
for(k=0;k<1024;k=k+1)begin
 seed;for(i=0;i<16;i=i+1)begin gold.slot_keep[i]=4'b1xz0;gate.slot_keep[i]=gold.slot_keep[i];end
 ptr=quad5(k);check;
end
if(n!=9216)$fatal(1,"V20_POINTER_COVERAGE");
$display("PASS_V20_EXHAUSTIVE_LOCAL_FOURSTATE cases9216 keep_verdict4096 count4096 pointer1024");$finish;end endmodule
