set_thread_count 1
define_corners slow typical fast
read_liberty -corner slow {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_slow_1p08V_125C.lib}
read_liberty -corner typical {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib}
read_liberty -corner fast {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_fast_1p32V_m40C.lib}
read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_stdcell.lef}
read_verilog {/dev/shm/nssoc-integrity-v21-balanced-import-01/mapped.v}
link_design soc_pcie_gen3_continuous_rx_integrity_v21
create_clock -name development_clock -period 4.0 [get_ports clk_i]
set data_inputs [get_ports {rst_ni flush_i stream_start_i stream_abort_i word_i* ready_i}]
set_input_delay -clock development_clock 0.2 $data_inputs
set_input_transition 0.1 $data_inputs
set_output_delay -clock development_clock 0.2 [all_outputs]
set_load 0.01 [all_outputs]
initialize_floorplan -die_area {0 0 2000 2000} -core_area {40 40 1960 1960} -site CoreSite
set_wire_rc -signal -layer Metal2
set_wire_rc -clock -layer Metal4
puts BASELINE_CELL_ONLY
report_worst_slack -max
report_worst_slack -min
report_check_types -max_slew -max_capacitance -violators
puts BASELINE_CELL_ONLY_slow_max
report_checks -corner slow -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts BASELINE_CELL_ONLY_slow_min
report_checks -corner slow -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts BASELINE_CELL_ONLY_typical_max
report_checks -corner typical -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts BASELINE_CELL_ONLY_typical_min
report_checks -corner typical -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts BASELINE_CELL_ONLY_fast_max
report_checks -corner fast -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts BASELINE_CELL_ONLY_fast_min
report_checks -corner fast -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
repair_design -pre_placement
puts PREPLACEMENT_REPAIRED
report_worst_slack -max
report_worst_slack -min
report_check_types -max_slew -max_capacitance -violators
puts PREPLACEMENT_REPAIRED_slow_max
report_checks -corner slow -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts PREPLACEMENT_REPAIRED_slow_min
report_checks -corner slow -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts PREPLACEMENT_REPAIRED_typical_max
report_checks -corner typical -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts PREPLACEMENT_REPAIRED_typical_min
report_checks -corner typical -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
puts PREPLACEMENT_REPAIRED_fast_max
report_checks -corner fast -path_delay max -group_path_count 1 -fields {slew cap fanout} -digits 6
puts PREPLACEMENT_REPAIRED_fast_min
report_checks -corner fast -path_delay min -group_path_count 1 -fields {slew cap fanout} -digits 6
write_verilog {/dev/shm/nssoc-integrity-v21-balanced-sta-01/rx/repaired.v}
write_db {/dev/shm/nssoc-integrity-v21-balanced-sta-01/rx/repaired.odb}
write_sdc {/dev/shm/nssoc-integrity-v21-balanced-sta-01/rx/screen.sdc}
