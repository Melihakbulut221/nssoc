puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-hbt-hybrid-final3-v2}
drc off
gds read {/dev/shm/nssoc-hbt-hybrid-final3-geometry/wires.gds}
load hbt_wires
select top cell
box values 19.125um 31.13um 19.125um 31.13um
label C_N1_T0 center metal1
port C_N1_T0 make 1
port C_N1_T0 class inout
port C_N1_T0 use signal
box values 20.875um 31.13um 20.875um 31.13um
label D_C_N1_T0 center metal1
port D_C_N1_T0 make 2
port D_C_N1_T0 class inout
port D_C_N1_T0 use signal
box values 19.075um 28.86um 19.075um 28.86um
label B_N1_T0 center metal1
port B_N1_T0 make 3
port B_N1_T0 class inout
port B_N1_T0 use signal
box values 20.925um 28.86um 20.925um 28.86um
label D_B_N1_T0 center metal1
port D_B_N1_T0 make 4
port D_B_N1_T0 class inout
port D_B_N1_T0 use signal
box values 58.870000000000005um 29.125um 58.870000000000005um 29.125um
label C_N1_T1 center metal1
port C_N1_T1 make 5
port C_N1_T1 class inout
port C_N1_T1 use signal
box values 58.870000000000005um 30.875um 58.870000000000005um 30.875um
label D_C_N1_T1 center metal1
port D_C_N1_T1 make 6
port D_C_N1_T1 class inout
port D_C_N1_T1 use signal
box values 61.14um 29.075um 61.14um 29.075um
label B_N1_T1 center metal1
port B_N1_T1 make 7
port B_N1_T1 class inout
port B_N1_T1 use signal
box values 61.14um 30.925um 61.14um 30.925um
label D_B_N1_T1 center metal1
port D_B_N1_T1 make 8
port D_B_N1_T1 class inout
port D_B_N1_T1 use signal
box values 99.125um 28.87um 99.125um 28.87um
label C_N1_T2 center metal1
port C_N1_T2 make 9
port C_N1_T2 class inout
port C_N1_T2 use signal
box values 100.875um 28.87um 100.875um 28.87um
label D_C_N1_T2 center metal1
port D_C_N1_T2 make 10
port D_C_N1_T2 class inout
port D_C_N1_T2 use signal
box values 99.075um 31.14um 99.075um 31.14um
label B_N1_T2 center metal1
port B_N1_T2 make 11
port B_N1_T2 class inout
port B_N1_T2 use signal
box values 100.925um 31.14um 100.925um 31.14um
label D_B_N1_T2 center metal1
port D_B_N1_T2 make 12
port D_B_N1_T2 class inout
port D_B_N1_T2 use signal
box values 141.13um 29.125um 141.13um 29.125um
label C_N1_T3 center metal1
port C_N1_T3 make 13
port C_N1_T3 class inout
port C_N1_T3 use signal
box values 141.13um 30.875um 141.13um 30.875um
label D_C_N1_T3 center metal1
port D_C_N1_T3 make 14
port D_C_N1_T3 class inout
port D_C_N1_T3 use signal
box values 138.86um 29.075um 138.86um 29.075um
label B_N1_T3 center metal1
port B_N1_T3 make 15
port B_N1_T3 class inout
port B_N1_T3 use signal
box values 138.86um 30.925um 138.86um 30.925um
label D_B_N1_T3 center metal1
port D_B_N1_T3 make 16
port D_B_N1_T3 class inout
port D_B_N1_T3 use signal
box values 179.125um 28.87um 179.125um 28.87um
label C_N1_T4 center metal1
port C_N1_T4 make 17
port C_N1_T4 class inout
port C_N1_T4 use signal
box values 180.875um 28.87um 180.875um 28.87um
label D_C_N1_T4 center metal1
port D_C_N1_T4 make 18
port D_C_N1_T4 class inout
port D_C_N1_T4 use signal
box values 179.07500000000002um 31.14um 179.07500000000002um 31.14um
label B_N1_T4 center metal1
port B_N1_T4 make 19
port B_N1_T4 class inout
port B_N1_T4 use signal
box values 180.925um 31.14um 180.925um 31.14um
label D_B_N1_T4 center metal1
port D_B_N1_T4 make 20
port D_B_N1_T4 class inout
port D_B_N1_T4 use signal
box values 221.13um 29.125um 221.13um 29.125um
label C_N1_T5 center metal1
port C_N1_T5 make 21
port C_N1_T5 class inout
port C_N1_T5 use signal
box values 221.13um 30.875um 221.13um 30.875um
label D_C_N1_T5 center metal1
port D_C_N1_T5 make 22
port D_C_N1_T5 class inout
port D_C_N1_T5 use signal
box values 218.86um 29.075um 218.86um 29.075um
label B_N1_T5 center metal1
port B_N1_T5 make 23
port B_N1_T5 class inout
port B_N1_T5 use signal
box values 218.86um 30.925um 218.86um 30.925um
label D_B_N1_T5 center metal1
port D_B_N1_T5 make 24
port D_B_N1_T5 class inout
port D_B_N1_T5 use signal
box values 259.125um 31.13um 259.125um 31.13um
label C_N1_T6 center metal1
port C_N1_T6 make 25
port C_N1_T6 class inout
port C_N1_T6 use signal
box values 260.875um 31.13um 260.875um 31.13um
label D_C_N1_T6 center metal1
port D_C_N1_T6 make 26
port D_C_N1_T6 class inout
port D_C_N1_T6 use signal
box values 259.075um 28.86um 259.075um 28.86um
label B_N1_T6 center metal1
port B_N1_T6 make 27
port B_N1_T6 class inout
port B_N1_T6 use signal
box values 260.925um 28.86um 260.925um 28.86um
label D_B_N1_T6 center metal1
port D_B_N1_T6 make 28
port D_B_N1_T6 class inout
port D_B_N1_T6 use signal
box values 298.87um 29.125um 298.87um 29.125um
label C_N1_T7 center metal1
port C_N1_T7 make 29
port C_N1_T7 class inout
port C_N1_T7 use signal
box values 298.87um 30.875um 298.87um 30.875um
label D_C_N1_T7 center metal1
port D_C_N1_T7 make 30
port D_C_N1_T7 class inout
port D_C_N1_T7 use signal
box values 301.14um 29.075um 301.14um 29.075um
label B_N1_T7 center metal1
port B_N1_T7 make 31
port B_N1_T7 class inout
port B_N1_T7 use signal
box values 301.14um 30.925um 301.14um 30.925um
label D_B_N1_T7 center metal1
port D_B_N1_T7 make 32
port D_B_N1_T7 class inout
port D_B_N1_T7 use signal
box values 19.125um 71.24um 19.125um 71.24um
label C_N2_T0 center metal1
port C_N2_T0 make 33
port C_N2_T0 class inout
port C_N2_T0 use signal
box values 22.725um 71.24um 22.725um 71.24um
label D_C_N2_T0 center metal1
port D_C_N2_T0 make 34
port D_C_N2_T0 class inout
port D_C_N2_T0 use signal
box values 19.075um 68.86um 19.075um 68.86um
label B_N2_T0 center metal1
port B_N2_T0 make 35
port B_N2_T0 class inout
port B_N2_T0 use signal
box values 22.775000000000002um 68.86um 22.775000000000002um 68.86um
label D_B_N2_T0 center metal1
port D_B_N2_T0 make 36
port D_B_N2_T0 class inout
port D_B_N2_T0 use signal
box values 58.76um 69.125um 58.76um 69.125um
label C_N2_T1 center metal1
port C_N2_T1 make 37
port C_N2_T1 class inout
port C_N2_T1 use signal
box values 58.76um 72.72500000000001um 58.76um 72.72500000000001um
label D_C_N2_T1 center metal1
port D_C_N2_T1 make 38
port D_C_N2_T1 class inout
port D_C_N2_T1 use signal
box values 61.14um 69.075um 61.14um 69.075um
label B_N2_T1 center metal1
port B_N2_T1 make 39
port B_N2_T1 class inout
port B_N2_T1 use signal
box values 61.14um 72.775um 61.14um 72.775um
label D_B_N2_T1 center metal1
port D_B_N2_T1 make 40
port D_B_N2_T1 class inout
port D_B_N2_T1 use signal
box values 97.275um 68.76um 97.275um 68.76um
label C_N2_T2 center metal1
port C_N2_T2 make 41
port C_N2_T2 class inout
port C_N2_T2 use signal
box values 100.875um 68.76um 100.875um 68.76um
label D_C_N2_T2 center metal1
port D_C_N2_T2 make 42
port D_C_N2_T2 class inout
port D_C_N2_T2 use signal
box values 97.22500000000001um 71.14um 97.22500000000001um 71.14um
label B_N2_T2 center metal1
port B_N2_T2 make 43
port B_N2_T2 class inout
port B_N2_T2 use signal
box values 100.925um 71.14um 100.925um 71.14um
label D_B_N2_T2 center metal1
port D_B_N2_T2 make 44
port D_B_N2_T2 class inout
port D_B_N2_T2 use signal
box values 141.24um 67.275um 141.24um 67.275um
label C_N2_T3 center metal1
port C_N2_T3 make 45
port C_N2_T3 class inout
port C_N2_T3 use signal
box values 141.24um 70.875um 141.24um 70.875um
label D_C_N2_T3 center metal1
port D_C_N2_T3 make 46
port D_C_N2_T3 class inout
port D_C_N2_T3 use signal
box values 138.86um 67.225um 138.86um 67.225um
label B_N2_T3 center metal1
port B_N2_T3 make 47
port B_N2_T3 class inout
port B_N2_T3 use signal
box values 138.86um 70.925um 138.86um 70.925um
label D_B_N2_T3 center metal1
port D_B_N2_T3 make 48
port D_B_N2_T3 class inout
port D_B_N2_T3 use signal
box values 179.125um 68.76um 179.125um 68.76um
label C_N2_T4 center metal1
port C_N2_T4 make 49
port C_N2_T4 class inout
port C_N2_T4 use signal
box values 182.725um 68.76um 182.725um 68.76um
label D_C_N2_T4 center metal1
port D_C_N2_T4 make 50
port D_C_N2_T4 class inout
port D_C_N2_T4 use signal
box values 179.07500000000002um 71.14um 179.07500000000002um 71.14um
label B_N2_T4 center metal1
port B_N2_T4 make 51
port B_N2_T4 class inout
port B_N2_T4 use signal
box values 182.775um 71.14um 182.775um 71.14um
label D_B_N2_T4 center metal1
port D_B_N2_T4 make 52
port D_B_N2_T4 class inout
port D_B_N2_T4 use signal
box values 221.24um 69.125um 221.24um 69.125um
label C_N2_T5 center metal1
port C_N2_T5 make 53
port C_N2_T5 class inout
port C_N2_T5 use signal
box values 221.24um 72.72500000000001um 221.24um 72.72500000000001um
label D_C_N2_T5 center metal1
port D_C_N2_T5 make 54
port D_C_N2_T5 class inout
port D_C_N2_T5 use signal
box values 218.86um 69.075um 218.86um 69.075um
label B_N2_T5 center metal1
port B_N2_T5 make 55
port B_N2_T5 class inout
port B_N2_T5 use signal
box values 218.86um 72.775um 218.86um 72.775um
label D_B_N2_T5 center metal1
port D_B_N2_T5 make 56
port D_B_N2_T5 class inout
port D_B_N2_T5 use signal
box values 257.275um 71.24um 257.275um 71.24um
label C_N2_T6 center metal1
port C_N2_T6 make 57
port C_N2_T6 class inout
port C_N2_T6 use signal
box values 260.875um 71.24um 260.875um 71.24um
label D_C_N2_T6 center metal1
port D_C_N2_T6 make 58
port D_C_N2_T6 class inout
port D_C_N2_T6 use signal
box values 257.225um 68.86um 257.225um 68.86um
label B_N2_T6 center metal1
port B_N2_T6 make 59
port B_N2_T6 class inout
port B_N2_T6 use signal
box values 260.925um 68.86um 260.925um 68.86um
label D_B_N2_T6 center metal1
port D_B_N2_T6 make 60
port D_B_N2_T6 class inout
port D_B_N2_T6 use signal
box values 298.76um 67.275um 298.76um 67.275um
label C_N2_T7 center metal1
port C_N2_T7 make 61
port C_N2_T7 class inout
port C_N2_T7 use signal
box values 298.76um 70.875um 298.76um 70.875um
label D_C_N2_T7 center metal1
port D_C_N2_T7 make 62
port D_C_N2_T7 class inout
port D_C_N2_T7 use signal
box values 301.14um 67.225um 301.14um 67.225um
label B_N2_T7 center metal1
port B_N2_T7 make 63
port B_N2_T7 class inout
port B_N2_T7 use signal
box values 301.14um 70.925um 301.14um 70.925um
label D_B_N2_T7 center metal1
port D_B_N2_T7 make 64
port D_B_N2_T7 class inout
port D_B_N2_T7 use signal
box values 19.125um 111.24000000000001um 19.125um 111.24000000000001um
label C_N4_T0 center metal1
port C_N4_T0 make 65
port C_N4_T0 class inout
port C_N4_T0 use signal
box values 26.425um 111.24000000000001um 26.425um 111.24000000000001um
label D_C_N4_T0 center metal1
port D_C_N4_T0 make 66
port D_C_N4_T0 class inout
port D_C_N4_T0 use signal
box values 19.075um 108.86um 19.075um 108.86um
label B_N4_T0 center metal1
port B_N4_T0 make 67
port B_N4_T0 class inout
port B_N4_T0 use signal
box values 26.475um 108.86um 26.475um 108.86um
label D_B_N4_T0 center metal1
port D_B_N4_T0 make 68
port D_B_N4_T0 class inout
port D_B_N4_T0 use signal
box values 58.76um 109.125um 58.76um 109.125um
label C_N4_T1 center metal1
port C_N4_T1 make 69
port C_N4_T1 class inout
port C_N4_T1 use signal
box values 58.76um 116.425um 58.76um 116.425um
label D_C_N4_T1 center metal1
port D_C_N4_T1 make 70
port D_C_N4_T1 class inout
port D_C_N4_T1 use signal
box values 61.14um 109.075um 61.14um 109.075um
label B_N4_T1 center metal1
port B_N4_T1 make 71
port B_N4_T1 class inout
port B_N4_T1 use signal
box values 61.14um 116.47500000000001um 61.14um 116.47500000000001um
label D_B_N4_T1 center metal1
port D_B_N4_T1 make 72
port D_B_N4_T1 class inout
port D_B_N4_T1 use signal
box values 93.575um 108.76um 93.575um 108.76um
label C_N4_T2 center metal1
port C_N4_T2 make 73
port C_N4_T2 class inout
port C_N4_T2 use signal
box values 100.875um 108.76um 100.875um 108.76um
label D_C_N4_T2 center metal1
port D_C_N4_T2 make 74
port D_C_N4_T2 class inout
port D_C_N4_T2 use signal
box values 93.525um 111.14um 93.525um 111.14um
label B_N4_T2 center metal1
port B_N4_T2 make 75
port B_N4_T2 class inout
port B_N4_T2 use signal
box values 100.925um 111.14um 100.925um 111.14um
label D_B_N4_T2 center metal1
port D_B_N4_T2 make 76
port D_B_N4_T2 class inout
port D_B_N4_T2 use signal
box values 141.24um 103.575um 141.24um 103.575um
label C_N4_T3 center metal1
port C_N4_T3 make 77
port C_N4_T3 class inout
port C_N4_T3 use signal
box values 141.24um 110.875um 141.24um 110.875um
label D_C_N4_T3 center metal1
port D_C_N4_T3 make 78
port D_C_N4_T3 class inout
port D_C_N4_T3 use signal
box values 138.86um 103.525um 138.86um 103.525um
label B_N4_T3 center metal1
port B_N4_T3 make 79
port B_N4_T3 class inout
port B_N4_T3 use signal
box values 138.86um 110.925um 138.86um 110.925um
label D_B_N4_T3 center metal1
port D_B_N4_T3 make 80
port D_B_N4_T3 class inout
port D_B_N4_T3 use signal
box values 179.125um 108.76um 179.125um 108.76um
label C_N4_T4 center metal1
port C_N4_T4 make 81
port C_N4_T4 class inout
port C_N4_T4 use signal
box values 186.425um 108.76um 186.425um 108.76um
label D_C_N4_T4 center metal1
port D_C_N4_T4 make 82
port D_C_N4_T4 class inout
port D_C_N4_T4 use signal
box values 179.07500000000002um 111.14um 179.07500000000002um 111.14um
label B_N4_T4 center metal1
port B_N4_T4 make 83
port B_N4_T4 class inout
port B_N4_T4 use signal
box values 186.475um 111.14um 186.475um 111.14um
label D_B_N4_T4 center metal1
port D_B_N4_T4 make 84
port D_B_N4_T4 class inout
port D_B_N4_T4 use signal
box values 221.24um 109.125um 221.24um 109.125um
label C_N4_T5 center metal1
port C_N4_T5 make 85
port C_N4_T5 class inout
port C_N4_T5 use signal
box values 221.24um 116.425um 221.24um 116.425um
label D_C_N4_T5 center metal1
port D_C_N4_T5 make 86
port D_C_N4_T5 class inout
port D_C_N4_T5 use signal
box values 218.86um 109.075um 218.86um 109.075um
label B_N4_T5 center metal1
port B_N4_T5 make 87
port B_N4_T5 class inout
port B_N4_T5 use signal
box values 218.86um 116.47500000000001um 218.86um 116.47500000000001um
label D_B_N4_T5 center metal1
port D_B_N4_T5 make 88
port D_B_N4_T5 class inout
port D_B_N4_T5 use signal
box values 253.57500000000002um 111.24000000000001um 253.57500000000002um 111.24000000000001um
label C_N4_T6 center metal1
port C_N4_T6 make 89
port C_N4_T6 class inout
port C_N4_T6 use signal
box values 260.875um 111.24000000000001um 260.875um 111.24000000000001um
label D_C_N4_T6 center metal1
port D_C_N4_T6 make 90
port D_C_N4_T6 class inout
port D_C_N4_T6 use signal
box values 253.525um 108.86um 253.525um 108.86um
label B_N4_T6 center metal1
port B_N4_T6 make 91
port B_N4_T6 class inout
port B_N4_T6 use signal
box values 260.925um 108.86um 260.925um 108.86um
label D_B_N4_T6 center metal1
port D_B_N4_T6 make 92
port D_B_N4_T6 class inout
port D_B_N4_T6 use signal
box values 298.76um 103.575um 298.76um 103.575um
label C_N4_T7 center metal1
port C_N4_T7 make 93
port C_N4_T7 class inout
port C_N4_T7 use signal
box values 298.76um 110.875um 298.76um 110.875um
label D_C_N4_T7 center metal1
port D_C_N4_T7 make 94
port D_C_N4_T7 class inout
port D_C_N4_T7 use signal
box values 301.14um 103.525um 301.14um 103.525um
label B_N4_T7 center metal1
port B_N4_T7 make 95
port B_N4_T7 class inout
port B_N4_T7 use signal
box values 301.14um 110.925um 301.14um 110.925um
label D_B_N4_T7 center metal1
port D_B_N4_T7 make 96
port D_B_N4_T7 class inout
port D_B_N4_T7 use signal
box values -1.0um 0.25um -1.0um 0.25um
label SUB center metal1
port SUB make 97
port SUB class inout
port SUB use signal
box values -1.0um 1.75um -1.0um 1.75um
label D_SUB center metal1
port D_SUB make 98
port D_SUB class inout
port D_SUB use signal
box values 20.0um 29.265um 20.0um 29.265um
label E_N1_T0 center metal2
port E_N1_T0 make 99
port E_N1_T0 class inout
port E_N1_T0 use signal
box values 20.0um 30.72um 20.0um 30.72um
label D_E_N1_T0 center metal2
port D_E_N1_T0 make 100
port D_E_N1_T0 class inout
port D_E_N1_T0 use signal
box values 59.28um 30.0um 59.28um 30.0um
label E_N1_T1 center metal2
port E_N1_T1 make 101
port E_N1_T1 class inout
port E_N1_T1 use signal
box values 60.735um 30.0um 60.735um 30.0um
label D_E_N1_T1 center metal2
port D_E_N1_T1 make 102
port D_E_N1_T1 class inout
port D_E_N1_T1 use signal
box values 100.0um 29.28um 100.0um 29.28um
label E_N1_T2 center metal2
port E_N1_T2 make 103
port E_N1_T2 class inout
port E_N1_T2 use signal
box values 100.0um 30.735um 100.0um 30.735um
label D_E_N1_T2 center metal2
port D_E_N1_T2 make 104
port D_E_N1_T2 class inout
port D_E_N1_T2 use signal
box values 139.26500000000001um 30.0um 139.26500000000001um 30.0um
label E_N1_T3 center metal2
port E_N1_T3 make 105
port E_N1_T3 class inout
port E_N1_T3 use signal
box values 140.72um 30.0um 140.72um 30.0um
label D_E_N1_T3 center metal2
port D_E_N1_T3 make 106
port D_E_N1_T3 class inout
port D_E_N1_T3 use signal
box values 180.0um 29.28um 180.0um 29.28um
label E_N1_T4 center metal2
port E_N1_T4 make 107
port E_N1_T4 class inout
port E_N1_T4 use signal
box values 180.0um 30.735um 180.0um 30.735um
label D_E_N1_T4 center metal2
port D_E_N1_T4 make 108
port D_E_N1_T4 class inout
port D_E_N1_T4 use signal
box values 219.26500000000001um 30.0um 219.26500000000001um 30.0um
label E_N1_T5 center metal2
port E_N1_T5 make 109
port E_N1_T5 class inout
port E_N1_T5 use signal
box values 220.72um 30.0um 220.72um 30.0um
label D_E_N1_T5 center metal2
port D_E_N1_T5 make 110
port D_E_N1_T5 class inout
port D_E_N1_T5 use signal
box values 260.0um 29.265um 260.0um 29.265um
label E_N1_T6 center metal2
port E_N1_T6 make 111
port E_N1_T6 class inout
port E_N1_T6 use signal
box values 260.0um 30.72um 260.0um 30.72um
label D_E_N1_T6 center metal2
port D_E_N1_T6 make 112
port D_E_N1_T6 class inout
port D_E_N1_T6 use signal
box values 299.28000000000003um 30.0um 299.28000000000003um 30.0um
label E_N1_T7 center metal2
port E_N1_T7 make 113
port E_N1_T7 class inout
port E_N1_T7 use signal
box values 300.735um 30.0um 300.735um 30.0um
label D_E_N1_T7 center metal2
port D_E_N1_T7 make 114
port D_E_N1_T7 class inout
port D_E_N1_T7 use signal
box values 19.305um 69.992um 19.305um 69.992um
label E_N2_T0 center metal2
port E_N2_T0 make 115
port E_N2_T0 class inout
port E_N2_T0 use signal
box values 22.545um 69.992um 22.545um 69.992um
label D_E_N2_T0 center metal2
port D_E_N2_T0 make 116
port D_E_N2_T0 class inout
port D_E_N2_T0 use signal
box values 60.007um 69.305um 60.007um 69.305um
label E_N2_T1 center metal2
port E_N2_T1 make 117
port E_N2_T1 class inout
port E_N2_T1 use signal
box values 60.007um 72.545um 60.007um 72.545um
label D_E_N2_T1 center metal2
port D_E_N2_T1 make 118
port D_E_N2_T1 class inout
port D_E_N2_T1 use signal
box values 97.455um 70.007um 97.455um 70.007um
label E_N2_T2 center metal2
port E_N2_T2 make 119
port E_N2_T2 class inout
port E_N2_T2 use signal
box values 100.69500000000001um 70.007um 100.69500000000001um 70.007um
label D_E_N2_T2 center metal2
port D_E_N2_T2 make 120
port D_E_N2_T2 class inout
port D_E_N2_T2 use signal
box values 139.992um 67.455um 139.992um 67.455um
label E_N2_T3 center metal2
port E_N2_T3 make 121
port E_N2_T3 class inout
port E_N2_T3 use signal
box values 139.992um 70.69500000000001um 139.992um 70.69500000000001um
label D_E_N2_T3 center metal2
port D_E_N2_T3 make 122
port D_E_N2_T3 class inout
port D_E_N2_T3 use signal
box values 179.305um 70.007um 179.305um 70.007um
label E_N2_T4 center metal2
port E_N2_T4 make 123
port E_N2_T4 class inout
port E_N2_T4 use signal
box values 182.54500000000002um 70.007um 182.54500000000002um 70.007um
label D_E_N2_T4 center metal2
port D_E_N2_T4 make 124
port D_E_N2_T4 class inout
port D_E_N2_T4 use signal
box values 219.99200000000002um 69.305um 219.99200000000002um 69.305um
label E_N2_T5 center metal2
port E_N2_T5 make 125
port E_N2_T5 class inout
port E_N2_T5 use signal
box values 219.99200000000002um 72.545um 219.99200000000002um 72.545um
label D_E_N2_T5 center metal2
port D_E_N2_T5 make 126
port D_E_N2_T5 class inout
port D_E_N2_T5 use signal
box values 257.455um 69.992um 257.455um 69.992um
label E_N2_T6 center metal2
port E_N2_T6 make 127
port E_N2_T6 class inout
port E_N2_T6 use signal
box values 260.695um 69.992um 260.695um 69.992um
label D_E_N2_T6 center metal2
port D_E_N2_T6 make 128
port D_E_N2_T6 class inout
port D_E_N2_T6 use signal
box values 300.007um 67.455um 300.007um 67.455um
label E_N2_T7 center metal2
port E_N2_T7 make 129
port E_N2_T7 class inout
port E_N2_T7 use signal
box values 300.007um 70.69500000000001um 300.007um 70.69500000000001um
label D_E_N2_T7 center metal2
port D_E_N2_T7 make 130
port D_E_N2_T7 class inout
port D_E_N2_T7 use signal
box values 19.305um 109.992um 19.305um 109.992um
label E_N4_T0 center metal2
port E_N4_T0 make 131
port E_N4_T0 class inout
port E_N4_T0 use signal
box values 26.245um 109.992um 26.245um 109.992um
label D_E_N4_T0 center metal2
port D_E_N4_T0 make 132
port D_E_N4_T0 class inout
port D_E_N4_T0 use signal
box values 60.007um 109.305um 60.007um 109.305um
label E_N4_T1 center metal2
port E_N4_T1 make 133
port E_N4_T1 class inout
port E_N4_T1 use signal
box values 60.007um 116.245um 60.007um 116.245um
label D_E_N4_T1 center metal2
port D_E_N4_T1 make 134
port D_E_N4_T1 class inout
port D_E_N4_T1 use signal
box values 93.755um 110.007um 93.755um 110.007um
label E_N4_T2 center metal2
port E_N4_T2 make 135
port E_N4_T2 class inout
port E_N4_T2 use signal
box values 100.69500000000001um 110.007um 100.69500000000001um 110.007um
label D_E_N4_T2 center metal2
port D_E_N4_T2 make 136
port D_E_N4_T2 class inout
port D_E_N4_T2 use signal
box values 139.992um 103.755um 139.992um 103.755um
label E_N4_T3 center metal2
port E_N4_T3 make 137
port E_N4_T3 class inout
port E_N4_T3 use signal
box values 139.992um 110.69500000000001um 139.992um 110.69500000000001um
label D_E_N4_T3 center metal2
port D_E_N4_T3 make 138
port D_E_N4_T3 class inout
port D_E_N4_T3 use signal
box values 179.305um 110.007um 179.305um 110.007um
label E_N4_T4 center metal2
port E_N4_T4 make 139
port E_N4_T4 class inout
port E_N4_T4 use signal
box values 186.245um 110.007um 186.245um 110.007um
label D_E_N4_T4 center metal2
port D_E_N4_T4 make 140
port D_E_N4_T4 class inout
port D_E_N4_T4 use signal
box values 219.99200000000002um 109.305um 219.99200000000002um 109.305um
label E_N4_T5 center metal2
port E_N4_T5 make 141
port E_N4_T5 class inout
port E_N4_T5 use signal
box values 219.99200000000002um 116.245um 219.99200000000002um 116.245um
label D_E_N4_T5 center metal2
port D_E_N4_T5 make 142
port D_E_N4_T5 class inout
port D_E_N4_T5 use signal
box values 253.755um 109.992um 253.755um 109.992um
label E_N4_T6 center metal2
port E_N4_T6 make 143
port E_N4_T6 class inout
port E_N4_T6 use signal
box values 260.695um 109.992um 260.695um 109.992um
label D_E_N4_T6 center metal2
port D_E_N4_T6 make 144
port D_E_N4_T6 class inout
port D_E_N4_T6 use signal
box values 300.007um 103.755um 300.007um 103.755um
label E_N4_T7 center metal2
port E_N4_T7 make 145
port E_N4_T7 class inout
port E_N4_T7 use signal
box values 300.007um 110.69500000000001um 300.007um 110.69500000000001um
label D_E_N4_T7 center metal2
port D_E_N4_T7 make 146
port D_E_N4_T7 class inout
port D_E_N4_T7 use signal
save hbt_wires
extract style ngspice()
extract all
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o wires.spice
quit -noprompt
