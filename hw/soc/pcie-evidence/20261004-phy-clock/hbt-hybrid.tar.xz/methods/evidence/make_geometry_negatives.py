# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import json,hashlib
from pathlib import Path
import klayout.db as d
V=Path('/dev/shm/nssoc-magic-hbt-axis-01');O=Path('/dev/shm/nssoc-hbt-hybrid-geometry-negatives');O.mkdir();r=json.loads((V/'result.json').read_text());summary={}
for fault in ['emitter_via_open_N2_T1','base_collector_short_N4_T6','missing_finger_N4_T7','emitter_width_N1_T1','missing_tap_contact']:
 l=d.Layout();l.read(str(V/'fixture.gds'));t=l.cell('nssoc_hbt_axis');t.flatten(True)
 if fault.startswith('base_collector'):
  layer=8;a=d.DBox(*r['ports']['C_N4_T6']['box']).to_itype(l.dbu).center();b=d.DBox(*r['ports']['B_N4_T6']['box']).to_itype(l.dbu).center();before=d.Region(t.shapes(l.layer(layer,0)));after=before+d.Region(d.Path([a,b],100));removed=None
 elif fault.startswith('emitter_via'):
  layer=19;box=d.DBox(*r['ports']['E_N2_T1']['box']).to_itype(l.dbu).enlarged(300);before=d.Region(t.shapes(l.layer(layer,0)));after=before-d.Region(box);removed=str(box)
 elif fault.startswith('missing_tap'):
  layer=6;box=d.DBox(*r['ports']['SUB']['box']).to_itype(l.dbu).enlarged(100);before=d.Region(t.shapes(l.layer(layer,0)));after=before-d.Region(box);removed=str(box)
 else:
  layer=33;tag='N4_T7' if fault.startswith('missing_finger') else 'N1_T1';box=d.DBox(*r['ports']['E_'+tag]['box']).to_itype(l.dbu).enlarged(300);before=d.Region(t.shapes(l.layer(layer,0)));hits=list(before.interacting(d.Region(box)).each());assert hits
  chosen=hits[0];after=before-d.Region(chosen);removed=chosen.to_s()
  if fault.startswith('emitter_width'):
   b=chosen.bbox();b=d.Box(b.left+20,b.bottom,b.right-20,b.top) if b.width()<b.height() else d.Box(b.left,b.bottom+20,b.right,b.top-20);after+=d.Region(b)
 delta=before^after;assert not delta.is_empty();t.shapes(l.layer(layer,0)).clear();t.shapes(l.layer(layer,0)).insert(after);p=O/(fault+'.gds');l.write(str(p));summary[fault]=dict(layer=layer,delta_area_dbu2=delta.area(),removed=removed,gds_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(O/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(len(summary))
