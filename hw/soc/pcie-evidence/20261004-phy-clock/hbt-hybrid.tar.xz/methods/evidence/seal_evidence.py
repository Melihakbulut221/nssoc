# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,tarfile,io,difflib,sys
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-hbt-contract-v2-20261004';sys.path.insert(0,str(R/'scripts'));import check_magic_hbt_hybrid_v2 as h;import patch_magic_hbt_contract_v2 as patch
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
SOURCES=[R/'scripts/patch_magic_hbt_contract_v2.py',R/'scripts/check_magic_hbt_hybrid_v2.py',R/'sw/tests/test_magic_hbt_contract_v2.py']
G=Path('/dev/shm/nssoc-hbt-hybrid-final3-geometry');A=Path('/dev/shm/nssoc-hbt-hybrid-final3-audit');N=Path('/dev/shm/nssoc-hbt-hybrid-geometry-negatives3')
def stats(folder):
 path=Path(folder)/'hbt.spice';rows=[s.split() for s in path.read_text().splitlines() if s.startswith('X')];matched=[];wrong=[];nx=[]
 for row in rows:
  tag=row[1].removeprefix('C_');expected=['C_'+tag,'B_'+tag,'E_'+tag]
  (matched if row[1:4]==expected else wrong).append(tag)
  if tag.startswith(('N2_','N4_')) and not any(t.startswith(('Nx=','m=')) for t in row[6:]):nx.append(tag)
 return dict(hbts=len(rows),correct_CBE=matched,wrong_CBE=wrong,nonunity_missing_Nx=nx,source=h.pin(path))
comparison={name:stats(path) for name,path in [('axis_only','/dev/shm/nssoc-magic-hbt-axis-overlay-01/axis-overlay-explicit-ports'),('contact_only','/dev/shm/nssoc-hbt-contact-probe-04/native'),('contact_and_per_tile_fix','/dev/shm/nssoc-hbt-contact-probe-06/native')]}
assert [x['hbts'] for x in comparison.values()]==[18,18,24];assert [len(x['wrong_CBE']) for x in comparison.values()]==[18,0,0];assert len(comparison['contact_and_per_tile_fix']['nonunity_missing_Nx'])==16
roots={
 'fixture':Path('/dev/shm/nssoc-magic-hbt-axis-01'),
 'native-lvs':Path('/dev/shm/nssoc-magic-hbt-axis-native-01/klayout'),
 'final-geometry':G,'final-v2':Path('/dev/shm/nssoc-hbt-hybrid-final3-v2'),'final-baseline':Path('/dev/shm/nssoc-hbt-hybrid-final3-baseline'),'final-audit':A,'geometry-controls':N,
 'first-flat-controls':Path('/dev/shm/nssoc-hbt-hybrid-geometry-negatives'),
 'failed-anchors':Path('/dev/shm/nssoc-hbt-wire-native-03'),
 'contact-only':Path('/dev/shm/nssoc-hbt-contact-probe-04/native'),'contact-and-search-fix':Path('/dev/shm/nssoc-hbt-contact-probe-06/native'),
 'terminal-instrumentation':Path('/dev/shm/nssoc-hbt-contact-probe-05/native'),
}
members={}
for label,folder in roots.items():
 for p in folder.rglob('*'):
  if p.is_file():members[label+'/'+str(p.relative_to(folder))]=p.read_bytes()
for p in SOURCES:members['methods/'+str(p.relative_to(R))]=p.read_bytes()
for p in B.glob('*.py'):members['methods/evidence/'+p.name]=p.read_bytes()
for number in [1,2]:
 d=Path(f'/dev/shm/nssoc-hbt-terminal-build-0{number}')
 for name in ['result.json','build0.log','build1.log']:members[f'private-build-{number}/'+name]=(d/name).read_bytes()
 before=(d/'ExtBasic.c.before').read_text();after=(d/'source/extract/ExtBasic.c').read_text();members[f'private-build-{number}/ExtBasic.c.patch']=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='upstream-pinned/ExtBasic.c',tofile='private/ExtBasic.c')).encode()
licensepath=R/'hw/soc/tools/magic-groundcap-combined-8.3.623/LICENSE'
notices='The two private Magic builds modify only the exact ExtBasic.c input pinned in their build receipts. No compiled runtime or upstream implementation source is distributed in this capsule. Patch fragments retain the following upstream notice.\n\n'+licensepath.read_text()+'\nIHP native PCell and LVS code are used from the pinned local PDK; full upstream model/implementation files are not redistributed here. Their source hashes and retrieval paths are in the native fixture input inventory. Project scripts carry Apache-2.0 headers; generated hardware views retain the circuit/project hardware licensing scope.\n'
members['UPSTREAM-NOTICES.txt']=notices.encode()
manifest={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(members.items())}
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode();archive=B/'hbt-hybrid-native-controls.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tf:
 for name,data in sorted(members.items()):
  inf=tarfile.TarInfo(name);inf.size=len(data);inf.mtime=0;tf.addfile(inf,io.BytesIO(data))
with tarfile.open(archive,'r:xz') as tf:
 assert len(tf.getmembers())==len(members)
 for inf in tf.getmembers():assert tf.extractfile(inf).read()==members[inf.name]
controls=json.loads((N/'native-results.json').read_text());positive=json.loads((A/'result.json').read_text())
record=dict(status='PASS_ISOLATED_DEVICE_WIRE_BRIDGE_WITH_MAGIC_MULTIPLICITY_LIMIT',recorded_utc=datetime.now(timezone.utc).isoformat(),sources={str(p.relative_to(R)):h.pin(p) for p in SOURCES},tests=dict(command='PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm .venv/bin/python -m pytest sw/tests/test_magic_hbt_contract_v2.py sw/tests/test_magic_hbt_axis_v1.py sw/tests/test_magic_coupled_cap_v2.py -q -p no:cacheprovider',passed=80,own_tests=42,ruff='PASS'),native_positive=positive,comparison=comparison,geometry_control_outcomes={name:dict(native_exit=x['extraction']['returncode'],checker_exit=x['checker']['returncode'],native_seconds=x['extraction']['seconds'],log=x['outputs']['deck.log']) for name,x in controls.items()},native_method_limit_bytes=2147483648,source_builds={f'private-build-{i}':json.loads(Path(f'/dev/shm/nssoc-hbt-terminal-build-0{i}/result.json').read_text()) for i in (1,2)},source_integrity={name:dict(original_sha=digest,unchanged=sha((Path('/dev/shm/nssoc-magic-coupled-v2-build-final/source/extract') if name=='ExtBasic.c' else R/'hw/soc/out/sram-closure-20260926/magic-tech-via-import')/name)==digest) for name,digest in patch.PINS.items()},archive=h.pin(archive),archive_members=len(members),reproduction=dict(geometry_command='hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage python scripts/check_magic_hbt_hybrid_v2.py geometry --gds FIXTURE/fixture.gds --fixture FIXTURE/result.json --report NATIVE_LVS/result.lvsdb --deck-log NATIVE_LVS/deck.log --extracted NATIVE_LVS/extracted.cir --output NEW_GEOMETRY',wire_command='python scripts/check_magic_hbt_hybrid_v2.py tcl NEW_GEOMETRY/geometry.json NEW_NATIVE; execute the generated native.tcl under each exact runtime with the documented 2 GiB runner and run.json inventory, as in methods/evidence/run_final3_wire.py',audit_command='python scripts/check_magic_hbt_hybrid_v2.py audit --geometry NEW_GEOMETRY/geometry.json --native-dir NEW_NATIVE_V2 --baseline-dir NEW_NATIVE_BASELINE --output NEW_AUDIT',controls='methods/evidence/make_geometry_negatives3.py and run_geometry_negatives3.py; actual native source paths and arguments retained in native-results.json'),limitations=['Private C correction fixes per-tile terminal search only; it has no regression qualification for every other Magic device class.','All 24 Magic HBTs now connect C/B/E correctly, but 16 Nx2/Nx4 instances still lose multiplicity; ngspice() also omits the finite tap. This Magic device output remains rejected.','Hybrid retains all native KLayout device/model/parameter tokens and the finite tap, and separately proves 73 wire conductors, 146 anchors, 73 R edges and full collapsed C matrix.','Metal/via-only RC excludes intrinsic terminal distribution, metal-device coupling, substrate spreading and RF calibration. This is not full-bank PEX or PHY adoption.','First flattened geometry controls are confounded by a separate native KLayout orientation-dependent dimension swap. They are not accepted negative proof; hierarchy-preserving controls plus unchanged-clone positive are the accepted set.','Native deck exits zero on several genuine mismatches; actual comparison/log status, exact census and database terminal/parameter binding decide acceptance.','Reference points are explicit long-axis endpoints within the real pin shapes; failed short-axis anchor attempts retain killed/missing native nodes and remain rejected.'],external_sources=dict(magic_license=h.pin(licensepath),distributed_vendor_runtime=False,distributed_vendor_implementation=False))
assert all(v['unchanged'] for v in record['source_integrity'].values());(B/'validation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(receipt=h.pin(B/'validation.json'),archive=h.pin(archive),members=len(members)),indent=2))
