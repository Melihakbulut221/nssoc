# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));sys.path.insert(0,str(R/'hw/soc/flow'));import check_magic_hbt_hybrid_v2 as h
from check_pcie_rx_cell import execute
G=Path('/dev/shm/nssoc-hbt-hybrid-final3-geometry/geometry.json');r=json.loads(G.read_text());TECH=R/'hw/soc/out/sram-closure-20260926/magic-tech-via-import';runs=[]
for label,rt in [('v2',Path('/dev/shm/nssoc-magic-coupled-v2-build-final/runtime/lib')),('baseline',R/'hw/soc/tools/magic-groundcap-combined-8.3.623/runtime/lib')]:
 o=Path('/dev/shm/nssoc-hbt-hybrid-final3-'+label);o.mkdir();(o/'native.tcl').write_text(h.wire_tcl(r['mapping'],G.parent/'wires.gds',o));x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',TECH/'ihp-sg13g2.magicrc',o/'native.tcl'],o,'native');assert x['returncode']==0
 record=dict(execution=x,runtime=h.pin(rt/'magic/tcl/tclmagic.so'),method=h.pin(__file__),producer=h.pin(h.__file__),geometry=h.pin(G),gds=h.pin(G.parent/'wires.gds'),technology={p.name:h.pin(p) for p in TECH.iterdir() if p.is_file()},outputs={p.name:h.pin(p) for p in o.iterdir() if p.is_file()});(o/'run.json').write_text(json.dumps(record,indent=2)+'\n');runs.append(o)
x=h.bridge(G,runs[0],runs[1],Path('/dev/shm/nssoc-hbt-hybrid-final3-audit'));print(x['status'])
