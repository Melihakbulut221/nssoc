# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import json,hashlib
from pathlib import Path
import klayout.db as d
V=Path('/dev/shm/nssoc-magic-hbt-axis-01');O=Path('/dev/shm/nssoc-hbt-wire-geometry-03');O.mkdir();r=json.loads((V/'result.json').read_text());l=d.Layout();l.read(str(V/'fixture.gds'));t=l.cell('nssoc_hbt_axis');w=d.Layout();w.dbu=l.dbu;top=w.create_cell('hbt_wires');regions={}
for layer in [8,19,10]:
 region=d.Region(t.begin_shapes_rec(l.layer(layer,0))).merged();assert not region.is_empty();regions[layer]=region;top.shapes(w.layer(layer,0)).insert(region)
n=d.LayoutToNetlist('WIRE',l.dbu)
for layer,reg in regions.items():n.register(reg,'gds_'+str(layer));n.connect(reg)
n.connect(regions[8],regions[19]);n.connect(regions[19],regions[10]);n.extract_netlist();mapping={}
for name,p in r['ports'].items():
 box=d.DBox(*p['box']);b=box.to_itype(l.dbu);point=b.center();net=n.probe_net(regions[p['layer']],point);assert net is not None,(name,point)
 points=([[b.left+50,point.y],[b.right-50,point.y]] if b.width()>b.height() else [[point.x,b.bottom+50],[point.x,b.top-50]])
 for xy in points:
  q=n.probe_net(regions[p['layer']],d.Point(*xy));assert q is not None and q.cluster_id==net.cluster_id,(name,xy)
 mapping[name]=dict(cluster=net.cluster_id,point_dbu=[point.x,point.y],anchors_dbu=points,layer=p['layer'])

assert len(set(x['cluster'] for x in mapping.values()))==73;assert sum(1 for _ in n.netlist().circuit_by_name('WIRE').each_net())==73
w.write(str(O/'wires.gds'));n.write(str(O/'wire.l2n'));print('PASS',len(mapping));(O/'result.json').write_text(json.dumps(dict(mapping=mapping,ports=r['ports'],source_sha256=hashlib.sha256((V/'fixture.gds').read_bytes()).hexdigest(),selected_layers=[8,19,10],no_device_or_substrate_rc=True),indent=2)+'\n')
