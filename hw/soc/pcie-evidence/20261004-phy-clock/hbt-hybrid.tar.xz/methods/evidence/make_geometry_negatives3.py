# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import json,hashlib
from pathlib import Path
import klayout.db as d
V=Path('/dev/shm/nssoc-magic-hbt-axis-01');O=Path('/dev/shm/nssoc-hbt-hybrid-geometry-negatives3');O.mkdir();r=json.loads((V/'result.json').read_text());summary={}
for fault in ['emitter_via_open_N2_T1','base_collector_short_N4_T6','missing_finger_N4_T7','emitter_width_N1_T1','missing_tap_contact','unchanged_clone_N4_T7']:
 l=d.Layout();l.read(str(V/'fixture.gds'));top=l.cell('nssoc_hbt_axis');tag={'emitter_via_open_N2_T1':'N2_T1','base_collector_short_N4_T6':'N4_T6','missing_finger_N4_T7':'N4_T7','emitter_width_N1_T1':'N1_T1','missing_tap_contact':None,'unchanged_clone_N4_T7':'N4_T7'}[fault]
 nx,o=(int(tag[1]),int(tag[-1])) if tag else (0,0);xy=(20+o*40,30+[1,2,4].index(nx)*40) if tag else (10,5)
 matches=([i for i in top.each_inst() if abs(i.dtrans.disp.x-xy[0])<1e-8 and abs(i.dtrans.disp.y-xy[1])<1e-8] if tag else [i for i in top.each_inst() if i.cell.name=='ptap1']);assert len(matches)==1;inst=matches[0];transform=inst.dtrans;source=inst.cell;t=l.create_cell('fault_local_'+fault);t.copy_tree(source);inst.cell_index=t.cell_index()
 def localbox(name):return d.DBox(*r['ports'][name]['box']).transformed(transform.inverted()).to_itype(l.dbu)

 if fault.startswith('unchanged_clone'):
  layer=33;before=d.Region(t.shapes(l.layer(layer,0)));after=before;removed=None
 elif fault.startswith('base_collector'):
  layer=8;a=localbox('C_N4_T6').center();b=localbox('B_N4_T6').center();before=d.Region(t.shapes(l.layer(layer,0)));after=before+d.Region(d.Path([a,b],100));removed=None
 elif fault.startswith('emitter_via'):
  layer=19;box=localbox('E_N2_T1').enlarged(300);before=d.Region(t.shapes(l.layer(layer,0)));after=before-d.Region(box);removed=str(box)
 elif fault.startswith('missing_tap'):
  layer=6;box=localbox('SUB').enlarged(100);before=d.Region(t.shapes(l.layer(layer,0)));after=before-d.Region(box);removed=str(box)
 else:
  layer=33;tag='N4_T7' if fault.startswith('missing_finger') else 'N1_T1';box=localbox('E_'+tag).enlarged(300);before=d.Region(t.shapes(l.layer(layer,0)));hits=list(before.interacting(d.Region(box)).each());assert hits
  chosen=hits[0];after=before-d.Region(chosen);removed=chosen.to_s()
  if fault.startswith('emitter_width'):
   b=chosen.bbox();b=d.Box(b.left+20,b.bottom,b.right-20,b.top) if b.width()<b.height() else d.Box(b.left,b.bottom+20,b.right,b.top-20);after+=d.Region(b)
 delta=before^after;assert delta.is_empty() == fault.startswith('unchanged_clone');t.shapes(l.layer(layer,0)).clear();t.shapes(l.layer(layer,0)).insert(after);p=O/(fault+'.gds');l.write(str(p));summary[fault]=dict(layer=layer,delta_area_dbu2=delta.area(),removed=removed,gds_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(O/'result.json').write_text(json.dumps(summary,indent=2)+'\n');print(len(summary))
