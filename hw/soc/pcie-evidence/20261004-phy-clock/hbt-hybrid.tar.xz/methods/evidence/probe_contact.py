# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Temporary bounded actual-contact hypothesis, not a qualified repair."""
import sys,json,hashlib,shutil
from pathlib import Path
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'hw/soc/flow'),str(ROOT/'scripts')];from check_pcie_rx_cell import execute
from patch_magic_hbt_axis_v1 import patch
OLD=ROOT/'hw/soc/out/sram-closure-20260926/magic-tech-via-import';OUT=Path('/dev/shm/nssoc-hbt-contact-probe-01');OUT.mkdir();TECH=OUT/'tech';shutil.copytree(OLD,TECH)
p=TECH/'ihp-sg13g2-extract.tech';p.write_bytes(patch(p.read_bytes()))
p=TECH/'ihp-sg13g2.tech';s=p.read_text();old='  nec\t   nemitter   metal1';assert s.count(old)==1;s=s.replace(old,old+'\n  gec      nemitter   metal1');p.write_text(s)
p=TECH/'ihp-sg13g2-cifin.tech';s=p.read_text();old=' layer gec DIFFMASK\n and lvnpnarea\n and EMITTER';assert s.count(old)==1;s=s.replace(old,old+'\n and CONT');p.write_text(s)
VIEW=Path('/dev/shm/nssoc-magic-hbt-axis-01');r=json.loads((VIEW/'result.json').read_text());RT=Path('/dev/shm/nssoc-magic-coupled-v2-build-final/runtime/lib');d=OUT/'native';d.mkdir()
s=(Path('/dev/shm/nssoc-magic-hbt-axis-overlay-01/original-explicit-ports/extract.tcl')).read_text().replace('/dev/shm/nssoc-magic-hbt-axis-overlay-01/original-explicit-ports',str(d));script=d/'extract.tcl';script.write_text(s)
x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',TECH/'ihp-sg13g2.magicrc',script],d,'native')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rec=dict(execution=x,inputs={str(p):sha(p) for p in [Path(__file__).resolve(),VIEW/'result.json',VIEW/'fixture.gds',RT/'magic/tcl/tclmagic.so']},tech_sha256={p.name:sha(p) for p in TECH.iterdir() if p.is_file()},outputs={str(p.relative_to(OUT)):sha(p) for p in d.iterdir() if p.is_file()},qualified_pex=False)
(OUT/'result.json').write_text(json.dumps(rec,indent=2)+'\n');print(x)
