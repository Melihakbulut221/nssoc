# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import sys,json,hashlib
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
V=Path('/dev/shm/nssoc-hbt-wire-geometry-02');O=Path('/dev/shm/nssoc-hbt-wire-native-03');O.mkdir();RT=Path('/dev/shm/nssoc-magic-coupled-v2-build-final/runtime/lib');TECH=R/'hw/soc/out/sram-closure-20260926/magic-tech-via-import';r=json.loads((V/'result.json').read_text());lines=['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',f'cd {{{O}}}','drc off',f'gds read {{{V/"wires.gds"}}}','load hbt_wires','select top cell']
for i,(name,p) in enumerate(r['ports'].items(),1):
 b=p['box'];y=(b[1]+b[3])/2;x1=b[0]+.05;x2=b[2]-.05;layer='metal'+str({8:1,10:2}[p['layer']])
 for label,x,index in [(name,x1,i*2-1),('D_'+name,x2,i*2)]:
  lines += [f'box values {x}um {y}um {x}um {y}um',f'label {label} center {layer}',f'port {label} make {index}',f'port {label} class inout',f'port {label} use signal']

lines+=['save hbt_wires','extract style ngspice()','extract all','ext2sim labels on','ext2sim','extresist threshold 0','extresist tolerance 0.000001','extresist simplify off','extresist all','ext2spice lvs','ext2spice global off','ext2spice cthresh 0','ext2spice rthresh 0','ext2spice extresist on','ext2spice -o wires.spice','quit -noprompt'];(O/'native.tcl').write_text('\n'.join(lines)+'\n');x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',TECH/'ihp-sg13g2.magicrc',O/'native.tcl'],O,'native');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(O/'result.json').write_text(json.dumps(dict(execution=x,source_sha=sha(V/'wires.gds'),runtime_sha=sha(RT/'magic/tcl/tclmagic.so'),method_sha=sha(__file__),outputs={p.name:sha(p) for p in O.iterdir() if p.is_file()},qualified_pex=False),indent=2)+'\n');print(x)
