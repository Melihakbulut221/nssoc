# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Isolated per-tile diagonal-side correction experiment. No source/runtime replacement."""
from pathlib import Path
import shutil,sys,json,hashlib
R=Path.cwd(); sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
BASE=Path('/dev/shm/nssoc-magic-coupled-v2-build-final'); O=Path('/dev/shm/nssoc-hbt-terminal-build-02');O.mkdir();S=O/'source';shutil.copytree(BASE/'source',S)
p=S/'extract/ExtBasic.c';before=p.read_bytes();s=before.decode();old="    Tile *t;\n    struct LT1 *t_next;";assert s.count(old)==1;s=s.replace(old,"    Tile *t;\n    TileType dinfo;\n    struct LT1 *t_next;")
old="    newdevtile->t = tile;";assert s.count(old)==1;s=s.replace(old,old+"\n    newdevtile->dinfo = dinfo;")
old="extTransFindSubs(lt->t, reg->treg_dinfo, tmask, def,";assert s.count(old)==1;s=s.replace(old,"extTransFindSubs(lt->t, lt->dinfo, tmask, def,")
p.write_text(s);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(O/'ExtBasic.c.before').write_bytes(before)
x=[]
for args in [['-C',str(S/'extract'),'module'],['-C',str(S/'magic'),'tcl-main']]:
 x.append(execute(['make',*args],O,'build'+str(len(x))))
 if x[-1]['returncode']:raise SystemExit(x[-1])
RT=O/'runtime/lib';shutil.copytree(BASE/'runtime/lib',RT);shutil.copyfile(S/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so')
(O/'result.json').write_text(json.dumps(dict(parent_result_sha=sha(BASE/'result.json'),source_before_sha=hashlib.sha256(before).hexdigest(),source_after_sha=sha(p),method_sha=sha(__file__),execution=x,runtime_sha=sha(RT/'magic/tcl/tclmagic.so'),qualification=False),indent=2)+'\n');print(x)
