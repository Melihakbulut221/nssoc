# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));sys.path.insert(0,str(R/'scripts'));from check_pcie_rx_cell import execute
import check_magic_hbt_hybrid_v2 as h
V=Path('/dev/shm/nssoc-magic-hbt-axis-01');O=Path('/dev/shm/nssoc-hbt-hybrid-geometry-negatives3');APP=R/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage';DECK=R/'hw/soc/tools/ihp-lvs-5e6d592/ihp-sg13g2/libs.tech/klayout/tech/lvs/sg13g2.lvs';rows={}
for gds in sorted(O.glob('*.gds')):
 d=O/(gds.stem+'-verified');d.mkdir();cmd=[APP,'klayout','-b','-zz','-r',DECK]
 for v in ['input='+str(gds),'topcell=nssoc_hbt_axis','schematic='+str(V/'schematic.cir'),'report='+str(d/'result.lvsdb'),'target_netlist='+str(d/'extracted.cir'),'log='+str(d/'deck.log'),'run_mode=deep','thr=2']:cmd+=['-rd',v]
 x=execute(cmd,d,'native');log=(d/'deck.log').read_text();positive=gds.stem.startswith('unchanged_clone');assert x['returncode'] in (0,1) and ('Congratulations! Netlists match.' if positive else "Netlists don't match") in log,(gds,x)
 cmd=[APP,'python',R/'scripts/check_magic_hbt_hybrid_v2.py','geometry','--gds',gds,'--fixture',V/'result.json','--report',d/'result.lvsdb','--deck-log',d/'deck.log','--extracted',d/'extracted.cir','--output',d/'rejected-geometry']
 check=execute(cmd,d,'bridge-rejection');assert check['returncode']==(0 if positive else 2) and ('PASS_NATIVE_DEVICE' if positive else 'Native complete LVS failed') in (d/'bridge-rejection.log').read_text()
 rows[gds.stem]=dict(extraction=x,checker=check,inputs={str(p):h.pin(p) for p in [gds,V/'schematic.cir',V/'result.json',APP,DECK,R/'scripts/check_magic_hbt_hybrid_v2.py']},outputs={p.name:h.pin(p) for p in d.iterdir() if p.is_file()});print(gds.stem,'PASS' if positive else 'REJECTED',flush=True)
(O/'native-results.json').write_text(json.dumps(rows,indent=2)+'\n')
