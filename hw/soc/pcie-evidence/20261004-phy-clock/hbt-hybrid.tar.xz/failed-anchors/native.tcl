puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-hbt-wire-native-03}
drc off
gds read {/dev/shm/nssoc-hbt-wire-geometry-02/wires.gds}
load hbt_wires
select top cell
box values 19.125um 31.130000000000003um 19.125um 31.130000000000003um
label C_N1_T0 center metal1
port C_N1_T0 make 1
port C_N1_T0 class inout
port C_N1_T0 use signal
box values 20.875um 31.130000000000003um 20.875um 31.130000000000003um
label D_C_N1_T0 center metal1
port D_C_N1_T0 make 2
port D_C_N1_T0 class inout
port D_C_N1_T0 use signal
box values 19.075um 28.86um 19.075um 28.86um
label B_N1_T0 center metal1
port B_N1_T0 make 3
port B_N1_T0 class inout
port B_N1_T0 use signal
box values 20.925um 28.86um 20.925um 28.86um
label D_B_N1_T0 center metal1
port D_B_N1_T0 make 4
port D_B_N1_T0 class inout
port D_B_N1_T0 use signal
box values 19.305um 29.9925um 19.305um 29.9925um
label E_N1_T0 center metal2
port E_N1_T0 make 5
port E_N1_T0 class inout
port E_N1_T0 use signal
box values 20.695um 29.9925um 20.695um 29.9925um
label D_E_N1_T0 center metal2
port D_E_N1_T0 make 6
port D_E_N1_T0 class inout
port D_E_N1_T0 use signal
box values 58.8um 30.0um 58.8um 30.0um
label C_N1_T1 center metal1
port C_N1_T1 make 7
port C_N1_T1 class inout
port C_N1_T1 use signal
box values 58.940000000000005um 30.0um 58.940000000000005um 30.0um
label D_C_N1_T1 center metal1
port D_C_N1_T1 make 8
port D_C_N1_T1 class inout
port D_C_N1_T1 use signal
box values 61.07um 30.0um 61.07um 30.0um
label B_N1_T1 center metal1
port B_N1_T1 make 9
port B_N1_T1 class inout
port B_N1_T1 use signal
box values 61.21um 30.0um 61.21um 30.0um
label D_B_N1_T1 center metal1
port D_B_N1_T1 make 10
port D_B_N1_T1 class inout
port D_B_N1_T1 use signal
box values 59.279999999999994um 30.0um 59.279999999999994um 30.0um
label E_N1_T1 center metal2
port E_N1_T1 make 11
port E_N1_T1 class inout
port E_N1_T1 use signal
box values 60.735um 30.0um 60.735um 30.0um
label D_E_N1_T1 center metal2
port D_E_N1_T1 make 12
port D_E_N1_T1 class inout
port D_E_N1_T1 use signal
box values 99.125um 28.869999999999997um 99.125um 28.869999999999997um
label C_N1_T2 center metal1
port C_N1_T2 make 13
port C_N1_T2 class inout
port C_N1_T2 use signal
box values 100.875um 28.869999999999997um 100.875um 28.869999999999997um
label D_C_N1_T2 center metal1
port D_C_N1_T2 make 14
port D_C_N1_T2 class inout
port D_C_N1_T2 use signal
box values 99.075um 31.14um 99.075um 31.14um
label B_N1_T2 center metal1
port B_N1_T2 make 15
port B_N1_T2 class inout
port B_N1_T2 use signal
box values 100.925um 31.14um 100.925um 31.14um
label D_B_N1_T2 center metal1
port D_B_N1_T2 make 16
port D_B_N1_T2 class inout
port D_B_N1_T2 use signal
box values 99.30499999999999um 30.0075um 99.30499999999999um 30.0075um
label E_N1_T2 center metal2
port E_N1_T2 make 17
port E_N1_T2 class inout
port E_N1_T2 use signal
box values 100.69500000000001um 30.0075um 100.69500000000001um 30.0075um
label D_E_N1_T2 center metal2
port D_E_N1_T2 make 18
port D_E_N1_T2 class inout
port D_E_N1_T2 use signal
box values 141.06um 30.0um 141.06um 30.0um
label C_N1_T3 center metal1
port C_N1_T3 make 19
port C_N1_T3 class inout
port C_N1_T3 use signal
box values 141.2um 30.0um 141.2um 30.0um
label D_C_N1_T3 center metal1
port D_C_N1_T3 make 20
port D_C_N1_T3 class inout
port D_C_N1_T3 use signal
box values 138.79000000000002um 30.0um 138.79000000000002um 30.0um
label B_N1_T3 center metal1
port B_N1_T3 make 21
port B_N1_T3 class inout
port B_N1_T3 use signal
box values 138.92999999999998um 30.0um 138.92999999999998um 30.0um
label D_B_N1_T3 center metal1
port D_B_N1_T3 make 22
port D_B_N1_T3 class inout
port D_B_N1_T3 use signal
box values 139.26500000000001um 30.0um 139.26500000000001um 30.0um
label E_N1_T3 center metal2
port E_N1_T3 make 23
port E_N1_T3 class inout
port E_N1_T3 use signal
box values 140.72um 30.0um 140.72um 30.0um
label D_E_N1_T3 center metal2
port D_E_N1_T3 make 24
port D_E_N1_T3 class inout
port D_E_N1_T3 use signal
box values 179.125um 28.869999999999997um 179.125um 28.869999999999997um
label C_N1_T4 center metal1
port C_N1_T4 make 25
port C_N1_T4 class inout
port C_N1_T4 use signal
box values 180.875um 28.869999999999997um 180.875um 28.869999999999997um
label D_C_N1_T4 center metal1
port D_C_N1_T4 make 26
port D_C_N1_T4 class inout
port D_C_N1_T4 use signal
box values 179.07500000000002um 31.14um 179.07500000000002um 31.14um
label B_N1_T4 center metal1
port B_N1_T4 make 27
port B_N1_T4 class inout
port B_N1_T4 use signal
box values 180.92499999999998um 31.14um 180.92499999999998um 31.14um
label D_B_N1_T4 center metal1
port D_B_N1_T4 make 28
port D_B_N1_T4 class inout
port D_B_N1_T4 use signal
box values 179.305um 30.0075um 179.305um 30.0075um
label E_N1_T4 center metal2
port E_N1_T4 make 29
port E_N1_T4 class inout
port E_N1_T4 use signal
box values 180.695um 30.0075um 180.695um 30.0075um
label D_E_N1_T4 center metal2
port D_E_N1_T4 make 30
port D_E_N1_T4 class inout
port D_E_N1_T4 use signal
box values 221.06um 30.0um 221.06um 30.0um
label C_N1_T5 center metal1
port C_N1_T5 make 31
port C_N1_T5 class inout
port C_N1_T5 use signal
box values 221.2um 30.0um 221.2um 30.0um
label D_C_N1_T5 center metal1
port D_C_N1_T5 make 32
port D_C_N1_T5 class inout
port D_C_N1_T5 use signal
box values 218.79000000000002um 30.0um 218.79000000000002um 30.0um
label B_N1_T5 center metal1
port B_N1_T5 make 33
port B_N1_T5 class inout
port B_N1_T5 use signal
box values 218.92999999999998um 30.0um 218.92999999999998um 30.0um
label D_B_N1_T5 center metal1
port D_B_N1_T5 make 34
port D_B_N1_T5 class inout
port D_B_N1_T5 use signal
box values 219.26500000000001um 30.0um 219.26500000000001um 30.0um
label E_N1_T5 center metal2
port E_N1_T5 make 35
port E_N1_T5 class inout
port E_N1_T5 use signal
box values 220.72um 30.0um 220.72um 30.0um
label D_E_N1_T5 center metal2
port D_E_N1_T5 make 36
port D_E_N1_T5 class inout
port D_E_N1_T5 use signal
box values 259.125um 31.130000000000003um 259.125um 31.130000000000003um
label C_N1_T6 center metal1
port C_N1_T6 make 37
port C_N1_T6 class inout
port C_N1_T6 use signal
box values 260.875um 31.130000000000003um 260.875um 31.130000000000003um
label D_C_N1_T6 center metal1
port D_C_N1_T6 make 38
port D_C_N1_T6 class inout
port D_C_N1_T6 use signal
box values 259.075um 28.86um 259.075um 28.86um
label B_N1_T6 center metal1
port B_N1_T6 make 39
port B_N1_T6 class inout
port B_N1_T6 use signal
box values 260.925um 28.86um 260.925um 28.86um
label D_B_N1_T6 center metal1
port D_B_N1_T6 make 40
port D_B_N1_T6 class inout
port D_B_N1_T6 use signal
box values 259.305um 29.9925um 259.305um 29.9925um
label E_N1_T6 center metal2
port E_N1_T6 make 41
port E_N1_T6 class inout
port E_N1_T6 use signal
box values 260.695um 29.9925um 260.695um 29.9925um
label D_E_N1_T6 center metal2
port D_E_N1_T6 make 42
port D_E_N1_T6 class inout
port D_E_N1_T6 use signal
box values 298.8um 30.0um 298.8um 30.0um
label C_N1_T7 center metal1
port C_N1_T7 make 43
port C_N1_T7 class inout
port C_N1_T7 use signal
box values 298.94um 30.0um 298.94um 30.0um
label D_C_N1_T7 center metal1
port D_C_N1_T7 make 44
port D_C_N1_T7 class inout
port D_C_N1_T7 use signal
box values 301.07um 30.0um 301.07um 30.0um
label B_N1_T7 center metal1
port B_N1_T7 make 45
port B_N1_T7 class inout
port B_N1_T7 use signal
box values 301.21um 30.0um 301.21um 30.0um
label D_B_N1_T7 center metal1
port D_B_N1_T7 make 46
port D_B_N1_T7 class inout
port D_B_N1_T7 use signal
box values 299.28000000000003um 30.0um 299.28000000000003um 30.0um
label E_N1_T7 center metal2
port E_N1_T7 make 47
port E_N1_T7 class inout
port E_N1_T7 use signal
box values 300.735um 30.0um 300.735um 30.0um
label D_E_N1_T7 center metal2
port D_E_N1_T7 make 48
port D_E_N1_T7 class inout
port D_E_N1_T7 use signal
box values 19.125um 71.24um 19.125um 71.24um
label C_N2_T0 center metal1
port C_N2_T0 make 49
port C_N2_T0 class inout
port C_N2_T0 use signal
box values 22.724999999999998um 71.24um 22.724999999999998um 71.24um
label D_C_N2_T0 center metal1
port D_C_N2_T0 make 50
port D_C_N2_T0 class inout
port D_C_N2_T0 use signal
box values 19.075um 68.86um 19.075um 68.86um
label B_N2_T0 center metal1
port B_N2_T0 make 51
port B_N2_T0 class inout
port B_N2_T0 use signal
box values 22.775um 68.86um 22.775um 68.86um
label D_B_N2_T0 center metal1
port D_B_N2_T0 make 52
port D_B_N2_T0 class inout
port D_B_N2_T0 use signal
box values 19.305um 69.9925um 19.305um 69.9925um
label E_N2_T0 center metal2
port E_N2_T0 make 53
port E_N2_T0 class inout
port E_N2_T0 use signal
box values 22.544999999999998um 69.9925um 22.544999999999998um 69.9925um
label D_E_N2_T0 center metal2
port D_E_N2_T0 make 54
port D_E_N2_T0 class inout
port D_E_N2_T0 use signal
box values 58.589999999999996um 70.92500000000001um 58.589999999999996um 70.92500000000001um
label C_N2_T1 center metal1
port C_N2_T1 make 55
port C_N2_T1 class inout
port C_N2_T1 use signal
box values 58.93um 70.92500000000001um 58.93um 70.92500000000001um
label D_C_N2_T1 center metal1
port D_C_N2_T1 make 56
port D_C_N2_T1 class inout
port D_C_N2_T1 use signal
box values 61.07um 70.92500000000001um 61.07um 70.92500000000001um
label B_N2_T1 center metal1
port B_N2_T1 make 57
port B_N2_T1 class inout
port B_N2_T1 use signal
box values 61.21um 70.92500000000001um 61.21um 70.92500000000001um
label D_B_N2_T1 center metal1
port D_B_N2_T1 make 58
port D_B_N2_T1 class inout
port D_B_N2_T1 use signal
box values 59.279999999999994um 70.925um 59.279999999999994um 70.925um
label E_N2_T1 center metal2
port E_N2_T1 make 59
port E_N2_T1 class inout
port E_N2_T1 use signal
box values 60.735um 70.925um 60.735um 70.925um
label D_E_N2_T1 center metal2
port D_E_N2_T1 make 60
port D_E_N2_T1 class inout
port D_E_N2_T1 use signal
box values 97.27499999999999um 68.76um 97.27499999999999um 68.76um
label C_N2_T2 center metal1
port C_N2_T2 make 61
port C_N2_T2 class inout
port C_N2_T2 use signal
box values 100.875um 68.76um 100.875um 68.76um
label D_C_N2_T2 center metal1
port D_C_N2_T2 make 62
port D_C_N2_T2 class inout
port D_C_N2_T2 use signal
box values 97.225um 71.14um 97.225um 71.14um
label B_N2_T2 center metal1
port B_N2_T2 make 63
port B_N2_T2 class inout
port B_N2_T2 use signal
box values 100.925um 71.14um 100.925um 71.14um
label D_B_N2_T2 center metal1
port D_B_N2_T2 make 64
port D_B_N2_T2 class inout
port D_B_N2_T2 use signal
box values 97.455um 70.0075um 97.455um 70.0075um
label E_N2_T2 center metal2
port E_N2_T2 make 65
port E_N2_T2 class inout
port E_N2_T2 use signal
box values 100.69500000000001um 70.0075um 100.69500000000001um 70.0075um
label D_E_N2_T2 center metal2
port D_E_N2_T2 make 66
port D_E_N2_T2 class inout
port D_E_N2_T2 use signal
box values 141.07000000000002um 69.07499999999999um 141.07000000000002um 69.07499999999999um
label C_N2_T3 center metal1
port C_N2_T3 make 67
port C_N2_T3 class inout
port C_N2_T3 use signal
box values 141.41um 69.07499999999999um 141.41um 69.07499999999999um
label D_C_N2_T3 center metal1
port D_C_N2_T3 make 68
port D_C_N2_T3 class inout
port D_C_N2_T3 use signal
box values 138.79000000000002um 69.07499999999999um 138.79000000000002um 69.07499999999999um
label B_N2_T3 center metal1
port B_N2_T3 make 69
port B_N2_T3 class inout
port B_N2_T3 use signal
box values 138.92999999999998um 69.07499999999999um 138.92999999999998um 69.07499999999999um
label D_B_N2_T3 center metal1
port D_B_N2_T3 make 70
port D_B_N2_T3 class inout
port D_B_N2_T3 use signal
box values 139.26500000000001um 69.075um 139.26500000000001um 69.075um
label E_N2_T3 center metal2
port E_N2_T3 make 71
port E_N2_T3 class inout
port E_N2_T3 use signal
box values 140.72um 69.075um 140.72um 69.075um
label D_E_N2_T3 center metal2
port D_E_N2_T3 make 72
port D_E_N2_T3 class inout
port D_E_N2_T3 use signal
box values 179.125um 68.76um 179.125um 68.76um
label C_N2_T4 center metal1
port C_N2_T4 make 73
port C_N2_T4 class inout
port C_N2_T4 use signal
box values 182.725um 68.76um 182.725um 68.76um
label D_C_N2_T4 center metal1
port D_C_N2_T4 make 74
port D_C_N2_T4 class inout
port D_C_N2_T4 use signal
box values 179.07500000000002um 71.14um 179.07500000000002um 71.14um
label B_N2_T4 center metal1
port B_N2_T4 make 75
port B_N2_T4 class inout
port B_N2_T4 use signal
box values 182.77499999999998um 71.14um 182.77499999999998um 71.14um
label D_B_N2_T4 center metal1
port D_B_N2_T4 make 76
port D_B_N2_T4 class inout
port D_B_N2_T4 use signal
box values 179.305um 70.0075um 179.305um 70.0075um
label E_N2_T4 center metal2
port E_N2_T4 make 77
port E_N2_T4 class inout
port E_N2_T4 use signal
box values 182.545um 70.0075um 182.545um 70.0075um
label D_E_N2_T4 center metal2
port D_E_N2_T4 make 78
port D_E_N2_T4 class inout
port D_E_N2_T4 use signal
box values 221.07000000000002um 70.92500000000001um 221.07000000000002um 70.92500000000001um
label C_N2_T5 center metal1
port C_N2_T5 make 79
port C_N2_T5 class inout
port C_N2_T5 use signal
box values 221.41um 70.92500000000001um 221.41um 70.92500000000001um
label D_C_N2_T5 center metal1
port D_C_N2_T5 make 80
port D_C_N2_T5 class inout
port D_C_N2_T5 use signal
box values 218.79000000000002um 70.92500000000001um 218.79000000000002um 70.92500000000001um
label B_N2_T5 center metal1
port B_N2_T5 make 81
port B_N2_T5 class inout
port B_N2_T5 use signal
box values 218.92999999999998um 70.92500000000001um 218.92999999999998um 70.92500000000001um
label D_B_N2_T5 center metal1
port D_B_N2_T5 make 82
port D_B_N2_T5 class inout
port D_B_N2_T5 use signal
box values 219.26500000000001um 70.925um 219.26500000000001um 70.925um
label E_N2_T5 center metal2
port E_N2_T5 make 83
port E_N2_T5 class inout
port E_N2_T5 use signal
box values 220.72um 70.925um 220.72um 70.925um
label D_E_N2_T5 center metal2
port D_E_N2_T5 make 84
port D_E_N2_T5 class inout
port D_E_N2_T5 use signal
box values 257.27500000000003um 71.24um 257.27500000000003um 71.24um
label C_N2_T6 center metal1
port C_N2_T6 make 85
port C_N2_T6 class inout
port C_N2_T6 use signal
box values 260.875um 71.24um 260.875um 71.24um
label D_C_N2_T6 center metal1
port D_C_N2_T6 make 86
port D_C_N2_T6 class inout
port D_C_N2_T6 use signal
box values 257.225um 68.86um 257.225um 68.86um
label B_N2_T6 center metal1
port B_N2_T6 make 87
port B_N2_T6 class inout
port B_N2_T6 use signal
box values 260.925um 68.86um 260.925um 68.86um
label D_B_N2_T6 center metal1
port D_B_N2_T6 make 88
port D_B_N2_T6 class inout
port D_B_N2_T6 use signal
box values 257.455um 69.9925um 257.455um 69.9925um
label E_N2_T6 center metal2
port E_N2_T6 make 89
port E_N2_T6 class inout
port E_N2_T6 use signal
box values 260.695um 69.9925um 260.695um 69.9925um
label D_E_N2_T6 center metal2
port D_E_N2_T6 make 90
port D_E_N2_T6 class inout
port D_E_N2_T6 use signal
box values 298.59000000000003um 69.07499999999999um 298.59000000000003um 69.07499999999999um
label C_N2_T7 center metal1
port C_N2_T7 make 91
port C_N2_T7 class inout
port C_N2_T7 use signal
box values 298.93um 69.07499999999999um 298.93um 69.07499999999999um
label D_C_N2_T7 center metal1
port D_C_N2_T7 make 92
port D_C_N2_T7 class inout
port D_C_N2_T7 use signal
box values 301.07um 69.07499999999999um 301.07um 69.07499999999999um
label B_N2_T7 center metal1
port B_N2_T7 make 93
port B_N2_T7 class inout
port B_N2_T7 use signal
box values 301.21um 69.07499999999999um 301.21um 69.07499999999999um
label D_B_N2_T7 center metal1
port D_B_N2_T7 make 94
port D_B_N2_T7 class inout
port D_B_N2_T7 use signal
box values 299.28000000000003um 69.075um 299.28000000000003um 69.075um
label E_N2_T7 center metal2
port E_N2_T7 make 95
port E_N2_T7 class inout
port E_N2_T7 use signal
box values 300.735um 69.075um 300.735um 69.075um
label D_E_N2_T7 center metal2
port D_E_N2_T7 make 96
port D_E_N2_T7 class inout
port D_E_N2_T7 use signal
box values 19.125um 111.24um 19.125um 111.24um
label C_N4_T0 center metal1
port C_N4_T0 make 97
port C_N4_T0 class inout
port C_N4_T0 use signal
box values 26.425um 111.24um 26.425um 111.24um
label D_C_N4_T0 center metal1
port D_C_N4_T0 make 98
port D_C_N4_T0 class inout
port D_C_N4_T0 use signal
box values 19.075um 108.86um 19.075um 108.86um
label B_N4_T0 center metal1
port B_N4_T0 make 99
port B_N4_T0 class inout
port B_N4_T0 use signal
box values 26.474999999999998um 108.86um 26.474999999999998um 108.86um
label D_B_N4_T0 center metal1
port D_B_N4_T0 make 100
port D_B_N4_T0 class inout
port D_B_N4_T0 use signal
box values 19.305um 109.9925um 19.305um 109.9925um
label E_N4_T0 center metal2
port E_N4_T0 make 101
port E_N4_T0 class inout
port E_N4_T0 use signal
box values 26.245um 109.9925um 26.245um 109.9925um
label D_E_N4_T0 center metal2
port D_E_N4_T0 make 102
port D_E_N4_T0 class inout
port D_E_N4_T0 use signal
box values 58.589999999999996um 112.775um 58.589999999999996um 112.775um
label C_N4_T1 center metal1
port C_N4_T1 make 103
port C_N4_T1 class inout
port C_N4_T1 use signal
box values 58.93um 112.775um 58.93um 112.775um
label D_C_N4_T1 center metal1
port D_C_N4_T1 make 104
port D_C_N4_T1 class inout
port D_C_N4_T1 use signal
box values 61.07um 112.775um 61.07um 112.775um
label B_N4_T1 center metal1
port B_N4_T1 make 105
port B_N4_T1 class inout
port B_N4_T1 use signal
box values 61.21um 112.775um 61.21um 112.775um
label D_B_N4_T1 center metal1
port D_B_N4_T1 make 106
port D_B_N4_T1 class inout
port D_B_N4_T1 use signal
box values 59.279999999999994um 112.775um 59.279999999999994um 112.775um
label E_N4_T1 center metal2
port E_N4_T1 make 107
port E_N4_T1 class inout
port E_N4_T1 use signal
box values 60.735um 112.775um 60.735um 112.775um
label D_E_N4_T1 center metal2
port D_E_N4_T1 make 108
port D_E_N4_T1 class inout
port D_E_N4_T1 use signal
box values 93.575um 108.76um 93.575um 108.76um
label C_N4_T2 center metal1
port C_N4_T2 make 109
port C_N4_T2 class inout
port C_N4_T2 use signal
box values 100.875um 108.76um 100.875um 108.76um
label D_C_N4_T2 center metal1
port D_C_N4_T2 make 110
port D_C_N4_T2 class inout
port D_C_N4_T2 use signal
box values 93.52499999999999um 111.14um 93.52499999999999um 111.14um
label B_N4_T2 center metal1
port B_N4_T2 make 111
port B_N4_T2 class inout
port B_N4_T2 use signal
box values 100.925um 111.14um 100.925um 111.14um
label D_B_N4_T2 center metal1
port D_B_N4_T2 make 112
port D_B_N4_T2 class inout
port D_B_N4_T2 use signal
box values 93.755um 110.0075um 93.755um 110.0075um
label E_N4_T2 center metal2
port E_N4_T2 make 113
port E_N4_T2 class inout
port E_N4_T2 use signal
box values 100.69500000000001um 110.0075um 100.69500000000001um 110.0075um
label D_E_N4_T2 center metal2
port D_E_N4_T2 make 114
port D_E_N4_T2 class inout
port D_E_N4_T2 use signal
box values 141.07000000000002um 107.225um 141.07000000000002um 107.225um
label C_N4_T3 center metal1
port C_N4_T3 make 115
port C_N4_T3 class inout
port C_N4_T3 use signal
box values 141.41um 107.225um 141.41um 107.225um
label D_C_N4_T3 center metal1
port D_C_N4_T3 make 116
port D_C_N4_T3 class inout
port D_C_N4_T3 use signal
box values 138.79000000000002um 107.225um 138.79000000000002um 107.225um
label B_N4_T3 center metal1
port B_N4_T3 make 117
port B_N4_T3 class inout
port B_N4_T3 use signal
box values 138.92999999999998um 107.225um 138.92999999999998um 107.225um
label D_B_N4_T3 center metal1
port D_B_N4_T3 make 118
port D_B_N4_T3 class inout
port D_B_N4_T3 use signal
box values 139.26500000000001um 107.225um 139.26500000000001um 107.225um
label E_N4_T3 center metal2
port E_N4_T3 make 119
port E_N4_T3 class inout
port E_N4_T3 use signal
box values 140.72um 107.225um 140.72um 107.225um
label D_E_N4_T3 center metal2
port D_E_N4_T3 make 120
port D_E_N4_T3 class inout
port D_E_N4_T3 use signal
box values 179.125um 108.76um 179.125um 108.76um
label C_N4_T4 center metal1
port C_N4_T4 make 121
port C_N4_T4 class inout
port C_N4_T4 use signal
box values 186.42499999999998um 108.76um 186.42499999999998um 108.76um
label D_C_N4_T4 center metal1
port D_C_N4_T4 make 122
port D_C_N4_T4 class inout
port D_C_N4_T4 use signal
box values 179.07500000000002um 111.14um 179.07500000000002um 111.14um
label B_N4_T4 center metal1
port B_N4_T4 make 123
port B_N4_T4 class inout
port B_N4_T4 use signal
box values 186.475um 111.14um 186.475um 111.14um
label D_B_N4_T4 center metal1
port D_B_N4_T4 make 124
port D_B_N4_T4 class inout
port D_B_N4_T4 use signal
box values 179.305um 110.0075um 179.305um 110.0075um
label E_N4_T4 center metal2
port E_N4_T4 make 125
port E_N4_T4 class inout
port E_N4_T4 use signal
box values 186.24499999999998um 110.0075um 186.24499999999998um 110.0075um
label D_E_N4_T4 center metal2
port D_E_N4_T4 make 126
port D_E_N4_T4 class inout
port D_E_N4_T4 use signal
box values 221.07000000000002um 112.775um 221.07000000000002um 112.775um
label C_N4_T5 center metal1
port C_N4_T5 make 127
port C_N4_T5 class inout
port C_N4_T5 use signal
box values 221.41um 112.775um 221.41um 112.775um
label D_C_N4_T5 center metal1
port D_C_N4_T5 make 128
port D_C_N4_T5 class inout
port D_C_N4_T5 use signal
box values 218.79000000000002um 112.775um 218.79000000000002um 112.775um
label B_N4_T5 center metal1
port B_N4_T5 make 129
port B_N4_T5 class inout
port B_N4_T5 use signal
box values 218.92999999999998um 112.775um 218.92999999999998um 112.775um
label D_B_N4_T5 center metal1
port D_B_N4_T5 make 130
port D_B_N4_T5 class inout
port D_B_N4_T5 use signal
box values 219.26500000000001um 112.775um 219.26500000000001um 112.775um
label E_N4_T5 center metal2
port E_N4_T5 make 131
port E_N4_T5 class inout
port E_N4_T5 use signal
box values 220.72um 112.775um 220.72um 112.775um
label D_E_N4_T5 center metal2
port D_E_N4_T5 make 132
port D_E_N4_T5 class inout
port D_E_N4_T5 use signal
box values 253.57500000000002um 111.24um 253.57500000000002um 111.24um
label C_N4_T6 center metal1
port C_N4_T6 make 133
port C_N4_T6 class inout
port C_N4_T6 use signal
box values 260.875um 111.24um 260.875um 111.24um
label D_C_N4_T6 center metal1
port D_C_N4_T6 make 134
port D_C_N4_T6 class inout
port D_C_N4_T6 use signal
box values 253.525um 108.86um 253.525um 108.86um
label B_N4_T6 center metal1
port B_N4_T6 make 135
port B_N4_T6 class inout
port B_N4_T6 use signal
box values 260.925um 108.86um 260.925um 108.86um
label D_B_N4_T6 center metal1
port D_B_N4_T6 make 136
port D_B_N4_T6 class inout
port D_B_N4_T6 use signal
box values 253.75500000000002um 109.9925um 253.75500000000002um 109.9925um
label E_N4_T6 center metal2
port E_N4_T6 make 137
port E_N4_T6 class inout
port E_N4_T6 use signal
box values 260.695um 109.9925um 260.695um 109.9925um
label D_E_N4_T6 center metal2
port D_E_N4_T6 make 138
port D_E_N4_T6 class inout
port D_E_N4_T6 use signal
box values 298.59000000000003um 107.225um 298.59000000000003um 107.225um
label C_N4_T7 center metal1
port C_N4_T7 make 139
port C_N4_T7 class inout
port C_N4_T7 use signal
box values 298.93um 107.225um 298.93um 107.225um
label D_C_N4_T7 center metal1
port D_C_N4_T7 make 140
port D_C_N4_T7 class inout
port D_C_N4_T7 use signal
box values 301.07um 107.225um 301.07um 107.225um
label B_N4_T7 center metal1
port B_N4_T7 make 141
port B_N4_T7 class inout
port B_N4_T7 use signal
box values 301.21um 107.225um 301.21um 107.225um
label D_B_N4_T7 center metal1
port D_B_N4_T7 make 142
port D_B_N4_T7 class inout
port D_B_N4_T7 use signal
box values 299.28000000000003um 107.225um 299.28000000000003um 107.225um
label E_N4_T7 center metal2
port E_N4_T7 make 143
port E_N4_T7 class inout
port E_N4_T7 use signal
box values 300.735um 107.225um 300.735um 107.225um
label D_E_N4_T7 center metal2
port D_E_N4_T7 make 144
port D_E_N4_T7 class inout
port D_E_N4_T7 use signal
box values -1.75um 1.0um -1.75um 1.0um
label SUB center metal1
port SUB make 145
port SUB class inout
port SUB use signal
box values -0.25um 1.0um -0.25um 1.0um
label D_SUB center metal1
port D_SUB make 146
port D_SUB class inout
port D_SUB use signal
save hbt_wires
extract style ngspice()
extract all
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o wires.spice
quit -noprompt
