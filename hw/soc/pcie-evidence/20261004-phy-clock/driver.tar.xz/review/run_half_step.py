# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Two explicit tighter-step controls on the selected derived circuit."""
from pathlib import Path
import sys, json, os, lzma, shutil
sys.path.insert(0,'scripts');import characterize_pcie_clock_driver_v3 as d
out=Path('/dev/shm/nssoc-clock-driver-selected-halfstep');assert not out.exists();out.mkdir()
baseline=Path('/dev/shm/nssoc-clock-vco-full-20261004');startup=Path('/dev/shm/nssoc-vco-zero-v2-full');cap=d.old.ROOT/'hw/soc/out/pcie-clocked-bank-v3-20261004/capacitance-and-rc-review.json'
_,pins=d.parent.inputs(baseline,startup)
for p in (Path(d.__file__).resolve(),Path(d.fanout.__file__).resolve(),d.CIRCUIT,cap,Path(__file__).resolve()):pins[str(p)]=d.old.sha(p)
assert d.old.sha(cap)==d.fanout.CAP_SHA
models=[Path(p).parent for p in pins if Path(p).name=='cornerHBT.lib'][0];runtime=[Path(p) for p in pins if Path(p).name=='ngspice'][0];cp,cn=d.fanout.loads(json.loads(cap.read_text()))[-1][1]
result=dict(status='RUNNING',source_sha256=pins,cases=[],scope='Two explicit selected-circuit half-step checks only; no additional PVT coverage or qualified PEX.')
(out/'spinit').write_text(d.parent.init.SPINIT);os.environ['SPICE_SCRIPTS']=str(out)
for original in [x for x in d.old.cases(False) if x['name'] in ('nominal','res_wcs_cap_wcs_2.415')]:
 case=dict(original,name=original['name']+'__halfstep_opposed',step_s=.5e-12);folder=out/case['name'];folder.mkdir();text=d.circuit(case,4,2);hbts=d.contract(text,4);(folder/d.FILE).write_text(text);(folder/'bench.cir').write_text(d.deck(case,models,[baseline/n for n in d.parent.init.MODELS],cp,cn,hbts))
 execution=d.parent.init.startup.s.rx.execute([str(runtime),'-n','-b','bench.cir'],folder,folder/'run.log');assert execution['returncode']==0
 log=(folder/'run.log').read_text();num=d.old.diagnostics(log);flags=d.flags(log,hbts);op=d.parent.init.startup.initial_op(folder/'initial-op.dat',d.vectors(hbts));assert num['clean'] and max(map(abs,op.values()))<=1e-10
 data=d.read_wave(folder/'wave.dat',hbts,case);measurement=d.measure(data,hbts);del data
 row=dict(case=case,load_p_f=cp,load_n_f=cn,execution=execution,numerical=num,flags_observed=flags,initial_op=op,measurement=measurement,uncompressed_wave_sha256=d.old.sha(folder/'wave.dat'))
 with (folder/'wave.dat').open('rb') as src,lzma.open(folder/'wave.dat.xz','wb',preset=1) as dst:shutil.copyfileobj(src,dst)
 (folder/'wave.dat').unlink();row['outputs']={p.name:d.old.sha(p) for p in folder.iterdir()};result['cases'].append(row);(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(case['name'],measurement['screen_pass'],measurement['frequency_hz'],flush=True)
assert all(d.old.sha(Path(p))==h for p,h in pins.items());result['source_bytes_unchanged']=True;result['status']='PASS_HALFSTEP_LIMITED_CONTROL' if all(r['measurement']['screen_pass'] for r in result['cases']) else 'FAIL_RETAINED';(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
