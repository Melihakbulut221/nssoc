# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,lzma,shutil,tempfile,tarfile,hashlib,io,importlib.util
sys.path.insert(0,'scripts');import characterize_pcie_clock_driver_v3 as final
B=Path('hw/soc/out/pcie-clock-driver-20261004');base=Path('/dev/shm/nssoc-clock-vco-full-20261004');cap=final.old.ROOT/'hw/soc/out/pcie-clocked-bank-v3-20261004/capacitance-and-rc-review.json';modelroot=next(Path(p).parent for p in json.loads((base/'result.json').read_text())['source_sha256'] if Path(p).name=='cornerHBT.lib')
modules={4:final}
for epoch in (1,2,3):
 path=B/f'phase{epoch}-methods/characterize_pcie_clock_driver_v3.py';spec=importlib.util.spec_from_file_location('driver_epoch'+str(epoch),path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules[epoch]=module
catalog=[('count1',1),('count4',1),('count6',1),('count4-pvt',1),('count4-full',1),('count6-pvt-final',2),('count4-sink2-pvt-final',2),('selected-negatives',3)]
reviewed=[];input_pins={};native_records=[];waves_checked=[];filemap={};wavefiles={}
canonical=str(Path(final.__file__).resolve())

def verify_inputs(pins,epoch):
 for p,h in pins.items():
  selected=Path(modules[epoch].__file__) if p==canonical else Path(p)
  assert final.old.sha(selected)==h,(p,h,str(selected));input_pins[str(selected.resolve())]=h

def review_row(row,root,module,count,sink):
 c=row['case'];folder=root/c['name'];hbts=module.contract((folder/module.FILE).read_text(),count)
 assert (folder/module.FILE).read_text()==(module.circuit(c,count) if module is modules[1] else module.circuit(c,count,sink))
 assert (folder/'bench.cir').read_text()==module.deck(c,modelroot,[base/n for n in module.parent.init.MODELS],row['load_p_f'],row['load_n_f'],hbts)
 assert set(row['outputs'])=={p.name for p in folder.iterdir()}
 for n,h in row['outputs'].items():assert final.old.sha(folder/n)==h
 log=(folder/'run.log').read_text();assert module.old.diagnostics(log)==row['numerical'] and row['numerical']['clean'];assert module.flags(log,hbts)==row['flags_observed'];op=module.parent.init.startup.initial_op(folder/'initial-op.dat',module.vectors(hbts));assert op==row['initial_op'] and max(map(abs,op.values()))<=1e-10
 assert row['execution']['returncode']==0 and row['execution']['address_space_limit_bytes']==2*1024**3 and row['execution']['cpu_affinity_count']==1
 if (folder/'wave.dat.xz').exists():
  with tempfile.TemporaryDirectory(prefix='nssoc-driver-wave-review-',dir='/dev/shm') as td:
   wave=Path(td)/'wave.dat'
   with lzma.open(folder/'wave.dat.xz','rb') as src,wave.open('wb') as dst:shutil.copyfileobj(src,dst)
   assert final.old.sha(wave)==row['uncompressed_wave_sha256'];data=module.read_wave(wave,hbts,c);assert module.measure(data,hbts)==row['measurement'];del data
  waves_checked.append(root.name+'/'+c['name'])
 if c['fault']:assert not final.functional_clock_pass(row['measurement']) and row['expected_negative_rejected']
 return dict(name=c['name'],screen_pass=row['measurement']['screen_pass'],native_clean=True)

def add_native(root):
 for p in root.rglob('*'):
  if p.is_file():
   key='native/'+root.name+'/'+str(p.relative_to(root));(wavefiles if p.name in ('wave.dat','wave.dat.xz') else filemap)[key]=p

for label,epoch in catalog:
 root=Path('/dev/shm/nssoc-clock-driver-'+label);r=json.loads((root/'result.json').read_text());module=modules[epoch];verify_inputs(r['source_sha256'],epoch);assert r['source_bytes_unchanged'] and r['clean_cases']==len(r['cases']);planned=module.cases(r['suite'],module.fanout.loads(json.loads(cap.read_text())));assert [x['case'] for x in r['cases']]==[c for c,_ in planned]
 result=[review_row(x,root,module,r['count'],r.get('sink_nx',1)) for x in r['cases']];reviewed.append(dict(dataset=label,epoch=epoch,cases=len(result),screen_pass=sum(x['screen_pass'] for x in result),faults=sum(bool(x['case']['fault']) for x in r['cases']),result_sha256=final.old.sha(root/'result.json')));native_records.append(r);add_native(root);print('reviewed',label,len(result),flush=True)

# The original producer failed ENOSPC. Its immutable partial JSON is never
# rewritten or called complete. Only separately validated complete objects count.
root=Path('/dev/shm/nssoc-clock-driver-selected-full');recovery=json.loads((B/'enospc-prefix-recovery.json').read_text());assert final.old.sha(root/'result.json')==recovery['truncated_result_sha256'];text=(root/'result.json').read_text();key=text.index('"cases": [');header=json.loads(text[:key]+'"cases": []}');verify_inputs(header['source_sha256'],3)
at=key+len('"cases": [');decoder=json.JSONDecoder();prefix=[]
while True:
 while at<len(text) and text[at] in ' \r\n\t,':at+=1
 try:row,at=decoder.raw_decode(text,at)
 except json.JSONDecodeError:break
 prefix.append(row)
assert prefix==recovery['cases'] and len(prefix)==45
for row in prefix:review_row(row,root,modules[3],4,2)
partial=root/recovery['partial_case']['name'];assert {p.name:final.old.sha(p) for p in partial.iterdir()}==recovery['partial_case']['outputs'];add_native(root)
reviewed.append(dict(dataset='selected-full-failed-original',epoch=3,cases=45,incomplete_native_attempts=1,producer_status='ENOSPC_FAILED_NOT_COMPLETE',screen_pass=45,result_sha256=final.old.sha(root/'result.json')))

retry=Path('/dev/shm/nssoc-clock-driver-selected-tail-retry');r=json.loads((retry/'result.json').read_text());verify_inputs(r['source_sha256'],4);assert r['status']=='COMPLETE_EXACT10_RETRY_WITH55_UNION' and r['full_union_55']['status']=='PASS_ALL55'
for row in r['cases']:review_row(row,retry,final,4,2)
union=prefix+r['cases'];planned=final.cases('full',final.fanout.loads(json.loads(cap.read_text())));assert len({x['case']['name'] for x in union})==55 and [x['case'] for x in union]==[c for c,_ in planned];assert all(x['measurement']['screen_pass'] for x in union);add_native(retry);reviewed.append(dict(dataset='selected-tail-retry',epoch=4,cases=10,screen_pass=10,result_sha256=final.old.sha(retry/'result.json')))
half=Path('/dev/shm/nssoc-clock-driver-selected-halfstep');h=json.loads((half/'result.json').read_text());verify_inputs(h['source_sha256'],3);assert h['status']=='PASS_HALFSTEP_LIMITED_CONTROL' and len(h['cases'])==2
for row in h['cases']:review_row(row,half,modules[3],4,2)
add_native(half);reviewed.append(dict(dataset='selected-halfstep',epoch=3,cases=2,screen_pass=2,result_sha256=final.old.sha(half/'result.json')))

candidate=final.old.ROOT/'hw/soc/analog/pcie/clock_vco_hbt_v3.spice';assert candidate.read_text()==final.circuit(dict(final.old.BASE),4,2)
selected_pvt=next(r for r in native_records if r.get('sink_nx')==2 and r['suite']=='pvt');nominal=next(x['measurement'] for x in selected_pvt['cases'] if x['case']['name']=='nominal__opposed_aggressor_equivalent')
sources=[Path(final.__file__).resolve(),final.old.ROOT/'sw/tests/test_pcie_clock_driver_v3.py',candidate];sourcepins={str(p.relative_to(final.old.ROOT)):final.old.sha(p) for p in sources}
summary=dict(status='FINITE_DRIVER_PROGRESS_NOT_PHYSICAL_ACCEPTANCE',source_sha256=sourcepins,completed_native_executions=sum(x['cases'] for x in reviewed),incomplete_native_attempts=1,datasets=reviewed,selected=dict(physical_hbts=30,follower_parallel_count_each_output=4,follower_nx_each=4,sink_parallel_count_each_output=4,sink_nx_each=2,pvt_load_cases=32,completed_full_case_union=55,full_union_prefix=45,full_union_retry=10,clean_functional_negatives=4,halfstep_cases=2,nominal_opposed_load=nominal,minimum_operating_vce_v=min(z['min_vce_v'] for x in union for z in x['measurement']['devices'].values()),maximum_full_capture_vce_v=max(z['full_capture_max_vce_v'] for x in union for z in x['measurement']['devices'].values()),minimum_opposed_load_diff_peak_v=min(min(x['measurement']['max_diff_v'],-x['measurement']['min_diff_v']) for x in union),max_full_capture_ic_per_nx_a=max(z['full_capture_max_abs_ic_a']/z['nx'] for x in union for z in x['measurement']['devices'].values())),retained_complete_waves_remeasured=waves_checked,source_replay_remap={f'phase{e}':dict(original_path=canonical,captured_path=str(Path(modules[e].__file__).resolve()),sha256=final.old.sha(Path(modules[e].__file__))) for e in (1,2,3)},limits=final.old.LIMITS,capacitance_input_sha256=final.fanout.CAP_SHA,limitations=['Each actual HBT uses foundry-validNx1..4, no extrapolatedNx16/24. Parallel branches have separate model thermal nodes; physical mutual heating is not qualified.','The55-case matrix consists of the original separated HBT/MOS/temperature and resistor/capacitor/supply sweeps plus nominal; it is not a complete factorial matrix or steady-state thermal qualification.','Operating minimumVCE and clock/swing/duty metrics use4–12ns. UpperVCE and current-density checks for phases2–4 cover the entire0–12ns capture. Phase1 results are not relabeled as carrying these newer checks.','Measured bank capacitance is the old physicalbank collapsed ground/quiet/opposed equivalent. RoutingR/L, actual aggressor activity, input-device loading, newdriver layout and mutual heating remain unqualified.','Selected full-capture maxVCE is close to1.6V; the finite result is not robust layout/signoff acceptance.','This is1–20GHz oscillator/safety screening, not all-corner8GHz compliance, PLL lock, CDR, random jitter or production acceptance.','OriginalENOSPC attempt remains failed/incomplete. Exact55 coverage is a source-bound union of45complete original objects and10freshnative cases; no case is inferred from a partial wave.'])
(B/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for p in sources:filemap['methods/'+str(p.relative_to(final.old.ROOT))]=p
for p in input_pins:
 path=Path(p)
 if '/libs.tech/'in p:filemap['inputs/libs.tech/'+p.split('/libs.tech/',1)[1]]=path
 elif path.is_relative_to(final.old.ROOT) and path.suffix in ('.py','.spice','.json'):filemap['inputs/project/'+str(path.relative_to(final.old.ROOT))]=path
for path in B.glob('phase*-methods/*.py'):filemap['methods/snapshots/'+str(path.relative_to(B))]=path
for name in ('summary.json','enospc-prefix-recovery.json','resume_exact_full.py','run_half_step.py','review_and_package.py'):
 filemap['review/'+name]=B/name
for name in ('nssoc-clock-driver-selected-full.log','nssoc-clock-driver-selected-halfstep.log'):
 p=Path('/dev/shm')/name
 if p.exists():filemap['execution/'+name]=p
filemap['execution/tail-retry.log']=B/'tail-retry.log';filemap['NOTICES.txt']=Path('hw/soc/out/pcie-startup-20261004/NOTICES.txt')
for n in ('Apache-2.0','CERN-OHL-W-2.0','BSD-3-Clause','CC-BY-4.0'):
 p=Path('LICENSES')/(n+'.txt')
 if p.exists():filemap[str(p)]=p

def pack(path,members):
 inventory={n:dict(bytes=p.stat().st_size,sha256=final.old.sha(p)) for n,p in sorted(members.items())}
 with tarfile.open(path,'w:xz',preset=6) as tar:
  for n,p in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
   with p.open('rb') as f:tar.addfile(info,f)
  data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 with tarfile.open(path,'r:xz') as tar:
  for n,r in inventory.items():
   f=tar.extractfile(n);hash=hashlib.sha256();count=0
   while chunk:=f.read(1024*1024):hash.update(chunk);count+=len(chunk)
   assert hash.hexdigest()==r['sha256'] and count==r['bytes']
 return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=final.old.sha(path),members=len(inventory)+1,roundtrip_verified=True)
compact=pack(B/'clock-driver-v3-native-compact.tar.xz',filemap);waves=pack(B/'clock-driver-v3-native-waves.tar.xz',wavefiles)
validation=dict(status='FROZEN_FINITE_NATIVE_DRIVER_SCREEN',source_sha256=sourcepins,summary_sha256=final.old.sha(B/'summary.json'),compact_capsule=compact,wave_capsule=waves,focused_tests=51,ruff='PASS',complete_native_executions=summary['completed_native_executions'],incomplete_native_attempts=1,retained_complete_waves_remeasured=len(waves_checked),replay_source_sha256=final.old.sha(Path(__file__)))
final.atomic_record(B/'validation.json',validation);print(json.dumps(validation,indent=2))
