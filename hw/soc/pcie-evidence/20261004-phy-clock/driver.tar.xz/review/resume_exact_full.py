# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Preserve ENOSPC failure; replay only missing cases46..55 after validating45."""
from pathlib import Path
import sys,json,lzma,shutil,os
sys.path.insert(0,'scripts');import characterize_pcie_clock_driver_v3 as d
B=Path('hw/soc/out/pcie-clock-driver-20261004');original=Path('/dev/shm/nssoc-clock-driver-selected-full');old_method=B/'phase3-methods/characterize_pcie_clock_driver_v3.py';blob=(original/'result.json').read_bytes();text=blob.decode();key=text.index('"cases": [');header=json.loads(text[:key]+'"cases": []}');at=key+len('"cases": [');decoder=json.JSONDecoder();rows=[]
while True:
 while at<len(text) and text[at] in ' \n\r\t,':at+=1
 try:row,end=decoder.raw_decode(text,at)
 except json.JSONDecodeError as error:stop=dict(position=error.pos,message=error.msg);break
 assert isinstance(row,dict);rows.append(row);at=end
assert len(rows)==45 and all('outputs'in x and x['clean_initialization'] and x['measurement']['screen_pass'] for x in rows)
canonical_path=str(Path(d.__file__).resolve());assert header['source_sha256'][canonical_path]==d.old.sha(old_method)
for p,h in header['source_sha256'].items():assert d.old.sha(old_method if p==canonical_path else Path(p))==h
cap=d.old.ROOT/'hw/soc/out/pcie-clocked-bank-v3-20261004/capacitance-and-rc-review.json';assert d.old.sha(cap)==d.fanout.CAP_SHA
loads=d.fanout.loads(json.loads(cap.read_text()));planned=d.cases('full',loads);assert len(planned)==55 and [x['case'] for x in rows]==[x[0] for x in planned[:45]]
for row in rows:
 folder=original/row['case']['name'];assert set(row['outputs'])=={p.name for p in folder.iterdir()}
 for n,h in row['outputs'].items():assert d.old.sha(folder/n)==h
 assert d.old.diagnostics((folder/'run.log').read_text())==row['numerical']
 assert (folder/d.FILE).read_text()==d.circuit(row['case'],4,2)
partial=original/planned[45][0]['name'];hbts=d.contract((partial/d.FILE).read_text(),4)
try:d.read_wave(partial/'wave.dat',hbts,planned[45][0])
except ValueError as error:partial_error=repr(error)
else:raise AssertionError('Original incomplete wave must remain rejected')
recovery=dict(status='VERBATIM45_COMPLETE_ROWS_VALIDATED_NOT_ORIGINAL_FINAL_CAPTURE',truncated_result_sha256=d.old.sha(original/'result.json'),truncated_bytes=len(blob),parse_stop=stop,old_method_sha256=d.old.sha(old_method),input_remap={canonical_path:str(old_method)},partial_case=dict(name=planned[45][0]['name'],error=partial_error,outputs={p.name:d.old.sha(p) for p in partial.iterdir()}),planned_names=[x[0]['name'] for x in planned],case_count=45,cases=rows)
d.atomic_record(B/'enospc-prefix-recovery.json',recovery)
baseline=Path('/dev/shm/nssoc-clock-vco-full-20261004');startup=Path('/dev/shm/nssoc-vco-zero-v2-full');_,pins=d.parent.inputs(baseline,startup)
for p in (Path(d.__file__).resolve(),Path(d.fanout.__file__).resolve(),d.CIRCUIT,cap,old_method,B/'enospc-prefix-recovery.json',original/'result.json',Path(__file__).resolve()):pins[str(p)]=d.old.sha(p)
models=[Path(p).parent for p in pins if Path(p).name=='cornerHBT.lib'][0];runtime=[Path(p) for p in pins if Path(p).name=='ngspice'][0]
out=Path('/dev/shm/nssoc-clock-driver-selected-tail-retry');assert not out.exists();out.mkdir();(out/'spinit').write_text(d.parent.init.SPINIT);os.environ['SPICE_SCRIPTS']=str(out)
record=dict(status='RUNNING',source_sha256=pins,complete_prefix_receipt_sha256=d.old.sha(B/'enospc-prefix-recovery.json'),explicit_missing_indices=list(range(45,55)),cases=[],qualified_pex=False,scope='Exactly ten native cases. Final55 coverage requires explicit union with independently rehashed45-case prefix; original ENOSPC attempt remains failed.')
d.atomic_record(out/'result.json',record)
try:
 for case,(cp,cn) in planned[45:]:
  folder=out/case['name'];folder.mkdir();source=d.circuit(case,4,2);hbts=d.contract(source,4);(folder/d.FILE).write_text(source);(folder/'bench.cir').write_text(d.deck(case,models,[baseline/n for n in d.parent.init.MODELS],cp,cn,hbts))
  row=dict(case=case,load_p_f=cp,load_n_f=cn,actual_hbt_count=len(hbts));record['cases'].append(row);d.atomic_record(out/'result.json',record)
  row['execution']=d.parent.init.startup.s.rx.execute([str(runtime),'-n','-b','bench.cir'],folder,folder/'run.log');assert row['execution']['returncode']==0
  log=(folder/'run.log').read_text();row['numerical']=d.old.diagnostics(log);row['flags_observed']=d.flags(log,hbts);row['initial_op']=d.parent.init.startup.initial_op(folder/'initial-op.dat',d.vectors(hbts));assert row['numerical']['clean'] and max(map(abs,row['initial_op'].values()))<=1e-10
  data=d.read_wave(folder/'wave.dat',hbts,case);row['measurement']=d.measure(data,hbts);del data;row['uncompressed_wave_sha256']=d.old.sha(folder/'wave.dat');row['clean_initialization']=True
  with (folder/'wave.dat').open('rb') as src,lzma.open(folder/'wave.dat.xz','wb',preset=1) as dst:shutil.copyfileobj(src,dst)
  (folder/'wave.dat').unlink();row['outputs']={p.name:d.old.sha(p) for p in folder.iterdir()};d.atomic_record(out/'result.json',record);print(case['name'],row['measurement']['screen_pass'],flush=True)
 assert all(d.old.sha(Path(p))==h for p,h in pins.items());record['source_bytes_unchanged']=True
 assert [r['case'] for r in record['cases']]==[c for c,_ in planned[45:]]
 union=rows+record['cases'];assert len({r['case']['name'] for r in union})==55 and [r['case'] for r in union]==[c for c,_ in planned]
 record['full_union_55']=dict(status='PASS_ALL55' if all(r['measurement']['screen_pass'] for r in union) else 'PHYSICAL_FAILURES_RETAINED',original_complete_count=45,new_completed_count=10,failures=[r['case']['name'] for r in union if not r['measurement']['screen_pass']])
 record['status']='COMPLETE_EXACT10_RETRY_WITH55_UNION'
except BaseException as error:record['status']='FAIL_PRESERVED';record['error']=repr(error);raise
finally:d.atomic_record(out/'result.json',record)
