read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-vco-v3-checks-03/lef_blocked_pin/wrong.lef}
set master [[ord::get_db] findMaster nssoc_clock_vco_hbt_v3_layout]
if {$master eq "NULL"} {error "VCO master missing"}
if {[$master getWidth] != 1880000 || [$master getHeight] != 277030} {error "VCO outline changed"}
if {[llength [$master getMTerms]] != 6} {error "Analog terminal census changed"}
set term [$master findMTerm CLKP]
if {$term eq "NULL"} {error "VCO terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "VCO terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 1878000 85030 1880000 87030}}} {error "VCO terminal geometry differs"}
set term [$master findMTerm CLKN]
if {$term eq "NULL"} {error "VCO terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "VCO terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 1878000 95030 1880000 97030}}} {error "VCO terminal geometry differs"}
set term [$master findMTerm VCTRL]
if {$term eq "NULL"} {error "VCO terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "VCO terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 105030 2000 107030}}} {error "VCO terminal geometry differs"}
set term [$master findMTerm AVDD]
if {$term eq "NULL"} {error "VCO terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "VCO terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 115030 2000 117030}}} {error "VCO terminal geometry differs"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "VCO terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "VCO terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 125030 2000 127030}}} {error "VCO terminal geometry differs"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "VCO terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "VCO terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 135030 2000 137030}}} {error "VCO terminal geometry differs"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "VCO blockage layer census changed"}
foreach term [$master getMTerms] {foreach pin [$term getMPins] {foreach pb [$pin getGeometry] {foreach ob [$master getObstructions] {
if {[[$pb getTechLayer] getName] eq [[$ob getTechLayer] getName] && [$pb xMin] < [$ob xMax] && [$ob xMin] < [$pb xMax] && [$pb yMin] < [$ob yMax] && [$ob yMin] < [$pb yMax]} {error "VCO pin obstruction overlap"}
}}}}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
