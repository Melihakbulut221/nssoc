import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-v3-layout-01/nssoc_clock_vco_hbt_v3_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_v3_layout')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-vco-v3-checks-03/offgrid/wrong.gds')
