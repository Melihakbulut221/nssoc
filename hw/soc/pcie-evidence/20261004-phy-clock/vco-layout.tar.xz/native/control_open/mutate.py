import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-v3-layout-01/nssoc_clock_vco_hbt_v3_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_v3_layout')
region=pya.Region(c.shapes(l.layer(67,0)))
region-=pya.Region(pya.DBox(3,104.03,4,108.03).to_itype(l.dbu))
c.shapes(l.layer(67,0)).clear()
c.shapes(l.layer(67,0)).insert(region)
l.write('/dev/shm/nssoc-vco-v3-checks-03/control_open/wrong.gds')
