# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2');OUT=Path('/dev/shm/nssoc-vco-v3-retry-02');OUT.mkdir()
x=execute([sys.executable,R/'hw/soc/flow/check_pcie_clock_vco_v3.py','--pdk',PDK,'--layout','/dev/shm/nssoc-vco-v3-layout-01','--out','/dev/shm/nssoc-vco-v3-checks-02'],OUT,'check');(OUT/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(x);raise SystemExit(x['returncode'])
