# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
APP=R/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage';PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2');OUT=Path('/dev/shm/nssoc-vco-v3-generation-01');OUT.mkdir()
x=execute([APP,'python',R/'hw/soc/flow/make_pcie_clock_vco_v3.py','--pdk',PDK,'--out','/dev/shm/nssoc-vco-v3-layout-01'],OUT,'generate');(OUT/'result.json').write_text(json.dumps(x,indent=2)+'\n');print(x)
if x['returncode']:raise SystemExit(1)
x=execute([sys.executable,R/'hw/soc/flow/check_pcie_clock_vco_v3.py','--pdk',PDK,'--layout','/dev/shm/nssoc-vco-v3-layout-01','--out','/dev/shm/nssoc-vco-v3-checks-01'],OUT,'check');(OUT/'check-result.json').write_text(json.dumps(x,indent=2)+'\n');print(x)
raise SystemExit(x['returncode'])
