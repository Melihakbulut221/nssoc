# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,tarfile,datetime,sys
R=Path.cwd();B=R/'hw/soc/out/pcie-clock-vco-v3-layout-20261004'
sys.path.insert(0,str(R/'hw/soc/flow'))
from check_pcie_clock_vco_v3 import validate_lvs,REFERENCE_FAULTS,PHYSICAL_FAULTS
from check_pcie_rx_cell import execute

def pin(p):
 return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_text())
L=Path('/dev/shm/nssoc-vco-v3-layout-01');N=Path('/dev/shm/nssoc-vco-v3-checks-03')
g=read(L/'result.json');n=read(N/'result.json')
assert n['status']=='PASS_VCO_MAIN_DRC_STRICT_DEEP_FLAT_LVS_LEF_AND_SEVENTEEN_NEGATIVE_CONTROLS_ONLY'
assert len(n['steps'])==21
for name,h in n['outputs'].items():assert pin(N/name)['sha256']==h,name
for name,h in g['output_sha256'].items():assert pin(L/name)['sha256']==h,name
for s in n['steps']:
 if 'audit' in s:validate_lvs(s,(N/s['name']/'extracted.cir').read_text(),s['name'] in ('lvs','lvs_flat'))
assert n['steps'][0]['measurement']['category_count']==560 and n['steps'][0]['status']=='PASS'
assert set(s['name'] for s in n['steps'])=={'drc','offgrid','lvs','lvs_flat','lef','lef_missing_pin','lef_blocked_pin',*REFERENCE_FAULTS,*PHYSICAL_FAULTS}
for p,h in n['inputs'].items():assert pin(Path(p))['sha256']==h,p
own=['hw/soc/flow/make_pcie_clock_vco_v3.py','hw/soc/flow/check_pcie_clock_vco_v3.py','sw/tests/test_pcie_clock_vco_v3_layout.py']
for label,cmd in [('tests',[R/'.venv/bin/python','-m','pytest','sw/tests/test_pcie_clock_vco_v3_layout.py','sw/tests/test_pcie_clock_vco_layout.py','-q','-p','no:cacheprovider']),('ruff',[R/'hw/soc/tools/dev-env/bin/ruff','check',*own])]:
 ex=execute(cmd,B,label);(B/(label+'-execution.json')).write_text(json.dumps(ex,indent=2)+'\n');assert ex['returncode']==0
sources={p:pin(R/p) for p in own}
selected={}
roots={'layout':L,'native':N,'first_census_failure':Path('/dev/shm/nssoc-vco-v3-checks-01'),'first_follower_mutation_failure':Path('/dev/shm/nssoc-vco-v3-checks-02'),'corrected_follower_probe':Path('/dev/shm/nssoc-vco-v3-follower-probe-01'),'generation_execution':Path('/dev/shm/nssoc-vco-v3-generation-01'),'second_execution':Path('/dev/shm/nssoc-vco-v3-retry-02'),'final_execution':Path('/dev/shm/nssoc-vco-v3-retry-03')}
for label,folder in roots.items():
 for p in sorted(folder.rglob('*')):
  if p.is_file():selected[label+'/'+str(p.relative_to(folder))]=p
for p in own:selected['methods/'+p]=R/p
for p in sorted(B.iterdir()):
 if p.is_file() and p.suffix in ('.py','.log','.png') or p.name in ('tests-execution.json','ruff-execution.json','render-execution.json'):
  selected['reproduction/'+p.name]=p
selected['methods/hw/soc/analog/pcie/clock_vco_hbt_v3.spice']=R/'hw/soc/analog/pcie/clock_vco_hbt_v3.spice'
inventory={name:pin(p) for name,p in selected.items()}
cap=B/'vco-v3-native-physical.tar.xz'
with tarfile.open(cap,'w:xz',preset=6) as t:
 for name,p in selected.items():t.add(p,arcname=name,recursive=False)
with tarfile.open(cap) as t:
 assert set(t.getnames())==set(selected)
 for m in t:
  assert m.isfile();data=t.extractfile(m).read();assert len(data)==inventory[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==inventory[m.name]['sha256']
r=dict(status=n['status'],utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sources=sources,circuit=dict(path='hw/soc/analog/pcie/clock_vco_hbt_v3.spice',**pin(R/'hw/soc/analog/pcie/clock_vco_hbt_v3.spice')),geometry=dict(top='nssoc_clock_vco_hbt_v3_layout',bbox_um=g['bbox_um'],ports=sorted(g['ports']),hbt_instances=30,nx1=2,nx2=17,nx4=11,hv_pmos=1,rppd=9,cap_cmim=6,ptap_2_by_2_um=12,ntap_2_by_2_um=1),native=dict(result=pin(N/'result.json'),drc_categories=560,drc_violations=0,deep_and_flat='PASS',native_compared_devices=36,native_hbt_records=18,expanded_hbt_instances=30,parallel_combining='Exactly four m=4 groups: separate Nx4 follower/Nx2 sink groups on CLKP and CLKN; all remaining14 HBT records m=1.',finite_taps='Native deck combines twelve physical ptaps to A48p/P96u and one ntap to A4p/P8u; SUB/BULK and AVDD/NWELL remain distinct.',steps=[dict(name=s['name'],status=s['status']) for s in n['steps']],negative_controls=17),tests=dict(passed=56,own=34,commands=[read(B/'tests-execution.json'),read(B/'ruff-execution.json')]),preserved_failures=[dict(path='first_census_failure/result.json',cause='Expected48 native records was wrong; strict native LVS combined identical parallel branches. Replaced with36 records plus exact expanded30 HBT multiplicity/topology guard; no geometry or deck change.'),dict(path='first_follower_mutation_failure/result.json',cause='First new follower-open cut missed after GDS origin translation; the checker rejected accepted fault. Corrected cut using recorded origin and actual native probe found37 versus36 records, split CLKP follower m3+1 and NoMatch.')],capsule=dict(path=str(cap.relative_to(R)),**pin(cap),members=len(inventory),inventory=inventory),render=dict(path=str((B/'vco-v3.png').relative_to(R)),**pin(B/'vco-v3.png'),scope='Actual native KLayout-rendered GDS; no illustration.'),limitations=['No post-layout oscillation, phase noise, skew, EM, full RF PEX, PLL/CDR, PCIe compliance or manufacturing acceptance.','One standalone macro; not integrated into bank or main chip.','Independent actual HBT branches have finite physical taps; no mutual thermal performance qualification.','Native LVS topology/geometry correspondence does not qualify extracted transistor simulation models or parasitics.'],external_material='No PDK implementation source, runtime binary or vendor model source included; generated PCell geometry/raw native reports retained, with all runtime/PDK/deck hashes and original paths in native result.',reproduction=['Use the pinned PDK c4b8b4e5 and Librelane3.0.5 AppImage SHA d6a349ec65be11456e96c4981d35f63ca34d3c85daf79a51e1ccb907bb5d7466; original native DRC/LVS decks5e6d592 are unchanged.','AppImage python hw/soc/flow/make_pcie_clock_vco_v3.py --pdk <pinned-pdk>/ihp-sg13g2 --out /dev/shm/nssoc-vco-<fresh-layout>','PYTHONDONTWRITEBYTECODE=1 .venv/bin/python hw/soc/flow/check_pcie_clock_vco_v3.py --layout <layout> --pdk <pinned-pdk>/ihp-sg13g2 --out /dev/shm/nssoc-vco-<fresh-checks>','Each recorded child uses RLIMIT_AS=2147483648 bytes; no elapsed watchdog claimed.'],phy_complete=False,bank_integrated=False,qualified_pex=False,manufacturing_approval=False)
(B/'validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'validation':pin(B/'validation.json'),'capsule':pin(cap),'sources':sources,'members':len(inventory)},indent=2))
