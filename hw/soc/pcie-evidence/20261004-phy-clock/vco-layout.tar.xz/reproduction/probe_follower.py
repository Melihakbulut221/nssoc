# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'))
from check_pcie_clock_vco_v3 import mutation_source,validate_lvs
from check_pcie_rx_cell import execute
D=Path('/dev/shm/nssoc-vco-v3-follower-probe-01');D.mkdir()
L=Path('/dev/shm/nssoc-vco-v3-layout-01');old=Path('/dev/shm/nssoc-vco-v3-checks-02/follower_open')
prior=next(s for s in json.loads((old.parent/'result.json').read_text())['steps'] if s['name']=='follower_open')
G=json.loads((L/'result.json').read_text());script=D/'mutate.py';script.write_text(mutation_source(L/'nssoc_clock_vco_hbt_v3_layout.gds',D/'wrong.gds',G,'follower_open'))
r={'name':'follower_open'}
for field,stem in [('mutation_execution','mutation'),('execution','run'),('audit_execution','audit')]:
 cmd=[x.replace(str(old),str(D)) for x in prior[field]['command']]
 r[field]=execute(cmd,D,stem)
r['audit']=json.loads((D/'audit.json').read_text());validate_lvs(r,(D/'extracted.cir').read_text(),False)
r['status']='EXPECTED_ACTUAL_FOLLOWER_OPEN_REJECTION';(D/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'])
