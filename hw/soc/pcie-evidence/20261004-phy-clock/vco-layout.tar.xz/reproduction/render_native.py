# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import pya
v = pya.LayoutView()
v.load_layout('/dev/shm/nssoc-vco-v3-layout-01/nssoc_clock_vco_hbt_v3_layout.gds', 0)
v.load_layer_props('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/klayout/tech/sg13g2.lyp')
v.add_missing_layers()
v.max_hier()
v.set_config('text-visible', 'false')
v.set_config('grid-visible', 'false')
v.zoom_fit()
v.save_image('/home/hasanmelih/Documents/ChatGPT/nnsoc/hw/soc/out/pcie-clock-vco-v3-layout-20261004/vco-v3.png', 1400, 280)
