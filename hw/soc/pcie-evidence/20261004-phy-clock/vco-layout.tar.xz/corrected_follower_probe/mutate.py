import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-v3-layout-01/nssoc_clock_vco_hbt_v3_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_v3_layout')
region=pya.Region(c.shapes(l.layer(30,0)))
region-=pya.Region(pya.DBox(1416.7900000000002,17.01,1416.99,17.610000000000003).to_itype(l.dbu))
c.shapes(l.layer(30,0)).clear()
c.shapes(l.layer(30,0)).insert(region)
l.write('/dev/shm/nssoc-vco-v3-follower-probe-01/wrong.gds')
