import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-v3-layout-01/nssoc_clock_vco_hbt_v3_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_v3_layout')
region=pya.Region(c.shapes(l.layer(30,0)))
region-=pya.Region(pya.DBox(1416.7900000000002,20.98,1416.99,21.580000000000002).to_itype(l.dbu))
c.shapes(l.layer(30,0)).clear()
c.shapes(l.layer(30,0)).insert(region)
l.write('/dev/shm/nssoc-vco-v3-checks-02/follower_open/wrong.gds')
