import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-v3-layout-01/nssoc_clock_vco_hbt_v3_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_v3_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(1878.5,86.03,1879.5,96.03))
l.write('/dev/shm/nssoc-vco-v3-checks-02/clock_short/wrong.gds')
