import json,hashlib,tarfile,io,datetime,sys
sys.path.insert(0,'scripts')
from cocotb_results import count_results
from pathlib import Path
repo=Path.cwd(); out=repo/'hw/soc/out/pcie-scrambler-20261004'; dst=repo/'hw/soc/pcie-evidence/20261004-phy-clock';members={}
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def pin(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def add_tree(root,label):
 for p in root.rglob('*'):
  if p.is_file() and 'sim' not in p.relative_to(root).parts and '__pycache__' not in p.parts:
   members[label+'/'+str(p.relative_to(root))]=p.read_bytes()
positive=[]
for label in ['rtl','native']:
 root=Path('/dev/shm/nssoc-gen3-scrambler-'+label+'-final');r=json.loads((root/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_PCIE_GEN3_SCRAMBLER';assert r['tests']=={'passed':3,'failed':0,'skipped':0}
 for path,want in r['inputs'].items():assert pin(Path(path))==want
 for path,want in r['runtime'].items():assert pin(Path(path))==want
 for path,want in r['outputs'].items():assert pin(root/path)==want
 add_tree(root,label);positive.append({'mode':label,'tests':r['tests'],'mapped_cells':r.get('mapped_cells'),'result_sha256':sha(root/'result.json')})
root=Path('/dev/shm/nssoc-scrambler-mutations-final'); runs=[p for p in root.glob('test*/run/result.json') if not p.parent.parent.is_symlink()];assert len(runs)==7
negative=[]
for p in runs:
 r=json.loads(p.read_text());assert r['status']=='FAIL';c=count_results([p.parent/'results.xml']);assert c[0]+c[1]==3 and c[1]>0 and c[2]==0;negative.append({'path':str(p.parent.parent.name),'result_sha256':sha(p)})
add_tree(root,'mutations')
for name in ['scripts/check_pcie_gen3_scrambler.py','scripts/check_pcie_integrity.py','scripts/check_pcie_integrity_native.py','scripts/cocotb_results.py','hw/soc/rtl/pcie/soc_pcie_gen3_scrambler.v','hw/soc/tb/cocotb/Makefile.soc_pcie_gen3_scrambler','hw/soc/tb/cocotb/test_soc_pcie_gen3_scrambler.py','sw/tests/test_pcie_gen3_scrambler.py','.github/workflows/pcie-buffered-soc.yml']:
 members['sources/'+name]=(repo/name).read_bytes()
members['review/seal.py']=Path(__file__).read_bytes()
r={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'PASS_SOURCE_BOUND_SCRAMBLER_PORT_CONTROLS','positive':positive,'actual_source_mutants_rejected':negative,'inputs_unchanged':True,'runtime_unchanged':True,'raw_outputs_rehashed':True,'scope':'Four logical lanes0..3,32payloadbits/lane. Explicit independent per-byte advance/XOR and after-word reseed controls. Bit-cell equation oracle plus eight published lane0 state anchors; per-lane bit0-first comparison, backpressure, reset/flush. Testbench clock250MHz and TT cell models only, no SDF or physical250MHz closure. Caller still provides ordered-set/DC-balance policy; no full PCS, block alignment, deskew, LTSSM, PMA or main-chip integration.','primary_references':['https://www.intel.com/programmable/technical-pdfs/683779.pdf','https://studylib.net/doc/28447088/pcie-v4.0'],'members':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(members.items())}}
members['manifest.json']=json.dumps(r,indent=2).encode()
p=dst/'scrambler.tar.xz';assert not p.exists()
with tarfile.open(p,'w:xz',preset=3) as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo(n);i.size=len(b);t.addfile(i,io.BytesIO(b))
r['capsule']={'path':str(p.relative_to(repo)),**pin(p)}
(dst/'scrambler.json').write_text(json.dumps(r,indent=2)+'\n');print(r['capsule'])
