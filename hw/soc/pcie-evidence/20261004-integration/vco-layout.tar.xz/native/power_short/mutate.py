import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-layout-01/nssoc_clock_vco_hbt_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(0.5,116.03,1.5,126.03))
l.write('/dev/shm/nssoc-vco-checks-01/power_short/wrong.gds')
