import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-layout-01/nssoc_clock_vco_hbt_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_layout')
region=pya.Region(c.shapes(l.layer(67,0)))
region-=pya.Region(pya.DBox(3,104.03,4,108.03).to_itype(l.dbu))
c.shapes(l.layer(67,0)).clear()
c.shapes(l.layer(67,0)).insert(region)
l.write('/dev/shm/nssoc-vco-checks-01/control_open/wrong.gds')
