import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-vco-layout-01/nssoc_clock_vco_hbt_layout.gds')
c=l.cell('nssoc_clock_vco_hbt_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(1398.5,86.03,1399.5,96.03))
l.write('/dev/shm/nssoc-vco-checks-01/clock_short/wrong.gds')
