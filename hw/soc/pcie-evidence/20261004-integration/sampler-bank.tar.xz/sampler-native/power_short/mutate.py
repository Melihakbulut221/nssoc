import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-layout-01/nssoc_rx_sampler_hbt_v2_layout.gds')
c=l.cell('nssoc_rx_sampler_hbt_v2_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(.5,136.03,1.5,146.03))
l.write('/dev/shm/nssoc-sampler-checks-02/power_short/wrong.gds')
