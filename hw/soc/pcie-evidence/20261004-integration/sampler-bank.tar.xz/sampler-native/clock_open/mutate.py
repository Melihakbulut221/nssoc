import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-layout-01/nssoc_rx_sampler_hbt_v2_layout.gds')
c=l.cell('nssoc_rx_sampler_hbt_v2_layout')
region=pya.Region(c.shapes(l.layer(67,0)))
region-=pya.Region(pya.DBox(3,114.03,4,118.03).to_itype(l.dbu))
c.shapes(l.layer(67,0)).clear()
c.shapes(l.layer(67,0)).insert(region)
l.write('/dev/shm/nssoc-sampler-checks-02/clock_open/wrong.gds')
