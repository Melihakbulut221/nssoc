import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-layout-01/nssoc_rx_sampler_hbt_v2_layout.gds')
c=l.cell('nssoc_rx_sampler_hbt_v2_layout')
c.shapes(l.layer(67,0)).insert(pya.DBox(.5,116.03,1.5,126.03))
l.write('/dev/shm/nssoc-sampler-checks-02/clock_short/wrong.gds')
