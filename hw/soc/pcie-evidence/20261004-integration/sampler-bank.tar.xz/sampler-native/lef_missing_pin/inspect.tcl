read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-sampler-checks-02/lef_missing_pin/wrong.lef}
set master [[ord::get_db] findMaster nssoc_rx_sampler_hbt_v2_layout]
if {$master eq "NULL"} {error "Sampler master missing"}
if {[$master getWidth] != 880000 || [$master getHeight] != 267030} {error "Sampler outline changed"}
if {[llength [$master getMTerms]] != 10} {error "Analog terminal census changed"}
set term [$master findMTerm DP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 75030 2000 77030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm DN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 85030 2000 87030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm QP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 878000 95030 880000 97030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm QN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 878000 105030 880000 107030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm CLKP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 115030 2000 117030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm CLKN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 125030 2000 127030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm AVDD]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 135030 2000 137030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 145030 2000 147030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 155030 2000 157030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 165030 2000 167030}}} {error "Sampler terminal geometry differs"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "Sampler blockage layer census changed"}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
