import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-layout-01/nssoc_rx_sampler_hbt_v2_layout.gds')
c=l.cell('nssoc_rx_sampler_hbt_v2_layout')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-sampler-checks-01/offgrid/wrong.gds')
