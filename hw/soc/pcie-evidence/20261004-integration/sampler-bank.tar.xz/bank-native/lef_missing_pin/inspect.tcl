read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-sampler-bank-checks-01/lef_missing_pin/wrong.lef}
set master [[ord::get_db] findMaster nssoc_pcie_analog_bank4_v2]
if {$master eq "NULL"} {error "Sampler master missing"}
if {[$master getWidth] != 1070000 || [$master getHeight] != 2640000} {error "Sampler outline changed"}
if {[llength [$master getMTerms]] != 60} {error "Analog terminal census changed"}
set term [$master findMTerm L0_TX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 59000 2000 61000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_TX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 59000 1070000 61000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_TX_OUTP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 67000 1070000 69000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_TX_OUTN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 67000 2000 69000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_TX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 31000 2000 33000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_RX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 244000 2000 246000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_RX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 244000 1070000 246000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_RX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 216000 2000 218000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_RX_VCM]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 332000 1070000 334000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_QP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 465030 1070000 467030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_QN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 475030 1070000 477030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_CLKP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 485030 2000 487030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_CLKN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 495030 2000 497030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 535030 2000 537030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_TX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 719000 2000 721000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_TX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 719000 1070000 721000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_TX_OUTP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 727000 1070000 729000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_TX_OUTN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 727000 2000 729000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_TX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 691000 2000 693000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_RX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 904000 2000 906000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_RX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 904000 1070000 906000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_RX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 876000 2000 878000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_RX_VCM]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 992000 1070000 994000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_QP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1125030 1070000 1127030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_QN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1135030 1070000 1137030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_CLKP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1145030 2000 1147030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_CLKN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1155030 2000 1157030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1195030 2000 1197030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_TX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1379000 2000 1381000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_TX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1379000 1070000 1381000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_TX_OUTP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1387000 1070000 1389000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_TX_OUTN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1387000 2000 1389000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_TX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1351000 2000 1353000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_RX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1564000 2000 1566000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_RX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1564000 1070000 1566000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_RX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1536000 2000 1538000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_RX_VCM]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1652000 1070000 1654000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_QP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1785030 1070000 1787030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_QN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 1795030 1070000 1797030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_CLKP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1805030 2000 1807030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_CLKN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1815030 2000 1817030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1855030 2000 1857030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_TX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2039000 2000 2041000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_TX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 2039000 1070000 2041000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_TX_OUTP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 2047000 1070000 2049000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_TX_OUTN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2047000 2000 2049000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_TX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2011000 2000 2013000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_RX_INP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2224000 2000 2226000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_RX_INN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 2224000 1070000 2226000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_RX_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2196000 2000 2198000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_RX_VCM]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 2312000 1070000 2314000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_QP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 2445030 1070000 2447030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_QN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1068000 2455030 1070000 2457030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_CLKP]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2465030 2000 2467030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_CLKN]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2475030 2000 2477030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_IREF]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2515030 2000 2517030}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm AVDD1V8]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 988000 0 992000 4000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm AVDD2V5]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1008000 0 1012000 4000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1028000 0 1032000 4000}}} {error "Sampler terminal geometry differs"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "Sampler terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Sampler terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1048000 0 1052000 4000}}} {error "Sampler terminal geometry differs"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "Sampler blockage layer census changed"}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
