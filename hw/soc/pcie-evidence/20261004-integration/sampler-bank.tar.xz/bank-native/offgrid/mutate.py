import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-bank-v2-01/nssoc_pcie_analog_bank4_v2.gds')
c=l.cell('nssoc_pcie_analog_bank4_v2')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-sampler-bank-checks-01/offgrid/wrong.gds')
