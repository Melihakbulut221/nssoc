import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-bank-v2-01/nssoc_pcie_analog_bank4_v2.gds')
c=l.cell('nssoc_pcie_analog_bank4_v2')
c.shapes(l.layer(126,0)).insert(pya.DBox(.5,1806.03,1.5,1816.03))
l.write('/dev/shm/nssoc-sampler-bank-checks-01/clock_short/wrong.gds')
