import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-bank-v2-01/nssoc_pcie_analog_bank4_v2.gds')
c=l.cell('nssoc_pcie_analog_bank4_v2')
c.shapes(l.layer(134,0)).insert(pya.DBox(990.0,1,1010.0,3))
l.write('/dev/shm/nssoc-sampler-bank-checks-01/power_short/wrong.gds')
