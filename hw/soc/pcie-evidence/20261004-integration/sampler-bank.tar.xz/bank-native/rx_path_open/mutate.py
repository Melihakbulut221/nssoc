import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-bank-v2-01/nssoc_pcie_analog_bank4_v2.gds')
c=l.cell('nssoc_pcie_analog_bank4_v2')
region=pya.Region(c.shapes(l.layer(134,0)))
region-=pya.Region(pya.DBox(937.0,1668.5149999999999,943.0,1670.5149999999999).to_itype(l.dbu))
c.shapes(l.layer(134,0)).clear()
c.shapes(l.layer(134,0)).insert(region)
l.write('/dev/shm/nssoc-sampler-bank-checks-01/rx_path_open/wrong.gds')
