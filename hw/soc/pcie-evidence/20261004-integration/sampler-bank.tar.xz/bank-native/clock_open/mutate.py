import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-sampler-bank-v2-01/nssoc_pcie_analog_bank4_v2.gds')
c=l.cell('nssoc_pcie_analog_bank4_v2')
region=pya.Region(c.shapes(l.layer(126,0)))
region-=pya.Region(pya.DBox(3,1804.03,4,1808.03).to_itype(l.dbu))
c.shapes(l.layer(126,0)).clear()
c.shapes(l.layer(126,0)).insert(region)
l.write('/dev/shm/nssoc-sampler-bank-checks-01/clock_open/wrong.gds')
