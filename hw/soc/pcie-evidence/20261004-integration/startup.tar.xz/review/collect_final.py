# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,tarfile,hashlib,io
sys.path.insert(0,'scripts')
import review_pcie_zero_start_v3 as r
B=Path('hw/soc/out/pcie-startup-20261004');B.mkdir(exist_ok=True)
roots={n:Path('/dev/shm/nssoc-zero-v3-'+p) for n,p in {
'ng47-rx-pvt':'ng47-full-rx-final','ng47-sampler-pvt':'ng47-full-sampler-final','ng42-rx-cross':'ng42-rx-pilot','ng42-sampler-cross':'ng42-pilot3','functional-negatives':'ng47-controls','default-init-negative':'default-negative','powered-init-negative':'powered-negative','ng47-settled-kcl':'kcl-final47-02','ng42-settled-kcl':'kcl-final42-02'}.items()}
checks={}
for name,p in roots.items():
 print('Review',name,flush=True);checks[name]=r.review(p)
(B/'raw-reviews.json').write_text(json.dumps(checks,indent=2)+'\n')
sources=['scripts/diagnose_pcie_zero_start_v3.py','scripts/check_pcie_startup_kcl_v3.py','scripts/review_pcie_zero_start_v3.py','sw/tests/test_pcie_zero_start_v3.py']
records={n:json.loads((p/'result.json').read_text()) for n,p in roots.items()}
source_pins={p:r.d.s.rx.tx.sha(Path(p)) for p in sources}
summary=dict(status='PASS_BOUNDED_COLD_STARTUP_PROTOCOL',source_sha256=source_pins,full_pvt={n:dict(cases=len(records[n]['cases']),clean=sum(x['diagnostics']['numerical_clean'] for x in records[n]['cases']),functional_pass=sum(x['measurement']['screen_pass'] for x in records[n]['cases']),worst_margin_v=min(x['measurement']['min_signed_margin_v'] for x in records[n]['cases'])) for n in ('ng47-rx-pvt','ng47-sampler-pvt')},cross_native_cases=6,kcl={n:records[n]['analysis'] for n in ('ng47-settled-kcl','ng42-settled-kcl')},functional_negatives=[dict(name=x['case']['name'],actual_functional_pass=x['measurement']['screen_pass'],margin_v=x['measurement']['min_signed_margin_v'],clean_start=x['diagnostics']['numerical_clean']) for x in records['functional-negatives']['cases'] if x['case']['fault']],initialization_controls={n:dict(status=records[n]['status'],cases=[dict(name=x['case']['name'],clean=x['diagnostics']['numerical_clean'],protocol_pass=x['protocol_pass'],error=x.get('error')) for x in records[n]['cases']]) for n in ('default-init-negative','powered-init-negative')},tests=54,raw_reviews=checks,limitations=['The1ns external rail/bias/input/clock ramp is a new explicit physical boundary condition, not a fitted model or implemented on-chip sequencer.','The OFF flag changes native initial Newton evaluation only; all native device equations remain active. Native current readbacks and real no-bias/wrong-output controls enforce that distinction.','Short127-bit18ns transient margins after cold start are not interchangeable with the old preheated DC-start margins.','A separate100ns static ramp and1us settling validates124zero-volt terminal ammeters and29-node KCL; it is not an8GHz steady thermal characterization.','Old fully powered direct operating-point initialization still fails and is preserved; no general ngspice/model fix is claimed.','Only explicitly retained waveforms were independently remeasured. Allcase raw logs,initialOP,OFFreadbacks,decks and byte pins are retained.','No PLL/CDR, fullPHY, extracted-layout performance or manufacturing approval.'],circuits_unchanged=True,models_unchanged=True,tolerances_unchanged=True,uic=False,physical_startup_circuit_implemented=False)
(B/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Keep all compact evidence; native full waves are split by scope below.
files={}
for label,root in roots.items():
 for p in root.rglob('*'):
  if p.is_file() and not p.name.endswith('.xz'):files['native/'+label+'/'+str(p.relative_to(root))]=p
for p in sources:files['methods/'+p]=Path(p)
for p in B.glob('*.json'):files['review/'+p.name]=p
files['review/collect_final.py']=Path(__file__)
for p in (B/'upstream').glob('*'):
 if p.is_file():files['upstream/'+p.name]=p
prior=Path('hw/soc/out/pcie-rx-v2-20261004/startup-diagnostics/upstream')
for n in ('ngspice42-devsup.c','ngspice42-vbicload.c','ngspice47-vbicload.c','sources.json'):files['upstream/initial-residual/'+n]=prior/n
inputs={p:h for data in records.values() for p,h in data['source_sha256'].items()}
for p in inputs:
 q=Path(p)
 if '/libs.tech/' in p:files['inputs/libs.tech/'+p.split('/libs.tech/',1)[1]]=q
 elif p.startswith(str(Path.cwd())) and p.endswith('.py'):files['inputs/'+str(q.relative_to(Path.cwd()))]=q
notice='''Native startup v3 evidence\nProject Python scripts/reports: Copyright2026HasanMelihAkbulut,Apache-2.0 (reportsCC-BY-4.0).\nGenerated native circuit files: Copyright2026HasanMelihAkbulut,CERN-OHL-W-2.0.\nIHP PDK sources retain originalApache-2.0/PDK notices in eachfile.\nngspice sources retain their originalBSD-style/SPDX/copyright notices; see sourceheaders.\nNo runtime executable or compiledOSDI is redistributed.\nNative waveformcapsules are separate; complete member inventories and raw-byteSHA256are below.\n'''
(B/'NOTICES.txt').write_text(notice)
files['NOTICES.txt']=B/'NOTICES.txt'
licenses=['LICENSES/Apache-2.0.txt','LICENSES/CERN-OHL-W-2.0.txt','LICENSES/BSD-3-Clause.txt','LICENSES/CC-BY-4.0.txt']
for p in licenses:
 if Path(p).exists():files[p]=Path(p)

def pack(path,members):
 inv={n:dict(bytes=p.stat().st_size,sha256=r.d.s.rx.tx.sha(p)) for n,p in sorted(members.items())}
 with tarfile.open(path,'w:xz',preset=6) as tar:
  for n,p in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
   with p.open('rb') as f:tar.addfile(info,f)
  data=(json.dumps(inv,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 with tarfile.open(path,'r:xz') as tar:
  for n,item in inv.items():
   f=tar.extractfile(n);h=hashlib.sha256();count=0
   while b:=f.read(1024*1024):h.update(b);count+=len(b)
   assert h.hexdigest()==item['sha256'] and count==item['bytes']
 return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=r.d.s.rx.tx.sha(path),members=len(inv)+1,roundtrip_verified=True)
cap=pack(B/'zero-start-v3-native-compact.tar.xz',files)
wave_caps=[]
for group,names in [('positive',['ng47-rx-pvt','ng47-sampler-pvt']),('cross-kcl',['ng42-rx-cross','ng42-sampler-cross','ng47-settled-kcl','ng42-settled-kcl']),('negative',['functional-negatives','default-init-negative','powered-init-negative'])]:
 members={'native/'+name+'/'+str(p.relative_to(roots[name])):p for name in names for p in roots[name].rglob('wave.dat.xz')}
 wave_caps.append(pack(B/('zero-start-v3-waves-'+group+'.tar.xz'),members))
validation=dict(status='FROZEN_NATIVE_EVIDENCE',source_sha256=source_pins,input_sha256=inputs,summary_sha256=r.d.s.rx.tx.sha(B/'summary.json'),compact_capsule=cap,wave_capsules=wave_caps,native_executions=sum(len(x.get('cases',[None])) for x in records.values()),source_validation=dict(pytest_passed=54,ruff='PASS'),raw_result_sha256={n:r.d.s.rx.tx.sha(p/'result.json') for n,p in roots.items()},reviewer_sha256=r.d.s.rx.tx.sha(Path(r.__file__)),all_frozen_sources_unchanged=all(r.d.s.rx.tx.sha(Path(p))==h for p,h in source_pins.items()))
(B/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(validation,indent=2),flush=True)
