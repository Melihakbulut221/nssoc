import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-clocked-bank-v3-01/nssoc_pcie_clocked_bank4_v3.gds')
c=l.cell('nssoc_pcie_clocked_bank4_v3')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-clocked-bank-checks-01/offgrid/wrong.gds')
