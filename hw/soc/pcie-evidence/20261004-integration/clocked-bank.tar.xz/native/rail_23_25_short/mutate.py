import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-clocked-bank-v3-01/nssoc_pcie_clocked_bank4_v3.gds')
c=l.cell('nssoc_pcie_clocked_bank4_v3')
c.shapes(l.layer(134,0)).insert(pya.DBox(1110.0,1,1620.0,3))
l.write('/dev/shm/nssoc-clocked-bank-checks-01/rail_23_25_short/wrong.gds')
