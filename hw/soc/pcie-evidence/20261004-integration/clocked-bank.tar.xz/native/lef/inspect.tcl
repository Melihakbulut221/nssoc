read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-clocked-bank-v3-01/nssoc_pcie_clocked_bank4_v3.lef}
set master [[ord::get_db] findMaster nssoc_pcie_clocked_bank4_v3]
if {$master eq "NULL"} {error "Clocked bank master missing"}
if {[$master getWidth] != 1650000 || [$master getHeight] != 3000000} {error "Clocked bank outline changed"}
if {[llength [$master getMTerms]] != 54} {error "Analog terminal census changed"}
set term [$master findMTerm L0_TX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 79000 2000 81000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 79000 1650000 81000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_OUTP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 87000 1650000 89000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_OUTN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 87000 2000 89000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_TX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 51000 2000 53000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 264000 2000 266000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 264000 1650000 266000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 236000 2000 238000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_RX_VCM]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 352000 1650000 354000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_QP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 485030 1650000 487030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_QN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 495030 1650000 497030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L0_SAMPLER_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 555030 2000 557030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 739000 2000 741000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 739000 1650000 741000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_OUTP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 747000 1650000 749000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_OUTN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 747000 2000 749000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_TX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 711000 2000 713000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 924000 2000 926000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 924000 1650000 926000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 896000 2000 898000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_RX_VCM]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1012000 1650000 1014000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_QP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1145030 1650000 1147030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_QN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1155030 1650000 1157030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L1_SAMPLER_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1215030 2000 1217030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1399000 2000 1401000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1399000 1650000 1401000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_OUTP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1407000 1650000 1409000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_OUTN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1407000 2000 1409000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_TX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1371000 2000 1373000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1584000 2000 1586000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1584000 1650000 1586000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1556000 2000 1558000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_RX_VCM]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1672000 1650000 1674000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_QP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1805030 1650000 1807030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_QN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 1815030 1650000 1817030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L2_SAMPLER_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1875030 2000 1877030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2059000 2000 2061000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 2059000 1650000 2061000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_OUTP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 2067000 1650000 2069000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_OUTN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2067000 2000 2069000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_TX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2031000 2000 2033000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_INP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2244000 2000 2246000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_INN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 2244000 1650000 2246000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2216000 2000 2218000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_RX_VCM]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 2332000 1650000 2334000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_QP]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 2465030 1650000 2467030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_QN]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 1648000 2475030 1650000 2477030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm L3_SAMPLER_IREF]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2535030 2000 2537030}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm AVDD1V8]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1088000 0 1092000 4000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm AVDD2V5]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1108000 0 1112000 4000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1128000 0 1132000 4000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1148000 0 1152000 4000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm AVDD2V3]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 1618000 0 1622000 4000}}} {error "Clocked bank terminal geometry differs"}
set term [$master findMTerm VCTRL]
if {$term eq "NULL"} {error "Clocked bank terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Clocked bank terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 2805030 2000 2807030}}} {error "Clocked bank terminal geometry differs"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "Clocked bank blockage layer census changed"}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
