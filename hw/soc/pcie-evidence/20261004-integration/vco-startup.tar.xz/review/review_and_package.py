# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,lzma,shutil,tempfile,tarfile,hashlib,io
sys.path.insert(0,'scripts');import diagnose_pcie_clock_zero_start_v2 as v
B=Path('hw/soc/out/pcie-vco-startup-20261004');parent=Path('/dev/shm/nssoc-clock-vco-full-20261004');root=Path('/dev/shm/nssoc-vco-zero-v2-full');record=json.loads((root/'result.json').read_text());pilot=Path('/dev/shm/nssoc-vco-zero-v2-pilot')
assert record['source_bytes_unchanged'] and len(record['cases'])==72 and record['clean_cases']==72
assert [x['case'] for x in record['cases']]==v.old.cases(False)
prior,pins=v.inputs(parent);assert pins==record['source_sha256']
transitive={str(v.startup.s.ROOT/p):h for p,h in v.startup.DEPENDENCIES.items()};assert all(v.old.sha(Path(p))==h for p,h in transitive.items())
models=[Path(p).parent for p in pins if Path(p).name=='cornerHBT.lib'][0];checked=[];raw_outputs=0
assert (root/'spinit').read_text()==v.SPINIT
for row in record['cases']:
 c=row['case'];d=root/c['name'];assert {p.name for p in d.iterdir()}==set(row['outputs'])
 for name,h in row['outputs'].items():assert v.old.sha(d/name)==h;raw_outputs+=1
 expected=v.transform(v.old.deck(c,models,[parent/n for n in v.MODELS]));assert (d/'bench.cir').read_text()==expected;assert (d/v.old.CIRCUIT.name).read_text()==v.old.circuit(c)
 log=(d/'run.log').read_text();assert v.old.diagnostics(log)==row['numerical'] and row['numerical']['clean'];assert v.read_flags(log)==row['flags_observed'];op=v.startup.initial_op(d/'initial-op.dat',v.old.vectors());assert op==row['initial_op'] and max(map(abs,op.values()))<=1e-10
 assert row['execution']['returncode']==0 and row['clean_initialization'];assert row['execution']['address_space_limit_bytes']==2*1024**3
 if row['wave_retained']:
  with tempfile.TemporaryDirectory(prefix='nssoc-vco-raw-review-',dir='/dev/shm') as td:
   wave=Path(td)/'wave.dat'
   with lzma.open(d/'wave.dat.xz','rb') as src,wave.open('wb') as dst:shutil.copyfileobj(src,dst)
   assert v.old.sha(wave)==row['uncompressed_wave_sha256'];assert v.old.measure(v.old.read_wave(wave))==row['measurement'];checked.append(c['name'])
 if c['fault']:assert row['expected_negative_rejected'] and not row['measurement']['screen_pass']
assert record['positive_characterization_failures']==[x['case']['name'] for x in record['cases'] if not x['case']['fault'] and not x['measurement']['screen_pass']]
assert record['negative_controls_rejected']
sources=['scripts/diagnose_pcie_clock_zero_start_v2.py','sw/tests/test_pcie_clock_zero_start_v2.py'];sourcepins={p:v.old.sha(Path(p)) for p in sources}
summary=dict(status=record['status'],source_sha256=sourcepins,native_cases=72,numerically_clean=72,positive_screen_passes=sum(not x['case']['fault'] and x['measurement']['screen_pass'] for x in record['cases']),positive_cases=68,real_negative_controls_rejected=4,original_dirty_positive_cases=sum(not x['numerical']['clean'] for x in prior['cases']),retained_native_waves_remeasured=checked,raw_outputs_rehashed=raw_outputs,source_inputs_rehashed=len(pins),transitive_source_sha256=transitive,nominal=record['cases'][0]['measurement'],physical_failures=[dict(name=x['case']['name'],measurement=x['measurement']) for x in record['cases'] if x['case']['name'] in record['positive_characterization_failures']],all_original_source_waveforms_unchanged=True,all_models_and_circuit_unchanged=True,limits_unchanged=True,limitations=['Only documented native HBT OFF initialization and explicit zero-OP/SHOW observations are added. Original VDD/VCTRL ramps, physical asymmetry and all solver tolerances remain unchanged.','The two original exploratory physical failures remain: no sustained oscillation at control1.30V and245.675microvolt XBN headroom deficit at hbt_bcs/mos_ss/125C.','Only nominal and failing hot retained waveforms were independently remeasured. All72 raw logs,OFFreadbacks,zeroOP,decks and output hashes were independently checked.','This is the original72-case finite exploratory sweep, not a full factorial PVT or statistical jitter/noise characterization.','No100MHz reference PLL, recovered clock, CDR, PHY or manufacturing acceptance.'],native_result_sha256=v.old.sha(root/'result.json'),parent_result_sha256=v.PARENT_SHA,pilot_result_sha256=v.old.sha(pilot/'result.json'))
(B/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for label,folder in [('full',root),('pilot',pilot)]:
 for p in folder.rglob('*'):
  if p.is_file() and not p.name.endswith('.xz'):files['native/'+label+'/'+str(p.relative_to(folder))]=p
for p in sources:files['methods/'+p]=Path(p)
for p in (Path(v.old.__file__),Path(v.startup.__file__)):
 files['methods/'+str(p.resolve().relative_to(Path.cwd()))]=p
for p in transitive:files['methods/'+str(Path(p).relative_to(Path.cwd()))]=Path(p)
files['original/result.json']=parent/'result.json';files['original/spinit']=parent/'spinit';files['review/summary.json']=B/'summary.json';files['review/review_and_package.py']=Path(__file__)
for p in pins:
 if '/libs.tech/' in p:files['inputs/libs.tech/'+p.split('/libs.tech/',1)[1]]=Path(p)
files['NOTICES.txt']=Path('hw/soc/out/pcie-startup-20261004/NOTICES.txt')
for n in ('Apache-2.0','CERN-OHL-W-2.0','BSD-3-Clause','CC-BY-4.0'):
 p=Path('LICENSES')/(n+'.txt')
 if p.exists():files[str(p)]=p

def pack(path,members):
 inventory={n:dict(bytes=p.stat().st_size,sha256=v.old.sha(p)) for n,p in sorted(members.items())}
 with tarfile.open(path,'w:xz',preset=6) as tar:
  for n,p in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
   with p.open('rb') as f:tar.addfile(info,f)
  data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 with tarfile.open(path,'r:xz') as tar:
  for n,r in inventory.items():
   f=tar.extractfile(n);h=hashlib.sha256();count=0
   while b:=f.read(1024*1024):h.update(b);count+=len(b)
   assert h.hexdigest()==r['sha256'] and count==r['bytes']
 return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=v.old.sha(path),members=len(inventory)+1,roundtrip_verified=True)
compact=pack(B/'vco-zero-start-v2-native-compact.tar.xz',files)
waves={'native/full/'+str(p.relative_to(root)):p for p in root.rglob('wave.dat.xz')};wave=pack(B/'vco-zero-start-v2-native-waves.tar.xz',waves)
validation=dict(status='FROZEN_NATIVE_REVIEW_PASS_WITH_PHYSICAL_LIMITS',source_sha256=sourcepins,compact_capsule=compact,wave_capsule=wave,summary_sha256=v.old.sha(B/'summary.json'),result_sha256=v.old.sha(root/'result.json'),source_inputs_sha256=pins,transitive_source_sha256=transitive,focused_tests=13,focused_plus_startup_tests=47,ruff='PASS',replay_source_sha256=v.old.sha(Path(__file__)))
(B/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(validation,indent=2))
