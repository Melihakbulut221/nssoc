# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Follow-up remaining native controls after the retained far-coupling failure."""
from pathlib import Path
import datetime, hashlib, json, os, re, resource, subprocess, sys, time
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc')
sys.path.insert(0,str(ROOT/'scripts'))
from audit_pcie_openrcx_fixture_v1 import audit
B=Path(__file__).parent
OUT=Path('/dev/shm/nssoc-pcie-openrcx-contract-final-04');OUT.mkdir()
PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
LEF=PDK/'libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef';RULES=PDK/'libs.tech/librelane/IHP_rcx_patterns.rules'
RUNTIME=ROOT/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
SOURCE=Path('/dev/shm/nssoc-pcie-openrcx-wires-probe-02/wires.def')
NEAR=Path('/dev/shm/nssoc-pcie-openrcx-coupling-probe-03/wire.def')
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
files=[Path(__file__),ROOT/'scripts/audit_pcie_openrcx_fixture_v1.py',LEF,RULES,RUNTIME,SOURCE,NEAR,B/'isolated-geometry.json',B/'coupled-geometry.json',PDK/'libs.doc/doc/SG13G2_os_process_spec.pdf']
before={str(p):pin(p) for p in files}
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'RUNNING','inputs':before,'cases':[],'qualified_rc':False}
def save(): (OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def limits():resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
save()
try:
 for name in ['grid200','short','open']:
  d=OUT/name;d.mkdir();coupled=name.startswith('coupled');text=(NEAR if coupled else SOURCE).read_text()
  if name=='coupled_far':
   assert text.count('10420')==4;text=text.replace('10420','12200')
  if name=='grid200':
   text=text.replace('MICRONS 1000','MICRONS 200')
   text=re.sub(r'\( (-?\d+) (-?\d+) \)',lambda m:f'( {int(m[1])//5} {int(m[2])//5} )',text)
  if name=='short':
   assert text.count('( 200000 400000 )')==2;text=text.replace('( 200000 400000 )','( 190000 400000 )')
  if name=='open':
   old='ROUTED Metal1 ( 100000 400000 ) ( 200000 400000 )';assert text.count(old)==1
   text=text.replace(old,'ROUTED Metal1 ( 100000 400000 ) ( 130000 400000 )\n NEW Metal1 ( 170000 400000 ) ( 200000 400000 )')
  (d/'wires.def').write_text(text)
  tcl=f'''set_thread_count 1
read_lef {{{LEF}}}
read_def {{{d/'wires.def'}}}
define_process_corner -ext_model_index 0 typical
extract_parasitics -ext_model_file {{{RULES}}} -coupling_threshold 0 -cc_model 10 -context_depth 5 -no_merge_via_res
write_spef {{{d/'wires.spef'}}}
write_db {{{d/'wires.odb'}}}
''';(d/'extract.tcl').write_text(tcl)
  command=[str(RUNTIME),'openroad','-exit',str(d/'extract.tcl')];start=time.monotonic()
  with (d/'native.log').open('x') as log:rc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits,start_new_session=True).returncode
  require_native=(rc==0 and (d/'wires.spef').is_file());assert require_native,(name,rc)
  geom=json.loads((B/('coupled-geometry.json' if coupled else 'isolated-geometry.json')).read_text())
  try:r=audit(d/'wires.spef',geom,coupling=coupled)
  except ValueError as exc:r={'status':'REJECTED_FIXTURE','error':str(exc)}
  negative=name in ['short','open'];expected=(r['status']=='REJECTED_FIXTURE') if negative else r['status'].startswith('PASS')
  row={'name':name,'command':command,'returncode':rc,'elapsed_seconds':time.monotonic()-start,'address_space_limit_bytes':1024**3,'elapsed_watchdog_seconds':None,'expected_negative':negative,'expected_outcome_observed':expected,'audit':r,'outputs':{p.name:pin(p) for p in d.iterdir() if p.is_file()}}
  record['cases'].append(row);save();assert expected,(name,r)
 prior=json.loads(Path('/dev/shm/nssoc-pcie-openrcx-contract-final-01/result.json').read_text())
 assert prior['status']=='FAIL' and len(prior['cases'])==3
 assert record['cases'][0]['audit']['nets']==prior['cases'][0]['audit']['nets']
 record['retained_failed_campaign']=prior
 assert before=={str(p):pin(p) for p in files},'Inputs changed'
 record['status']='PASS_REMAINING_GRID_AND_GEOMETRY_CONTROLS_COUPLING_QUALIFICATION_REMAINS_FAILED'
 record['limitations']=['Nominal rule export contract only; no qualified absolute capacitance/processcorner/via/RF model','Length includes physical halfwidth end extensions; not center-to-center terminal accuracy proof','Nominal sheet follows processspec14; LEF resistance uses sheet maxima, not nominal','No PDK/tool modifications or fullchip/timing acceptance']
except BaseException as exc:record.update(status='FAIL',error=repr(exc))
finally:save()
print(record['status']);sys.exit(int(record['status']=='FAIL'))
