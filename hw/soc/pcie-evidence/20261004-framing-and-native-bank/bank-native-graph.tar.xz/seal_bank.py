# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,tarfile,io,sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));from check_magic_hbt_multiplicity_v3 import pin
B=R/'hw/soc/out/pcie-magic-pad-stack-v1-20261004';O=Path('/dev/shm/nssoc-padded-clocked-pad-stack-01')
r=json.loads((B/'bank-review.json').read_text());assert r['device_inventory_equal'] and r['full_device_graph_equal'] and not r['disconnected_serial_port_incidence']
assert r['source_gds']['sha256']=='a6973418f56cb907d263854cc735466e0f8706b883f0247d9d398c4e39df0616'
native=json.loads((O/'result.json').read_text())
for path,sha in native['inputs'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha
for name,sha in native['outputs'].items():assert hashlib.sha256((O/name).read_bytes()).hexdigest()==sha
for name,value in r['outputs'].items():assert pin(O/name)==value
controls=json.loads((B/'full-graph-controls.json').read_text());assert len(controls['cases'])==6 and all(c['status']=='REJECTED_COMPLETE_GRAPH' for c in controls['cases'].values())
bijection=json.loads((B/'full-graph-bijection.json').read_text());assert bijection['nodes']==1541 and bijection['all_original_colors_and_edges_rechecked']
explanation=dict(status='PRESERVED_AUDIT_FALSE_NEGATIVE_NOT_EXTRACTION_FAILURE',receipt=pin(B/'bank-review-before-decimal-fix.json'),cause="An intermediate refinement accelerator classified Decimal('7E-8') and Decimal('7.0E-8') by repr text. They are exactly numerically equal. The final method uses hashable numeric colors and rechecks original color equality and every edge after search, with no tolerance/rounding.",first_slow_method=pin(B/'audit_bank_graph-vf2-first.py'),slow_method='Original NetworkX GraphMatcher search was terminated after about4min due parallel-device symmetry; it returned no verdict. Final VF2++ plus joint color refinement took less than1s and its total mapping is independently checked.',negative_controls=pin(B/'full-graph-controls.json'))
(B/'audit-correction.json').write_text(json.dumps(explanation,indent=2)+'\n')
files={}
for p in O.iterdir():
 if p.is_file():files['native/'+p.name]=p.read_bytes()
for name in ('bank-review.json','bank_attempt.py','audit_bank_graph.py','audit_bank_graph-vf2-first.py','bank-review-before-decimal-fix.json','audit-correction.json','full-graph-bijection.json','full-graph-controls.json','check_full_graph_controls.py','bank-graph.log','full-graph-controls.log','seal_bank.py','UPSTREAM-NOTICES.txt'):
 files[name]=(B/name).read_bytes()
for name in ('scripts/compare_magic_device_graph_v1.py','sw/tests/test_magic_device_graph_v1.py'):
 files['methods/'+name]=(R/name).read_bytes()
files['MANIFEST.json']=(json.dumps({n:dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in files.items()},indent=2)+'\n').encode()
p=B/'padded-bank-pad-stack-native.tar.xz'
with tarfile.open(p,'w:xz') as t:
 for n,d in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(d);m.mtime=0;t.addfile(m,io.BytesIO(d))
with tarfile.open(p) as t:
 assert len(t.getmembers())==len(files)
 for m in t.getmembers():assert t.extractfile(m).read()==files[m.name]
record=dict(status='PASS_COMPLETE_NATIVE_DEVICE_GRAPH_ONLY',source_gds=r['source_gds'],source_reference=r['source_reference'],device_inventory_equal=True,full_device_graph_equal=True,fixed_top_ports=56,devices=sum(r['reference_counts'].values()),bijection=pin(B/'full-graph-bijection.json'),graph_nodes=bijection['nodes'],graph_edges=bijection['edges'],reference_counts=r['reference_counts'],extracted_counts=r['extracted_counts'],isolated_method_receipt=pin(B/'validation.json'),raw_graph_audit=pin(B/'bank-review.json'),comparator_controls=pin(B/'full-graph-controls.json'),audit_false_negative_explanation=pin(B/'audit-correction.json'),capsule=dict(**pin(p),members=len(files),all_roundtrip_verified=True),qualified_pex=False,esd_stress_qualified=False,post_layout_rf_qualified=False,main_chip_adopted=False,limitations=['All351 native extracted source devices participate in the complete colored graph, with all56 named external ports fixed and all terminal edges checked.','Finite108ptap/one welltap and all32 ESD devices remain actual native elements; no assumed substrate joins or omitted device subset.','Only exact numeric equality, no tolerance/rounding. Resistor terminals may exchange, while transistor/MOS/MIM/ESD ordered terminals remain fixed.','Raw native rescaling/off-lambda snapping warnings remain unresolved; this connectivity result is not geometry metrology or qualified PEX.','No coupled-RC conservation/RF fanout timing/ESD-stress/8GT/s/mainchip acceptance.'])
q=B/'bank-validation.json';q.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({p.name:pin(p),q.name:pin(q)},indent=2))
