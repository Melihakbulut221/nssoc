# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Read-only real extracted full-bank graph mutations; no native replacement."""
from pathlib import Path
from decimal import Decimal
from copy import deepcopy
import runpy,json,sys,time
R=Path.cwd();B=R/'hw/soc/out/pcie-magic-pad-stack-v1-20261004'
z=runpy.run_path(str(B/'audit_bank_graph.py'));sys.path.insert(0,str(R/'scripts'))
from compare_magic_device_graph_v1 import exact_bijection
from check_magic_hbt_multiplicity_v3 import pin
cases={}
for name in ('wrong_hbt_terminal','body_tie','changed_value','missing_esd','serial_port_swap','missing_tap'):
 ds=deepcopy(z['ad'])
 if name=='wrong_hbt_terminal':
  d=next(d for d in ds if d['model']=='npn13g2' and len(set(d['nodes']))==4)
  before=deepcopy(d);d['nodes'][1],d['nodes'][2]=d['nodes'][2],d['nodes'][1]
 elif name=='body_tie':
  d=next(d for d in ds if d['model']=='ptap1');before=deepcopy(d);d['nodes'][1]=d['nodes'][0]
 elif name=='changed_value':
  d=next(d for d in ds if d['model']=='npn13g2');before=deepcopy(d);d['parameters']['we']=Decimal('7.1e-8')
 elif name=='missing_esd':
  d=next(d for d in ds if d['model']=='diodevss_2kv');before=deepcopy(d);ds.remove(d);d=None
 elif name=='missing_tap':
  d=next(d for d in ds if d['model']=='ptap1');before=deepcopy(d);ds.remove(d);d=None
 else:
  d=next(d for d in ds if d['model']=='diodevdd_2kv' and 'L0_TX_OUTP' in d['nodes']);before=deepcopy(d)
  d['nodes']=['L0_TX_OUTN' if n=='L0_TX_OUTP' else n for n in d['nodes']]
 start=time.monotonic();mapping=exact_bijection(z['left'],z['graph'](ds));assert mapping is None,name
 cases[name]=dict(status='REJECTED_COMPLETE_GRAPH',before=before,after=d,seconds=time.monotonic()-start)
record=dict(status='PASS_FULL_GRAPH_MUTATION_CONTROLS',cases=cases,raw_inputs={str(p):pin(p) for p in (z['V']/'schematic.cir',z['O']/'capacitance.spice',z['O']/'esd-geometry.json')},method=pin(__file__),comparator=pin(R/'scripts/compare_magic_device_graph_v1.py'),no_native_rerun=True)
(B/'full-graph-controls.json').write_text(json.dumps(record,indent=2,default=str)+'\n');print(record['status'])
