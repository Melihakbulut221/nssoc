#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Seal exact executed source/port/mutation evidence; no simulator rerun."""
import hashlib,io,json,pathlib,tarfile,xml.etree.ElementTree as ET,sys
R=pathlib.Path.cwd();B=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R/'sw/tests'));import test_pcie_gen3_framer as tests

def pin(p):
 p=pathlib.Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)
def xml(p):
 cases=list(ET.parse(p).getroot().iter('testcase'))
 return dict(passed=sum(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in cases),failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
freeze=json.loads((B/'source-freeze.json').read_text());members={};inputs={};caps=[]
for p,v in freeze['source_files'].items():assert pin(p)==v;members['sources/'+p]=R/p
roots=['nssoc-gen3-stp-rtl-final','nssoc-gen3-framer-rtl-final','nssoc-gen3-framer-maximum-rtl-final','nssoc-gen3-framed-path-rtl-final','nssoc-gen3-stp-native-final','nssoc-gen3-framer-native-final']
for name in roots:
 p=pathlib.Path('/dev/shm')/name;r=json.loads((p/'result.json').read_text());assert r['status']=='PASS_PORT_ONLY_PCIE_GEN3_FRAMER'
 assert r['tests']==xml(p/'results.xml') and r['tests']['passed']==r['expected_tests'] and r['tests']['failed']==r['tests']['skipped']==0
 for f,v in r['inputs'].items():assert pin(f)==v;inputs[f]=v
 for f,v in r['runtime'].items():assert pin(f)==v
 for f,v in r['outputs'].items():assert pin(p/f)==v;members['captures/'+name+'/'+f]=p/f
 members['captures/'+name+'/result.json']=p/'result.json'
 caps.append(dict(name=name,result=pin(p/'result.json'),top=r['top'],mode=r['mode'],capacity=r['max_encoded_bytes'],tests=r['tests'],mapped_cells=r.get('mapped_cells')))
mutations=[];M=pathlib.Path('/dev/shm/nssoc-gen3-framer-mutations-final')
for i,(name,module,old,new,top) in enumerate(tests.FAULTS):
 p=M/f'test_real_source_fault_rejecte{i}';r=json.loads((p/'capture/result.json').read_text());assert r['status']=='FAIL' and r['top']==top
 assert xml(p/'capture/results.xml')['failed']>0 and 'AssertionError' in (p/'capture/simulation.log').read_text()
 for src in tests.SOURCES:
  actual=(p/'rtl'/f'{src}.v').read_text();orig=(R/'hw/soc/rtl/pcie'/f'{src}.v').read_text()
  assert actual==(orig.replace(old,new) if src==module else orig)
 for f,v in r['inputs'].items():assert pin(f)==v
 for f,v in r['outputs'].items():assert pin(p/'capture'/f)==v
 for f in p.rglob('*'):
  if f.is_file() and 'sim' not in f.relative_to(p).parts and '__pycache__' not in f.parts:members['mutations/'+name+'/'+str(f.relative_to(p))]=f
 mutations.append(dict(name=name,module=module,top=top,old=old,new=new,receipt=pin(p/'capture/result.json'),xml=xml(p/'capture/results.xml')))
log=pathlib.Path('/dev/shm/nssoc-gen3-framer-mutations-final.log');assert '15 passed' in log.read_text();members['mutations/focused-tests.log']=log
for i,(p,v) in enumerate(sorted(inputs.items())):
 path=pathlib.Path(p)
 if path.is_relative_to(R):key='sources/'+str(path.relative_to(R))
 else:key=f'external-inputs/{i:03d}-{path.name}'
 members[key]=path
for name in ['Apache-2.0','CERN-OHL-W-2.0','CC-BY-4.0']:members['LICENSES/'+name+'.txt']=R/'LICENSES'/f'{name}.txt'
(B/'NOTICES.txt').write_text('Project sources/tests: Copyright 2026 Hasan Melih Akbulut, Apache-2.0. Generated evidence: CC-BY-4.0. IHP model/Liberty copies retain their original Apache-2.0 notices. No compiled runtime redistributed. Caller-supplied TLP LCRC/DLLP CRC bytes are preserved, not validated by this framer. STP CRC4 is generated and independently checked. No full PCIe controller/PHY/conformance or physical timing acceptance.\n')
for f in ['source-freeze.json','seal.py','NOTICES.txt']:members['review/'+f]=B/f
inventory={name:pin(p) for name,p in sorted(members.items())}
cap=B/'framer-source-native.tar.xz'
assert not cap.exists()
with tarfile.open(cap,'w:xz',preset=3) as t:
 for name,p in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
  with p.open('rb') as f:t.addfile(info,f)
 data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(cap) as t:
 assert set(t.getnames())==set(inventory)|{'inventory.json'}
 for name,v in inventory.items():
  assert t.getmember(name).size==v['bytes']
  with t.extractfile(name) as f:assert hashlib.file_digest(f,'sha256').hexdigest()==v['sha256']
result=dict(status='PASS_FROZEN_GEN3_TX_FRAMER_RTL_CORE_NATIVE_AND_ACTUAL_FAULTS',source_freeze=pin(B/'source-freeze.json'),sources=freeze['source_files'],capsule=dict(path=str(cap),**pin(cap),members=len(inventory)+1,all_members_roundtrip_verified=True),captures=caps,actual_faults=mutations,focused_tests=dict(passed=15,actual_hdl_faults=13,cli_bounds_controls=2,log=pin(log)),rtl_port_cases=11,native_port_cases=5,stp_vectors_per_mode=6144,contract=dict(input='8-bit complete encoded packets with accepted SOP/EOP/type/error/nullify flags',tlp='Two sequence-prefix bytes plus complete 3DW/4DW TLP optional payload/digest and caller-provided LCRC',dllp='Exactly six caller-provided DLLP bytes including CRC16',output='x4 full 64-symbol Data Blocks with header10, laneN gets symbol4k+N; zero IDL filling',quarantine='Complete packet shape validated before any packet block emission',nullification='Optional four C0 EDB symbols appended after complete supplied TLP/LCRC; STP length unchanged. Upstream sequence/LCRC nullification semantics are caller responsibility.',capacity_default=150,capacity_maximum_rtl_tested=4118,maximum_digest_limitation='4096-byte payload plus 4DW header plus digest plus LCRC and sequence totals4122 bytes and is rejected by the maximum4118 buffer.',idle='Continuous full IDL Data Blocks; registered output remains stable under stalls',wrapper='Optional frozen TXv3 scrambler/gearbox with all-byte advance/scrambling and no reseed'),scope=dict(core_native=True,combined_wrapper_native=False,maximum_capacity_native=False,formal=False,sdf_or_timing_signoff=False,mainchip_integrated=False,full_pcs_or_phy=False,ordered_sets_skp_training_ltssm=False,input_line_rate_claim=False),primary_rule=freeze['primary_rule'],primary_source_url=freeze['source_url'],input_inventory=inputs,peer_review_pending=True,source_unchanged_after_capture=all(pin(p)==v for p,v in freeze['source_files'].items()))
(B/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'capsule':result['capsule'],'validation':pin(B/'validation.json')},indent=2))
