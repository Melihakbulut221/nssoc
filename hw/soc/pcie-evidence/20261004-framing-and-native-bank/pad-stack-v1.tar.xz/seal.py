# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,sys,difflib,tarfile,io
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
import check_magic_pad_stack_v1 as c
import patch_magic_pad_stack_v1 as patch
from check_magic_hbt_multiplicity_v3 import pin
B=R/'hw/soc/out/pcie-magic-pad-stack-v1-20261004'
F=Path('/dev/shm/nssoc-magic-pad-stack-fixture-v1');N=Path('/dev/shm/nssoc-magic-pad-stack-native-v1-01')
OLD=Path('/dev/shm/nssoc-magic-esd-tech-final');NEW=Path('/dev/shm/nssoc-magic-pad-stack-tech-v1')
sources=[R/'scripts'/n for n in ('patch_magic_pad_stack_v1.py','make_magic_pad_stack_fixture_v1.py','audit_magic_pad_stack_geometry_v1.py','check_magic_pad_stack_v1.py','compare_magic_device_graph_v1.py')]+[R/'sw/tests'/n for n in ('test_magic_pad_stack_v1.py','test_magic_device_graph_v1.py')]
fixture=json.loads((F/'result.json').read_text());native=json.loads((N/'result.json').read_text());assert native['status']=='PASS_NATIVE_PAD_STACK_IMPORT_REPAIR'
assert set(native['cases'])=={'unfixed','nominal',*c.FAULTS}
for path,value in native['inputs'].items():assert pin(path)==value
for path,value in fixture['inputs'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==value
for name,value in fixture['outputs'].items():assert hashlib.sha256((F/name).read_bytes()).hexdigest()==value
for name,row in native['cases'].items():
 d=N/name
 for rel,value in row['outputs'].items():assert pin(d/rel)==value
 reread=c.assess((d/'pad_stack_flat.ext').read_text(),(d/'native.log').read_text(),fixture)
 assert reread==row['native'] and reread['partition']==c.expected_partition(name)
 geo=json.loads((d/'geometry.json').read_text());assert geo==row['reference']
 assert geo['partition']==c.expected_partition('nominal' if name=='unfixed' else name)
 assert row['execution']['returncode']==0 and row['geometry_execution']['returncode']==0
old={p.name:pin(p) for p in OLD.iterdir() if p.is_file()};new={p.name:pin(p) for p in NEW.iterdir() if p.is_file()}
assert set(old)==set(new);changed=[n for n in old if old[n]!=new[n]];assert changed==['ihp-sg13g2.tech']
assert patch.patch((OLD/'ihp-sg13g2.tech').read_bytes())==(NEW/'ihp-sg13g2.tech').read_bytes()
diff=''.join(difflib.unified_diff((OLD/'ihp-sg13g2.tech').read_text().splitlines(True),(NEW/'ihp-sg13g2.tech').read_text().splitlines(True),fromfile='before/ihp-sg13g2.tech',tofile='after/ihp-sg13g2.tech'))
(B/'native-pad-stack.diff').write_text(diff)
(B/'technology-audit.json').write_text(json.dumps(dict(before=old,after=new,changed=changed,no_runtime_change=True),indent=2)+'\n')
notice=(R/'hw/soc/out/pcie-magic-esd-v1-20261004/UPSTREAM-NOTICES.txt').read_text()+'\nPAD-STACK V1 ADDENDUM\nOnly two IHP technology paint rules changed; technology and native bondpad/via PCell-derived geometry remain Apache-2.0. Existing private Magic runtime is unchanged and is not redistributed here. Native extraction outputs and project methods retain the source/license provenance above.\n'
(B/'UPSTREAM-NOTICES.txt').write_text(notice)
entries={}
for label,root in (('fixture',F),('native',N),('technology',NEW)):
 for p in root.rglob('*'):
  if p.is_file():entries[label+'/'+str(p.relative_to(root))]=p.read_bytes()
for p in sources:entries['methods/'+str(p.relative_to(R))]=p.read_bytes()
for name in ('seal.py','native-pad-stack.diff','technology-audit.json','UPSTREAM-NOTICES.txt','probe.py'):
 entries[name]=(B/name).read_bytes()
entries['MANIFEST.json']=(json.dumps({n:dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in entries.items()},indent=2)+'\n').encode()
cap=B/'pad-stack-v1-native.tar.xz'
with tarfile.open(cap,'w:xz') as t:
 for name,data in sorted(entries.items()):
  m=tarfile.TarInfo(name);m.size=len(data);m.mtime=0;t.addfile(m,io.BytesIO(data))
with tarfile.open(cap) as t:
 assert len(t.getmembers())==len(entries)
 for m in t.getmembers():assert t.extractfile(m).read()==entries[m.name]
record=dict(status='PASS_ISOLATED_NATIVE_PAD_STACK_IMPORT_REPAIR',sources={str(p.relative_to(R)):pin(p) for p in sources},native=native,technology_audit=pin(B/'technology-audit.json'),ancestor_esd_receipt=pin(R/'hw/soc/out/pcie-magic-esd-v1-20261004/validation.json'),capsule=dict(**pin(cap),members=len(entries),all_roundtrip_verified=True),tests=dict(passed=143,own=38,ruff='PASS',command='PYTHONPATH=/dev/shm/nssoc-graph-audit-pythonpath PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm .venv/bin/python -m pytest sw/tests/test_magic_pad_stack_v1.py sw/tests/test_magic_device_graph_v1.py sw/tests/test_magic_esd_v1.py sw/tests/test_magic_finite_tap_v1.py -q -p no:cacheprovider',networkx_version='3.6.1',optional_graph_dependency='NetworkX tests require the exact native graph dependency; all9 ran locally using the existing installed package, no skipped tests.'),changes=['Only paint m6 obsm5 m6 -> paint m6 obsm6 m6, and equivalent m7 same-plane rule.','Real native pad/TopVia2 fixtures exercise both metal route directions across all8 rigid orientations.','Independent native KLayout connectivity matches all32 physical terminal partitions for nominal and all5 real GDS faults; original native Magic failure is preserved.'],limitations=['Isolated16-chain32-port wire fixture, not ESD stress, RF performance or qualified PEX.','No GDS geometry, devices, return paths, extraction coefficients or runtime changed.','Full bank graph and import-grid fidelity are separately audited; isolated result does not imply those gates.'],qualified_pex=False,esd_stress_qualified=False)
(B/'validation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({p.name:pin(p) for p in (cap,B/'validation.json')},indent=2))
