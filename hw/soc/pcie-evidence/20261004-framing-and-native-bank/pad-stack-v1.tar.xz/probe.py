# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from check_pcie_rx_cell import execute
F=Path('/dev/shm/nssoc-magic-pad-stack-fixture-v1');r=json.loads((F/'result.json').read_text());O=Path('/dev/shm/nssoc-magic-pad-stack-probe01');O.mkdir();rt=Path('/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib')
for name,tech in [('before','/dev/shm/nssoc-magic-esd-tech-final'),('after','/dev/shm/nssoc-magic-pad-stack-tech-v1')]:
 d=O/name;d.mkdir();lines=[f'cd {{{d}}}','drc off',f'gds read {{{F/"fixture.gds"}}}','load nssoc_pad_stack_fixture','flatten pad_stack_flat','load pad_stack_flat','select top cell']
 for i,(n,p) in enumerate(r['ports'].items(),1):
  lines+=['box values '+' '.join(str(x)+'um' for x in p['box']),f'label {n} center '+{126:'metal6',134:'metal7'}[p['layer']],f'port {n} make {i}',f'port {n} class inout',f'port {n} use signal']
 lines+=['save pad_stack_flat','extract style ngspice()','extract all','puts NSSOC_PAD_STACK_COMPLETE','quit -noprompt'];s=d/'native.tcl';s.write_text('\n'.join(lines)+'\n');x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',Path(tech)/'ihp-sg13g2.magicrc',s],d,'native');print(name,x)
