puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-magic-pad-stack-native-v1-01/wrong_layer}
drc off
gds read {/dev/shm/nssoc-magic-pad-stack-fixture-v1/wrong_layer.gds}
load nssoc_pad_stack_fixture
flatten pad_stack_flat
load pad_stack_flat
select top cell
box values 115.0um 115.0um 125.0um 125.0um
label PAD00 center metal7
port PAD00 make 1
port PAD00 class inout
port PAD00 use signal
box values 158.0um 199.0um 160.0um 201.0um
label CORE00 center metal6
port CORE00 make 2
port CORE00 class inout
port CORE00 use signal
box values 355.0um 115.0um 365.0um 125.0um
label PAD01 center metal7
port PAD01 make 3
port PAD01 class inout
port PAD01 use signal
box values 279.0um 158.0um 281.0um 160.0um
label CORE01 center metal6
port CORE01 make 4
port CORE01 class inout
port CORE01 use signal
box values 595.0um 115.0um 605.0um 125.0um
label PAD02 center metal7
port PAD02 make 5
port PAD02 class inout
port PAD02 use signal
box values 560.0um 39.0um 562.0um 41.0um
label CORE02 center metal6
port CORE02 make 6
port CORE02 class inout
port CORE02 use signal
box values 835.0um 115.0um 845.0um 125.0um
label PAD03 center metal7
port PAD03 make 7
port PAD03 class inout
port PAD03 use signal
box values 919.0um 80.0um 921.0um 82.0um
label CORE03 center metal6
port CORE03 make 8
port CORE03 class inout
port CORE03 use signal
box values 1075.0um 115.0um 1085.0um 125.0um
label PAD04 center metal7
port PAD04 make 9
port PAD04 class inout
port PAD04 use signal
box values 1118.0um 39.0um 1120.0um 41.0um
label CORE04 center metal6
port CORE04 make 10
port CORE04 class inout
port CORE04 use signal
box values 1315.0um 115.0um 1325.0um 125.0um
label PAD05 center metal7
port PAD05 make 11
port PAD05 class inout
port PAD05 use signal
box values 1399.0um 158.0um 1401.0um 160.0um
label CORE05 center metal6
port CORE05 make 12
port CORE05 class inout
port CORE05 use signal
box values 1555.0um 115.0um 1565.0um 125.0um
label PAD06 center metal7
port PAD06 make 13
port PAD06 class inout
port PAD06 use signal
box values 1520.0um 199.0um 1522.0um 201.0um
label CORE06 center metal6
port CORE06 make 14
port CORE06 class inout
port CORE06 use signal
box values 1795.0um 115.0um 1805.0um 125.0um
label PAD07 center metal7
port PAD07 make 15
port PAD07 class inout
port PAD07 use signal
box values 1719.0um 80.0um 1721.0um 82.0um
label CORE07 center metal6
port CORE07 make 16
port CORE07 class inout
port CORE07 use signal
box values 115.0um 355.0um 125.0um 365.0um
label PAD08 center metal7
port PAD08 make 17
port PAD08 class inout
port PAD08 use signal
box values 158.0um 439.0um 160.0um 441.0um
label CORE08 center metal6
port CORE08 make 18
port CORE08 class inout
port CORE08 use signal
box values 355.0um 355.0um 365.0um 365.0um
label PAD09 center metal7
port PAD09 make 19
port PAD09 class inout
port PAD09 use signal
box values 279.0um 398.0um 281.0um 400.0um
label CORE09 center metal6
port CORE09 make 20
port CORE09 class inout
port CORE09 use signal
box values 595.0um 355.0um 605.0um 365.0um
label PAD10 center metal7
port PAD10 make 21
port PAD10 class inout
port PAD10 use signal
box values 560.0um 279.0um 562.0um 281.0um
label CORE10 center metal6
port CORE10 make 22
port CORE10 class inout
port CORE10 use signal
box values 835.0um 355.0um 845.0um 365.0um
label PAD11 center metal7
port PAD11 make 23
port PAD11 class inout
port PAD11 use signal
box values 919.0um 320.0um 921.0um 322.0um
label CORE11 center metal6
port CORE11 make 24
port CORE11 class inout
port CORE11 use signal
box values 1075.0um 355.0um 1085.0um 365.0um
label PAD12 center metal7
port PAD12 make 25
port PAD12 class inout
port PAD12 use signal
box values 1118.0um 279.0um 1120.0um 281.0um
label CORE12 center metal6
port CORE12 make 26
port CORE12 class inout
port CORE12 use signal
box values 1315.0um 355.0um 1325.0um 365.0um
label PAD13 center metal7
port PAD13 make 27
port PAD13 class inout
port PAD13 use signal
box values 1399.0um 398.0um 1401.0um 400.0um
label CORE13 center metal6
port CORE13 make 28
port CORE13 class inout
port CORE13 use signal
box values 1555.0um 355.0um 1565.0um 365.0um
label PAD14 center metal7
port PAD14 make 29
port PAD14 class inout
port PAD14 use signal
box values 1520.0um 439.0um 1522.0um 441.0um
label CORE14 center metal6
port CORE14 make 30
port CORE14 class inout
port CORE14 use signal
box values 1795.0um 355.0um 1805.0um 365.0um
label PAD15 center metal7
port PAD15 make 31
port PAD15 class inout
port PAD15 use signal
box values 1719.0um 320.0um 1721.0um 322.0um
label CORE15 center metal6
port CORE15 make 32
port CORE15 class inout
port CORE15 use signal
save pad_stack_flat
extract style ngspice()
extract all
puts NSSOC_PAD_STACK_COMPLETE
quit -noprompt
