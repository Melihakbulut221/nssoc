from pathlib import Path
import sys,json
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from check_pcie_rx_cell import execute
import check_magic_hbt_multiplicity_v3 as h
B=Path('/dev/shm/nssoc-magic-esd-v1-build-final');T=Path('/dev/shm/nssoc-magic-esd-tech-final')
F=Path('/dev/shm/nssoc-magic-hbt-axis-01');A=Path('/dev/shm/nssoc-magic-esd-hbt-regression-final');A.mkdir();script=A/'native.tcl';script.write_text(h.native_tcl(F/'fixture.gds',json.loads((F/'result.json').read_text()),A));rt=B/'runtime/lib'
x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',script],A,'native');assert x['returncode']==0
rows=[s.split() for s in h.spice_lines((A/'hbt.spice').read_text())];taps=[r for r in rows if len(r)>3 and r[3]=='ptap1'];hbts=[r for r in rows if len(r)>5 and r[5]=='npn13g2'];assert len(taps)==1 and len(hbts)==24
body=taps[0][2];assert taps[0][1]=='SUB' and body!='SUB' and dict(t.split('=') for t in taps[0][4:])==dict(w='2u',l='2u',r='81.6667')
observed=sorted((tuple(r[1:5]),tuple(sorted(dict(t.split('=') for t in r[6:]).items()))) for r in hbts)
expected=sorted(((f'C_N{n}_T{o}',f'B_N{n}_T{o}',f'E_N{n}_T{o}',body),tuple(sorted(dict(we='70n',le='0.9u',Nx=str(n)).items()))) for n in (1,2,4) for o in range(8));assert observed==expected
assert set(rows[0][2:])==set(h.PORTS) and len(rows[0][2:])==73
(A/'result.json').write_text(json.dumps(dict(status='PASS24_HBTS_BOUND_TO_FINITE_TAP_BODY_73PORTS',execution=x,inputs={str(p):h.pin(p) for p in [Path(__file__),F/'fixture.gds',F/'result.json',rt/'magic/tcl/tclmagic.so',T/'ihp-sg13g2-extract.tech']},observed=observed,tap=taps[0],outputs={p.name:h.pin(p) for p in A.iterdir() if p.is_file()},qualified_pex=False),indent=2)+'\n')
