# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,hashlib,difflib,tarfile,io
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));import check_magic_hbt_multiplicity_v3 as h;import check_magic_esd_v1 as c
B=R/'hw/soc/out/pcie-magic-esd-v1-20261004';P=Path('/dev/shm/nssoc-finite-tap-v1-build-final');F=Path('/dev/shm/nssoc-magic-esd-v1-build-final');T=Path('/dev/shm/nssoc-magic-esd-tech-final')
sources=[R/'scripts'/n for n in ('patch_magic_esd_v1.py','make_magic_esd_fixture_v1.py','check_magic_esd_v1.py','audit_magic_esd_geometry_v1.py')]+[R/'sw/tests/test_magic_esd_v1.py']
old={str(p.relative_to(P/'source')):h.pin(p) for p in (P/'source').rglob('*') if p.is_file() and p.suffix in ('.c','.h')};new={str(p.relative_to(F/'source')):h.pin(p) for p in (F/'source').rglob('*') if p.is_file() and p.suffix in ('.c','.h')};assert set(old)==set(new);changed=[p for p in old if old[p]!=new[p]];assert set(changed)=={'cif/CIFrdtech.c','cif/CIFgen.c'}
(B/'private-source-build-audit.json').write_text(json.dumps(dict(c_and_headers_checked=len(old),changed=changed,headers_and_abi_unchanged=True,before=old,after=new,build=json.loads((F/'result.json').read_text())),indent=2)+'\n')
diff=''.join(''.join(difflib.unified_diff((P/'source'/n).read_text().splitlines(True),(F/'source'/n).read_text().splitlines(True),fromfile='before/'+n,tofile='after/'+n)) for n in changed)
for n in ('ihp-sg13g2.tech','ihp-sg13g2-cifin.tech','ihp-sg13g2-extract.tech'):
 diff+=''.join(difflib.unified_diff((Path('/dev/shm/nssoc-finite-tap-tech-final')/n).read_text().splitlines(True),(T/n).read_text().splitlines(True),fromfile='before/'+n,tofile='after/'+n))
(B/'native-esd.diff').write_text(diff)
roots={'native':Path('/dev/shm/nssoc-magic-esd-native-final05'),'fixture':Path('/dev/shm/nssoc-magic-esd-fixture-final02'),'klayout':Path('/dev/shm/nssoc-magic-esd-klayout-final02'),'prior-klayout':Path('/dev/shm/nssoc-magic-esd-klayout-final'),'operator':Path('/dev/shm/nssoc-magic-esd-operator-final04'),'tap-regression':Path('/dev/shm/nssoc-magic-esd-tap-regression-final'),'hbt-regression':Path('/dev/shm/nssoc-magic-esd-hbt-regression-final'),'launch':Path('/dev/shm/nssoc-magic-esd-launch-final')}
r=json.loads((roots['native']/'result.json').read_text());assert r['status']=='PASS_ISOLATED_NATIVE_ESD_CONTROLS';fixture=json.loads((roots['fixture']/'result.json').read_text())
for path,pin in r['inputs'].items():assert h.pin(path)==pin
for name,row in r['cases'].items():
 d=roots['native']/name
 for n,pin in row['outputs'].items():assert h.pin(d/n)==pin
 assert row['execution']['returncode']==0
 try:v=c.assess((d/'esd.spice').read_text(),(d/'esd_flat.ext').read_text(),(d/'native.log').read_text(),fixture)
 except ValueError as e:assert name in c.FAULTS and str(e)==row['outcome']['reason']
 else:assert name not in c.FAULTS and v['count']==32 and v['ports']==65
 g=json.loads((d/'geometry.json').read_text());assert (g['status']=='PASS_FIXED_NATIVE_ESD_MASKS')==(name not in ('width_vdd','width_vss','excluded_geometry','well_split'))
 for path,sha in g['inputs'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha
k=json.loads((roots['klayout']/'result.json').read_text());assert k['fixture']['audit']['returncode']==0 and k['well_split']['audit']['returncode']==1
prior=json.loads((roots['prior-klayout']/'result.json').read_text());assert {n:x['audit']['returncode'] for n,x in prior.items()}==dict(fixture=0,removed_device=1,pad_open=1,pad_short=1,collector_open=1,width_vdd=0)
ka=json.loads((roots['klayout']/'fixture/audit.json').read_text());assert ka['circuits'][0]['layout_devices_recursive']==32
op=json.loads((roots['operator']/'result.json').read_text());assert op['status']=='PASS_ACTUAL_NATIVE_OPERATOR_REGRESSION'
c.operator_assess((roots['operator']/'fixed/interact_probe.mag').read_text(),json.loads((roots['fixture']/'interact-expected.json').read_text()))
for name,x in op['cases'].items():
 for n,pin in x['outputs'].items():assert h.pin(roots['operator']/name/n)==pin
for kind in ('tap-regression','hbt-regression'):
 z=json.loads((roots[kind]/'result.json').read_text());assert z['status'].startswith('PASS')
bridge=json.loads((roots['launch']/'geometry-bridge.json').read_text());assert all(x['all_actual_geometry_xor_zero'] for x in bridge['cases'].values())
notice=(R/'hw/soc/out/pcie-magic-finite-tap-v1-20261004/UPSTREAM-NOTICES.txt').read_text()+'\nESD V1 ADDENDUM\nModified CIFgen.c and CIFrdtech.c retain the original UC Regents permission notice reproduced in each file. IHP technology and native PCell-derived geometry remain Apache-2.0. Only project methods, technology/source diff and source-bound native evidence are included. No runtime/AppImage/OSDI or foundry simulation-model binary is redistributed. Native semiconductor mask references derive from the pinned IHP esd PCell under Apache-2.0; they reject unsupported shapes and never construct terminal nodes.\n'
(B/'UPSTREAM-NOTICES.txt').write_text(notice)
entries={}
def add(n,p):
 assert n not in entries;entries[n]=Path(p).read_bytes()
for label,d in roots.items():
 for p in d.rglob('*'):
  if p.is_file():add(label+'/'+str(p.relative_to(d)),p)
for p in sources:add('methods/'+str(p.relative_to(R)),p)
for n in changed:
 add('private-source/before/'+n,P/'source'/n);add('private-source/after/'+n,F/'source'/n)
for p in T.iterdir():
 if p.is_file():add('technology/'+p.name,p)
for p in F.iterdir():
 if p.is_file():add('build/'+p.name,p)
for name in ('nssoc-magic-esd-fixture-01','nssoc-magic-esd-fixture-02','nssoc-magic-esd-overlay-01','nssoc-magic-esd-overlay-02','nssoc-magic-esd-overlay-03','nssoc-magic-esd-overlay-04','nssoc-magic-esd-overlay-05','nssoc-magic-esd-overlay-06','nssoc-magic-esd-native-final01','nssoc-magic-esd-native-final02','nssoc-magic-esd-native-final03','nssoc-magic-esd-native-final04','nssoc-magic-esd-operator-final','nssoc-magic-esd-operator-final02'):
 d=Path('/dev/shm')/name
 for p in d.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.log','.ext','.spice','.tcl') and 'tech' not in p.relative_to(d).parts:add('preserved-diagnostics/'+name+'/'+str(p.relative_to(d)),p)
for p in B.iterdir():
 if p.is_file() and p.suffix in ('.py','.json','.diff','.txt') and p.name not in ('validation.json','bank-review.json'):add('reproduction/'+p.name,p)
manifest={n:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for n,data in entries.items()};entries['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
cap=B/'esd-v1-native.tar.xz'
with tarfile.open(cap,'w:xz') as tf:
 for n,data in sorted(entries.items()):
  m=tarfile.TarInfo(n);m.size=len(data);m.mtime=0;tf.addfile(m,io.BytesIO(data))
with tarfile.open(cap) as tf:
 assert len(tf.getmembers())==len(entries)
 for m in tf.getmembers():assert tf.extractfile(m).read()==entries[m.name]
record=dict(status='PASS_ISOLATED_NATIVE_ESD_GEOMETRY_AND_TERMINALS_ONLY',sources={str(p.relative_to(R)):h.pin(p) for p in sources},native=r,klayout=ka,prior_klayout_results={n:x['audit']['returncode'] for n,x in prior.items()},prior_geometry_bridge=bridge,operator_controls=op,private_build_audit=h.pin(B/'private-source-build-audit.json'),runtime=h.pin(F/'runtime/lib/magic/tcl/tclmagic.so'),regressions={k:json.loads((roots[k]/'result.json').read_text()) for k in ('tap-regression','hbt-regression')},capsule=dict(**h.pin(cap),members=len(entries),all_roundtrip_verified=True),tests=dict(passed=149,own=56,ruff='PASS',command='PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm .venv/bin/python -m pytest sw/tests/test_magic_esd_v1.py sw/tests/test_magic_finite_tap_v1.py sw/tests/test_magic_hbt_multiplicity_v3.py -q -p no:cacheprovider'),changes=['Enable existing native interacting/noninteracting geometry operators in CIF input parser.','Fix existing native region-copy walk: marked tiles must enqueue unconditionally; no changes to its geometry selection predicate.','Recognition uses real ESDID/emitter/well geometry and a separate marker plane. All physical well/diffusion masks and existing substrate/tap connectivity remain intact.','A conservative exact native semiconductor-mask gate rejects unsupported or split well/ring shapes. Device and CBE-like terminal identities still come only from native electrical extraction.'],limitations=['Only ordinary diodevdd_2kv/diodevss_2kv:32 actual PCells,65ports,all8 orientations twice; no general ESD family or stress model qualification.','Raw ea/ep are retained geometry annotations and are not silently passed as supported foundry compact-model parameters.','Native KLayout width control passes due ESD area normalization; actual Magic emitter-area guard and raw-mask gate reject it. All other sampled physical node/open/short/removal/split-well faults fail both supported audits.','Both import runs finish on the actual5nm ESD grid:10nm starting grid is refined by native import. This is not two distinct final-grid coverage.','No full-bank graph, coupled RC conservation, RF fullPEX, package/ESD stress,8GHz clock/PHY qualification or mainchip adoption.','The prior fixture regeneration changed GDS bytes; all9 prior complete mask sets were independently checked zero XOR and their exact before/after hashes preserved; newest baseline and split-well ran exact new GDS through native LVS.','Original PDK and all frozen ancestors remain unchanged. All559 C/header inputs audited: only2C files differ, no ABI/header changes.'],qualified_pex=False,full_bank_qualified=False,esd_stress_qualified=False)
(B/'validation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({x.name:h.pin(x) for x in (cap,B/'validation.json')},indent=2))
