# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import shutil,json,sys
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')];from check_pcie_rx_cell import execute;from check_magic_hbt_multiplicity_v3 import pin
from patch_magic_esd_v1 import patch
P=Path('/dev/shm/nssoc-finite-tap-v1-build-final');O=Path('/dev/shm/nssoc-magic-esd-v1-build-final');O.mkdir();S=O/'source';shutil.copytree(P/'source',S)
for name in ('CIFrdtech.c','CIFgen.c'):
 f=S/'cif'/name;f.write_bytes(patch(name,f.read_bytes()))
runs=[]
for cmd in [['make','-C',str(S/'cif'),'module'],['make','-C',str(S/'magic'),'tcl-main']]:
 x=execute(cmd,O,'build'+str(len(runs)));runs.append(x);assert x['returncode']==0
RT=O/'runtime/lib';shutil.copytree(P/'runtime/lib',RT);shutil.copyfile(S/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so')
T=Path('/dev/shm/nssoc-magic-esd-tech-final');shutil.copytree('/dev/shm/nssoc-finite-tap-tech-final',T)
for name in ('ihp-sg13g2.tech','ihp-sg13g2-cifin.tech','ihp-sg13g2-extract.tech'):
 f=T/name;f.write_bytes(patch(name,f.read_bytes()))
(O/'result.json').write_text(json.dumps(dict(parent=pin(P/'result.json'),method=pin(__file__),patcher=pin(R/'scripts/patch_magic_esd_v1.py'),runs=runs,runtime=pin(RT/'magic/tcl/tclmagic.so'),sources={str(f.relative_to(S)):pin(f) for f in [S/'cif/CIFrdtech.c',S/'cif/CIFgen.c']},technology={f.name:pin(f) for f in T.iterdir() if f.is_file()},qualified=False),indent=2)+'\n')
