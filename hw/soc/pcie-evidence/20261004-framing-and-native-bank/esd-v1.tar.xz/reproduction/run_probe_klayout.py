# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R/'hw/soc/flow'));from check_pcie_rx_cell import execute
V=Path('/dev/shm/nssoc-magic-esd-fixture-02');O=Path('/dev/shm/nssoc-magic-esd-klayout-02');O.mkdir();A=R/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage';rows={}
for name in ('fixture',):
 d=O/name;d.mkdir();cmd=[A,'klayout','-b','-zz','-r',R/'hw/soc/tools/ihp-lvs-5e6d592/ihp-sg13g2/libs.tech/klayout/tech/lvs/sg13g2.lvs']
 for value in ['input='+str(V/(name+'.gds')),'topcell=esd_probe','schematic='+str(V/'schematic.cir'),'report='+str(d/'result.lvsdb'),'target_netlist='+str(d/'extracted.cir'),'log='+str(d/'deck.log'),'run_mode=deep','thr=2']:cmd+=['-rd',value]
 x=execute(cmd,d,'native');y=execute([A,'python',R/'hw/soc/flow/audit_klayout_lvs.py',d/'result.lvsdb','--top','esd_probe','--deck-log',d/'deck.log','--output',d/'audit.json'],d,'audit');rows[name]=dict(native=x,audit=y)
(O/'result.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows)
