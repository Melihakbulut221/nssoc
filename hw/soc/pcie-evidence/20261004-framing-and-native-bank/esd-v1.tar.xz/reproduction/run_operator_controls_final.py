# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,shutil
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from check_pcie_rx_cell import execute
from check_magic_esd_v1 import operator_assess
from check_magic_hbt_multiplicity_v3 import pin
F=Path('/dev/shm/nssoc-magic-esd-fixture-final02');O=Path('/dev/shm/nssoc-magic-esd-operator-final04');O.mkdir();T=O/'tech';shutil.copytree('/dev/shm/nssoc-magic-esd-tech-final',T)
p=T/'ihp-sg13g2.tech';s=p.read_text().replace('  esddevice esdpnp\n','  esddevice esdpnp\n  comment esd_interact_yes\n  passiv esd_interact_no\n');p.write_text(s)
p=T/'ihp-sg13g2-cifin.tech';s=p.read_text();s=s.replace(' layer nwell NWELL,WELLPIN\n',' layer esd_interact_yes ITESTA\n interacting ITESTB\n layer esd_interact_no ITESTA\n noninteracting ITESTB\n layer nwell NWELL,WELLPIN\n');s=s.replace(' calma NWELL 31 0\n',' calma ITESTA 200 0\n calma ITESTB 201 0\n calma NWELL 31 0\n');p.write_text(s)
rows={}
for name,rt in [('unfixed','/dev/shm/nssoc-magic-esd-parser-build-01/runtime/lib'),('fixed','/dev/shm/nssoc-magic-esd-v1-build-final/runtime/lib')]:
 d=O/name;d.mkdir();rt=Path(rt);s=d/'native.tcl';s.write_text(f'puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"\ncd {{{d}}}\ndrc off\ngds read {{{F/"interact.gds"}}}\nload interact_probe\nsave interact_probe\nputs NSSOC_OPERATOR_COMPLETE\nquit -noprompt\n');x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',s],d,'native');assert x['returncode']==0;assert (d/'native.log').read_text().count('NSSOC_OPERATOR_COMPLETE')==1
 try:y=operator_assess((d/'interact_probe.mag').read_text(),json.loads((F/'interact-expected.json').read_text()))
 except ValueError as e:
  assert name=='unfixed' and str(e)=='Native interaction copied an empty region';y=dict(status='REJECTED_REAL_UPSTREAM_EMPTY_COPY',reason=str(e))
 else:assert name=='fixed'
 rows[name]=dict(execution=x,assessment=y,runtime=pin(rt/'magic/tcl/tclmagic.so'),outputs={p.name:pin(p) for p in d.iterdir() if p.is_file()})
(O/'result.json').write_text(json.dumps(dict(status='PASS_ACTUAL_NATIVE_OPERATOR_REGRESSION',method=pin(__file__),reader=pin(R/'scripts/check_magic_esd_v1.py'),cases=rows,technology={p.name:pin(p) for p in T.iterdir() if p.is_file()}),indent=2)+'\n');print(rows['fixed']['assessment'])
