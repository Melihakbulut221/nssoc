# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,hashlib
R=Path.cwd();O=Path('/dev/shm/nssoc-magic-esd-fixture-01');O.mkdir();PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2');P=PDK/'libs.tech/klayout/python';sys.path[:0]=[str(P),str(P/'pycell4klayout-api/source/python')];sys.dont_write_bytecode=True
import pya
import sg13g2_pycell_lib
l=pya.Layout();top=l.create_cell('esd_probe');ports={};instances=[];shapes={};bodies=[]
for index,model in enumerate(('diodevdd_2kv','diodevss_2kv')):
 c=l.create_cell('esd','SG13_dev',{'model':model});assert c and not c.is_empty();t=pya.DTrans(20+index*40,20);top.insert(pya.DCellInstArray(c.cell_index(),t));ps={layer:sorted([s.dbbox() for s in c.each_shape(l.layer(layer,2))],key=lambda b:b.center().x) for layer in (8,10)};assert len(ps[8])==1 and len(ps[10])==2
 mapping={'PAD':(10,ps[10][0]),'VDD':(10,ps[10][1]),'VSS':(8,ps[8][0])} if index==0 else {'PAD':(10,ps[10][0]),'VSS':(10,ps[10][1]),'VDD':(8,ps[8][0])}
 for name,(layer,b) in mapping.items():
  n='SUB' if name=='VSS' else f'{name}{index}';b=b.transformed(t);top.shapes(l.layer(layer,2)).insert(b);top.shapes(l.layer(layer,25)).insert(pya.DText(n,pya.DTrans(b.center().x,b.center().y)));ports.setdefault(n,[]).append(dict(layer=layer,box=[b.left,b.bottom,b.right,b.top]))
 shapes[model]={str((info.layer,info.datatype)):[str(s.dbbox()) for s in c.each_shape(l.layer(info))] for info in l.layer_infos()}
 bodies.append(f'D{index} VDD{index} PAD{index} SUB {model} m=1')
l.write(str(O/'fixture.gds'));(O/'schematic.cir').write_text('.subckt esd_probe '+' '.join(ports)+'\n'+'\n'.join(bodies)+'\n.ends esd_probe\n');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=dict(ports=ports,shapes=shapes,inputs={str(p):sha(p) for p in [Path(__file__),*P.rglob('*.py'),*P.rglob('*.json')]},outputs={p.name:sha(p) for p in O.iterdir() if p.is_file()});(O/'result.json').write_text(json.dumps(r,indent=2)+'\n')
