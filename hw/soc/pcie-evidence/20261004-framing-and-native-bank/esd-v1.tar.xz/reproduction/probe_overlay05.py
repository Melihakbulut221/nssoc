# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,shutil
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')]
from check_pcie_rx_cell import execute
from check_magic_hbt_multiplicity_v3 import pin
O=Path('/dev/shm/nssoc-magic-esd-overlay-05');O.mkdir();T=O/'tech';shutil.copytree('/dev/shm/nssoc-finite-tap-tech-final',T)
p=T/'ihp-sg13g2.tech';s=p.read_text();s=s.replace('planes\n','planes\n  esddevice\n');s=s.replace('  well nbase,pnp\n','  well nbase,pnp\n  esddevice esdpnp\n  esddevice esdnpn\n');s=s.replace('connect\n  *nwell', 'connect\n  esdpnp,esdnpn *nwell\n  *nwell');p.write_text(s)
p=T/'ihp-sg13g2-cifin.tech';s=p.read_text();anchor=' layer nwell NWELL,WELLPIN\n and-not pnparea';assert s.count(anchor)==1
new=''' templayer esdvddcore DIFF
 and PSD
 and NWELL
 and ESDID
 templayer esdvsscore DIFF
 and-not PSD
 and-not NWELL
 and ESDID
 templayer esdvddbase ESDID
 interacting esdvddcore
 templayer esdvssbase ESDID
 interacting esdvsscore
 layer esdpnp esdvddbase
 layer esdnpn esdvssbase
 layer nwell NWELL,WELLPIN
 and-not pnparea''';s=s.replace(anchor,new);p.write_text(s)
p=T/'ihp-sg13g2-extract.tech';s=p.read_text();anchor=' # Lateral PNP bipolar\n';assert s.count(anchor)==1;s=s.replace(anchor,''' # Prototype geometric ESD recognition; NOT qualified.
 device subcircuit diodevdd_2kv esdpnp *pdiff pwell,space/w error a1=ea p1=ep
 device subcircuit diodevss_2kv esdnpn *ndiff pwell,space/w error a1=ea p1=ep
'''+anchor);s=s.replace(' planeorder comment    12',' planeorder comment    12\n planeorder esddevice 13');p.write_text(s)
F=Path('/dev/shm/nssoc-magic-esd-fixture-02');r=json.loads((F/'result.json').read_text());N=O/'native';N.mkdir();rt=Path('/dev/shm/nssoc-magic-esd-parser-build-02/runtime/lib');lines=['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',f'cd {{{N}}}','drc off','gds readonly true',f'gds read {{{F/"fixture.gds"}}}','load esd_probe','flatten esd_flat','load esd_flat','select top cell']
for i,(name,ps) in enumerate(r['ports'].items(),1):
 for b in ps:
  layer={8:'metal1',10:'metal2'}[b['layer']];lines+=['box values '+' '.join(str(x)+'um' for x in b['box']),f'label {name} center {layer}']
 lines += [f'port {name} make {i}',f'port {name} class inout',f'port {name} use signal']
lines+=['save esd_flat','extract style ngspice()','extract all','ext2spice lvs','ext2spice merge none','ext2spice global off','ext2spice cthresh infinite','ext2spice extresist off','ext2spice -o esd.spice','puts NSSOC_ESD_PROBE_COMPLETE','quit -noprompt'];p=N/'native.tcl';p.write_text('\n'.join(lines)+'\n');x=execute(['/usr/bin/env','CAD_ROOT='+str(rt),'/usr/bin/tclsh8.6',rt/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',T/'ihp-sg13g2.magicrc',p],N,'native');(O/'result.json').write_text(json.dumps(dict(execution=x,qualified=False,source=pin(__file__),outputs={str(p.relative_to(O)):pin(p) for p in O.rglob('*') if p.is_file()}),indent=2)+'\n');print(x)
