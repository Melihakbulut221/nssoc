# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import shutil,json,sys
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')];from check_pcie_rx_cell import execute;from check_magic_hbt_multiplicity_v3 import pin
P=Path('/dev/shm/nssoc-magic-esd-parser-build-01');O=Path('/dev/shm/nssoc-magic-esd-parser-build-02');O.mkdir();S=O/'source';shutil.copytree(P/'source',S);f=S/'cif/CIFgen.c';before=f.read_bytes();s=before.decode();start=s.index('void\ncifInteractingRegions(');end=s.index('/*\n * ----------------------------------------------------------------------------',start);part=s[start:end];anchor=part.index('\tTiSetClientINT(tile, CIF_IGNORE);');head=part[:anchor];tail=part[anchor:];assert tail.count('PUSHTILEONLY')==5;tail=tail.replace('PUSHTILEONLY(tile, RegStack);','STACKPUSH(PTR2CD(tile), RegStack);').replace('PUSHTILEONLY(tp, RegStack);','STACKPUSH(PTR2CD(tp), RegStack);');s=s[:start]+head+tail+s[end:];f.write_text(s);runs=[]
for cmd in [['make','-C',str(S/'cif'),'module'],['make','-C',str(S/'magic'),'tcl-main']]:
 x=execute(cmd,O,'build'+str(len(runs)));runs.append(x);assert x['returncode']==0
RT=O/'runtime/lib';shutil.copytree(P/'runtime/lib',RT);shutil.copyfile(S/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so');(O/'result.json').write_text(json.dumps(dict(parent=pin(P/'result.json'),source=pin(f),original_source=pin(P/'source/cif/CIFgen.c'),method=pin(__file__),runs=runs,runtime=pin(RT/'magic/tcl/tclmagic.so'),qualified=False),indent=2)+'\n')
