# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import pya,json,hashlib
A=Path('/dev/shm/nssoc-magic-esd-fixture-final');B=Path('/dev/shm/nssoc-magic-esd-fixture-final02');rows={}
for p in A.glob('*.gds'):
 la=pya.Layout();la.read(str(p));lb=pya.Layout();lb.read(str(B/p.name));top='interact_probe' if p.name=='interact.gds' else 'nssoc_esd_fixture';ca=la.cell(top);cb=lb.cell(top);assert la.dbu==lb.dbu
 layers=set((i.layer,i.datatype) for i in la.layer_infos())|set((i.layer,i.datatype) for i in lb.layer_infos());checked=[]
 for k in sorted(layers):
  ra=pya.Region(ca.begin_shapes_rec(la.layer(*k)));rb=pya.Region(cb.begin_shapes_rec(lb.layer(*k)));assert (ra^rb).is_empty(),(p,k);checked.append(k)
 rows[p.name]=dict(before_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),after_sha256=hashlib.sha256((B/p.name).read_bytes()).hexdigest(),layers_checked=checked,all_actual_geometry_xor_zero=True)
O=Path('/dev/shm/nssoc-magic-esd-launch-final/geometry-bridge.json');O.write_text(json.dumps(dict(status='PASS_ALL_PRIOR_GDS_MASKS_UNCHANGED',cases=rows,method_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
