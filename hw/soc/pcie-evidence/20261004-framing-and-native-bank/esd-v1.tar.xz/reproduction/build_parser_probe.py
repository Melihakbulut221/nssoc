# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import shutil,json,sys
R=Path.cwd();sys.path[:0]=[str(R/'scripts'),str(R/'hw/soc/flow')];from check_pcie_rx_cell import execute;from check_magic_hbt_multiplicity_v3 import pin
P=Path('/dev/shm/nssoc-finite-tap-v1-build-final');O=Path('/dev/shm/nssoc-magic-esd-parser-build-01');O.mkdir();S=O/'source';shutil.copytree(P/'source',S);f=S/'cif/CIFrdtech.c';before=f.read_bytes();s=before.decode();anchor='    else if (strcmp(argv[0], "copyup") == 0)\n';assert s.count(anchor)==1;s=s.replace(anchor,'''    else if (strcmp(argv[0], "interacting") == 0)
    {
        newOp->co_opcode = CIFOP_INTERACT;
        newOp->co_client = (ClientData)CIFOP_INT_TOUCHING;
    }
    else if (strcmp(argv[0], "noninteracting") == 0)
    {
        newOp->co_opcode = CIFOP_INTERACT;
        newOp->co_client = (ClientData)(CIFOP_INT_TOUCHING | CIFOP_INT_NOT);
    }
'''+anchor);anchor='\tcase CIFOP_COPYUP:\n\t    if (argc != 2)';assert s.count(anchor)==1;s=s.replace(anchor,'\tcase CIFOP_COPYUP:\n        case CIFOP_INTERACT:\n\t    if (argc != 2)');f.write_text(s);runs=[]
for cmd in [['make','-C',str(S/'cif'),'module'],['make','-C',str(S/'magic'),'tcl-main']]:
 x=execute(cmd,O,'build'+str(len(runs)));runs.append(x);assert x['returncode']==0
RT=O/'runtime/lib';shutil.copytree(P/'runtime/lib',RT);shutil.copyfile(S/'magic/tclmagic.so',RT/'magic/tcl/tclmagic.so');(O/'result.json').write_text(json.dumps(dict(parent=pin(P/'result.json'),source=pin(f),original_source=pin(P/'source/cif/CIFrdtech.c'),method=pin(__file__),runs=runs,runtime=pin(RT/'magic/tcl/tclmagic.so'),qualified=False),indent=2)+'\n')
