puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-magic-esd-overlay-02/native}
drc off
gds readonly true
gds read {/dev/shm/nssoc-magic-esd-fixture-02/fixture.gds}
load esd_probe
flatten esd_flat
load esd_flat
select top cell
box values 17.88um 27.755um 21.48um 49.315um
label PAD0 center metal2
port PAD0 make 1
port PAD0 class inout
port PAD0 use signal
box values 27.34um 23.735um 30.939999999999998um 53.335um
label VDD0 center metal2
port VDD0 make 2
port VDD0 class inout
port VDD0 use signal
box values 20.0um 20.0um 29.72um 21.35um
label SUB center metal1
box values 67.38um 23.725um 70.98um 53.325um
label SUB center metal2
port SUB make 3
port SUB class inout
port SUB use signal
box values 57.92um 27.745um 61.52um 49.305um
label PAD1 center metal2
port PAD1 make 4
port PAD1 class inout
port PAD1 use signal
box values 60.0um 55.7um 69.72um 57.050000000000004um
label VDD1 center metal1
port VDD1 make 5
port VDD1 class inout
port VDD1 use signal
save esd_flat
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh infinite
ext2spice extresist off
ext2spice -o esd.spice
puts NSSOC_ESD_PROBE_COMPLETE
quit -noprompt
