puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-magic-esd-overlay-01/native}
drc off
gds readonly true
gds read {/dev/shm/nssoc-magic-esd-fixture-01/fixture.gds}
load esd_probe
flatten esd_flat
load esd_flat
select top cell
box values -2.12um -29.315um 1.48um -7.755um
label PAD0 center metal2
port PAD0 make 1
port PAD0 class inout
port PAD0 use signal
box values 7.34um -33.335um 10.94um -3.735um
label VDD0 center metal2
port VDD0 make 2
port VDD0 class inout
port VDD0 use signal
box values 0.0um -1.35um 9.72um 0.0um
label SUB center metal1
box values 7.38um -33.325um 10.98um -3.725um
label SUB center metal2
port SUB make 3
port SUB class inout
port SUB use signal
box values -2.08um -29.305um 1.52um -7.745um
label PAD1 center metal2
port PAD1 make 4
port PAD1 class inout
port PAD1 use signal
box values 0.0um -37.050000000000004um 9.72um -35.7um
label VDD1 center metal1
port VDD1 make 5
port VDD1 class inout
port VDD1 use signal
save esd_flat
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh infinite
ext2spice extresist off
ext2spice -o esd.spice
puts NSSOC_ESD_PROBE_COMPLETE
quit -noprompt
