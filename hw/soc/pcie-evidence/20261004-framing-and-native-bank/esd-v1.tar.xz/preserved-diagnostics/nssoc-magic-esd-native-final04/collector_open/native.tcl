puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-magic-esd-native-final04/collector_open}
drc off
scalegrid 1 1
puts "NSSOC_PREIMPORT_GRID_UM [cif scale out]"
gds readonly true
gds read {/dev/shm/nssoc-magic-esd-fixture-final02/collector_open.gds}
load nssoc_esd_fixture
flatten esd_flat
load esd_flat
select top cell
box values 57.88um 67.755um 61.48um 89.315um
label PAD00 center metal2
port PAD00 make 1
port PAD00 class inout
port PAD00 use signal
box values 67.34um 63.735um 70.94um 93.33500000000001um
label VDD00 center metal2
port VDD00 make 2
port VDD00 class inout
port VDD00 use signal
box values 60.0um 60.0um 69.72um 61.35um
label SUB center metal1
box values 128.65um 60.0um 130.0um 69.72um
label SUB center metal1
box values 190.28um 58.65um 200.0um 60.0um
label SUB center metal1
box values 270.0um 50.28um 271.35um 60.0um
label SUB center metal1
box values 340.0um 58.65um 349.72um 60.0um
label SUB center metal1
box values 410.0um 60.0um 411.35um 69.72um
label SUB center metal1
box values 470.28um 60.0um 480.0um 61.35um
label SUB center metal1
box values 548.65um 50.28um 550.0um 60.0um
label SUB center metal1
box values 60.0um 140.0um 69.72um 141.35um
label SUB center metal1
box values 128.65um 140.0um 130.0um 149.72um
label SUB center metal1
box values 190.28um 138.65um 200.0um 140.0um
label SUB center metal1
box values 270.0um 130.28um 271.35um 140.0um
label SUB center metal1
box values 340.0um 138.65um 349.72um 140.0um
label SUB center metal1
box values 410.0um 140.0um 411.35um 149.72um
label SUB center metal1
box values 470.28um 140.0um 480.0um 141.35um
label SUB center metal1
box values 548.65um 130.28um 550.0um 140.0um
label SUB center metal1
box values 67.38um 223.725um 70.98um 253.325um
label SUB center metal2
box values 96.675um 227.38um 126.275um 230.98um
label SUB center metal2
box values 189.02um 186.675um 192.62um 216.275um
label SUB center metal2
box values 273.725um 209.02um 303.325um 212.62um
label SUB center metal2
box values 347.38um 186.675um 350.98um 216.275um
label SUB center metal2
box values 413.725um 227.38um 443.325um 230.98um
label SUB center metal2
box values 469.02um 223.725um 472.62um 253.325um
label SUB center metal2
box values 516.675um 209.02um 546.275um 212.62um
label SUB center metal2
box values 67.38um 303.725um 70.98um 333.325um
label SUB center metal2
box values 96.675um 307.38um 126.275um 310.98um
label SUB center metal2
box values 189.02um 266.675um 192.62um 296.275um
label SUB center metal2
box values 273.725um 289.02um 303.325um 292.62um
label SUB center metal2
box values 347.38um 266.675um 350.98um 296.275um
label SUB center metal2
box values 413.725um 307.38um 443.325um 310.98um
label SUB center metal2
box values 469.02um 303.725um 472.62um 333.325um
label SUB center metal2
box values 516.675um 289.02um 546.275um 292.62um
label SUB center metal2
port SUB make 3
port SUB class inout
port SUB use signal
box values 100.685um 57.88um 122.245um 61.48um
label PAD01 center metal2
port PAD01 make 4
port PAD01 class inout
port PAD01 use signal
box values 96.66499999999999um 67.34um 126.265um 70.94um
label VDD01 center metal2
port VDD01 make 5
port VDD01 class inout
port VDD01 use signal
box values 198.52um 30.685um 202.12um 52.245um
label PAD02 center metal2
port PAD02 make 6
port PAD02 class inout
port PAD02 use signal
box values 189.06um 26.665um 192.66um 56.265um
label VDD02 center metal2
port VDD02 make 7
port VDD02 class inout
port VDD02 use signal
box values 277.755um 58.52um 299.315um 62.12um
label PAD03 center metal2
port PAD03 make 8
port PAD03 class inout
port PAD03 use signal
box values 273.735um 49.06um 303.335um 52.66um
label VDD03 center metal2
port VDD03 make 9
port VDD03 class inout
port VDD03 use signal
box values 337.88um 30.685um 341.48um 52.245um
label PAD04 center metal2
port PAD04 make 10
port PAD04 class inout
port PAD04 use signal
box values 347.34um 26.665um 350.94um 56.265um
label VDD04 center metal2
port VDD04 make 11
port VDD04 class inout
port VDD04 use signal
box values 417.755um 57.88um 439.315um 61.48um
label PAD05 center metal2
port PAD05 make 12
port PAD05 class inout
port PAD05 use signal
box values 413.735um 67.34um 443.335um 70.94um
label VDD05 center metal2
port VDD05 make 13
port VDD05 class inout
port VDD05 use signal
box values 478.52um 67.755um 482.12um 89.315um
label PAD06 center metal2
port PAD06 make 14
port PAD06 class inout
port PAD06 use signal
box values 469.06um 63.735um 472.66um 93.33500000000001um
label VDD06 center metal2
port VDD06 make 15
port VDD06 class inout
port VDD06 use signal
box values 520.685um 58.52um 542.245um 62.12um
label PAD07 center metal2
port PAD07 make 16
port PAD07 class inout
port PAD07 use signal
box values 516.665um 49.06um 546.265um 52.66um
label VDD07 center metal2
port VDD07 make 17
port VDD07 class inout
port VDD07 use signal
box values 57.88um 147.755um 61.48um 169.315um
label PAD08 center metal2
port PAD08 make 18
port PAD08 class inout
port PAD08 use signal
box values 67.34um 143.735um 70.94um 173.335um
label VDD08 center metal2
port VDD08 make 19
port VDD08 class inout
port VDD08 use signal
box values 100.685um 137.88um 122.245um 141.48um
label PAD09 center metal2
port PAD09 make 20
port PAD09 class inout
port PAD09 use signal
box values 96.66499999999999um 147.34um 126.265um 150.94um
label VDD09 center metal2
port VDD09 make 21
port VDD09 class inout
port VDD09 use signal
box values 198.52um 110.685um 202.12um 132.245um
label PAD10 center metal2
port PAD10 make 22
port PAD10 class inout
port PAD10 use signal
box values 189.06um 106.66499999999999um 192.66um 136.265um
label VDD10 center metal2
port VDD10 make 23
port VDD10 class inout
port VDD10 use signal
box values 277.755um 138.52um 299.315um 142.12um
label PAD11 center metal2
port PAD11 make 24
port PAD11 class inout
port PAD11 use signal
box values 273.735um 129.06um 303.335um 132.66um
label VDD11 center metal2
port VDD11 make 25
port VDD11 class inout
port VDD11 use signal
box values 337.88um 110.685um 341.48um 132.245um
label PAD12 center metal2
port PAD12 make 26
port PAD12 class inout
port PAD12 use signal
box values 347.34um 106.66499999999999um 350.94um 136.265um
label VDD12 center metal2
port VDD12 make 27
port VDD12 class inout
port VDD12 use signal
box values 417.755um 137.88um 439.315um 141.48um
label PAD13 center metal2
port PAD13 make 28
port PAD13 class inout
port PAD13 use signal
box values 413.735um 147.34um 443.335um 150.94um
label VDD13 center metal2
port VDD13 make 29
port VDD13 class inout
port VDD13 use signal
box values 478.52um 147.755um 482.12um 169.315um
label PAD14 center metal2
port PAD14 make 30
port PAD14 class inout
port PAD14 use signal
box values 469.06um 143.735um 472.66um 173.335um
label VDD14 center metal2
port VDD14 make 31
port VDD14 class inout
port VDD14 use signal
box values 520.685um 138.52um 542.245um 142.12um
label PAD15 center metal2
port PAD15 make 32
port PAD15 class inout
port PAD15 use signal
box values 516.665um 129.06um 546.265um 132.66um
label VDD15 center metal2
port VDD15 make 33
port VDD15 class inout
port VDD15 use signal
box values 57.92um 227.745um 61.52um 249.305um
label PAD16 center metal2
port PAD16 make 34
port PAD16 class inout
port PAD16 use signal
box values 60.0um 255.7um 69.72um 257.05um
label VDD16 center metal1
port VDD16 make 35
port VDD16 class inout
port VDD16 use signal
box values 100.695um 217.92um 122.255um 221.52um
label PAD17 center metal2
port PAD17 make 36
port PAD17 class inout
port PAD17 use signal
box values 92.94999999999999um 220.0um 94.3um 229.72um
label VDD17 center metal1
port VDD17 make 37
port VDD17 class inout
port VDD17 use signal
box values 198.48um 190.695um 202.08um 212.255um
label PAD18 center metal2
port PAD18 make 38
port PAD18 class inout
port PAD18 use signal
box values 190.28um 182.95um 200.0um 184.3um
label VDD18 center metal1
port VDD18 make 39
port VDD18 class inout
port VDD18 use signal
box values 277.745um 218.48um 299.305um 222.08um
label PAD19 center metal2
port PAD19 make 40
port PAD19 class inout
port PAD19 use signal
box values 305.7um 210.28um 307.05um 220.0um
label VDD19 center metal1
port VDD19 make 41
port VDD19 class inout
port VDD19 use signal
box values 337.92um 190.695um 341.52um 212.255um
label PAD20 center metal2
port PAD20 make 42
port PAD20 class inout
port PAD20 use signal
box values 340.0um 182.95um 349.72um 184.3um
label VDD20 center metal1
port VDD20 make 43
port VDD20 class inout
port VDD20 use signal
box values 417.745um 217.92um 439.305um 221.52um
label PAD21 center metal2
port PAD21 make 44
port PAD21 class inout
port PAD21 use signal
box values 445.7um 220.0um 447.05um 229.72um
label VDD21 center metal1
port VDD21 make 45
port VDD21 class inout
port VDD21 use signal
box values 478.48um 227.745um 482.08um 249.305um
label PAD22 center metal2
port PAD22 make 46
port PAD22 class inout
port PAD22 use signal
box values 470.28um 255.7um 480.0um 257.05um
label VDD22 center metal1
port VDD22 make 47
port VDD22 class inout
port VDD22 use signal
box values 520.695um 218.48um 542.255um 222.08um
label PAD23 center metal2
port PAD23 make 48
port PAD23 class inout
port PAD23 use signal
box values 512.95um 210.28um 514.3um 220.0um
label VDD23 center metal1
port VDD23 make 49
port VDD23 class inout
port VDD23 use signal
box values 57.92um 307.745um 61.52um 329.305um
label PAD24 center metal2
port PAD24 make 50
port PAD24 class inout
port PAD24 use signal
box values 60.0um 335.7um 69.72um 337.05um
label VDD24 center metal1
port VDD24 make 51
port VDD24 class inout
port VDD24 use signal
box values 100.695um 297.92um 122.255um 301.52um
label PAD25 center metal2
port PAD25 make 52
port PAD25 class inout
port PAD25 use signal
box values 92.94999999999999um 300.0um 94.3um 309.72um
label VDD25 center metal1
port VDD25 make 53
port VDD25 class inout
port VDD25 use signal
box values 198.48um 270.695um 202.08um 292.255um
label PAD26 center metal2
port PAD26 make 54
port PAD26 class inout
port PAD26 use signal
box values 190.28um 262.95um 200.0um 264.3um
label VDD26 center metal1
port VDD26 make 55
port VDD26 class inout
port VDD26 use signal
box values 277.745um 298.48um 299.305um 302.08um
label PAD27 center metal2
port PAD27 make 56
port PAD27 class inout
port PAD27 use signal
box values 305.7um 290.28um 307.05um 300.0um
label VDD27 center metal1
port VDD27 make 57
port VDD27 class inout
port VDD27 use signal
box values 337.92um 270.695um 341.52um 292.255um
label PAD28 center metal2
port PAD28 make 58
port PAD28 class inout
port PAD28 use signal
box values 340.0um 262.95um 349.72um 264.3um
label VDD28 center metal1
port VDD28 make 59
port VDD28 class inout
port VDD28 use signal
box values 417.745um 297.92um 439.305um 301.52um
label PAD29 center metal2
port PAD29 make 60
port PAD29 class inout
port PAD29 use signal
box values 445.7um 300.0um 447.05um 309.72um
label VDD29 center metal1
port VDD29 make 61
port VDD29 class inout
port VDD29 use signal
box values 478.48um 307.745um 482.08um 329.305um
label PAD30 center metal2
port PAD30 make 62
port PAD30 class inout
port PAD30 use signal
box values 470.28um 335.7um 480.0um 337.05um
label VDD30 center metal1
port VDD30 make 63
port VDD30 class inout
port VDD30 use signal
box values 520.695um 298.48um 542.255um 302.08um
label PAD31 center metal2
port PAD31 make 64
port PAD31 class inout
port PAD31 use signal
box values 512.95um 290.28um 514.3um 300.0um
label VDD31 center metal1
port VDD31 make 65
port VDD31 class inout
port VDD31 use signal
save esd_flat
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh infinite
ext2spice extresist off
ext2spice -o esd.spice
puts NSSOC_ESD_NATIVE_COMPLETE
quit -noprompt
