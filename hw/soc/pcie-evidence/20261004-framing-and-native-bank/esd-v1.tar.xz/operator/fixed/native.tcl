puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-magic-esd-operator-final04/fixed}
drc off
gds read {/dev/shm/nssoc-magic-esd-fixture-final02/interact.gds}
load interact_probe
save interact_probe
puts NSSOC_OPERATOR_COMPLETE
quit -noprompt
