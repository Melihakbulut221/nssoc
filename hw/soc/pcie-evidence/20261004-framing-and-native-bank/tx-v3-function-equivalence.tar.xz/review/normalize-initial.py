import hashlib,json,os,pathlib,resource,subprocess,time
root=pathlib.Path.cwd()
out=pathlib.Path('/dev/shm/nssoc-txv3-physical-equivalence-peer')
out.mkdir(exist_ok=False)
lib=pathlib.Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib')
yosys=root/'hw/soc/tools/oss-cad-suite/bin/yosys'
inputs=[lib,yosys,root/'hw/soc/tools/oss-cad-suite/libexec/yosys',pathlib.Path('/dev/shm/nssoc-gen3-tx-path-v3-native-01/mapped.v'),pathlib.Path('/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.v')]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in inputs}
record={'inputs':pins,'scope':'Native Liberty functional expansion, no blackboxes or assumptions','runs':[]}
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
 os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
for name,net in [('gold',inputs[-2]),('gate',inputs[-1])]:
 script=out/(name+'.ys')
 script.write_text(f'read_liberty {lib}\nread_verilog {net}\nhierarchy -check -top soc_pcie_gen3_tx_path_v3\nflatten\nproc\nopt_clean\ncheck -assert\nstat\nwrite_json {out}/{name}.json\n')
 started=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  p=subprocess.run([str(yosys),'-T','-s',str(script)],stdout=f,stderr=subprocess.STDOUT,preexec_fn=limits,timeout=90)
 record['runs'].append({'name':name,'returncode':p.returncode,'elapsed_seconds':time.monotonic()-started,'script_sha256':sha(script),'log_sha256':sha(out/(name+'.log'))})
 (out/'normalization.json').write_text(json.dumps(record,indent=2)+'\n')
 assert p.returncode==0
 assert all(sha(pathlib.Path(p))==row['sha256'] for p,row in pins.items())
print(json.dumps(record,indent=2))
