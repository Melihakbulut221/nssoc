# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import collections,hashlib,io,json,lzma,pathlib,re,tarfile,xml.etree.ElementTree as ET
import compare as m
B=pathlib.Path(__file__).resolve().parent;P=m.ROOT
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
pin=lambda p:{'path':str(pathlib.Path(p).resolve()),'bytes':pathlib.Path(p).stat().st_size,'sha256':sha(p)}
norm=json.loads((P/'normalization.json').read_text())
for path,row in norm['inputs'].items():assert pin(path)=={'path':path,**row}
gold,gate=m.read('gold'),m.read('gate');proof=m.compare(gold,gate);assert proof['mismatches']==[]
mut=json.loads((P/'mutation-controls.json').read_text());assert len(mut['controls'])==9 and mut['positive']==proof
assert all(c['status'].startswith('REJECTED_') for c in mut['controls'])
replay=pathlib.Path('/dev/shm/nssoc-tx-path-v3-physical-replay-01');r=json.loads((replay/'result.json').read_text())
for path,row in r['inputs'].items():assert pin(path)=={'path':path,**row}
for name,row in r['outputs'].items():assert pin(replay/name)=={'path':str(replay/name),**row}
tests=ET.parse(replay/'results.xml').getroot().findall('.//testcase');assert len(tests)==3 and all(not any(t.find(x) is not None for x in ('failure','error','skipped')) for t in tests)
physical=pathlib.Path('/dev/shm/nssoc-tx-path-v3-final-repair-01');route=pathlib.Path('/dev/shm/nssoc-tx-path-v3-drt-01')
route_tcl=(route/'route.tcl').read_text();assert f'read_db {{{physical}/repaired.odb}}' in route_tcl and f'read_sdc {{{physical}/repaired.sdc}}' in route_tcl
log=(route/'route.log').read_text();prefix=log.split('[INFO DRT-0149]')[0];assert 'FINAL_RELOAD_BEFORE_DETAILED_ROUTE' in prefix and 'tns max 0.00' in prefix and '(VIOLATED)' not in prefix
checks=[]
for part in prefix.split('Startpoint:')[1:]:
 corner=re.search(r'\nCorner: (slow|typical|fast)\n',part).group(1)
 mode=re.search(r'\nPath Type: (max|min)\n',part).group(1)
 group=re.search(r'\nPath Group: ([^\n]+)\n',part).group(1)
 slack=float(re.search(r'\n\s*([\d.+-]+)\s+slack \(MET\)',part).group(1))
 checks.append(dict(corner=corner,path_type=mode,group=group,slack_ns=slack))
corners={c:{mode:min(x['slack_ns'] for x in checks if x['corner']==c and x['path_type']==kind) for mode,kind in [('setup_ns','max'),('hold_ns','min')]} for c in ('slow','typical','fast')}
expected={'slow':{'setup_ns':.018697,'hold_ns':.066373},'typical':{'setup_ns':1.477523,'hold_ns':.114728},'fast':{'setup_ns':2.243468,'hold_ns':.148566}}
assert corners==expected
sdc=(physical/'repaired.sdc').read_text();assert 'create_clock -name development_clock -period 4.0000' in sdc
assert not re.search(r'(?m)^set_(?:false_path|multicycle_path|clock_uncertainty)\b',sdc)
counts=collections.Counter(line.split()[0] for line in sdc.splitlines() if line.strip() and not line.startswith('#'))
assert counts['set_input_delay']==650 and counts['set_output_delay']==130 and counts['set_input_transition']==650 and counts['set_load']==130,counts
for command,value in [('set_input_delay','0.2000'),('set_output_delay','0.2000'),('set_input_transition','0.1000')]:assert all(line.split()[1]==value for line in sdc.splitlines() if line.startswith(command+' '))
# Snapshot the immutable initial reload reports; do not claim completion of DRT.
(B/'three-corner-reload-prefix.log').write_text(prefix)
state_tables={}
for name,source in [('gold','/dev/shm/nssoc-gen3-tx-path-v3-native-01/mapped.v'),('gate',str(physical/'repaired.v'))]:
 rows=re.findall(r'(?m)^\s*(sg13g2_dfrbpq_\d+)\s+(_[0-9]+_)\s*\(',pathlib.Path(source).read_text())
 assert len(rows)==2158 and len(set(n for t,n in rows))==2158
 state_tables[name]={n:t for t,n in rows}
assert state_tables['gold'].keys()==state_tables['gate'].keys()
resized={n:[t,state_tables['gate'][n]] for n,t in state_tables['gold'].items() if t!=state_tables['gate'][n]};assert len(resized)==69
(B/'state-map.json').write_text(json.dumps({'map':state_tables,'resized':resized},indent=2)+'\n')
record={'status':'PASS_EXACT_BINARY_STATE_AND_OUTPUT_FUNCTION_EQUIVALENCE_AND_RECORDED_NATIVE_REPLAY','proof':proof,'method':'Exact native Yosys read_liberty functional expansion and collision-free canonical Boolean DAG comparison; common state inputs use a complete bijection of native FF instance identities. Proves all D/clock/reset functions and all port outputs, not just tested traces.','primitive_semantics':['$_AND_','$_OR_','$_XOR_','$_NOT_','$_DFF_PP0_'],'rules':['commutativity and associativity of AND/OR/XOR','AND/OR idempotence','double inversion','literal inversion','exact tuple equality; no digest used to decide equivalence'],'blackboxes':0,'missing_used_functions':0,'unknowns_allowed':False,'assumptions_or_omitted_boundaries':0,'state_map':pin(B/'state-map.json'),'native_ff_strength_changes':69,'mutations':mut,'normalization':norm,'native_port_replay':{'receipt':pin(replay/'result.json'),'tests':[x.attrib for x in tests],'independent_xml_reparse':True,'new_simulation_by_reviewer':False},'timing':{'corners':corners,'all_reported_paths':checks,'sdc':pin(physical/'repaired.sdc'),'command_counts':dict(counts),'raw_reload_prefix':pin(B/'three-corner-reload-prefix.log'),'source_route_script':pin(route/'route.tcl'),'original_route_log':pin(route/'route.log'),'electrical_report_has_no_violators':True},'physical_source':[pin(physical/name) for name in ['repaired.v','repaired.odb','repaired.sdc']],'initial_attempts':['Native Liberty import first stopped on unused sg13g2_lgcp_1 missing int_GATE function. Retried with ignore_miss_func; hierarchy/check plus strict complete primitive census proves no used model was omitted.','First state-name comparison stopped on69 resized-cell internal model suffixes. State map now uses exact unique native instance path, while requiring identical native FF/reset semantics.','Commutative-only expression grouping left2158 residual targets. Standard Boolean associativity proved all6604 boundaries; this was structural incompleteness, not a circuit counterexample.'],'limits':['Binary functional equivalence under the explicit bijective state relation; not four-state X/glitch or analog delay equivalence.','Recorded3-case specify-model simulation independently hash/XML checked, not rerun by reviewer; no SDF.','Three-corner timing reloaded from exact repaired ODB/SDC uses global-route estimated RC and development4ns constraints, not signoff extracted RC.','No DRT completion, DRC/LVS, full PHY or main-chip qualification claimed.'],'review_sources':[pin(B/name) for name in ['normalize.py','compare.py','mutations.py','seal.py']]}
files={}
for p in P.iterdir():
 if p.is_file():files['native-functions/'+p.name]=p
for name in ['normalize.py','normalize-initial.py','compare.py','compare-initial.py','mutations.py','seal.py','state-map.json','three-corner-reload-prefix.log']:files['review/'+name]=B/name
for name in ['result.json','simulation.log','results.xml']:files['physical-port-replay/'+name]=replay/name
for name in ['repair.tcl','repair.log','repaired.sdc']:files['physical/'+name]=physical/name
files['history/liberty-import-failure.log']=pathlib.Path('/dev/shm/nssoc-txv3-physical-equivalence-peer/gold.log')
files['history/liberty-import-failure.json']=pathlib.Path('/dev/shm/nssoc-txv3-physical-equivalence-peer/normalization.json')
files['LICENSES/Apache-2.0.txt']=pathlib.Path('LICENSES/Apache-2.0.txt')
manifest={n:pin(p) for n,p in files.items()};record['capsule_members']=manifest
capsule=B/'physical-function-proof.tar.xz'
with lzma.open(capsule,'wb',preset=3) as stream,tarfile.open(fileobj=stream,mode='w|') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(capsule,'r:xz') as tar:
 assert set(tar.getnames())==set(manifest)
 for name,row in manifest.items():
  f=tar.extractfile(name);assert f and hashlib.file_digest(f,'sha256').hexdigest()==row['sha256']
record['capsule']=pin(capsule)
for path,row in norm['inputs'].items():assert sha(path)==row['sha256']
(B/'independent-review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'receipt':pin(B/'independent-review.json'),'capsule':pin(capsule),'corners':corners,'proof':proof},indent=2))
