set_thread_count 2
define_corners slow typical fast
read_liberty -corner slow {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_slow_1p08V_125C.lib}
read_liberty -corner typical {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib}
read_liberty -corner fast {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_fast_1p32V_m40C.lib}
read_db {/dev/shm/nssoc-tx-path-v3-port-repair-02/repaired.odb}
read_sdc {/dev/shm/nssoc-tx-path-v3-port-repair-02/repaired.sdc}
set_wire_rc -signal -layer Metal2
set_wire_rc -clock -layer Metal4
set_routing_layers -signal Metal2-Metal5 -clock Metal2-Metal5
set_global_routing_layer_adjustment Metal2-Metal5 0.30
estimate_parasitics -global_routing
puts RELOADED_INITIAL
report_worst_slack -max
report_worst_slack -min
detailed_placement
global_route -start_incremental
repair_design -slew_margin 5 -cap_margin 5
repair_timing -setup -setup_margin 0.10 -repair_tns 100
repair_timing -hold -hold_margin 0.05
detailed_placement
check_placement -verbose
global_route -end_incremental -congestion_iterations 100 -guide_file /dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.guide
estimate_parasitics -global_routing
puts REPAIRED_GLOBAL_ROUTE
report_worst_slack -max
report_worst_slack -min
report_tns
report_check_types -max_slew -max_capacitance -violators
report_checks -path_delay max -group_path_count 3 -fields {slew cap fanout} -digits 6
report_checks -path_delay min -group_path_count 3 -fields {slew cap fanout} -digits 6
write_db {/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.odb}
write_verilog {/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.v}
write_def {/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.def}
write_sdc {/dev/shm/nssoc-tx-path-v3-final-repair-01/repaired.sdc}
