# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Full device inventory failure remains authoritative; partial graph diagnostic only."""
from pathlib import Path
from decimal import Decimal
from collections import Counter
import sys,json,re,networkx as nx
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));import check_magic_hbt_multiplicity_v3 as h
V=Path('/dev/shm/nssoc-padded-clocked-layout-01');O=Path('/dev/shm/nssoc-padded-clocked-esd-01');B=R/'hw/soc/out/pcie-magic-esd-v1-20261004'
def rows(path):return [s.split() for s in h.spice_lines(path.read_text())]
def number(t):
 m=re.fullmatch(r'([-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)([numkp]?)',t.lower());assert m,t
 return Decimal(m[1])*{'':Decimal(1),'n':Decimal('1e-9'),'u':Decimal('1e-6'),'m':Decimal('1e-3'),'k':Decimal('1e3'),'p':Decimal('1e-12')}[m[2]]
def devs(rs):
 result=[]
 for r in rs:
  if r[0][0] not in 'XQRMDC':continue
  if r[0][0]=='C' and not any('=' in t for t in r):continue # separately retained native interconnect caps, not intrinsic source devices
  i=next(i for i,t in enumerate(r) if '=' in t);result.append(dict(name=r[0],nodes=[n.upper() for n in r[1:i-1]],model=r[i-1].lower(),parameters={k.lower():number(v) for k,v in (t.split('=') for t in r[i:])}))
 return result
ref=rows(V/'schematic.cir');raw=rows(O/'capacitance.spice');gd,ad=devs(ref),devs(raw)
ports={p.upper() for p in ref[0][2:]};assert ports=={p.upper() for p in raw[0][2:]} and len(raw[0][2:])==56
rc,ac=Counter(d['model'] for d in gd),Counter(d['model'] for d in ad)
print('counts',rc,ac,flush=True)
taps=[d for d in ad if d['model']=='ptap1'];assert len(taps)==108 and all(d['nodes']==['SUB','ESD_RETURN'] and d['parameters']==dict(l=Decimal('2e-6'),w=Decimal('2e-6'),r=Decimal('81.6667')) for d in taps)
ntap=[d for d in ad if d['model']=='ntap1'];assert len(ntap)==1 and ntap[0]['nodes'][0]=='AVDD2V3' and ntap[0]['nodes'][1] not in ports
pmos=[d for d in ad if d['model']=='sg13_hv_pmos'];assert len(pmos)==1 and pmos[0]['nodes'][3]==ntap[0]['nodes'][1]
# Every source device/model participates. ESD annotation normalization is
# permitted only after exact raw-mask identity and native emitter metrology.
geometry=json.loads((O/'esd-geometry.json').read_text());assert geometry['status']=='PASS_FIXED_NATIVE_ESD_MASKS' and geometry['marker_count']==32 and not geometry['rejected']
assert Counter(x['model'] for x in geometry['matches'])==Counter(diodevdd_2kv=16,diodevss_2kv=16)
allowed=set(rc);assert ac==rc
def graph(ds):
 g=nx.Graph()
 for p in ports:g.add_node(('net',p),color='port:'+p)
 for i,d in enumerate(ds):
  if d['model'] not in allowed:continue
  model=d['model'];p=d['parameters'];p=dict(p)
  assert p.pop('m',Decimal(1))==1
  if model in ('diodevdd_2kv','diodevss_2kv'):
   if p:
    assert p==dict(ea=Decimal('35.0028e-12'),ep=Decimal('58.08e-6'))
    p={}

  if model in ('ptap1','ntap1'):
   if 'a' in p:
    assert p==dict(a=Decimal('4e-12'),p=Decimal('8e-6'));p=dict(w=Decimal('2e-6'),l=Decimal('2e-6'))
   else:
    assert p.pop('r')==Decimal('81.6667')
  if model in ('rsil','rppd'):
   assert p.pop('b',Decimal(0))==0
  if model=='sg13_hv_pmos':p={k:p[k] for k in ('w','l')}
  color=(model,tuple(sorted(p.items())));g.add_node(('dev',i),color=color)
  for j,n in enumerate(d['nodes']):
   if ('net',n) not in g:g.add_node(('net',n),color='internal')
   role='end' if model in ('rsil','rppd') and j<2 else j
   g.add_node(('pin',i,j),color=('pin',role));g.add_edge(('dev',i),('pin',i,j));g.add_edge(('pin',i,j),('net',n))
 return g
left,right=graph(gd),graph(ad)
print('full graph',left.number_of_nodes(),right.number_of_nodes(),flush=True)
match=nx.algorithms.isomorphism.GraphMatcher(left,right,node_match=lambda a,b:a['color']==b['color']);equivalent=match.is_isomorphic();print('full equivalence',equivalent,flush=True)
incidence={}
for port in sorted(ports):
 def hits(ds):
  return sorted((d['model'],j) for d in ds if d['model'] in allowed for j,n in enumerate(d['nodes']) if n==port)
 expected,actual=hits(gd),hits(ad)
 if expected and not actual:incidence[port]=dict(expected=expected,actual=actual)
record=dict(status='PASS_COMPLETE_DEVICE_GRAPH_ONLY' if equivalent else 'FAIL_COMPLETE_BANK_GRAPH_WITH_ALL32_ESD_RECOVERED',
 source_gds=h.pin(V/'nssoc_pcie_padded_clocked_bank4_v1.gds'),source_reference=h.pin(V/'schematic.cir'),
 native_record=h.pin(O/'result.json'),method=h.pin(__file__),geometry_mask_audit=h.pin(O/'esd-geometry.json'),
 exact_56_ports=True,reference_counts=dict(rc),extracted_counts=dict(ac),device_inventory_equal=rc==ac,
 full_device_graph_equal=equivalent,graph_nodes=[left.number_of_nodes(),right.number_of_nodes()],
 disconnected_serial_port_incidence=incidence,native_ptap=dict(count=108,terminals=['SUB','ESD_RETURN'],each_resistance_ohm='81.6667',dimensions_um=[2,2]),
 ntap=ntap[0],pmos_body_bound_to_finite_well=True,
 esd_ordered_native_rows=[d for d in ad if d['model'].startswith('diode')],
 normalization=['All source and extracted models participate; no device subset is discarded.','All56 top ports fixed; internal node names alone are existentially matched. Ordered transistor/ESD/MIM/MOS terminals retained, symmetric resistor endpoints may exchange.','ESD m=1 normalization uses exact native PCell semiconductor masks and raw measured emitter A35.0028um2/P58.08um. Raw annotations are retained, not passed to a compact model.','Finite taps remain2x2um/81.6667ohm, not shorts. SourceA/P and outputw/l syntax normalize to the same exact physical geometry.','Onlym=1,b=0 defaults removed; PMOS diffusion-area/perimeter extra annotations excluded from this connectivity-only comparison, not claimed as PEX metrology.'],
 qualified_pex=False,qualified_esd_stress=False,original_gds_unchanged=True,
 limitations=['Raw fullbank capacitances are retained but have not passed conservation/RC qualification.','A passing isolated ESD device fixture is not fullbank topology approval.','Original native KLayout strictLVS passes; any remaining mismatch is a native-import/extraction discrepancy, not a demonstrated newphysicalGDS defect.'],
 outputs={p.name:h.pin(p) for p in O.iterdir() if p.is_file()})
(B/'bank-review.json').write_text(json.dumps(record,indent=2,default=str)+'\n');print(record['status'],len(incidence),flush=True)
