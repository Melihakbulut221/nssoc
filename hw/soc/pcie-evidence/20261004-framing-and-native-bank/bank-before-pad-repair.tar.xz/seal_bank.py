# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,hashlib,tarfile,io,sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));from check_magic_hbt_multiplicity_v3 import pin
B=R/'hw/soc/out/pcie-magic-esd-v1-20261004';O=Path('/dev/shm/nssoc-padded-clocked-esd-01');r=json.loads((B/'bank-review.json').read_text());assert r['device_inventory_equal'] and not r['full_device_graph_equal'] and len(r['disconnected_serial_port_incidence'])==16
for name,value in r['outputs'].items():assert pin(O/name)==value
files={}
for p in O.iterdir():
 if p.is_file():files['native/'+p.name]=p.read_bytes()
for name in ('bank-review.json','bank_attempt.py','audit_bank_graph.py','seal_bank.py','UPSTREAM-NOTICES.txt'):
 files[name]=(B/name).read_bytes()
files['MANIFEST.json']=(json.dumps({n:dict(bytes=len(d),sha256=hashlib.sha256(d).hexdigest()) for n,d in files.items()},indent=2)+'\n').encode()
p=B/'padded-bank-esd-full-census-failed-native.tar.xz'
with tarfile.open(p,'w:xz') as t:
 for n,d in sorted(files.items()):
  m=tarfile.TarInfo(n);m.size=len(d);m.mtime=0;t.addfile(m,io.BytesIO(d))
with tarfile.open(p) as t:
 assert len(t.getmembers())==len(files)
 for m in t.getmembers():assert t.extractfile(m).read()==files[m.name]
record=dict(status=r['status'],source_gds=r['source_gds'],source_reference=r['source_reference'],device_inventory_equal=True,full_device_graph_equal=False,disconnected_ports=sorted(r['disconnected_serial_port_incidence']),reference_counts=r['reference_counts'],extracted_counts=r['extracted_counts'],isolated_method_receipt=pin(B/'validation.json'),raw_graph_audit=pin(B/'bank-review.json'),capsule=dict(**pin(p),members=len(files),all_roundtrip_verified=True),qualified_pex=False,esd_stress_qualified=False,limitations=['All device counts now match;16 serial pad/core node opens remain in native Magic import. Full graph stillFAIL.','Raw original GDS preserved; no alias unions, terminal omission, reference device substitution or body-return short.','Native import reported rescaling and off-lambda snapping warnings; those remain in rawlog and require investigation with pad stack.','No coupled-RC conservation or RFPEX acceptance.'])
q=B/'bank-validation.json';q.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({p.name:pin(p),q.name:pin(q)},indent=2))
