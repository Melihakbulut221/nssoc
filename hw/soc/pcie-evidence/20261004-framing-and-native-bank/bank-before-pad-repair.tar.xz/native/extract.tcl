puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-padded-clocked-esd-01}
drc off
gds readonly true
gds read {/dev/shm/nssoc-padded-clocked-layout-01/nssoc_pcie_padded_clocked_bank4_v1.gds}
load nssoc_pcie_padded_clocked_bank4_v1
flatten nssoc_padded_clocked_esd_flat
load nssoc_padded_clocked_esd_flat
select top cell
box values 1488.0um 3436.0um 1492.0um 3440.0um
label AVDD1V8 center metal7
port AVDD1V8 make 1
port AVDD1V8 class inout
port AVDD1V8 use signal
box values 1508.0um 3436.0um 1512.0um 3440.0um
label AVDD2V5 center metal7
port AVDD2V5 make 2
port AVDD2V5 class inout
port AVDD2V5 use signal
box values 1528.0um 3436.0um 1532.0um 3440.0um
label AVSS center metal7
port AVSS make 3
port AVSS class inout
port AVSS use signal
box values 1548.0um 3436.0um 1552.0um 3440.0um
label SUB center metal7
port SUB make 4
port SUB class inout
port SUB use signal
box values 2498.0um 3436.0um 2502.0um 3440.0um
label AVDD2V3 center metal7
port AVDD2V3 make 5
port AVDD2V3 class inout
port AVDD2V3 use signal
box values 0.0um 479.0um 2.0um 481.0um
label L0_TX_INP center metal6
port L0_TX_INP make 6
port L0_TX_INP class inout
port L0_TX_INP use signal
box values 2938.0um 479.0um 2940.0um 481.0um
label L0_TX_INN center metal6
port L0_TX_INN make 7
port L0_TX_INN class inout
port L0_TX_INN use signal
box values 0.0um 451.0um 2.0um 453.0um
label L0_TX_IREF center metal6
port L0_TX_IREF make 8
port L0_TX_IREF class inout
port L0_TX_IREF use signal
box values 0.0um 636.0um 2.0um 638.0um
label L0_RX_IREF center metal6
port L0_RX_IREF make 9
port L0_RX_IREF class inout
port L0_RX_IREF use signal
box values 2938.0um 752.0um 2940.0um 754.0um
label L0_RX_VCM center metal6
port L0_RX_VCM make 10
port L0_RX_VCM class inout
port L0_RX_VCM use signal
box values 2938.0um 885.03um 2940.0um 887.03um
label L0_SAMPLER_QP center metal6
port L0_SAMPLER_QP make 11
port L0_SAMPLER_QP class inout
port L0_SAMPLER_QP use signal
box values 2938.0um 895.03um 2940.0um 897.03um
label L0_SAMPLER_QN center metal6
port L0_SAMPLER_QN make 12
port L0_SAMPLER_QN class inout
port L0_SAMPLER_QN use signal
box values 0.0um 955.03um 2.0um 957.03um
label L0_SAMPLER_IREF center metal6
port L0_SAMPLER_IREF make 13
port L0_SAMPLER_IREF class inout
port L0_SAMPLER_IREF use signal
box values 0.0um 1139.0um 2.0um 1141.0um
label L1_TX_INP center metal6
port L1_TX_INP make 14
port L1_TX_INP class inout
port L1_TX_INP use signal
box values 2938.0um 1139.0um 2940.0um 1141.0um
label L1_TX_INN center metal6
port L1_TX_INN make 15
port L1_TX_INN class inout
port L1_TX_INN use signal
box values 0.0um 1111.0um 2.0um 1113.0um
label L1_TX_IREF center metal6
port L1_TX_IREF make 16
port L1_TX_IREF class inout
port L1_TX_IREF use signal
box values 0.0um 1296.0um 2.0um 1298.0um
label L1_RX_IREF center metal6
port L1_RX_IREF make 17
port L1_RX_IREF class inout
port L1_RX_IREF use signal
box values 2938.0um 1412.0um 2940.0um 1414.0um
label L1_RX_VCM center metal6
port L1_RX_VCM make 18
port L1_RX_VCM class inout
port L1_RX_VCM use signal
box values 2938.0um 1545.03um 2940.0um 1547.03um
label L1_SAMPLER_QP center metal6
port L1_SAMPLER_QP make 19
port L1_SAMPLER_QP class inout
port L1_SAMPLER_QP use signal
box values 2938.0um 1555.03um 2940.0um 1557.03um
label L1_SAMPLER_QN center metal6
port L1_SAMPLER_QN make 20
port L1_SAMPLER_QN class inout
port L1_SAMPLER_QN use signal
box values 0.0um 1615.03um 2.0um 1617.03um
label L1_SAMPLER_IREF center metal6
port L1_SAMPLER_IREF make 21
port L1_SAMPLER_IREF class inout
port L1_SAMPLER_IREF use signal
box values 0.0um 1799.0um 2.0um 1801.0um
label L2_TX_INP center metal6
port L2_TX_INP make 22
port L2_TX_INP class inout
port L2_TX_INP use signal
box values 2938.0um 1799.0um 2940.0um 1801.0um
label L2_TX_INN center metal6
port L2_TX_INN make 23
port L2_TX_INN class inout
port L2_TX_INN use signal
box values 0.0um 1771.0um 2.0um 1773.0um
label L2_TX_IREF center metal6
port L2_TX_IREF make 24
port L2_TX_IREF class inout
port L2_TX_IREF use signal
box values 0.0um 1956.0um 2.0um 1958.0um
label L2_RX_IREF center metal6
port L2_RX_IREF make 25
port L2_RX_IREF class inout
port L2_RX_IREF use signal
box values 2938.0um 2072.0um 2940.0um 2074.0um
label L2_RX_VCM center metal6
port L2_RX_VCM make 26
port L2_RX_VCM class inout
port L2_RX_VCM use signal
box values 2938.0um 2205.0299999999997um 2940.0um 2207.0299999999997um
label L2_SAMPLER_QP center metal6
port L2_SAMPLER_QP make 27
port L2_SAMPLER_QP class inout
port L2_SAMPLER_QP use signal
box values 2938.0um 2215.0299999999997um 2940.0um 2217.0299999999997um
label L2_SAMPLER_QN center metal6
port L2_SAMPLER_QN make 28
port L2_SAMPLER_QN class inout
port L2_SAMPLER_QN use signal
box values 0.0um 2275.0299999999997um 2.0um 2277.0299999999997um
label L2_SAMPLER_IREF center metal6
port L2_SAMPLER_IREF make 29
port L2_SAMPLER_IREF class inout
port L2_SAMPLER_IREF use signal
box values 0.0um 2459.0um 2.0um 2461.0um
label L3_TX_INP center metal6
port L3_TX_INP make 30
port L3_TX_INP class inout
port L3_TX_INP use signal
box values 2938.0um 2459.0um 2940.0um 2461.0um
label L3_TX_INN center metal6
port L3_TX_INN make 31
port L3_TX_INN class inout
port L3_TX_INN use signal
box values 0.0um 2431.0um 2.0um 2433.0um
label L3_TX_IREF center metal6
port L3_TX_IREF make 32
port L3_TX_IREF class inout
port L3_TX_IREF use signal
box values 0.0um 2616.0um 2.0um 2618.0um
label L3_RX_IREF center metal6
port L3_RX_IREF make 33
port L3_RX_IREF class inout
port L3_RX_IREF use signal
box values 2938.0um 2732.0um 2940.0um 2734.0um
label L3_RX_VCM center metal6
port L3_RX_VCM make 34
port L3_RX_VCM class inout
port L3_RX_VCM use signal
box values 2938.0um 2865.03um 2940.0um 2867.03um
label L3_SAMPLER_QP center metal6
port L3_SAMPLER_QP make 35
port L3_SAMPLER_QP class inout
port L3_SAMPLER_QP use signal
box values 2938.0um 2875.03um 2940.0um 2877.03um
label L3_SAMPLER_QN center metal6
port L3_SAMPLER_QN make 36
port L3_SAMPLER_QN class inout
port L3_SAMPLER_QN use signal
box values 0.0um 2935.03um 2.0um 2937.03um
label L3_SAMPLER_IREF center metal6
port L3_SAMPLER_IREF make 37
port L3_SAMPLER_IREF class inout
port L3_SAMPLER_IREF use signal
box values 0.0um 3205.03um 2.0um 3207.03um
label VCTRL center metal6
port VCTRL make 38
port VCTRL class inout
port VCTRL use signal
box values 535.0um 65.0um 565.0um 95.0um
label L0_TX_OUTP center metal7
port L0_TX_OUTP make 39
port L0_TX_OUTP class inout
port L0_TX_OUTP use signal
box values 635.0um 65.0um 665.0um 95.0um
label L0_TX_OUTN center metal7
port L0_TX_OUTN make 40
port L0_TX_OUTN class inout
port L0_TX_OUTN use signal
box values 775.0um 65.0um 805.0um 95.0um
label L0_RX_INP center metal7
port L0_RX_INP make 41
port L0_RX_INP class inout
port L0_RX_INP use signal
box values 875.0um 65.0um 905.0um 95.0um
label L0_RX_INN center metal7
port L0_RX_INN make 42
port L0_RX_INN class inout
port L0_RX_INN use signal
box values 1015.0um 65.0um 1045.0um 95.0um
label L1_TX_OUTP center metal7
port L1_TX_OUTP make 43
port L1_TX_OUTP class inout
port L1_TX_OUTP use signal
box values 1115.0um 65.0um 1145.0um 95.0um
label L1_TX_OUTN center metal7
port L1_TX_OUTN make 44
port L1_TX_OUTN class inout
port L1_TX_OUTN use signal
box values 1255.0um 65.0um 1285.0um 95.0um
label L1_RX_INP center metal7
port L1_RX_INP make 45
port L1_RX_INP class inout
port L1_RX_INP use signal
box values 1355.0um 65.0um 1385.0um 95.0um
label L1_RX_INN center metal7
port L1_RX_INN make 46
port L1_RX_INN class inout
port L1_RX_INN use signal
box values 1495.0um 65.0um 1525.0um 95.0um
label L2_TX_OUTP center metal7
port L2_TX_OUTP make 47
port L2_TX_OUTP class inout
port L2_TX_OUTP use signal
box values 1595.0um 65.0um 1625.0um 95.0um
label L2_TX_OUTN center metal7
port L2_TX_OUTN make 48
port L2_TX_OUTN class inout
port L2_TX_OUTN use signal
box values 1735.0um 65.0um 1765.0um 95.0um
label L2_RX_INP center metal7
port L2_RX_INP make 49
port L2_RX_INP class inout
port L2_RX_INP use signal
box values 1835.0um 65.0um 1865.0um 95.0um
label L2_RX_INN center metal7
port L2_RX_INN make 50
port L2_RX_INN class inout
port L2_RX_INN use signal
box values 1975.0um 65.0um 2005.0um 95.0um
label L3_TX_OUTP center metal7
port L3_TX_OUTP make 51
port L3_TX_OUTP class inout
port L3_TX_OUTP use signal
box values 2075.0um 65.0um 2105.0um 95.0um
label L3_TX_OUTN center metal7
port L3_TX_OUTN make 52
port L3_TX_OUTN class inout
port L3_TX_OUTN use signal
box values 2215.0um 65.0um 2245.0um 95.0um
label L3_RX_INP center metal7
port L3_RX_INP make 53
port L3_RX_INP class inout
port L3_RX_INP use signal
box values 2315.0um 65.0um 2345.0um 95.0um
label L3_RX_INN center metal7
port L3_RX_INN make 54
port L3_RX_INN class inout
port L3_RX_INN use signal
box values 2858.0um 3436.0um 2862.0um 3440.0um
label ESD_VDD center metal7
port ESD_VDD make 55
port ESD_VDD class inout
port ESD_VDD use signal
box values 2888.0um 3436.0um 2892.0um 3440.0um
label ESD_RETURN center metal7
port ESD_RETURN make 56
port ESD_RETURN class inout
port ESD_RETURN use signal
save nssoc_padded_clocked_esd_flat
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice merge none
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {/dev/shm/nssoc-padded-clocked-esd-01/capacitance.spice}
puts NSSOC_CAPACITANCE_EXPORT_COMPLETE
quit -noprompt
