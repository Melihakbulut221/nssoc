#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Author replay and finite evidence seal; never invokes a simulator."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
RAW = Path('/dev/shm/nssoc-div2-native-final')
spec = importlib.util.spec_from_file_location('div2', ROOT / 'scripts/characterize_pcie_div2.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda: stream.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def pin(path):
    return {'bytes': path.stat().st_size, 'sha256': digest(path)}

def canonical(value):
    return json.loads(json.dumps(value))

record = json.loads((RAW / 'result.json').read_text())
assert record['limits'] == d.LIMITS and not record['quick']
assert [r['case'] for r in record['cases']] == d.cases(False)
assert len(record['inputs']) == 64
for name, expected in record['inputs'].items():
    assert digest(Path(name)) == expected, name
for name, expected in record['compiled_models'].items():
    assert digest(Path(name)) == expected, name
models = next(Path(p).parent for p in record['inputs'] if p.endswith('/cornerHBT.lib'))
osdi = [Path(p) for p in record['compiled_models']]
summary = []
for entry in record['cases']:
    case = entry['case']
    folder = RAW / case['name']
    assert set(entry['outputs']) == {p.name for p in folder.iterdir() if p.is_file()}
    for name, expected in entry['outputs'].items():
        assert digest(folder / name) == expected
    assert (folder / 'bench.cir').read_text() == d.deck(case, models, osdi)
    assert (folder / d.CIRCUIT.name).read_text() == d.circuit(case)
    for parent in (d.VCO, d.LATCH):
        assert (folder / parent.name).read_bytes() == parent.read_bytes()
    h = hashlib.sha256()
    with gzip.open(folder / 'wave.dat.gz', 'rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    assert h.hexdigest() == entry['uncompressed_wave_sha256']
    measured = d.measure(d.read_wave(folder / 'wave.dat.gz', case), case)
    assert canonical(measured) == entry['measurement']
    assert d.diagnostics((folder / 'run.log').read_text()) == entry['numerical']
    assert d.expected_result(entry) == entry['expected_outcome_observed']
    assert entry['returncode'] == 0 and not entry.get('execution_failure')
    devices = measured['devices']
    summary.append(dict(
        name=case['name'], role=case['role'], fault=case['fault'],
        functional_divide_pass=measured['functional_divide_pass'],
        numeric_limits_pass=measured['screen_pass'],
        numerical_clean=entry['numerical']['clean'],
        expected_outcome_observed=entry['expected_outcome_observed'],
        input_frequency_hz=measured['input_frequency_hz'],
        output_frequency_hz=measured['output_frequency_hz'],
        input_rising_edges=measured['input_rising_edges'],
        output_rising_edges=measured['output_rising_edges'],
        min_operating_vce_v=min(x['min_operating_vce_v'] for x in devices.values()),
        max_capture_vce_v=max(x['max_capture_vce_v'] for x in devices.values()),
        max_capture_abs_ic_a_per_nx=max(x['max_capture_abs_ic_a_per_nx'] for x in devices.values()),
        failed_checks=[k for k,v in measured['checks'].items() if not v],
        diagnostics=entry['numerical']['lines'],
    ))
    print('Replayed', case['name'], flush=True)

sources = [d.CIRCUIT, ROOT / 'scripts/characterize_pcie_div2.py', ROOT / 'sw/tests/test_pcie_div2.py']
capsule = OUT / 'div2-native-compact.tar.xz'
full = OUT / 'div2-native-full-waves.tar'
members = {}
def add(tar, path, name):
    assert name not in members
    members[name] = pin(path)
    tar.add(path, arcname=name, recursive=False)

with tarfile.open(capsule, 'w:xz', preset=3) as tar:
    for source in sources + [d.VCO, d.LATCH]:
        add(tar, source, 'sources/' + str(source.relative_to(ROOT)))
    add(tar, Path(__file__), 'review/seal.py')
    add(tar, Path('/dev/shm/nssoc-div2-pytests-01.log'), 'review/pytest.log')
    for p in sorted(RAW.rglob('*')):
        if p.is_file() and p.suffix != '.osdi' and p.name != 'wave.dat.gz':
            add(tar, p, 'native-final/' + str(p.relative_to(RAW)))
    for old in ('nssoc-div2-native-01', 'nssoc-div2-native-02', 'nssoc-div2-prototype-01'):
        folder = Path('/dev/shm') / old
        for p in sorted(folder.rglob('*')):
            if p.is_file() and (p.suffix in ('.json', '.log', '.py', '.cir', '.spice') or p.name == 'spinit'):
                add(tar, p, 'history/' + old + '/' + str(p.relative_to(folder)))
    add(tar, Path('/dev/shm/nssoc-div2-native-final/nominal/wave.dat.gz'), 'native-final/nominal/wave.dat.gz')
with tarfile.open(capsule, 'r:xz') as tar:
    assert {m.name for m in tar.getmembers()} == set(members)
    for m in tar.getmembers():
        b = tar.extractfile(m).read()
        assert len(b) == members[m.name]['bytes']
        assert hashlib.sha256(b).hexdigest() == members[m.name]['sha256']
wave_members = {}
with tarfile.open(full, 'w') as tar:
    for p in sorted(RAW.glob('*/wave.dat.gz')):
        name = str(p.relative_to(RAW))
        wave_members[name] = pin(p)
        tar.add(p, arcname=name, recursive=False)
with tarfile.open(full) as tar:
    assert {m.name for m in tar.getmembers()} == set(wave_members)
    for m in tar.getmembers():
        b = tar.extractfile(m).read()
        assert hashlib.sha256(b).hexdigest() == wave_members[m.name]['sha256']
nominal = record['cases'][0]['measurement']
receipt = dict(
    schema=1, status=record['status'], author_replay=True, independent_peer_review=False,
    source_files={str(p.relative_to(ROOT)): pin(p) for p in sources},
    frozen_parents={str(p.relative_to(ROOT)): pin(p) for p in (d.VCO,d.LATCH)},
    native_result=pin(RAW/'result.json'), inputs=record['inputs'], compiled_models=record['compiled_models'],
    complete_input_output_and_all_12_raw_wave_reparse=True, native_case_count=12,
    required_clean_safe_positive_cases=4, actual_functional_negative_cases=4,
    exploratory_cases=4, exploratory_safe_clean_passes=0,
    cases=summary, nominal=nominal,
    half_step_frequency_relative_delta=record['half_step_frequency_relative_delta'],
    tests={'passed':24,'log':pin(Path('/dev/shm/nssoc-div2-pytests-01.log'))},
    source_and_model_equations_unchanged=True,
    hardware_inventory={'hbt':33,'divider_hbt':15,'resistors':18,'divider_native_mim':2},
    full_capture_duration_s=12e-9, functional_window_s=[4e-9,12e-9], limits=record['limits'],
    compact_capsule={**pin(capsule),'path':str(capsule.relative_to(ROOT)),'members':members},
    full_waves={**pin(full),'path':str(full.relative_to(ROOT)),'compression':'Each of 12 native wave members is gzip-compressed; outer tar is uncompressed.', 'members':wave_members},
    first_compile_failure_preserved='history/nssoc-div2-native-01: OpenVAF parallel runtime failed under 2 GiB; one-thread compile fixed runtime configuration. No native functional result existed in that failed attempt.',
    historical_quick_scope='The earlier quick producer lacked the final full-current/latency guards. Its original producer and raw result are retained as history, not substituted for the final run.',
    scope='Actual frozen native VCO drives a two-native-latch toggle prescaler, nominally 8.01933 GHz to 4.00961 GHz. Four required finite operating cases pass. Cold exploratory VCE failures and hot exploratory initialization warnings prevent full PVT qualification.',
    physical_qualification=False, pll_implemented=False, cdr_implemented=False,
    full_pvt_qualification=False, extracted_layout_timing=False,
    limitations=['One simulator ngspice 47 native campaign; no ngspice 42 cross-version run.', 'No full 81-corner matrix, statistical mismatch, phase noise, random jitter, or RF/package extraction.', 'Finite 4–12 ns measurement window after the actual zero-source supply ramp; minimum VCE is an operating-window screen. Maximum VCE and collector-current density cover the entire 0–12 ns capture.', 'Analytical pytest waveforms test measurement predicates only; transistor evidence comes exclusively from the retained native waveforms.', 'No PCIe link or PLL/CDR compliance claim.'],
)
(OUT/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':pin(OUT/'validation.json'),'compact':pin(capsule),'full_waves':pin(full)},indent=2))
