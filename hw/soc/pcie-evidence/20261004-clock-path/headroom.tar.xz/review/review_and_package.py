# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys,json,lzma,shutil,tempfile,tarfile,hashlib,io
sys.path.insert(0,'scripts');import characterize_pcie_clock_headroom_v2 as v
B=Path('hw/soc/out/pcie-clock-headroom-20261004');parent=Path('/dev/shm/nssoc-clock-vco-full-20261004');startup=Path('/dev/shm/nssoc-vco-zero-v2-full');records={};checked=[];raw_outputs=0;filemap={};wavefiles={}
for label in ('4p0-pilot','3p8-pilot','4p0-full','4p0-tuning'):
 root=Path('/dev/shm/nssoc-vco-headroom-'+label);record=json.loads((root/'result.json').read_text());records[label]=record
 assert record['source_bytes_unchanged'] and record['status']=='CLEAN_CHARACTERIZATION_WITH_EXPLICIT_LIMITS'
 assert [r['case'] for r in record['cases']]==v.cases(record['suite'])
 prior,pins=v.inputs(parent,startup)
 if label.endswith(('full','tuning')):
  candidate=v.old.ROOT/'hw/soc/analog/pcie/clock_vco_hbt_v2.spice';pins[str(candidate)]=v.old.sha(candidate)
 assert pins==record['source_sha256'];assert record['original_limits']==v.old.LIMITS
 models=[Path(p).parent for p in pins if Path(p).name=='cornerHBT.lib'][0]
 assert (root/'spinit').read_text()==v.init.SPINIT
 assert (root/v.NEW_FILE).read_text()==v.revised(v.old.CIRCUIT.read_text(),record['limiter_length_um'])
 for row in record['cases']:
  c=row['case'];d=root/c['name'];assert set(row['outputs'])=={p.name for p in d.iterdir()}
  for name,h in row['outputs'].items():assert v.old.sha(d/name)==h;raw_outputs+=1
  assert (d/'bench.cir').read_text()==v.deck(c,models,[parent/n for n in v.init.MODELS])
  assert (d/v.NEW_FILE).read_text()==v.revised(v.old.circuit(c),record['limiter_length_um'])
  log=(d/'run.log').read_text();assert v.old.diagnostics(log)==row['numerical'] and row['numerical']['clean']
  assert v.init.read_flags(log)==row['flags_observed'];op=v.init.startup.initial_op(d/'initial-op.dat',v.old.vectors());assert op==row['initial_op'] and max(map(abs,op.values()))<=1e-10
  assert row['execution']['returncode']==0 and row['clean_initialization'];assert row['execution']['address_space_limit_bytes']==2*1024**3 and row['execution']['cpu_affinity_count']==1
  if row['wave_retained']:
   with tempfile.TemporaryDirectory(prefix='nssoc-headroom-review-',dir='/dev/shm') as td:
    wave=Path(td)/'wave.dat'
    with lzma.open(d/'wave.dat.xz','rb') as src,wave.open('wb') as dst:shutil.copyfileobj(src,dst)
    assert v.old.sha(wave)==row['uncompressed_wave_sha256'];data=v.old.read_wave(wave)
    assert max(b-a for a,b in zip(data['time'],data['time'][1:]))<=c['step_s']*1.00001
    assert v.old.measure(data)==row['measurement'];del data;checked.append(label+'/'+c['name'])
  if c['fault']:assert row['expected_negative_rejected'] and not row['measurement']['screen_pass']
 assert record['positive_characterization_failures']==[r['case']['name'] for r in record['cases'] if not r['case']['fault'] and not r['measurement']['screen_pass']]
 assert record['negative_controls_rejected']
 if record['suite']=='tuning':assert record['tuning']==v.classify_tuning(record['cases'])
 for p in root.rglob('*'):
  if p.is_file():
   key='native/'+label+'/'+str(p.relative_to(root))
   (wavefiles if p.name.endswith('.xz') else filemap)[key]=p
 print('Reviewed',label,len(record['cases']),flush=True)

sources=['scripts/characterize_pcie_clock_headroom_v2.py','sw/tests/test_pcie_clock_headroom_v2.py','hw/soc/analog/pcie/clock_vco_hbt_v2.spice'];sourcepins={p:v.old.sha(Path(p)) for p in sources}
summary=dict(status='FROZEN_LIMITER_HEADROOM_PROGRESS_WITH_TUNING_LIMITS',source_sha256=sourcepins,native_cases=sum(len(r['cases']) for r in records.values()),cases_by_dataset={k:len(r['cases']) for k,r in records.items()},numerically_clean=sum(r['clean_cases'] for r in records.values()),retained_waves_remeasured=checked,raw_outputs_rehashed=raw_outputs,
 datasets={k:dict(native_result_sha256=v.old.sha(Path('/dev/shm/nssoc-vco-headroom-'+k)/'result.json'),positive_screen_pass=sum(not x['case']['fault'] and x['measurement']['screen_pass'] for x in r['cases']),positive_cases=sum(not x['case']['fault'] for x in r['cases']),negative_controls_rejected=sum(bool(x['case']['fault']) and x['expected_negative_rejected'] for x in r['cases']),failures=[dict(name=x['case']['name'],measurement=x['measurement']) for x in r['cases'] if x['case']['name'] in r['positive_characterization_failures']]) for k,r in records.items()},
 nominal=records['4p0-full']['cases'][0]['measurement'],prior_failed_corner=next(x['measurement'] for x in records['4p0-full']['cases'] if x['case']['name']=='hbt_bcs_mos_ss_125'),tuning=records['4p0-tuning']['tuning'],
 limitations=['Only two limiter load lengths change from4.4 to4.0um; native models/equations,18HBTs, six oscillator loads, asymmetricCMIM seed and all engineering thresholds remain exact.','Both13-case pilot revisions are preserved, including3.8um unselected.4.0um is the smaller change and is only selected for further characterization.','Full72 is the same original separated exploratory corner matrix, not a full factorial PVT sweep.63 tuning samples comprise seven explicitly identified corners times nine control voltages.','Only adjacent actual passing samples can bracket8GHz. A bracket is not a measured operating point, interpolation guarantee, closed-loop lock, PLL, jitter or reference-clock proof.','VCTRL1.3V nooscillation and all other amplitude/period/headroom/current violations remain failed points. The limiter change narrows some valid control ranges.','Original physical layout is untouched and does not cover this new subcircuit. No PHY/mainchip/production acceptance.'])
(B/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for p in sources:filemap['methods/'+p]=Path(p)
for p in pins:
 path=Path(p)
 if '/libs.tech/' in p:filemap['inputs/libs.tech/'+p.split('/libs.tech/',1)[1]]=path
 elif path.is_relative_to(Path.cwd()) and path.suffix in ('.py','.spice'):filemap['methods/'+str(path.relative_to(Path.cwd()))]=path
filemap['prior/original-result.json']=parent/'result.json';filemap['prior/startup-result.json']=startup/'result.json';filemap['review/summary.json']=B/'summary.json';filemap['review/selection.json']=B/'selection.json';filemap['review/review_and_package.py']=Path(__file__)
filemap['NOTICES.txt']=Path('hw/soc/out/pcie-startup-20261004/NOTICES.txt')
for n in ('Apache-2.0','CERN-OHL-W-2.0','BSD-3-Clause','CC-BY-4.0'):
 p=Path('LICENSES')/(n+'.txt')
 if p.exists():filemap[str(p)]=p

def pack(path,members):
 inventory={n:dict(bytes=p.stat().st_size,sha256=v.old.sha(p)) for n,p in sorted(members.items())}
 with tarfile.open(path,'w:xz',preset=6) as tar:
  for n,p in sorted(members.items()):
   info=tarfile.TarInfo(n);info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
   with p.open('rb') as f:tar.addfile(info,f)
  data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('inventory.json');info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 with tarfile.open(path,'r:xz') as tar:
  for n,r in inventory.items():
   f=tar.extractfile(n);h=hashlib.sha256();count=0
   while b:=f.read(1024*1024):h.update(b);count+=len(b)
   assert h.hexdigest()==r['sha256'] and count==r['bytes']
 return dict(path=str(path.resolve()),bytes=path.stat().st_size,sha256=v.old.sha(path),members=len(inventory)+1,roundtrip_verified=True)
compact=pack(B/'clock-headroom-v2-native-compact.tar.xz',filemap)
waves=pack(B/'clock-headroom-v2-native-waves.tar.xz',wavefiles)
validation=dict(status='FROZEN_NATIVE_REVIEW_WITH_EXPLICIT_LIMITS',source_sha256=sourcepins,compact_capsule=compact,wave_capsule=waves,summary_sha256=v.old.sha(B/'summary.json'),focused_and_startup_tests=29,ruff='PASS',replay_source_sha256=v.old.sha(Path(__file__)),recorded_native_datasets={k:v.old.sha(Path('/dev/shm/nssoc-vco-headroom-'+k)/'result.json') for k in records})
(B/'validation.json').write_text(json.dumps(validation,indent=2)+'\n');print(json.dumps(validation,indent=2))
