# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Audit actual dimension-only native controls without dropping other failures."""
import json,hashlib,shlex,collections,re,tarfile
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'hw/soc/out/pcie-magic-hbt-axis-20261004';V=Path('/dev/shm/nssoc-magic-hbt-axis-01');N=Path('/dev/shm/nssoc-magic-hbt-axis-native-01');F=Path('/dev/shm/nssoc-magic-hbt-axis-overlay-01')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def spice(p):
 lines=[]
 for s in p.read_text().splitlines():
  if not s.strip() or s.startswith('*'):continue
  if s.startswith('+'):lines[-1]+=' '+s[1:]
  else:lines.append(s)
 return [s.split() for s in lines]
def ext(p):return [shlex.split(s) for s in p.read_text().splitlines() if s.strip()]
v=json.loads((V/'result.json').read_text());expected={r['tag']:r for r in v['devices']};assert len(expected)==24
for path,key,outputs in [(V/'result.json','inputs','outputs'),(N/'result.json','source_pins','outputs'),(F/'result.json','source_pins','outputs')]:
 r=json.loads(path.read_text());assert all(sha(p)==h for p,h in r[key].items());assert all(sha(path.parent/p)==h for p,h in r[outputs].items())
kl=json.loads((N/'klayout/audit.json').read_text());assert kl['status']=='PASS within comparison scope' and kl['circuits'][0]['layout_devices_recursive']==25
ks=spice(N/'klayout/extracted.cir');assert set(next(r for r in ks if r[0].upper()=='.SUBCKT')[2:])==set(v['ports'])
kq=[r for r in ks if r[0].startswith('Q')];assert len(kq)==24
for r in kq:
 tag=r[1][2:];assert tag in expected and r[2]=='B_'+tag and r[3]=='E_'+tag
 params=dict(t.split('=') for t in r[6:]);assert params==dict(we='70n',le='900n',Nx=str(expected[tag]['nx']),m='1')
old=spice(F/'original-explicit-ports/hbt.spice');new=spice(F/'axis-overlay-explicit-ports/hbt.spice')
assert next(r for r in old if r[0]=='.subckt')[2:]==next(r for r in new if r[0]=='.subckt')[2:]==list(v['ports'])
oldq={r[1][2:]:r for r in old if r[0].startswith('X')};newq={r[1][2:]:r for r in new if r[0].startswith('X')};assert set(oldq)==set(newq)
rows=[]
for tag,r in oldq.items():
 c=newq[tag];assert r[:6]==c[:6]
 assert dict(t.split('=') for t in r[6:])==dict(le='70n',we='0.9u')
 assert dict(t.split('=') for t in c[6:])==dict(we='70n',le='0.9u')
 rows.append(dict(tag=tag,nx_expected=expected[tag]['nx'],orientation=expected[tag]['orientation'],original_dimensions=dict(le='70n',we='0.9u'),overlay_dimensions=dict(we='70n',le='0.9u'),emitter_actual=c[3],emitter_expected='E_'+tag,emitter_matches=c[3]=='E_'+tag,multiplicity_omitted=expected[tag]['nx']!=1))
a=ext(F/'original-explicit-ports/hbt_axis_flat.ext');b=ext(F/'axis-overlay-explicit-ports/hbt_axis_flat.ext')
norm=lambda rs:sorted(tuple(r) for r in rs if r[0]!='timestamp' and not(r[0]=='parameters' and r[1]=='npn13g2'))
assert norm(a)==norm(b)
assert [r for r in b if r[0]=='parameters' and r[1]=='npn13g2']==[['parameters','npn13g2','w1=le','l1=we']]
missing=sorted(set(expected)-set(newq));assert missing==[f'N{nx}_T{o}' for nx in (1,2,4) for o in (1,7)]
assert len(rows)==18 and not any(r['emitter_matches'] for r in rows)
negatives=[]
for tag in ('N2_T1','N4_T6'):
 d=F/('wrong-dimensions-'+tag);audit=json.loads((d/'audit.json').read_text());assert audit['status']=='FAIL' and audit['circuit_status_counts']['NoMatch']==1
 negatives.append(dict(case=tag,audit=pin(d/'audit.json'),status=audit['status']))
record=dict(status='PASS_TWO_AXIS_LABEL_CORRECTION_ONLY_FULL_DEVICE_EXTRACTION_FAILS',sources=[pin(ROOT/'scripts/patch_magic_hbt_axis_v1.py'),pin(ROOT/'sw/tests/test_magic_hbt_axis_v1.py')],native_results=[pin(V/'result.json'),pin(N/'result.json'),pin(F/'result.json')],klayout_complete_reference=dict(hbts=24,ptap=1,ports=73,nx_values=[1,2,4],orientation_codes=list(range(8)),audit=kl),magic=dict(original_hbts=18,overlay_hbts=18,ports=73,dimensions_corrected_on_all_exported_devices=True,device_terminal_cap_geometry_records_unchanged=True,missing_device_tags=missing,emitter_mismatches=18,nx_gt_one_without_multiplicity=12,device_rows=rows,full_device_acceptance=False),actual_wrong_dimension_native_negatives=negatives,tests=dict(command='PYTHONDONTWRITEBYTECODE=1 TMPDIR=/dev/shm .venv/bin/python -m pytest sw/tests/test_magic_hbt_axis_v1.py -q -p no:cacheprovider',passed=7,skipped_local=0,public_pdk_dependent_tests_skip_if_unprovisioned=6,ruff='All checks passed'),reproduce=dict(overlay='python scripts/patch_magic_hbt_axis_v1.py --source ORIGINAL_TECH/ihp-sg13g2-extract.tech --out FRESH_TECH_FILE',native_control_methods=['make_fixture.py','native_fixture.py','native_axis_overlay.py','audit_axis.py'],note='Replay into fresh /dev/shm paths; copy unchanged original technology directory and replace only this generated extraction file. Original PDK and frozen Magic runtime are never changed.'),limitations=['This fixes only a demonstrated parameter-label inversion in an isolated technology copy. No resistance, model equations, geometry or numeric constants are fitted.','All24 native GDS HBTs and real substrate contact pass independent KLayout LVS. Magic loses the six T1/T7 devices and maps all18 exported emitters to other internal nodes, while omitting required Nx for12 exported Nx2/4 devices. These are separate failures, not waived.','T0..T3 are R0/R90/R180/R270; T4..T7 are mirrored versions passed directly as pya.DTrans(rot,mirror).','Original first fixture Magic port creation encountered multiple PCell labels under cursor; it is retained as interface failure. Final original/overlay runs select the explicit unique port name and both preserve all73ports.','No complete transistor equivalence, tap recovery, bank RC conservation or RF/PEX qualification.'],qualified_pex=False,original_pdk_unchanged=True)
(OUT/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
paths={}
for tag,folder in [('fixture',V),('first-native',N),('final-native',F)]:
 for p in folder.rglob('*'):
  if p.is_file() and not p.is_relative_to(F/'isolated-tech'):paths[tag+'/'+str(p.relative_to(folder))]=p
for p in OUT.glob('*.py'):paths['methods/'+p.name]=p
for rel in ('scripts/patch_magic_hbt_axis_v1.py','sw/tests/test_magic_hbt_axis_v1.py'):paths['methods/'+rel]=ROOT/rel
paths['validation.json']=OUT/'validation.json'
manifest={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in paths.items()};m=Path('/dev/shm/nssoc-hbt-axis-manifest.json');m.write_text(json.dumps(manifest,indent=2)+'\n');paths['manifest.json']=m
caps=OUT/'hbt-axis-native-controls.tar.xz'
with tarfile.open(caps,'w:xz') as tf:
 for n,p in sorted(paths.items()):tf.add(p,arcname=n,recursive=False)
with tarfile.open(caps,'r:xz') as tf:
 assert len(tf.getmembers())==len(paths)
 for member in tf.getmembers():
  if member.name=='manifest.json':continue
  raw=tf.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==manifest[member.name]['sha256']
receipt=dict(status=record['status'],validation=pin(OUT/'validation.json'),capsule=pin(caps),members=len(paths),vendor_implementation_and_runtime_not_redistributed=True)
(OUT/'capsule.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
