# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys,shutil,hashlib
ROOT=Path.cwd();sys.path[:0]=[str(ROOT/'hw/soc/flow'),str(ROOT/'scripts')];from check_pcie_rx_cell import execute
from patch_magic_hbt_axis_v1 import patch
OUT=Path('/dev/shm/nssoc-magic-hbt-axis-overlay-01');OUT.mkdir();VIEW=Path('/dev/shm/nssoc-magic-hbt-axis-01');r=json.loads((VIEW/'result.json').read_text());APP=ROOT/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
RT=Path('/dev/shm/nssoc-magic-coupled-v2-build-final/runtime/lib');TECH=ROOT/'hw/soc/out/sram-closure-20260926/magic-tech-via-import';overlay=OUT/'isolated-tech';shutil.copytree(TECH,overlay)
file=overlay/'ihp-sg13g2-extract.tech';file.write_bytes(patch(file.read_bytes()))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
tech_pins={str(p):sha(p) for p in TECH.iterdir() if p.is_file()}
assert all((overlay/p.name).read_bytes()==p.read_bytes() for p in TECH.iterdir() if p.is_file() and p.name!='ihp-sg13g2-extract.tech')
steps=[]
for name,tech in [('original-explicit-ports',TECH),('axis-overlay-explicit-ports',overlay)]:
 d=OUT/name;d.mkdir();lines=['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',f'cd {{{d}}}','drc off','gds readonly true',f'gds read {{{VIEW/"fixture.gds"}}}','load nssoc_hbt_axis','flatten hbt_axis_flat','load hbt_axis_flat','select top cell']
 for i,(n,p) in enumerate(r['ports'].items(),1):
  b=p['box'];layer={8:'metal1',10:'metal2'}[p['layer']];lines+=['box values '+' '.join(str(v)+'um' for v in b),f'label {n} center {layer}',f'port {n} make {i}',f'port {n} class inout',f'port {n} use signal']
 lines+=['save hbt_axis_flat','extract style ngspice()','extract all','ext2spice lvs','ext2spice global off','ext2spice cthresh infinite','ext2spice extresist off','ext2spice -o hbt.spice','quit -noprompt'];script=d/'extract.tcl';script.write_text('\n'.join(lines)+'\n')
 x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',tech/'ihp-sg13g2.magicrc',script],d,'native');steps.append(dict(name=name,execution=x));assert x['returncode']==0
for tag in ('N2_T1','N4_T6'):
 d=OUT/('wrong-dimensions-'+tag);d.mkdir();before=(VIEW/'schematic.cir').read_text();old=f'Q{tag} C_{tag} B_{tag} E_{tag} BULK npn13G2 Nx={tag[1]} we=0.07u le=0.9u m=1';assert before.count(old)==1
 wrong=d/'wrong.cir';wrong.write_text(before.replace(old,old.replace('we=0.07u le=0.9u','we=0.9u le=0.07u')))
 cmd=[APP,'klayout','-b','-zz','-r',ROOT/'hw/soc/tools/ihp-lvs-5e6d592/ihp-sg13g2/libs.tech/klayout/tech/lvs/sg13g2.lvs']
 for value in ['input='+str(VIEW/'fixture.gds'),'topcell=nssoc_hbt_axis','schematic='+str(wrong),'report='+str(d/'result.lvsdb'),'target_netlist='+str(d/'extracted.cir'),'log='+str(d/'deck.log'),'run_mode=deep','thr=2']:cmd+=['-rd',value]
 x=execute(cmd,d,'native');assert x['returncode']==0
 audit=execute([APP,'python',ROOT/'hw/soc/flow/audit_klayout_lvs.py',d/'result.lvsdb','--top','nssoc_hbt_axis','--deck-log',d/'deck.log','--output',d/'audit.json'],d,'audit');assert audit['returncode']==1
 steps.append(dict(name=d.name,execution=x,audit_execution=audit))
assert all(sha(p)==h for p,h in tech_pins.items())
inputs={**tech_pins,**{str(p):sha(p) for p in [Path(__file__).resolve(),ROOT/'scripts/patch_magic_hbt_axis_v1.py',VIEW/'result.json',VIEW/'fixture.gds',VIEW/'schematic.cir',RT/'magic/tcl/tclmagic.so']}}
record=dict(steps=steps,source_pins=inputs,overlay_tech_sha256=sha(file),outputs={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()},original_tech_unchanged=True,qualified_pex=False)
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');print([(x['name'],x['execution']['returncode']) for x in steps])
