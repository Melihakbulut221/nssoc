# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""24 native isolated HBT geometry controls; no source PCell/deck alteration."""
import sys,json,hashlib
from pathlib import Path
ROOT=Path.cwd();OUT=Path('/dev/shm/nssoc-magic-hbt-axis-01');assert not OUT.exists();OUT.mkdir()
PDK=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2');SOURCE=PDK/'libs.tech/klayout/python'
sys.dont_write_bytecode=True;sys.path[:0]=[str(SOURCE),str(SOURCE/'pycell4klayout-api/source/python')]
import pya
import sg13g2_pycell_lib
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [Path(__file__).resolve(),*SOURCE.rglob('*.py'),*SOURCE.rglob('*.json')]}
l=pya.Layout();top=l.create_cell('nssoc_hbt_axis');rows=[];ports={};bodies=[]
def pin(name,metal,b):
 top.shapes(l.layer(metal,2)).insert(b);top.shapes(l.layer(metal,25)).insert(pya.DText(name,pya.DTrans(b.center().x,b.center().y)));ports[name]=dict(layer=metal,box=[b.left,b.bottom,b.right,b.top])
for ix,nx in enumerate((1,2,4)):
 c=l.create_cell('npn13G2','SG13_dev',{'Nx':nx});assert c and not c.is_empty()
 ps=sorted([s.dbbox() for s in c.each_shape(l.layer(8,2))],key=lambda b:b.center().y);es=[s.dbbox() for s in c.each_shape(l.layer(10,2))];assert len(ps)==2 and len(es)==1
 for orientation in range(8):
  tag=f'N{nx}_T{orientation}';t=pya.DTrans(orientation%4,orientation>=4,20+orientation*40,30+ix*40);top.insert(pya.DCellInstArray(c.cell_index(),t))
  for suffix,metal,b in [('C',8,ps[1]),('B',8,ps[0]),('E',10,es[0])]:pin(suffix+'_'+tag,metal,b.transformed(t))
  bodies.append(f'Q{tag} C_{tag} B_{tag} E_{tag} BULK npn13G2 Nx={nx} we=0.07u le=0.9u m=1')
  rows.append(dict(tag=tag,nx=nx,orientation=orientation,transform=str(t)))
tap=l.create_cell('ptap1','SG13_dev',{'w':'2u','l':'2u'});t=pya.DTrans(10,5);top.insert(pya.DCellInstArray(tap.cell_index(),t));ps=[s.dbbox() for s in tap.each_shape(l.layer(8,2))];assert len(ps)==1;pin('SUB',8,ps[0].transformed(t));bodies.append('RTAP SUB BULK ptap1 A=4p P=8u')
l.write(str(OUT/'fixture.gds'));(OUT/'schematic.cir').write_text('.subckt nssoc_hbt_axis '+' '.join(ports)+'\n'+'\n'.join(bodies)+'\n.ends nssoc_hbt_axis\n')
assert all(sha(p)==h for p,h in pins.items());r=dict(inputs=pins,ports=ports,devices=rows,outputs={p.name:sha(p) for p in OUT.iterdir()});(OUT/'result.json').write_text(json.dumps(r,indent=2)+'\n')
