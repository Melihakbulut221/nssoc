# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,sys,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'hw/soc/flow'));from check_pcie_rx_cell import execute
OUT=Path('/dev/shm/nssoc-magic-hbt-axis-native-01');OUT.mkdir();VIEW=Path('/dev/shm/nssoc-magic-hbt-axis-01');r=json.loads((VIEW/'result.json').read_text());APP=ROOT/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
RT=Path('/dev/shm/nssoc-magic-coupled-v2-build-final/runtime/lib');TECH=ROOT/'hw/soc/out/sram-closure-20260926/magic-tech-via-import'
steps=[]
d=OUT/'klayout';d.mkdir();cmd=[APP,'klayout','-b','-zz','-r',ROOT/'hw/soc/tools/ihp-lvs-5e6d592/ihp-sg13g2/libs.tech/klayout/tech/lvs/sg13g2.lvs']
for value in ['input='+str(VIEW/'fixture.gds'),'topcell=nssoc_hbt_axis','schematic='+str(VIEW/'schematic.cir'),'report='+str(d/'result.lvsdb'),'target_netlist='+str(d/'extracted.cir'),'log='+str(d/'deck.log'),'run_mode=deep','thr=2']:cmd+=['-rd',value]
x=execute(cmd,d,'native');steps.append(x);assert x['returncode']==0
x=execute([APP,'python',ROOT/'hw/soc/flow/audit_klayout_lvs.py',d/'result.lvsdb','--top','nssoc_hbt_axis','--deck-log',d/'deck.log','--output',d/'audit.json'],d,'audit');steps.append(x)
d=OUT/'magic-original';d.mkdir();lines=['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',f'cd {{{d}}}','drc off','gds readonly true',f'gds read {{{VIEW/"fixture.gds"}}}','load nssoc_hbt_axis','flatten hbt_axis_flat','load hbt_axis_flat','select top cell']
for i,(name,p) in enumerate(r['ports'].items(),1):
 b=p['box'];layer={8:'metal1',10:'metal2'}[p['layer']];lines+=['box values '+' '.join(str(v)+'um' for v in b),f'label {name} center {layer}',f'port make {i}','port class inout','port use signal']
lines+=['save hbt_axis_flat','extract style ngspice()','extract all','ext2spice lvs','ext2spice global off','ext2spice cthresh infinite','ext2spice extresist off','ext2spice -o hbt.spice','quit -noprompt'];script=d/'extract.tcl';script.write_text('\n'.join(lines)+'\n')
x=execute(['/usr/bin/env','CAD_ROOT='+str(RT),'/usr/bin/tclsh8.6',RT/'magic/tcl/magic.tcl','-dnull','-noconsole','-rcfile',TECH/'ihp-sg13g2.magicrc',script],d,'native');steps.append(x);assert x['returncode']==0
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record=dict(steps=steps,source_pins={str(p):sha(p) for p in [Path(__file__).resolve(),VIEW/'result.json',VIEW/'fixture.gds',VIEW/'schematic.cir',TECH/'ihp-sg13g2-extract.tech',RT/'magic/tcl/tclmagic.so']},outputs={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()});(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(record['steps'])
