# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
import sys,types,pathlib,json,subprocess,os,gzip,shutil,resource,re
sys.path.insert(0,'/home/hasanmelih/Documents/ChatGPT/nnsoc/scripts')
import characterize_pcie_div2_v2 as v2
old=v2.old
OUT=pathlib.Path('/dev/shm/nssoc-div2-condition-pilot-01')
assert not OUT.exists(); OUT.mkdir()
CIR='''* SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
* SPDX-License-Identifier: CERN-OHL-W-2.0
* Separate native resistive clock common-mode conditioner prototype.
.subckt nssoc_clock_div2_conditioned_hbt clkp clkn qp qn avdd avss sub
XSP clkp ckp sub rppd w=4u l=3.6u b=0 sw_et=1
XSN clkn ckn sub rppd w=4u l=3.6u b=0 sw_et=1
XUP avdd ckp sub rppd w=1u l=8u b=0 sw_et=1
XUN avdd ckn sub rppd w=1u l=8u b=0 sw_et=1
XCORE ckp ckn qp qn avdd avss sub nssoc_clock_div2_hbt
.ends nssoc_clock_div2_conditioned_hbt
'''
(OUT/'clock_div2_conditioned_hbt.spice').write_text(CIR)
pathlib.Path(OUT/'pilot-at-run.py').write_bytes(pathlib.Path(__file__).read_bytes())
source={ 'nssoc_clock_div2_conditioned_hbt':CIR,'nssoc_clock_div2_hbt':old.CIRCUIT.read_text(),'nssoc_cml_latch':old.LATCH.read_text(),'nssoc_clock_vco_hbt_v2':v2.VCO.read_text() }
def device_contract(case):
 hbts={};res=[]
 def add(name,prefix,actual):
  ports,body=old.statements(source[name],name);assert len(ports)==len(actual)
  m=dict(zip(ports,actual)); node=lambda n:m.get(n,prefix+'.'+n)
  for words in body:
   if words[0][0]!='x':continue
   if len(words)>5 and words[5]=='npn13g2': hbts[prefix+'.'+words[0]]=(tuple(node(n) for n in words[1:4]),int(next(w[3:] for w in words[6:] if w.startswith('nx='))))
   elif len(words)>4 and words[4]=='rppd':res.append(prefix+'.'+words[0])
   elif words[-1] in source:add(words[-1],prefix+'.'+words[0],[node(n) for n in words[1:-1]])
 add('nssoc_clock_vco_hbt_v2','xosc',['clkp','clkn','vctrl','avdd','0','0'])
 add('nssoc_clock_div2_conditioned_hbt','xdiv',['clkp','clkn','qp','qn','dvdd','0','0'])
 assert len(hbts)==33 and len(res)==22
 return hbts,res
def vectors(case):
 h,r=device_contract(case); ns={n for pins,_ in h.values() for n in pins}|{'clkp','clkn','xdiv.ckp','xdiv.ckn','qp','qn','avdd','dvdd','vctrl'}
 return ['v('+n+')' for n in sorted(ns-{'0'})]+['i(vdd)','i(vddiv)','i(vctrl)']+['@q.'+n+'.qnpn13g2[ic]' for n in h]+['v('+n+'.dt)' for n in r]
# Separate function namespaces bind exact source-derived terminals without any
# mutation of imported/frozen module globals or bytecode.
measure=types.FunctionType(old.measure.__code__,dict(old.measure.__globals__,device_contract=device_contract))
read_wave=types.FunctionType(old.read_wave.__code__,dict(old.read_wave.__globals__,vectors=vectors))
prior=json.load(open('/dev/shm/nssoc-div2-native-final/result.json')); pins=dict(prior['inputs']);pins.update(prior['compiled_models']);pins[str(v2.VCO)]=old.sha(v2.VCO);pins[__file__]=old.sha(pathlib.Path(__file__));pins[str(OUT/'clock_div2_conditioned_hbt.spice')]=old.sha(OUT/'clock_div2_conditioned_hbt.spice')
assert all(old.sha(pathlib.Path(p))==h for p,h in pins.items());v2.verify_vco()
models=next(pathlib.Path(p).parent for p in pins if p.endswith('/cornerHBT.lib')); osdi=[pathlib.Path(p) for p in prior['compiled_models']]; runtime=next(p for p in pins if pathlib.Path(p).name=='ngspice')
(OUT/'spinit').write_text('* Explicit native models only.\nset num_threads=1\n')
result={'status':'RUNNING','inputs':pins,'cases':[],'scope':'Prototype finite actual conditioned VCO-driven divider; no qualification. Frozen native functions bind an isolated source-derived device namespace; no module-global mutation.'}
def save():(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
def bound():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
for c in [x for x in old.cases() if x['name'] in ('nominal','cold_fast','cold_slow','hot_slow')]:
 p=OUT/c['name'];p.mkdir()
 for f in(v2.VCO,old.LATCH,old.CIRCUIT):shutil.copyfile(f,p/f.name)
 (p/'clock_div2_conditioned_hbt.spice').write_text(CIR)
 deck=old.deck(c,models,osdi).split('.control')[0].replace('clock_vco_hbt.spice','clock_vco_hbt_v2.spice').replace('nssoc_clock_vco_hbt\n','nssoc_clock_vco_hbt_v2\n').replace('nssoc_clock_div2_hbt\n','nssoc_clock_div2_conditioned_hbt\n')
 deck+='.include "clock_div2_conditioned_hbt.spice"\n.control\n'+''.join('pre_osdi '+str(o)+'\n' for o in osdi)+'set wr_singlescale\nset wr_vecnames\nset numdgt=12\nsave '+' '.join(vectors(c))+'\n'
 ids=['q.'+n+'.qnpn13g2' for n in device_contract(c)[0]]
 for n in ids:deck+=f'alter @{n}[off] = 1\necho NSSOC_DIV2_FLAG_BEGIN {n}\nshow {n} : off\necho NSSOC_DIV2_FLAG_END\n'
 deck+='op\nwrdata initial-op.dat '+' '.join(vectors(c))+f'\ntran {c["step_s"]:.12g} 12n 0 {c["step_s"]:.12g}\nwrdata wave.dat '+' '.join(vectors(c))+'\nquit\n.endc\n.end\n';(p/'bench.cir').write_text(deck)
 row={'case':c};result['cases'].append(row);save()
 with (p/'run.log').open('w') as f:r=subprocess.run([runtime,'-n','-b','bench.cir'],cwd=p,env={**os.environ,'SPICE_SCRIPTS':str(OUT)},stdout=f,stderr=subprocess.STDOUT,timeout=180,preexec_fn=bound)
 row['returncode']=r.returncode;log=(p/'run.log').read_text();row['diagnostics']=old.diagnostics(log)
 flags=re.findall(r'(?ms)^NSSOC_DIV2_FLAG_BEGIN (\S+)\n(.*?)^NSSOC_DIV2_FLAG_END\s*$',log);assert [n for n,_ in flags]==ids
 assert all(re.findall(r'(?m)^\s*device\s+(\S+)\s*$',b)==[n[:21]] and re.findall(r'(?m)^\s*off\s+(\S+)\s*$',b)==['1'] for n,b in flags)
 op=(p/'initial-op.dat').read_text().splitlines();assert len(op)==2 and op[0].split()[1:]==vectors(c);vals=list(map(float,op[1].split()));assert len(vals)==len(vectors(c))+1 and all(__import__('math').isfinite(x) for x in vals) and max(map(abs,vals[1:]))<=1e-10
 row['flags_verified']=len(ids);row['zero_op']=True
 data=read_wave(p/'wave.dat',c);row['measurement']=measure(data,c)
 active=[i for i,t in enumerate(data['time']) if t>=4e-9]
 for key,a,b in [('conditioned_clock','v(xdiv.ckp)','v(xdiv.ckn)'),('raw_clock','v(clkp)','v(clkn)')]:
  diff=[data[a][i]-data[b][i] for i in active];cm=[(data[a][i]+data[b][i])/2 for i in active]
  row[key]={'diff_range':[min(diff),max(diff)],'cm_range':[min(cm),max(cm)]}
 row['wave_sha256']=old.sha(p/'wave.dat')
 with (p/'wave.dat').open('rb') as a,gzip.open(p/'wave.dat.gz','wb') as b:shutil.copyfileobj(a,b)
 (p/'wave.dat').unlink();row['outputs']={f.name:old.sha(f) for f in p.iterdir() if f.is_file()};save()
 print(c['name'],row['diagnostics']['clean'],{k:v for k,v in row['measurement']['checks'].items() if not v},min((x['min_operating_vce_v'],n) for n,x in row['measurement']['devices'].items()),flush=True)
assert all(old.sha(pathlib.Path(p))==h for p,h in pins.items());result['inputs_rechecked']=True;result['status']='PASS_FINITE_PROTOTYPE' if all(x['returncode']==0 and x['diagnostics']['clean'] and x['measurement']['screen_pass'] for x in result['cases']) else 'FAIL_PRESERVED';save()
