# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Author audit of all actual native conditioned-divider data; no simulation."""
from pathlib import Path
import sys,json,hashlib,gzip,tarfile,shutil
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT/'scripts'))
import characterize_pcie_div2_conditioned as c
B=Path(__file__).resolve().parent;RAW=Path('/dev/shm/nssoc-div2-condition-native-final')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for x in iter(lambda:s.read(1048576),b''):h.update(x)
 return h.hexdigest()
def pin(p):return {'bytes':p.stat().st_size,'sha256':sha(p)}
def canonical(x):return json.loads(json.dumps(x))
r=json.loads((RAW/'result.json').read_text());assert r['status']=='PASS_FINITE_CONDITIONED_DIV2_SCREEN' and r['complete_inputs_rechecked']
assert not r['pilot'] and [x['case'] for x in r['cases']]==c.old.cases(False)
assert r['limits']==c.old.LIMITS and r['conditioner_min_peak_v']==0.3 and len(r['source_sha256'])==72
c.verify_vco()
for p,h in r['source_sha256'].items():assert sha(Path(p))==h,p
models=next(Path(p).parent for p in r['source_sha256'] if p.endswith('/cornerHBT.lib'))
osdi=[Path(p) for p in r['source_sha256'] if p.endswith('.osdi')]
assert [p.name for p in osdi]==['r3_cmc.osdi','psp103.osdi','psp103_nqs.osdi']
summary=[]
for e in r['cases']:
 case=e['case'];folder=RAW/case['name']
 assert set(e['outputs'])=={p.name for p in folder.iterdir() if p.is_file()}
 for name,h in e['outputs'].items():assert sha(folder/name)==h
 assert (folder/'bench.cir').read_text()==c.deck(case,models,osdi)
 assert (folder/c.old.CIRCUIT.name).read_text()==c.old.circuit(case)
 for source in(c.VCO,c.old.LATCH,c.CIRCUIT):assert (folder/source.name).read_bytes()==source.read_bytes()
 log=(folder/'run.log').read_text();assert c.read_flags(log,case)==e['flags_observed']
 assert c.initial_op(folder/'initial-op.dat',case)==e['initial_op']
 assert c.old.diagnostics(log)==e['numerical']
 h=hashlib.sha256()
 with gzip.open(folder/'wave.dat.gz','rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 assert h.hexdigest()==e['uncompressed_wave_sha256']
 measured=c.measure(c.read_wave(folder/'wave.dat.gz',case),case)
 assert canonical(measured)==e['measurement']
 assert c.accepted(e) and e['expected_outcome_observed'] and e['returncode']==0 and not e.get('execution_failure')
 ds=measured['devices']
 summary.append(dict(name=case['name'],role=case['role'],fault=case['fault'],numerical_clean=e['numerical']['clean'],zero_initial_op=True,native_flags=33,input_hz=measured['input_frequency_hz'],output_hz=measured['output_frequency_hz'],functional_divide_pass=measured['functional_divide_pass'],all_numeric_limits_pass=measured['screen_pass'],failed_checks=[k for k,v in measured['checks'].items() if not v],min_operating_vce=min((d['min_operating_vce_v'],k) for k,d in ds.items()),max_capture_vce=max((d['max_capture_vce_v'],k) for k,d in ds.items()),max_capture_abs_ic_per_nx=max(d['max_capture_abs_ic_a_per_nx'] for d in ds.values()),raw_clock=measured['raw_clock'],conditioned_clock=measured['conditioned_clock'],conditioner_models=measured['conditioner_models'],duty_range=measured['duty_range'],edge_delay_range_s=measured['edge_delay_range_s'],period_ratio_to_two=measured['period_ratio_to_exact_two'],mean_divider_power_w=measured['mean_divider_supply_power_w'],mean_vco_power_w=measured['mean_vco_supply_power_w']))
 print('Replayed',case['name'],flush=True)
for p,h in r['source_sha256'].items():assert sha(Path(p))==h,p
sources=[c.CIRCUIT,Path(c.__file__).resolve(),ROOT/'sw/tests/test_pcie_div2_conditioned.py']
reused=[c.old.CIRCUIT,c.VCO,c.old.VCO,c.old.LATCH,Path(c.old.__file__).resolve(),Path(c.previous.__file__).resolve()]
all_sources={str(p.relative_to(ROOT)):pin(p) for p in sources+reused}
compact=B/'div2-conditioned-native-compact.tar.xz';members={}
def add(tar,p,name):
 assert name not in members;members[name]=pin(p);tar.add(p,arcname=name,recursive=False)
with tarfile.open(compact,'w:xz',preset=1) as t:
 for p in sources+reused:add(t,p,'sources/'+str(p.relative_to(ROOT)))
 for p in sorted(RAW.rglob('*')):
  if p.is_file() and p.name!='wave.dat.gz':add(t,p,'native/'+str(p.relative_to(RAW)))
 add(t,RAW/'nominal/wave.dat.gz','native/nominal/wave.dat.gz')
 add(t,Path('/dev/shm/nssoc-div2-condition-tests-01.log'),'review/pytest.log')
 add(t,Path(__file__),'review/seal_conditioned.py')
 for name in ('nssoc-div2-condition-pilot-01','nssoc-div2-condition-model-op-01'):
  folder=Path('/dev/shm')/name
  for p in sorted(folder.rglob('*')):
   if p.is_file() and p.name!='wave.dat.gz':add(t,p,'history/'+name+'/'+str(p.relative_to(folder)))
with tarfile.open(compact) as t:
 assert {m.name for m in t.getmembers()}==set(members)
 for m in t.getmembers():
  data=t.extractfile(m).read();assert len(data)==members[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==members[m.name]['sha256']
full=B/'div2-conditioned-full-waves.tar';waves={str(p.relative_to(RAW)):pin(p) for p in sorted(RAW.glob('*/wave.dat.gz'))}
need=sum(x['bytes'] for x in waves.values())+64*1024**2
assert shutil.disk_usage(B).free>need,('Insufficient disk for complete compressed-wave capsule',need)
with tarfile.open(full,'w') as t:
 for name in waves:t.add(RAW/name,arcname=name,recursive=False)
with tarfile.open(full) as t:
 assert {m.name for m in t.getmembers()}==set(waves)
 for m in t.getmembers():
  data=t.extractfile(m).read();assert len(data)==waves[m.name]['bytes'] and hashlib.sha256(data).hexdigest()==waves[m.name]['sha256']
positive=[e for e in summary if not e['fault']]
result=dict(schema=1,status=r['status'],source_files={str(p.relative_to(ROOT)):pin(p) for p in sources},frozen_reuse_sources={str(p.relative_to(ROOT)):pin(p) for p in reused},native_result=pin(RAW/'result.json'),inputs=r['source_sha256'],source_and_full_raw_author_replay=True,independent_peer_review=False,native_process_count=12,clean_safe_positive_cases=8,clean_actual_functional_negative_cases=4,tests={'passed':56,'log':pin(Path('/dev/shm/nssoc-div2-condition-tests-01.log'))},complete_actual_hbt_census=33,complete_actual_resistor_census=22,actual_conditioning_rppd_count=4,all_33_flags_native_readback_verified=True,all_initial_electrical_thermal_op_zero=True,all_12_native_waves_full_reparsed=True,all_actual_devices_current_and_vce_measured=True,inherited_measurement_bytecode_identity=True,imported_module_globals_unchanged=True,model_equations_tolerances_and_hbt_limits_unchanged=True,maximum_full_capture_vce_v=max(x['max_capture_vce'][0] for x in positive),minimum_operating_vce_v=min(x['min_operating_vce'][0] for x in positive),maximum_full_capture_ic_a_per_nx=max(x['max_capture_abs_ic_per_nx'] for x in positive),cases=summary,nominal_measurement=r['cases'][0]['measurement'],half_step_frequency_relative_delta=r['half_step_frequency_relative_delta'],compact_capsule={**pin(compact),'path':str(compact.relative_to(ROOT)),'members':members},full_wave_capsule={**pin(full),'path':str(full.relative_to(ROOT)),'compression':'12 individual gzip waves in an uncompressed tar; no recompression or wave omission.','members':waves},prior_unconditioned_v1=pin(B/'validation.json'),prior_unconditioned_v2_failure=pin(B/'v2-pilot-validation.json'),physical_layout_implemented=False,full_pvt_qualification=False,pll_implemented=False,cdr_implemented=False,scope='Finite actual VCO-v2 plus four-native-resistor conditioner and two frozen HBT latch prescaler. All eight finite positive cases and four actual functional fault controls meet their strict predicates. This fixes the observed cold common-mode headroom defect in this local 50fF clock-load experiment only.',limitations=['No full 81-corner/PVT or statistical mismatch campaign. Four explicitly selected corner cases only.', 'Free-running input/output frequencies vary by corner; this is not a locked 8GHz/4GHz clock or PLL.', 'No full extracted bank clock fanout, wire RC, jitter/phase-noise or package load included. Default each raw clock has50fF plus actual conditioner/divider native loading; divided outputs50fF or the explicit100fF case.', 'No physical layout for the new conditioner or revised VCO is qualified here. Existing old-VCO layout is not substituted.', 'OFF is a documented native initial Newton flag; external zero-source ramps are explicit test conditions, not a physical sequencer.', 'Whole0–12ns capture enforces maximum VCE/current and finite vectors; minimum VCE/duty/division use4–12ns operating window.', 'Only ngspice47 campaign run here; no cross-version replay yet.', 'Four-rppd current,resistance,selfheat and whole supply power are native observations; no independent resistor thermal-reliability qualification asserted.'])
(B/'conditioned-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'receipt':pin(B/'conditioned-validation.json'),'compact':pin(compact),'full_waves':pin(full)},indent=2))
