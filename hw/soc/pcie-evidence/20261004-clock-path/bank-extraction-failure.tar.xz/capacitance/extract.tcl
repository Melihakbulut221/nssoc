puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-clocked-magic-v3-01}
drc off
gds readonly true
gds read {/dev/shm/nssoc-clocked-bank-v3-01/nssoc_pcie_clocked_bank4_v3.gds}
load nssoc_pcie_clocked_bank4_v3
flatten nssoc_clocked_v3_flat
load nssoc_clocked_v3_flat
select top cell
box values 1088.0um 0.0um 1092.0um 4.0um
label AVDD1V8 center metal7
port make 1
port class inout
port use signal
box values 1108.0um 0.0um 1112.0um 4.0um
label AVDD2V5 center metal7
port make 2
port class inout
port use signal
box values 1128.0um 0.0um 1132.0um 4.0um
label AVSS center metal7
port make 3
port class inout
port use signal
box values 1148.0um 0.0um 1152.0um 4.0um
label SUB center metal7
port make 4
port class inout
port use signal
box values 1618.0um 0.0um 1622.0um 4.0um
label AVDD2V3 center metal7
port make 5
port class inout
port use signal
box values 0.0um 79.0um 2.0um 81.0um
label L0_TX_INP center metal6
port make 6
port class inout
port use signal
box values 1648.0um 79.0um 1650.0um 81.0um
label L0_TX_INN center metal6
port make 7
port class inout
port use signal
box values 0.0um 51.0um 2.0um 53.0um
label L0_TX_IREF center metal6
port make 8
port class inout
port use signal
box values 0.0um 87.0um 2.0um 89.0um
label L0_TX_OUTN center metal6
port make 9
port class inout
port use signal
box values 1648.0um 87.0um 1650.0um 89.0um
label L0_TX_OUTP center metal6
port make 10
port class inout
port use signal
box values 0.0um 264.0um 2.0um 266.0um
label L0_RX_INP center metal6
port make 11
port class inout
port use signal
box values 1648.0um 264.0um 1650.0um 266.0um
label L0_RX_INN center metal6
port make 12
port class inout
port use signal
box values 0.0um 236.0um 2.0um 238.0um
label L0_RX_IREF center metal6
port make 13
port class inout
port use signal
box values 1648.0um 352.0um 1650.0um 354.0um
label L0_RX_VCM center metal6
port make 14
port class inout
port use signal
box values 1648.0um 485.03000000000003um 1650.0um 487.03000000000003um
label L0_SAMPLER_QP center metal6
port make 15
port class inout
port use signal
box values 1648.0um 495.03000000000003um 1650.0um 497.03000000000003um
label L0_SAMPLER_QN center metal6
port make 16
port class inout
port use signal
box values 0.0um 555.03um 2.0um 557.03um
label L0_SAMPLER_IREF center metal6
port make 17
port class inout
port use signal
box values 0.0um 739.0um 2.0um 741.0um
label L1_TX_INP center metal6
port make 18
port class inout
port use signal
box values 1648.0um 739.0um 1650.0um 741.0um
label L1_TX_INN center metal6
port make 19
port class inout
port use signal
box values 0.0um 711.0um 2.0um 713.0um
label L1_TX_IREF center metal6
port make 20
port class inout
port use signal
box values 0.0um 747.0um 2.0um 749.0um
label L1_TX_OUTN center metal6
port make 21
port class inout
port use signal
box values 1648.0um 747.0um 1650.0um 749.0um
label L1_TX_OUTP center metal6
port make 22
port class inout
port use signal
box values 0.0um 924.0um 2.0um 926.0um
label L1_RX_INP center metal6
port make 23
port class inout
port use signal
box values 1648.0um 924.0um 1650.0um 926.0um
label L1_RX_INN center metal6
port make 24
port class inout
port use signal
box values 0.0um 896.0um 2.0um 898.0um
label L1_RX_IREF center metal6
port make 25
port class inout
port use signal
box values 1648.0um 1012.0um 1650.0um 1014.0um
label L1_RX_VCM center metal6
port make 26
port class inout
port use signal
box values 1648.0um 1145.03um 1650.0um 1147.03um
label L1_SAMPLER_QP center metal6
port make 27
port class inout
port use signal
box values 1648.0um 1155.03um 1650.0um 1157.03um
label L1_SAMPLER_QN center metal6
port make 28
port class inout
port use signal
box values 0.0um 1215.03um 2.0um 1217.03um
label L1_SAMPLER_IREF center metal6
port make 29
port class inout
port use signal
box values 0.0um 1399.0um 2.0um 1401.0um
label L2_TX_INP center metal6
port make 30
port class inout
port use signal
box values 1648.0um 1399.0um 1650.0um 1401.0um
label L2_TX_INN center metal6
port make 31
port class inout
port use signal
box values 0.0um 1371.0um 2.0um 1373.0um
label L2_TX_IREF center metal6
port make 32
port class inout
port use signal
box values 0.0um 1407.0um 2.0um 1409.0um
label L2_TX_OUTN center metal6
port make 33
port class inout
port use signal
box values 1648.0um 1407.0um 1650.0um 1409.0um
label L2_TX_OUTP center metal6
port make 34
port class inout
port use signal
box values 0.0um 1584.0um 2.0um 1586.0um
label L2_RX_INP center metal6
port make 35
port class inout
port use signal
box values 1648.0um 1584.0um 1650.0um 1586.0um
label L2_RX_INN center metal6
port make 36
port class inout
port use signal
box values 0.0um 1556.0um 2.0um 1558.0um
label L2_RX_IREF center metal6
port make 37
port class inout
port use signal
box values 1648.0um 1672.0um 1650.0um 1674.0um
label L2_RX_VCM center metal6
port make 38
port class inout
port use signal
box values 1648.0um 1805.03um 1650.0um 1807.03um
label L2_SAMPLER_QP center metal6
port make 39
port class inout
port use signal
box values 1648.0um 1815.03um 1650.0um 1817.03um
label L2_SAMPLER_QN center metal6
port make 40
port class inout
port use signal
box values 0.0um 1875.03um 2.0um 1877.03um
label L2_SAMPLER_IREF center metal6
port make 41
port class inout
port use signal
box values 0.0um 2059.0um 2.0um 2061.0um
label L3_TX_INP center metal6
port make 42
port class inout
port use signal
box values 1648.0um 2059.0um 1650.0um 2061.0um
label L3_TX_INN center metal6
port make 43
port class inout
port use signal
box values 0.0um 2031.0um 2.0um 2033.0um
label L3_TX_IREF center metal6
port make 44
port class inout
port use signal
box values 0.0um 2067.0um 2.0um 2069.0um
label L3_TX_OUTN center metal6
port make 45
port class inout
port use signal
box values 1648.0um 2067.0um 1650.0um 2069.0um
label L3_TX_OUTP center metal6
port make 46
port class inout
port use signal
box values 0.0um 2244.0um 2.0um 2246.0um
label L3_RX_INP center metal6
port make 47
port class inout
port use signal
box values 1648.0um 2244.0um 1650.0um 2246.0um
label L3_RX_INN center metal6
port make 48
port class inout
port use signal
box values 0.0um 2216.0um 2.0um 2218.0um
label L3_RX_IREF center metal6
port make 49
port class inout
port use signal
box values 1648.0um 2332.0um 1650.0um 2334.0um
label L3_RX_VCM center metal6
port make 50
port class inout
port use signal
box values 1648.0um 2465.03um 1650.0um 2467.03um
label L3_SAMPLER_QP center metal6
port make 51
port class inout
port use signal
box values 1648.0um 2475.03um 1650.0um 2477.03um
label L3_SAMPLER_QN center metal6
port make 52
port class inout
port use signal
box values 0.0um 2535.03um 2.0um 2537.03um
label L3_SAMPLER_IREF center metal6
port make 53
port class inout
port use signal
box values 0.0um 2805.03um 2.0um 2807.03um
label VCTRL center metal6
port make 54
port class inout
port use signal
save nssoc_clocked_v3_flat
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {/dev/shm/nssoc-clocked-magic-v3-01/capacitance.spice}
puts NSSOC_CAPACITANCE_EXPORT_COMPLETE
quit -noprompt
