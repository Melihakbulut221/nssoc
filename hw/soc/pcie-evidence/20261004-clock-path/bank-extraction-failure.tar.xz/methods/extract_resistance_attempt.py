# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Bounded fixed-runtime unreduced RC attempt from the unchanged flat bank import."""
import hashlib,json,os,resource,shutil,subprocess,time
from pathlib import Path
ROOT=Path.cwd();OUT=Path('/dev/shm/nssoc-clocked-magic-v3-rc-01');OLD=Path('/dev/shm/nssoc-clocked-magic-v3-01')
RT=Path('/dev/shm/nssoc-magic-coupled-v2-build-final/runtime/lib');TECH=ROOT/'hw/soc/out/sram-closure-20260926/magic-tech-via-import';TOP='nssoc_clocked_v3_flat'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def limits():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
prior=json.loads((OLD/'result.json').read_text());assert prior['returncode']==0
assert all(sha(p)==h for p,h in prior['inputs'].items());assert all(sha(OLD/p)==h for p,h in prior['outputs'].items())
assert not OUT.exists();OUT.mkdir();shutil.copyfile(OLD/(TOP+'.mag'),OUT/(TOP+'.mag'))
lines=['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',f'cd {{{OUT}}}','drc off',f'load {TOP}','select top cell','extract unique all','extract style ngspice()','extract all','ext2sim labels on','ext2sim','extresist threshold 0','extresist tolerance 0.000001','extresist simplify off','extresist lumped off','extresist all','ext2spice lvs','ext2spice global off','ext2spice cthresh 0','ext2spice rthresh 0','ext2spice extresist on',f'ext2spice -o {{{OUT/"rc.spice"}}}','puts NSSOC_UNREDUCED_RC_EXPORT_COMPLETE','quit -noprompt']
script=OUT/'extract.tcl';script.write_text('\n'.join(lines)+'\n')
pins={**prior['inputs'],str(OLD/'result.json'):sha(OLD/'result.json'),str(Path(__file__).resolve()):sha(__file__),str(script):sha(script),str(OUT/(TOP+'.mag')):sha(OUT/(TOP+'.mag'))}
cmd=['/usr/bin/tclsh8.6',str(RT/'magic/tcl/magic.tcl'),'-dnull','-noconsole','-rcfile',str(TECH/'ihp-sg13g2.magicrc'),str(script)]
env={k:v for k,v in os.environ.items() if k not in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME')};env['CAD_ROOT']=str(RT)
start=time.monotonic()
with (OUT/'native.log').open('w') as log:
 try:code=subprocess.run(cmd,cwd=OUT,env=env,preexec_fn=limits,stdout=log,stderr=subprocess.STDOUT,timeout=90,check=False).returncode;status='NATIVE_RC_ATTEMPT_COMPLETE_REQUIRES_STRICT_AUDIT'
 except subprocess.TimeoutExpired:code=None;status='BOUNDED_NATIVE_TIMEOUT_PRESERVED'
record=dict(status=status,returncode=code,seconds=time.monotonic()-start,command=cmd,memory_limit_bytes=2*1024**3,timeout_s=90,inputs=pins,outputs={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file()},qualified_pex=False)
assert all(sha(p)==h for p,h in pins.items());(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ('inputs','outputs')}))
