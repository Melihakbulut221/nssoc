# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Read-only native clock net labels at actual fixed clock trunk coordinates."""
import hashlib,json,os,resource,shutil,subprocess,time
from pathlib import Path
ROOT=Path.cwd();OLD=Path('/dev/shm/nssoc-clocked-magic-v3-01');OUT=Path('/dev/shm/nssoc-clocked-magic-clock-probe-01')
RT=Path('/dev/shm/nssoc-magic-coupled-v2-build-final/runtime/lib');TECH=ROOT/'hw/soc/out/sram-closure-20260926/magic-tech-via-import';TOP='nssoc_clocked_v3_flat'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def limits():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
assert not OUT.exists();OUT.mkdir();shutil.copyfile(OLD/(TOP+'.mag'),OUT/(TOP+'.mag'))
view=Path('/dev/shm/nssoc-clocked-bank-v3-01/result.json');generated=json.loads(view.read_text())
lines=['puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"',f'cd {{{OUT}}}','drc off',f'load {TOP}','select top cell']
witnesses=[]
for net,x in [('CLOCKP',30.0),('CLOCKN',50.0)]:
 rows=[r for r in generated['routes'] if r['net']==net and r['layer']=='TopMetal2'];assert len(rows)==1
 b=rows[0]['rect_um'];assert b[0]<x<b[2] and b[1]<1000<b[3]
 lines += [f'box values {x}um 1000um {x}um 1000um',f'label {net} center metal7']
 witnesses.append(dict(net=net,source_route=rows[0],label_point_um=[x,1000],port_added=False))
lines += ['extract unique all','extract style ngspice()','extract all','ext2spice lvs','ext2spice global off','ext2spice cthresh 0','ext2spice rthresh 0','ext2spice extresist off',f'ext2spice -o {{{OUT/"capacitance.spice"}}}','puts NSSOC_CLOCK_LABEL_CAP_EXPORT_COMPLETE','quit -noprompt']
script=OUT/'extract.tcl';script.write_text('\n'.join(lines)+'\n')
prior=json.loads((OLD/'result.json').read_text());pins={**prior['inputs'],str(view):sha(view),str(OLD/'result.json'):sha(OLD/'result.json'),str(OLD/(TOP+'.mag')):sha(OLD/(TOP+'.mag')),str(Path(__file__).resolve()):sha(__file__),str(script):sha(script)}
assert all(sha(p)==h for p,h in pins.items())
cmd=['/usr/bin/tclsh8.6',str(RT/'magic/tcl/magic.tcl'),'-dnull','-noconsole','-rcfile',str(TECH/'ihp-sg13g2.magicrc'),str(script)]
env={k:v for k,v in os.environ.items() if k not in ('GH_TOKEN','GITHUB_TOKEN','PYTHONPATH','PYTHONHOME')};env['CAD_ROOT']=str(RT)
start=time.monotonic()
with (OUT/'native.log').open('w') as log:code=subprocess.run(cmd,cwd=OUT,env=env,preexec_fn=limits,stdout=log,stderr=subprocess.STDOUT,timeout=60,check=False).returncode
assert all(sha(p)==h for p,h in pins.items())
record=dict(status='NATIVE_CLOCK_ANNOTATION_ONLY_REQUIRES_AUDIT',returncode=code,seconds=time.monotonic()-start,command=cmd,inputs=pins,outputs={p.name:sha(p) for p in OUT.iterdir() if p.is_file()},clock_label_source_witnesses=witnesses,qualified_pex=False)
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(code)
