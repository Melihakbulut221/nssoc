# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Source-bound failed full-bank PEX audit plus limited C-export accounting."""
import collections,hashlib,json,math,re,shlex,sys
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT/'hw/soc/flow'))
import check_magic_coupled_cap_v2 as frozen
from make_pcie_clocked_bank_v3 import PORTS,COUNTS
OUT=ROOT/'hw/soc/out/pcie-clocked-bank-v3-20261004'
BASE=Path('/dev/shm/nssoc-clocked-magic-v3-01');RC=Path('/dev/shm/nssoc-clocked-magic-v3-rc-01');PROBE=Path('/dev/shm/nssoc-clocked-magic-clock-probe-01');NAME='nssoc_clocked_v3_flat'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def records(p):return [shlex.split(s) for s in Path(p).read_text().splitlines() if s.strip()]
def spice(p):
 lines=[]
 for s in Path(p).read_text().splitlines():
  if not s.strip() or s.startswith('*'):continue
  if s.startswith('+'):lines[-1]+=' '+s[1:]
  else:lines.append(s)
 return [s.split() for s in lines]
results={}
for p in (BASE,RC,PROBE):
 r=json.loads((p/'result.json').read_text());assert r['returncode']==0
 assert all(sha(f)==h for f,h in r['inputs'].items())
 assert all(sha(p/f)==h for f,h in r['outputs'].items())
 results[p.name]=pin(p/'result.json')
rows=records(BASE/(NAME+'.ext'));export=spice(BASE/'capacitance.spice');probe=records(PROBE/(NAME+'.ext'))
ports=[x[1] for x in sorted((r for r in rows if r[0]=='port'),key=lambda x:int(x[2]))]
assert len(ports)==54 and set(ports)==set(PORTS);assert [r for r in export if r[0]=='.subckt'][0][2:]==ports
assert [r for r in rows if r[0]=='port']==[r for r in probe if r[0]=='port']
models=collections.Counter(r[2] for r in rows if r[0]=='device');assert models==dict(npn13g2=110,rppd=57,rsil=24,cap_cmim=6,sg13_hv_pmos=1)
clock=[];aliases={}
for net in ('CLOCKP','CLOCKN'):
 node=[r for r in probe if r[0]=='node' and r[1]==net];assert len(node)==1
 origin=[r for r in rows if r[0]=='node' and r[2:]==node[0][2:]];assert len(origin)==1
 aliases[net]=origin[0][1]
 edges=[r for r in probe if r[0]=='cap' and net in r[1:3]]
 ground=float(node[0][3])*1e-18;mutual=sum(float(r[3]) for r in edges)*1e-18
 clock.append(dict(native_label=net,original_native_node=origin[0][1],intrinsic_ground_f=ground,incident_mutual_f=mutual,ground_plus_incident_mutual_f=ground+mutual,mutual_edge_count=len(edges),raw_node_record=node[0],mutual_edges=[dict(a=r[1],b=r[2],capacitance_af=float(r[3])) for r in edges]))
# New labels may change names only, never native device/cap/geometry records.
def normalized(rs):
 out=[]
 for row in rs:
  if row[0] in ('timestamp','equiv'):continue
  r=[aliases.get(w,w) for w in row]
  if r[0]=='cap':r[1:3]=sorted(r[1:3])
  out.append(tuple(r))
 return sorted(out)
assert normalized(rows)==normalized(probe)
owner={}
def root(n):
 owner.setdefault(n,n)
 if owner[n]!=n:owner[n]=root(owner[n])
 return owner[n]
for r in rows:
 if r[0] in ('node','substrate'):root(r[1])
for r in rows:
 if r[0]=='equiv':owner[root(r[2])]=root(r[1])
def key(a,b):return tuple(sorted((root(a),root(b))))
expected,actual=collections.defaultdict(float),collections.defaultdict(float)
for r in rows:
 if r[0]=='node' and float(r[3]):expected[key(r[1],'SUB')]+=float(r[3])
 if r[0]=='cap' and float(r[3]):expected[key(r[1],r[2])]+=float(r[3])
for r in export:
 if r[0].startswith('C'):actual[key(r[1],r[2])]+=float(r[3])*1e18
assert set(expected)==set(actual) and all(math.isclose(expected[k],actual[k],rel_tol=3e-6,abs_tol=1e-4) for k in expected)
try:frozen.audit(RC/(NAME+'.ext'),RC/(NAME+'.res.ext'),RC/'rc.spice',RC/'native.log',BASE/(NAME+'.ext'),BASE/'capacitance.spice')
except ValueError as exc:rejection=str(exc)
else:raise AssertionError('Frozen restricted auditor unexpectedly accepted device bank')
log=(BASE/'native.log').read_text();rclog=(RC/'native.log').read_text()
assert 'Noncanonical/hierarchical/device extraction'==rejection
assert rclog.count('Missing terminal connection')==50
record=dict(status='FAIL_FULL_BANK_PEX_PRESERVED_WITH_LIMITED_NATIVE_CAPACITANCE_ACCOUNTING',native_results=results,reference_counts=COUNTS,extracted_models=dict(models),functional_device_counts_match=True,extracted_device_count=198,strict_lvs_combined_count=200,explicit_vertical_ptap_ntap_models_omitted=True,ports=ports,exact54_port_identity=True,clock_nets=clock,clock_probe=pin(PROBE/'result.json'),clock_annotation_geometry_and_device_cap_records_unchanged=True,capacitance_export=dict(status='PASS_SAME_EXTRACTION_TO_SPICE_EDGE_ACCOUNTING_ONLY',edges=len(expected),max_edge_error_af=max(abs(expected[k]-actual[k]) for k in expected),sum_source_edges_af=sum(expected.values()),sum_export_edges_af=sum(actual.values()),meaning='All1162 native ground and mutual C edges transfer numerically within original3e-6 relative/1e-4aF serialization tolerance. This does not validate extraction physics, transistor dimensions or the unreduced RC output.'),unreduced_rc=dict(frozen_auditor_rejection=rejection,missing_device_terminal_warnings=50,native_net_counts=re.findall(r'^(?:Total Nets|Nets extracted|Nets output):.*$',rclog,re.M),native_branch_witnesses=len(re.findall(r'^NSSOC_V2_INTRINSIC_DISTRIBUTION',rclog,re.M)),replacement_records=dict(collections.Counter(r[0] for r in records(RC/(NAME+'.res.ext'))))),native_import_warnings=dict(input_off_grid_snaps=log.count('Input off lambda grid'),multiple_device_length_warnings=log.count('Device has multiple lengths')),hbt_parameter_diagnostic=dict(observed='npn13g2 le=70n we=0.9u in exported native devices',expected='npn13g2 we=0.07u le=0.9u with explicit Nx in frozen physical reference',scope='Possible dimension mapping defect to be tested with isolated orientations; not corrected or waived here.'),source_pins=[pin(Path(__file__).resolve()),pin(ROOT/'scripts/check_magic_coupled_cap_v2.py'),pin(ROOT/'scripts/check_magic_intrinsic_cap_retirement.py')],qualified_pex=False,post_layout_speed_qualified=False,limitations=['Native Magic consumes unchanged full GDS under the frozen corrected runtime and technology; geometry was not pruned. Exact port rectangles and two non-port clock labels only supply interface annotations.','Clock capacitances are source-bound screening estimates from an unqualified whole-device extraction. Incident mutual sum is a static collapsed value, not phase-dependent effective load or worst-case Miller C.','Separate substrate and well tap models disappear in ngspice extraction. HBT axis mapping and import-grid/device geometry warnings preclude replacement of the independently LVS-passing reference.','Actual unreduced RC has50 missing terminal warnings and only62 of565 total nets output. Strict canonical coupled audit rejects the full-device grammar; no full RC matrix conservation or RF/PEX acceptance claimed.'])
(OUT/'capacitance-and-rc-review.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(pin(OUT/'capacitance-and-rc-review.json')))
