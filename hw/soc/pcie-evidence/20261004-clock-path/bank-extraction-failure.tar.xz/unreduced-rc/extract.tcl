puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-clocked-magic-v3-rc-01}
drc off
load nssoc_clocked_v3_flat
select top cell
extract unique all
extract style ngspice()
extract all
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist lumped off
extresist all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o {/dev/shm/nssoc-clocked-magic-v3-rc-01/rc.spice}
puts NSSOC_UNREDUCED_RC_EXPORT_COMPLETE
quit -noprompt
