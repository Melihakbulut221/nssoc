puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-clocked-magic-clock-probe-01}
drc off
load nssoc_clocked_v3_flat
select top cell
box values 30.0um 1000um 30.0um 1000um
label CLOCKP center metal7
box values 50.0um 1000um 50.0um 1000um
label CLOCKN center metal7
extract unique all
extract style ngspice()
extract all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist off
ext2spice -o {/dev/shm/nssoc-clocked-magic-clock-probe-01/capacitance.spice}
puts NSSOC_CLOCK_LABEL_CAP_EXPORT_COMPLETE
quit -noprompt
