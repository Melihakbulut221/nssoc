puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-magic-coupled-v2-native-final/regression}
drc off
gds readonly true
gds read {/dev/shm/nssoc-magic-coupled-v2-native-final/regression/subset.gds}
load sheet_tm2
select top cell
box values 1um 0um 1um 4um
label A center metal7
port make 1
port class inout
port use signal
box values 19um 0um 19um 4um
label B center metal7
port make 2
port class inout
port use signal
save sheet_tm2
extract unique all
extract style ngspice()
extract all
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o {/dev/shm/nssoc-magic-coupled-v2-native-final/regression/sheet_tm2.spice}
load pad_tm2
select top cell
box values 35um 45um 65um 75um
label BOND_P center metal7
port make 1
port class inout
port use signal
box values 48um 216um 52um 220um
label CORE_P center metal7
port make 2
port class inout
port use signal
box values 135um 45um 165um 75um
label BOND_N center metal7
port make 3
port class inout
port use signal
box values 148um 216um 152um 220um
label CORE_N center metal7
port make 4
port class inout
port use signal
save pad_tm2
extract unique all
extract style ngspice()
extract all
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o {/dev/shm/nssoc-magic-coupled-v2-native-final/regression/pad_tm2.spice}
quit -noprompt
