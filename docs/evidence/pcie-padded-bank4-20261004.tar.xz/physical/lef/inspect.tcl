read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-padded-bank-final/nssoc_pcie_padded_bank4.lef}
set m [[ord::get_db] findMaster nssoc_pcie_padded_bank4]
if {$m eq "NULL"} {error "Analog master missing"}
if {[$m getWidth]!=860000 || [$m getHeight]!=1520000} {error "Analog outline changed"}
if {[llength [$m getMTerms]]!=47} {error "Analog terminal census changed"}
set t [$m findMTerm SUB]
if {$t eq "NULL" || [$t getIoType] ne "INOUT" || [$t getSigType] ne "GROUND"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 542000 60000 546000 64000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_TX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 119000 302000 121000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_TX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 119000 560000 121000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_TX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 91000 302000 93000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_RX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 312000 560000 314000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_RX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 312000 302000 314000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_RX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 276000 302000 278000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_RX_VCM]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 392000 560000 394000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_TX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 479000 302000 481000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_TX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 479000 560000 481000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_TX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 451000 302000 453000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_RX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 672000 560000 674000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_RX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 672000 302000 674000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_RX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 636000 302000 638000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_RX_VCM]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 752000 560000 754000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_TX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 839000 302000 841000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_TX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 839000 560000 841000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_TX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 811000 302000 813000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_RX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 1032000 560000 1034000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_RX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 1032000 302000 1034000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_RX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 996000 302000 998000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_RX_VCM]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 1112000 560000 1114000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_TX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 1199000 302000 1201000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_TX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 1199000 560000 1201000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_TX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 1171000 302000 1173000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_RX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 1392000 560000 1394000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_RX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 1392000 302000 1394000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_RX_IREF]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 300000 1356000 302000 1358000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_RX_VCM]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal1 558000 1472000 560000 1474000}}} {error "Analog physical access changed"}
set t [$m findMTerm AVDD]
if {$t eq "NULL" || [$t getIoType] ne "INOUT" || [$t getSigType] ne "POWER"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{Metal2 0 19000 4000 21000}}} {error "Analog physical access changed"}
set t [$m findMTerm AVSS]
if {$t eq "NULL" || [$t getIoType] ne "INOUT" || [$t getSigType] ne "GROUND"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{Metal2 0 39000 4000 41000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_TX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 215000 75000 245000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_TX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 115000 75000 145000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_RX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 235000 815000 265000}}} {error "Analog physical access changed"}
set t [$m findMTerm L0_RX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 335000 815000 365000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_TX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 575000 75000 605000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_TX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 475000 75000 505000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_RX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 595000 815000 625000}}} {error "Analog physical access changed"}
set t [$m findMTerm L1_RX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 695000 815000 725000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_TX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 935000 75000 965000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_TX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 835000 75000 865000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_RX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 955000 815000 985000}}} {error "Analog physical access changed"}
set t [$m findMTerm L2_RX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 1055000 815000 1085000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_TX_OUTP]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 1295000 75000 1325000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_TX_OUTN]
if {$t eq "NULL" || [$t getIoType] ne "OUTPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 45000 1195000 75000 1225000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_RX_INP]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 1315000 815000 1345000}}} {error "Analog physical access changed"}
set t [$m findMTerm L3_RX_INN]
if {$t eq "NULL" || [$t getIoType] ne "INPUT" || [$t getSigType] ne "SIGNAL"} {error "Analog terminal contract changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {$boxes ne {{TopMetal2 785000 1415000 815000 1445000}}} {error "Analog physical access changed"}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
