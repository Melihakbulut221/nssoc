import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-bank-final/nssoc_pcie_padded_bank4.gds')
c=l.cell('nssoc_pcie_padded_bank4')
c.shapes(l.layer(10,0)).insert(pya.DBox(10,19,12,41))
l.write('/dev/shm/nssoc-padded-check-final/physical_rail_short/wrong.gds')
