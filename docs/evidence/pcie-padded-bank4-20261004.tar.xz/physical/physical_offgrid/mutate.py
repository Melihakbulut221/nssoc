import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-bank-final/nssoc_pcie_padded_bank4.gds')
c=l.cell('nssoc_pcie_padded_bank4')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-padded-check-final/physical_offgrid/wrong.gds')
