import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-bank-final/nssoc_pcie_padded_bank4.gds')
c=l.cell('nssoc_pcie_padded_bank4')
matches=[i for i in c.each_inst() if i.dbbox().center()==pya.DPoint(280.0,1025.0) and not pya.Region(l.cell(i.cell_index).begin_shapes_rec(l.layer(133,0))).is_empty()]
if len(matches)!=1:raise ValueError('Specific parent RX input via not unique in native geometry')
matches[0].delete()
l.write('/dev/shm/nssoc-padded-check-final/physical_serial_open/wrong.gds')
