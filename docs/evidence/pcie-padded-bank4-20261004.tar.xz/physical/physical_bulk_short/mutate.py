import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-padded-bank-final/nssoc_pcie_padded_bank4.gds')
c=l.cell('nssoc_pcie_padded_bank4')
c.shapes(l.layer(134,0)).insert(pya.DBox(530,61,546,63))
l.write('/dev/shm/nssoc-padded-check-final/physical_bulk_short/wrong.gds')
