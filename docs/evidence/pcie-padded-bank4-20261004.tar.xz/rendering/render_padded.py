# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Actual GDS polygons only, rotated for documentation; annotations are not geometry."""
import hashlib,json
from pathlib import Path
import pya
r=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');o=r/'hw/soc/out/pcie-pad-rc-20261004';gds=Path('/dev/shm/nssoc-padded-bank-final/nssoc_pcie_padded_bank4.gds')
l=pya.Layout();l.read(str(gds));top=l.cell('nssoc_pcie_padded_bank4');selected=[(1,'#64748b','Activ'),(5,'#aa77bb','GatPoly'),(8,'#b09f4c','Metal1'),(10,'#57a773','Metal2'),(30,'#427db8','Metal3'),(50,'#4a9a9b','Metal4'),(67,'#e6b85c','Metal5'),(126,'#e07a5f','TopMetal1'),(134,'#71a8dc','TopMetal2')]
s=['<svg xmlns="http://www.w3.org/2000/svg" width="1570" height="980" viewBox="0 0 1570 980">','<rect width="1570" height="980" fill="#101724"/>','<text x="20" y="26" fill="white" font-family="sans-serif" font-size="20">Four-lane analog bank + 16 real bondpads / 32 native ESD diodes</text>','<text x="20" y="49" fill="#cbd5e1" font-family="sans-serif" font-size="14">Actual GDS: 860 × 1520 µm, view rotated 90°. Separate physical block; not full PCIe PHY or main-chip integration.</text>'];counts={}
for layer,color,name in selected:
 region=pya.Region(top.begin_shapes_rec(l.layer(layer,0)));paths=[];n=0
 for p in region.each():
  for ring in [list(p.each_point_hull())]+[list(p.each_point_hole(i)) for i in range(p.holes())]:paths.append('M '+' L '.join(f'{q.y*l.dbu+20:.3f},{940-q.x*l.dbu:.3f}' for q in ring)+' Z')
  n+=1
 s.append('<path fill="'+color+'" fill-rule="evenodd" d="'+' '.join(paths)+'"/>');counts[name]=n
for i in range(4):s.append(f'<text x="{160+i*360}" y="73" fill="white" font-family="sans-serif" font-size="15">Lane {i}</text>')
s+=['<text x="20" y="967" fill="#cbd5e1" font-family="sans-serif" font-size="13">Blue: TopMetal2 bonds/routes. Original TX/RX bank centered. Metal2/3 power and Metal4 signal crossings are physical geometry.</text>','</svg>'];p=o/'padded-bank4-actual-layout.svg';p.write_text('\n'.join(s)+'\n');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rec=dict(scope='Read-only selected actual GDS layers; exact polygons, view rotation only. Text annotations are not physical geometry.',gds_sha256=sha(gds),method_sha256=sha(Path(__file__)),svg_sha256=sha(p),selected_layer_polygon_counts=counts,klayout_version=pya.__version__);(o/'padded-rendering.json').write_text(json.dumps(rec,indent=2)+'\n')
