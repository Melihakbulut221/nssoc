# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,tarfile,io
r=Path.cwd();b=r/'hw/soc/out/pcie-pad-rc-20261004';layout=Path('/dev/shm/nssoc-padded-bank-final');check=Path('/dev/shm/nssoc-padded-check-final')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
methods=[r/'hw/soc/flow/make_pcie_padded_bank.py',r/'hw/soc/flow/check_pcie_padded_bank.py',r/'sw/tests/test_pcie_padded_bank.py'];files={};records={};verified={}
for tag,d in [('layout',layout),('physical',check)]:
 rec=json.loads((d/'result.json').read_text());records[tag]=rec
 for p,h in rec.get('input_sha256',rec.get('inputs')).items():
  if p not in verified:assert sha(p)==h,p;verified[p]=h
  else:assert verified[p]==h,p
 outputs=rec['output_sha256' if tag=='layout' else 'outputs']
 for n,h in outputs.items():assert sha(d/n)==h,n;files[tag+'/'+n]=d/n
 files[tag+'/result.json']=d/'result.json'
for p in methods:files['methods/'+str(p.relative_to(r))]=p
for n in ['render_padded.py','padded-rendering.json','padded-bank4-actual-layout.svg','padded-bank4-actual-layout.png','package_padded.py']:files['rendering/'+n]=b/n
# Preserve actual rejected first-layout artifact/logs, without transferring any acceptance.
failed=Path('/dev/shm/nssoc-padded-bank-01')
for p in sorted(failed.rglob('*')):
 if p.is_file():files['rejected-first-layout/'+str(p.relative_to(failed))]=p
notice=(b/'PAD-NOTICES.txt').read_text().replace('Native differential pad boundary research evidence.','Native four-lane padded analog bank research evidence.').replace('bank/main-chip','main-chip');(b/'PADDED-NOTICES.txt').write_text(notice);files['NOTICES.txt']=b/'PADDED-NOTICES.txt'
archive=b/'padded-bank4-native.tar.xz'
with tarfile.open(archive,'w:xz',preset=9) as t:
 for n,p in sorted(files.items()):
  data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for n,p in files.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==sha(p)
rec=dict(status='FROZEN_NATIVE_FOUR_LANE_ANALOG_BANK_PLUS_SIXTEEN_REAL_PADS_ONLY',sources={str(p.relative_to(r)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in methods},native_status={k:v['status'] for k,v in records.items()},raw_roots=dict(layout=str(layout),physical=str(check)),raw_result_pins=dict(layout=sha(layout/'result.json'),physical=sha(check/'result.json')),source_input_count=len(verified),output_counts=dict(layout=len(records['layout']['output_sha256']),physical=len(records['physical']['outputs'])),native_checks=dict(main_drc_markers=0,main_drc_categories=560,strict_lvs_devices=89,strict_lvs_ports=47,negative_controls=8,physical_serial_connections=16,pad_pairs=8,unchanged_bank_hierarchy=True,source_conductor_xor_zero=True,exact_seven_layer_obstruction_union=True),substrate_contract=records['layout']['substrate_contract'],named_native_topology=records['physical']['native_geometry'],tests=dict(command='PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q sw/tests/test_pcie_padded_bank.py sw/tests/test_pcie_pad_boundary.py sw/tests/test_pcie_analog_bank.py sw/tests/test_pcie_rx_cell.py -p no:cacheprovider',passed=83,ruff='PASS'),rendering=dict(source_gds_sha256=sha(layout/'nssoc_pcie_padded_bank4.gds'),png_sha256=sha(b/'padded-bank4-actual-layout.png'),svg_sha256=sha(b/'padded-bank4-actual-layout.svg'),scope='Actual selected GDS polygons; visual readback inspected.'),capsule=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(files),roundtrip_all_members=True),retained_failed_attempt=dict(path=str(failed),capsule_prefix='rejected-first-layout',actual_drc_markers=32,actual_drc_category='TM2.a',actual_lvs='FAIL AVDD/AVSS short',corrected='Parent-only Metal3 supply crossing reordered; TopMetal2 Manhattan elbow width increased to4um. No changes to original primitive geometry/deck/reference tap parameters.'),limitations=['Separate physical macro containing original four-lane TX/RX bank and16native bondpads/32fixed ESD diode cells. Not integrated into main SoC.','No rail clamp/package discharge-path validation, HBM/CDM or RF qualification.','No combined-layout parasitic extraction, post-layout TX/RX eye/jitter measurement or manufacturing approval.','No clock recovery, PLL, sampler, SERDES or digital PIPE/LTSSM connection in this physical macro.','Explicit new substrate contract grounded internal BULK through real ESD electrodes; external SUB remains through all64literal tap geometries. Old bank reference/GDS unchanged.'])
(b/'padded-source-validation.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:rec[k] for k in ['status','sources','output_counts','capsule']},indent=2))
