`timescale 1ns/1ps
module tiny;reg clk=0,rst=0;integer cycles=0;reg a=0,s=1'b0,b=1;wire d,q;
always #5 clk=~clk;always @(posedge clk)cycles=cycles+1;
sg13g2_o21ai_1 root(.A1(a),.A2(s),.B1(b),.Y(d));
sg13g2_dfrbpq_1 ff(.D(d),.Q(q),.CLK(clk),.RESET_B(rst));
always @(negedge clk) #0.002 $display("SIGNATURE cycle=%0d d=%b q=%b",cycles,d,q);
initial begin #2;rst=1;#28;s=1'bx;#20;a=1;s=0;#40;$finish;end
endmodule
