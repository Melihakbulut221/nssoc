// SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
// SPDX-License-Identifier: CERN-OHL-W-2.0

// GENERATED FILE - edit regmap/regmap.yaml and run regmap/generate.py
//
// UNGUARDED ON PURPOSE: this is a BODY of localparam
// declarations included inside a module, and more than one
// module in this compilation unit includes it. An include
// guard would give the constants to the first module and an
// empty file to every later one. docs/39 section 8 defect 1.

localparam [11:0] ADDR_ID = 12'h000;
localparam [11:0] ADDR_VERSION = 12'h004;
localparam [11:0] ADDR_SCRATCH = 12'h008;
localparam [11:0] ADDR_CTRL = 12'h00C;
localparam [11:0] ADDR_STATUS = 12'h010;
localparam [11:0] ADDR_STATUS_CLR = 12'h014;
localparam [11:0] ADDR_CFG_NEUR = 12'h020;
localparam [11:0] ADDR_CFG_AXON = 12'h024;
localparam [11:0] ADDR_CFG_THRESH = 12'h028;
localparam [11:0] ADDR_CFG_VRESET = 12'h02C;
localparam [11:0] ADDR_CFG_LEAK = 12'h030;
localparam [11:0] ADDR_CFG_SYNSHIFT = 12'h034;
localparam [11:0] ADDR_CFG_REFR = 12'h038;
localparam [11:0] ADDR_CFG_FLAGS = 12'h03C;
localparam [11:0] ADDR_PASS_TILE_OFF = 12'h040;
localparam [11:0] ADDR_W_BASE = 12'h044;
localparam [11:0] ADDR_PASS_ID = 12'h048;
localparam [11:0] ADDR_W_ADDR = 12'h050;
localparam [11:0] ADDR_W_DATA_LO = 12'h054;
localparam [11:0] ADDR_W_DATA_HI = 12'h058;
localparam [11:0] ADDR_N_ADDR = 12'h060;
localparam [11:0] ADDR_N_DATA = 12'h064;
localparam [11:0] ADDR_CNT_SEC = 12'h070;
localparam [11:0] ADDR_CNT_DED = 12'h074;
localparam [11:0] ADDR_CNT_EVQ_OVF = 12'h078;
localparam [11:0] ADDR_CNT_AXON_OOR = 12'h07C;
localparam [11:0] ADDR_FAULT_ADDR = 12'h080;
localparam [11:0] ADDR_ECC_INJ = 12'h084;
localparam [11:0] ADDR_FAULT_CLR = 12'h088;
localparam [11:0] ADDR_EVQ_STAT = 12'h090;
localparam [11:0] ADDR_EVQ_IN = 12'h094;
localparam [11:0] ADDR_EVQ_OUT = 12'h098;
localparam [11:0] ADDR_NODE_ID = 12'h09C;

localparam [31:0] RST_ID = 32'h4E505531;
localparam [31:0] RST_VERSION = 32'h00000001;
localparam [31:0] RST_SCRATCH = 32'h00000000;
localparam [31:0] RST_CTRL = 32'h00000008;
localparam [31:0] RST_STATUS = 32'h00000006;
localparam [31:0] RST_STATUS_CLR = 32'h00000000;
localparam [31:0] RST_CFG_NEUR = 32'h00000200;
localparam [31:0] RST_CFG_AXON = 32'h00000200;
localparam [31:0] RST_CFG_THRESH = 32'h00000100;
localparam [31:0] RST_CFG_VRESET = 32'h00000000;
localparam [31:0] RST_CFG_LEAK = 32'h00000003;
localparam [31:0] RST_CFG_SYNSHIFT = 32'h00000000;
localparam [31:0] RST_CFG_REFR = 32'h00000000;
localparam [31:0] RST_CFG_FLAGS = 32'h00000002;
localparam [31:0] RST_PASS_TILE_OFF = 32'h00000000;
localparam [31:0] RST_W_BASE = 32'h00000000;
localparam [31:0] RST_PASS_ID = 32'h00000000;
localparam [31:0] RST_W_ADDR = 32'h00000000;
localparam [31:0] RST_W_DATA_LO = 32'h00000000;
localparam [31:0] RST_W_DATA_HI = 32'h00000000;
localparam [31:0] RST_N_ADDR = 32'h00000000;
localparam [31:0] RST_N_DATA = 32'h00000000;
localparam [31:0] RST_CNT_SEC = 32'h00000000;
localparam [31:0] RST_CNT_DED = 32'h00000000;
localparam [31:0] RST_CNT_EVQ_OVF = 32'h00000000;
localparam [31:0] RST_CNT_AXON_OOR = 32'h00000000;
localparam [31:0] RST_FAULT_ADDR = 32'h00000000;
localparam [31:0] RST_ECC_INJ = 32'h00000000;
localparam [31:0] RST_FAULT_CLR = 32'h00000000;
localparam [31:0] RST_EVQ_STAT = 32'h00000000;
localparam [31:0] RST_EVQ_IN = 32'h00000000;
localparam [31:0] RST_EVQ_OUT = 32'h00000000;
localparam [31:0] RST_NODE_ID = 32'h00000000;

localparam BIT_CTRL_EN = 0;
localparam BIT_CTRL_STATE_CLR = 1;
localparam BIT_CTRL_SOFT_RST = 2;
localparam BIT_CTRL_SCRUB_EN = 3;
localparam BIT_STATUS_BUSY = 0;
localparam BIT_STATUS_EVQ_IN_EMPTY = 1;
localparam BIT_STATUS_EVQ_OUT_EMPTY = 2;
localparam BIT_STATUS_SYNC_DONE = 3;
localparam BIT_STATUS_ERR_CFG = 4;
localparam BIT_STATUS_DED_SEEN = 5;
localparam BIT_STATUS_OVF_SEEN = 6;
localparam BIT_CFG_NEUR_CNT = 0;
localparam WIDTH_CFG_NEUR_CNT = 11;
localparam BIT_CFG_AXON_CNT = 0;
localparam WIDTH_CFG_AXON_CNT = 11;
localparam BIT_CFG_THRESH_THETA = 0;
localparam WIDTH_CFG_THRESH_THETA = 16;
localparam BIT_CFG_VRESET_VRESET = 0;
localparam WIDTH_CFG_VRESET_VRESET = 16;
localparam BIT_CFG_LEAK_S_LEAK = 0;
localparam WIDTH_CFG_LEAK_S_LEAK = 4;
localparam BIT_CFG_SYNSHIFT_S_SYN = 0;
localparam WIDTH_CFG_SYNSHIFT_S_SYN = 3;
localparam BIT_CFG_REFR_T_REFR = 0;
localparam WIDTH_CFG_REFR_T_REFR = 4;
localparam BIT_CFG_FLAGS_TS_EN = 0;
localparam BIT_CFG_FLAGS_LEAK_EN = 1;
localparam BIT_PASS_TILE_OFF_OFF = 0;
localparam WIDTH_PASS_TILE_OFF_OFF = 10;
localparam BIT_PASS_ID_NUM = 0;
localparam WIDTH_PASS_ID_NUM = 8;
localparam BIT_N_DATA_V = 0;
localparam WIDTH_N_DATA_V = 16;
localparam BIT_N_DATA_R = 16;
localparam WIDTH_N_DATA_R = 4;
localparam BIT_ECC_INJ_SINGLE = 0;
localparam BIT_ECC_INJ_DOUBLE = 1;
localparam BIT_FAULT_CLR_CNT_SEC = 0;
localparam BIT_FAULT_CLR_CNT_DED = 1;
localparam BIT_FAULT_CLR_CNT_EVQ_OVF = 2;
localparam BIT_FAULT_CLR_CNT_AXON_OOR = 3;
localparam BIT_FAULT_CLR_FAULT_ADDR = 4;
localparam BIT_EVQ_STAT_IN_FILL = 0;
localparam WIDTH_EVQ_STAT_IN_FILL = 8;
localparam BIT_EVQ_STAT_OUT_FILL = 8;
localparam WIDTH_EVQ_STAT_OUT_FILL = 8;
localparam BIT_EVQ_OUT_EVENT = 0;
localparam WIDTH_EVQ_OUT_EVENT = 16;
localparam BIT_EVQ_OUT_VALID = 31;
localparam BIT_NODE_ID_NID = 0;
localparam WIDTH_NODE_ID_NID = 4;
