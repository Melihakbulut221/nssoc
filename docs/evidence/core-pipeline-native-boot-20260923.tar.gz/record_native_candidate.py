from pathlib import Path
import json,hashlib,subprocess,tarfile,re
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
run=json.loads((c/'native-candidate-completed-run.json').read_text());assert run['conclusion']=='success' and run['status']=='completed';commit=run['headSha'];assert commit=='95cbb15c0b41e26f2a2bd9086f5b8a6cb8b4e4e6'
artifacts=json.loads((c/'native-candidate-artifacts-final.json').read_text())['artifacts'];records={}
for profile in ['base','full']:
 b=c/f'native-candidate-{profile}';artifact=next(a for a in artifacts if a['name']==f'native-recovery-{profile}');z=c/f'native-candidate-{profile}.zip';assert 'sha256:'+sha(z)==artifact['digest'] and z.stat().st_size==artifact['size_in_bytes']
 cfg=json.loads((b/'core-configuration.json').read_text());assert cfg['interface_profile']==profile and all(cfg[k]==1 for k in ['CORE_REQ_REG','CORE_WB_STAGE','CORE_BRANCH_TARGET_ALU'])
 syn=(b/'synthesis/syn.log').read_text();selected={}
 for name in ['CORE_REQ_REG','CORE_WB_STAGE','BranchTargetALU','WritebackStage']:
  values=re.findall(r'Parameter \\'+name+r' = ([^\n]+)',syn);assert values and set(values)<={'1',"1'1"},(name,set(values));selected[name]=1
 r=json.loads((b/'gates/result.json').read_text());assert r['passed'] is True and r['sources_unchanged'] is True and r['compile']['returncode']==0 and all(x['returncode']==0 and x['pass_banner'] is True for x in r['runs'])
 scrub=json.loads((b/'scrub-native/result.json').read_text());assert scrub['status']=='PASS' and scrub['sources_unchanged'] is True
 inp=json.loads((b/'gates/inputs.json').read_text());rows=[];lock=json.loads((b/'model-lock.json').read_text());locked={x['path']:x['sha256'] for x in lock['files']};assert lock['commit']=='c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c'
 for source,v in inp['sources'].items():
  rel=source.split('/nssoc/nssoc/',1)[1]
  if '/out/native-boot/' in rel:data=(b/rel.split('/out/native-boot/',1)[1]).read_bytes();basis='retained artifact'
  elif '/tools/ihp-native-boot-' in rel:
   q=rel.split('/ihp-sg13g2/',1)[1];data=(Path('/home/hasanmelih/.ciel/ihp-sg13g2')/q).read_bytes();basis='independently verified pinned PDK model';assert locked['ihp-sg13g2/'+q]==v['sha256']
  else:data=subprocess.check_output(['git','show',commit+':'+rel]);basis='exact run commit'
  assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256'],rel
  rows.append(dict(source=rel,sha256=v['sha256'],bytes=len(data),verification=basis))
 log=(b/'gates/run-0.log').read_text();expected='cycles=630363 checks=28 fails=00000000 code=00000000 magic=600dc0de watchdog=1/0/0 flash_violations=0 uart_pass=1 framing=0';assert expected in log and 'LOGICROM_GL PASS checks=28' in log
 manifest=inp['loader_manifest'];assert manifest['image_sha256']==sha(b/'rtl/test_soc.bin') and manifest['rtl_sha256']==sha(b/'synthesis/boot-rom/soc_logic_boot_rom.v')==sha(b/'rtl/boot-rom/soc_logic_boot_rom.v')
 records[profile]={'status':'PASS: functional mapped boot and SCRUBCTL controls','parameters_confirmed_in_synthesis':selected,'cycles':630363,'firmware_checks':28,'failure_mask':'00000000','watchdog_counts':[1,0,0],'flash_violations':0,'uart_pass':True,'framing_errors':0,'artifact':{k:artifact[k] for k in ['id','name','digest','size_in_bytes']},'verified_gate_sources':rows,'gate_result':r,'scrub_status':scrub['status']}
files=[p for profile in ['base','full'] for p in (c/f'native-candidate-{profile}').rglob('*') if p.is_file()]
files += [c/n for n in ['native-candidate-completed-run.json','native-candidate-artifacts-final.json','record_native_candidate.py']]
a=root/'docs/evidence/core-pipeline-native-boot-20260923.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(c)))
with tarfile.open(a) as t:
 for p in files:assert hashlib.sha256(t.extractfile(str(p.relative_to(c))).read()).hexdigest()==sha(p)
receipt={'date':'2026-09-23','status':'PASS: both interface profiles with native IHP models, within functional simulation scope','run':run['url'],'commit':commit,'scope':'Icarus four-state mapped boot with unmodified locked IHP standard-cell and SRAM models. CORE_REQ_REG=1, CORE_WB_STAGE=1, BranchTargetALU=1. No ROM/RAM preload and no SDF; this does not establish physical timing, extracted connectivity or silicon acceptance.','profiles':records,'artifact_limitation':'The workflow at the tested commit retained the wrong RTL parameter-file name, so soc_param_override.v is absent. Selected parameters are independently confirmed by the retained synthesis log and core-configuration.json. Commit 73a6759 fixes retention for subsequent runs.','archive':{'path':str(a.relative_to(root)),'sha256':sha(a),'bytes':a.stat().st_size,'members':{str(p.relative_to(c)):sha(p) for p in files}}}
(root/'docs/evidence/core-pipeline-native-boot-20260923.json').write_text(json.dumps(receipt,indent=2)+'\n');print('published paired native boot',a.stat().st_size)
