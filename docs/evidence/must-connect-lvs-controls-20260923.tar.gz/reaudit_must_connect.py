from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';base=c/'must-connect-control';rows=[]
for name,code,status in [('joined-strict',0,'PASS within comparison scope'),('cut-soft',1,'FAIL'),('joined-missing-device',1,'FAIL')]:
 d=base/name;cmd=['python','hw/soc/flow/audit_klayout_lvs.py',str(d/'MC_TOP.lvsdb'),'--top','MC_TOP','--deck-log',str(d/'deck.log'),'--output',str(d/'audit-with-extraction-final.json')]
 with (d/'audit-with-extraction-final.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 result=json.loads((d/'audit-with-extraction-final.json').read_text());assert r.returncode==code and result['status']==status,(name,r.returncode,result);rows.append({'case':name,'returncode':r.returncode,'result':result});print(name,result['status'],result['reasons'],flush=True)
assert any(e['category']=='must-connect' for e in rows[1]['result']['extraction_diagnostics'])
(base/'reaudit-results.json').write_text(json.dumps({'auditor_sha256':hashlib.sha256((root/'hw/soc/flow/audit_klayout_lvs.py').read_bytes()).hexdigest(),'cases':rows},indent=2)+'\n')
