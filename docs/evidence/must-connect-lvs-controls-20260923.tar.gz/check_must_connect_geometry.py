from pathlib import Path
import klayout.db as db
import json,hashlib
c=Path(__file__).resolve().parent;d=c/'must-connect-control';layouts=[]
for name in ['joined','cut']:
 l=db.Layout();l.read(str(d/f'{name}.gds'));layouts.append(l)
a,b=layouts;assert a.dbu==b.dbu==.001;assert sorted(v.name for v in a.each_cell())==sorted(v.name for v in b.each_cell());differences=[]
for ca in a.each_cell():
 cb=b.cell(ca.name)
 def instances(cell):return sorted((i.cell.name,i.trans.to_s(),i.a.to_s(),i.b.to_s(),i.na,i.nb) for i in cell.each_inst())
 assert instances(ca)==instances(cb)
 for ia in a.layer_indexes():
  info=a.get_info(ia);ib=b.find_layer(info);assert ib is not None
  sa,sb=ca.shapes(ia),cb.shapes(ib)
  assert sorted(s.text.to_s() for s in sa.each() if s.is_text())==sorted(s.text.to_s() for s in sb.each() if s.is_text())
  diff=db.Region(sa)^db.Region(sb)
  if not diff.is_empty():
   assert ca.name=='MC_TOP' and info.layer==8 and info.datatype==0
   assert (diff^db.Region(db.Box(600,3700,4850,3880))).is_empty()
   differences.append({'cell':ca.name,'layer':info.to_s(),'bridge_dbu':[600,3700,4850,3880]})
assert len(differences)==1
r={'status':'PASS within scope','scope':'The joined/cut GDS pairs differ only by one top-level Metal1 VDD bridge; all cells, instances, labels and remaining polygons match.','differences':differences,'input_sha256':{n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in ['joined.gds','cut.gds']}}
(d/'geometry-control.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'])
