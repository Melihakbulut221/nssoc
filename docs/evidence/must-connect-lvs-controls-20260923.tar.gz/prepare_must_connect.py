from pathlib import Path
import json,hashlib,shutil
import klayout.db as db
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';out=c/'must-connect-control';out.mkdir(exist_ok=False);src=root/'hw/soc/out/external-review-20260919/stdcell-inverter-repro'
for connected in [False,True]:
 l=db.Layout();l.read(str(src/'inv.gds'));inv=l.cell('sg13g2_inv_1');block=l.create_cell('MC_BLOCK');top=l.create_cell('MC_TOP');metal=l.layer(8,0);labels=l.layer(8,25)
 block.insert(db.CellInstArray(inv.cell_index(),db.Trans(0,0)));block.insert(db.CellInstArray(inv.cell_index(),db.Trans(4000,0)));top.insert(db.CellInstArray(block.cell_index(),db.Trans(0,0)))
 # Ground is physically joined within the block in both controls.
 block.shapes(metal).insert(db.Box(600,-100,4850,100))
 ports={'A1':(480,1680),'A2':(4480,1680),'Y1':(980,1690),'Y2':(4980,1690),'VSS':(720,-20)}
 for cell in [block,top]:
  for name,(x,y) in ports.items():cell.shapes(labels).insert(db.Text(name,db.Trans(x,y)))
  for x in [705,4705]:cell.shapes(labels).insert(db.Text('VDD',db.Trans(x,3780)))
 if connected:top.shapes(metal).insert(db.Box(600,3700,4850,3880))
 # No standard-cell geometry is edited. The only pairwise difference is the
 # single top-level Metal1 bridge that physically joins the two VDD islands.
 l.write(str(out/('joined.gds' if connected else 'cut.gds')))
cdl=(src/'inv.cdl').read_text()+'''\n.SUBCKT MC_BLOCK A1 A2 Y1 Y2 VDD VSS
X0 Y1 A1 VDD VSS sg13g2_inv_1
X1 Y2 A2 VDD VSS sg13g2_inv_1
.ENDS MC_BLOCK
.SUBCKT MC_TOP A1 A2 Y1 Y2 VDD VSS
X0 A1 A2 Y1 Y2 VDD VSS MC_BLOCK
.ENDS MC_TOP
''';(out/'reference.cdl').write_text(cdl);(out/'missing-nmos.cdl').write_text('\n'.join(l for l in cdl.splitlines() if not l.startswith('MX1 '))+'\n')
deck=root/'hw/soc/tools/ihp-lvs-5e6d592/ihp-sg13g2/libs.tech/klayout/tech/lvs';shutil.copytree(deck,out/'deck');p=out/'deck/sg13g2.lvs';s=p.read_text();anchor='# === Tech Switches ===';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n# Diagnostic only: retain mandatory physical closure at MC_TOP.\nconnect_implicit("MC_BLOCK", "VDD")\ntop_level(($strict_must_connect || "true").to_s == "true")\n');p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(out/'inputs.json').write_text(json.dumps({'scope':'Diagnostic two-inverter hierarchy with joined/cut top-level VDD metal. Original vendor inverter cell tree and transistor CDL. Copied experimental deck adds cell-scoped connect_implicit and explicit top_level; no production deck edits or SRAM acceptance.','sources':{str(p):sha(p) for p in [src/'inv.gds',src/'inv.cdl',deck/'sg13g2.lvs',Path(__file__)]},'generated':{p.name:sha(p) for p in out.iterdir() if p.is_file()},'experimental_deck_sha256':sha(out/'deck/sg13g2.lvs')},indent=2)+'\n')
