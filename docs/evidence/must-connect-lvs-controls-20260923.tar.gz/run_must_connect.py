from pathlib import Path
import json,hashlib,subprocess,time,resource
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';base=c/'must-connect-control';results=[]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def limit():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
version=subprocess.run(['klayout','-v'],capture_output=True,text=True,check=True).stdout
for tag,geometry,strict,reference in [('joined-strict','joined',True,'reference'),('cut-strict','cut',True,'reference'),('cut-soft','cut',False,'reference'),('joined-missing-device','joined',True,'missing-nmos')]:
 out=base/tag;out.mkdir(exist_ok=False);flags=dict(input=str(base/f'{geometry}.gds'),schematic=str(base/f'{reference}.cdl'),topcell='MC_TOP',run_mode='deep',report=str(out/'MC_TOP.lvsdb'),log=str(out/'deck.log'),target_netlist=str(out/'extracted.cir'),strict_must_connect=str(strict).lower())
 for k in ['no_net_names','spice_comments','net_only','top_lvl_pins','no_simplify','no_series_res','no_parallel_res','combine_devices','purge','purge_nets','verbose','ignore_top_ports_mismatch','disable_tap_extraction','purge_devices']:flags[k]='false'
 cmd=['klayout','-b','-zz','-r',str(base/'deck/sg13g2.lvs')]
 for k,v in flags.items():cmd+=['-rd',k+'='+v]
 inputs={str(p):sha(p) for p in [base/f'{geometry}.gds',base/f'{reference}.cdl',*sorted((base/'deck').rglob('*.lvs'))]};start=time.monotonic()
 with (out/'run.log').open('w') as f:
  try:ret=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=90,preexec_fn=limit).returncode
  except subprocess.TimeoutExpired:ret=124
 row=dict(tag=tag,returncode=ret,elapsed_s=time.monotonic()-start,flags=flags,inputs=inputs,inputs_unchanged=all(sha(Path(p))==h for p,h in inputs.items()),klayout_version=version)
 if (out/'MC_TOP.lvsdb').exists():
  with (out/'audit.log').open('w') as f:subprocess.run(['python','hw/soc/flow/audit_klayout_lvs.py',str(out/'MC_TOP.lvsdb'),'--top','MC_TOP','--deck-log',str(out/'deck.log'),'--output',str(out/'audit.json')],stdout=f,stderr=subprocess.STDOUT)
  if (out/'audit.json').exists():row['audit']=json.loads((out/'audit.json').read_text())
 (out/'result.json').write_text(json.dumps(row,indent=2)+'\n');results.append(row);print(tag,ret,row.get('audit',{}).get('status','no audit'),flush=True)
(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
