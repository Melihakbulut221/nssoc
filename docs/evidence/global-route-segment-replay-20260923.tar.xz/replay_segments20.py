from pathlib import Path
from librelane.flows import Flow, SequentialFlow
from librelane.steps import OpenROAD
class Check(OpenROAD.ResizerTimingPostGRT):
 def get_script_path(self):
  c=Path(__file__).resolve().parent
  script='''source $::env(SCRIPTS_DIR)/openroad/common/io.tcl
read_current_odb
set_thread_count 2
set_propagated_clock [all_clocks]
source $::env(SCRIPTS_DIR)/openroad/common/set_rc.tcl
read_global_route_segments {GUIDE}
estimate_parasitics -global_routing
report_parasitic_annotation -report_unannotated > $::env(STEP_DIR)/annotation.rpt
foreach corner $::env(STA_CORNERS) {
 report_checks -corner $corner -path_delay max -group_path_count 1 -fields {fanout cap slew} -digits 8 > $::env(STEP_DIR)/$corner-max.rpt
 report_checks -corner $corner -path_delay min -group_path_count 1 -fields {fanout cap slew} -digits 8 > $::env(STEP_DIR)/$corner-min.rpt
 report_check_types -corner $corner -max_slew -max_capacitance -violators -digits 8 > $::env(STEP_DIR)/$corner-electrical.rpt
}
write_views
'''.replace('GUIDE',str(c/'runs/electrical-segments20/1-openroad-resizertimingpostgrt/soc_top.grt.segments'))
  p=Path(self.step_dir)/'recheck.tcl';p.write_text(script);return str(p)
@Flow.factory.register()
class ReplaySegments20(SequentialFlow):Steps=[Check]
if __name__=='__main__':
 from librelane.__main__ import cli
 cli()
