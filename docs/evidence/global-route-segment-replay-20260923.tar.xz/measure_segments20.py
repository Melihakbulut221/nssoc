from pathlib import Path
import json,time,hashlib,subprocess
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';run=c/'runs/electrical-segments20';step=run/'1-openroad-resizertimingpostgrt'
while not (run/'final/nl/soc_top.nl.v').exists():
 if 'Flow failed' in (c/'electrical-segments20-driver.log').read_text():raise SystemExit('Segment producer failed')
 time.sleep(5)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity={}
for name,a,b in [('netlist',run/'final/nl/soc_top.nl.v',c/'runs/electrical-incremental19/final/nl/soc_top.nl.v'),('guides',step/'soc_top.final.guide',c/'runs/electrical-incremental19/1-openroad-resizertimingpostgrt/soc_top.final.guide')]:
 identity[name]={'eco20_sha256':sha(a),'eco19_sha256':sha(b),'equal':sha(a)==sha(b)}
assert identity['netlist']['equal'],identity
assert (step/'soc_top.grt.segments').stat().st_size>1000000
(c/'segment-replay-identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity),flush=True)
out=c/'runs/segment-replay20';out.mkdir()
args=[str(root/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'),'python',str(c/'replay_segments20.py'),'--flow','ReplaySegments20','--pdk-root','/home/hasanmelih/.ciel','--pdk','ihp-sg13g2','--force-run-dir',str(out),'--with-initial-state',str(step/'state_out.json'),str(c/'config-route19.json')]
with (c/'segment-replay20-driver.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
raise SystemExit(r.returncode)
