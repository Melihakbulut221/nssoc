source $::env(SCRIPTS_DIR)/openroad/common/io.tcl
read_current_odb
set_thread_count 2
set_propagated_clock [all_clocks]
source $::env(SCRIPTS_DIR)/openroad/common/set_rc.tcl
read_global_route_segments {/home/hasanmelih/Documents/ChatGPT/nnsoc/hw/soc/out/external-review-20260919/route-closure-20260923/runs/electrical-segments20/1-openroad-resizertimingpostgrt/soc_top.grt.segments}
estimate_parasitics -global_routing
report_parasitic_annotation -report_unannotated > $::env(STEP_DIR)/annotation.rpt
foreach corner $::env(STA_CORNERS) {
 report_checks -corner $corner -path_delay max -group_path_count 1 -fields {fanout cap slew} -digits 8 > $::env(STEP_DIR)/$corner-max.rpt
 report_checks -corner $corner -path_delay min -group_path_count 1 -fields {fanout cap slew} -digits 8 > $::env(STEP_DIR)/$corner-min.rpt
 report_check_types -corner $corner -max_slew -max_capacitance -violators -digits 8 > $::env(STEP_DIR)/$corner-electrical.rpt
}
write_views
