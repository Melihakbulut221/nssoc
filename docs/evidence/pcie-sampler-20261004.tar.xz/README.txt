NSSOC transistor sampler development capture, 2026-10-04.
This capsule contains both 121-case native producer receipts, all decks/circuits/logs,
eight completed ngspice42 subset measurements and one failed native solve,
three startup strategies plus half step and extra thermal-node guesses, and
lossless seven-column projections at ALL native timepoints for v1 failed/v2 worst.
The projections are NOT complete native waveforms. Their exact original raw SHA
and column maps are in reviews/*projection.json. Full local waves were replayed
before packaging. Other full waves require regeneration; do not claim retention.
One complete final worst waveform is separately retained in the repository at
hw/soc/analog/pcie/evidence/sampler-v2-worst-20261004.dat.xz (see its exact pins).
No vendor implementation/model sources, simulator binaries or compiled OSDI are
redistributed here. Native .lib paths and model/runtime hashes refer to external
pinned inputs, not bundled implementations. Recompile OSDI with the recorded
original command; reproduce model/runtime paths or rerun a fresh campaign.

Metadata replay (from repository with exact external inputs restored):
 python scripts/review_pcie_sampler.py --directory EXTRACT/capture/v1 --mode metadata --output NEW-v1.json
 python scripts/review_pcie_sampler_v2.py --directory EXTRACT/capture/v2 --mode metadata --output NEW-v2.json
For a one-wave replay, copy the separate repository .xz file into
 EXTRACT/capture/v2/hbt_wcs_res_bcs_125_1.71/wave.dat.xz
and invoke the v2 reviewer with --mode retained. It reparses exactly one full wave.
Cross/startup archived full review receipts describe local raw replay; their full
waves are not bundled. Regenerate by the commands in the outer validation receipt.
All engineering limits/window definitions remain unchanged across revisions.
V2 measured screens passed, but numerical startup and cross-version negative-control
residuals prevent a clean qualification claim. External clock/biases are required;
there is no CDR/PLL, CMOS deserializer, physical extraction, jitter/BER or PCIe signoff.
