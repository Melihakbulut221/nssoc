# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""One requested physical+resistor-thermal nodeset attempt, without forced states."""
import gzip, json, shutil, sys, tempfile
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import characterize_pcie_sampler_v2 as s
import review_pcie_sampler_v2 as v
import diagnose_pcie_sampler_startup as probe
root=Path('/dev/shm/nssoc-sampler-v2-full-ng47-20261004')
out=Path('/dev/shm/nssoc-sampler-thermal-startup-20261004');out.mkdir()
r=json.loads((root/'result.json').read_text());v.source_contract(r)
name=v.selected_wave(r);row=next(x for x in r['cases'] if x['case']['name']==name)
pins=dict(r['source_sha256'])
for p in (Path(__file__).resolve(),Path(probe.__file__),Path(v.__file__),root/'result.json'):
 pins[str(p)]=v.digest(p)
with tempfile.TemporaryDirectory(dir='/dev/shm') as scratch:
 wave=Path(scratch)/'wave.dat';s.diagnostics.unpack_wave(root/name/'wave.dat.gz',wave,row['wave_sha256']);t=s.rx.rx.read_table(wave,['time',*s.VECTORS])
hints={n:t['v('+n+')'][0] for n in s.NODES}
thermal={n+'.dt':t['v('+n+'.dt)'][0] for n in s.THERMAL}
text=probe.transformed_deck((root/name/'bench.cir').read_text(),'physical_nodeset',hints)
lines=text.splitlines();ix=next(i for i,l in enumerate(lines) if l.startswith('.nodeset '));lines[ix]+=' '+' '.join(f'v({n})={x:.12g}' for n,x in thermal.items())
(out/'bench.cir').write_text('\n'.join(lines)+'\n')
for f in (s.NETLIST.name,s.rx.NETLIST.name):shutil.copyfile(root/name/f,out/f)
result=dict(source_sha256=pins,case=row['case'],original_wave_sha256=row['wave_sha256'],electrical_hints=hints,resistor_thermal_hints_kelvin=thermal,unchanged_models_tolerances_devices=True,uic=False,node_clamps=False,source=probe.MANUAL)
try:
 result['execution']=s.rx.execute(row['execution']['command'],out,out/'run.log')
 result['measurement']=s.measure(out/'wave.dat',row['case'])
 result['diagnostics']=s.diagnostics.diagnostics((out/'run.log').read_text())
 result['wave_sha256']=v.digest(out/'wave.dat')
 with (out/'wave.dat').open('rb') as a,gzip.open(out/'wave.dat.gz','wb',compresslevel=1) as b:shutil.copyfileobj(a,b)
 (out/'wave.dat').unlink()
 result['status']='CLEAN_SINGLE_STRATEGY_NOT_PVT_QUALIFIED' if result['diagnostics']['numerical_clean'] and result['measurement']['screen_pass'] else 'NUMERICAL_RESIDUAL_NOT_CURED'
except RuntimeError as exc:
 result['status']='NATIVE_FAILURE_PRESERVED';result['error']=str(exc)
finally:
 for p,sha in pins.items():v.verify(p,sha)
 result['source_bytes_unchanged']=True
 result['outputs']={p.name:v.digest(p) for p in out.iterdir()}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(result['status'],result.get('diagnostics'))
