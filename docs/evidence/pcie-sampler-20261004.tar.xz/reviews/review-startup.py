import json,sys,gzip,tempfile,math
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import diagnose_pcie_sampler_startup as method
import review_pcie_sampler_v2 as v
s=method.s
root=Path('/dev/shm/nssoc-sampler-startup-final-20261004');r=json.loads((root/'result.json').read_text());base=Path('/dev/shm/nssoc-sampler-v2-full-ng47-20261004');original=json.loads((base/'result.json').read_text());v.source_contract(original);case=r['baseline_case'];name=case['name'];raw=next(x for x in original['cases'] if x['case']==case);assert r['baseline_measurement']==raw['measurement'];assert [x['strategy'] for x in r['strategies']]==list(method.STRATEGIES)
for p,h in r['source_sha256'].items():v.verify(p,h)
replayed=[]
for row in r['strategies']:
 d=root/row['strategy']
 for p,h in row['output_sha256'].items():v.verify(d/p,h)
 assert (d/'bench.cir').read_text()==method.transformed_deck((base/name/'bench.cir').read_text(),row['strategy'],r['initial_newton_hints'])
 assert s.diagnostics.diagnostics((d/'run.log').read_text())==row['numerical_diagnostics']
 if 'measurement'in row:
  with tempfile.TemporaryDirectory(dir='/dev/shm')as scratch:
   wave=Path(scratch)/'w';s.diagnostics.unpack_wave(d/'wave.dat.gz',wave,row['wave_sha256']);assert s.measure(wave,case)==row['measurement']
  vals=[float(v) for line in (d/'dc.dat').read_text().splitlines()[1:] for v in line.split()];assert row['dc_finite']==(bool(vals) and all(math.isfinite(x)for x in vals));replayed.append(row['strategy'])
 else:
  assert row['strategy']=='source_homotopy' and 'Timestep too small' in(d/'run.log').read_text()
assert r['clean_strategies']==[] and r['native_failed_strategies']==['source_homotopy']
out={'status':'PASS_CAPTURE_REVIEW_NUMERICAL_RESIDUAL_RETAINED','result_sha256':v.digest(root/'result.json'),'full_waveforms_reparsed':replayed,'native_failed_strategies':r['native_failed_strategies'],'clean_strategy_found':False,'source_bytes_rechecked':True,'no_native_execution':True}
Path('hw/soc/out/pcie-sampler-20261004/startup-final-review.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
