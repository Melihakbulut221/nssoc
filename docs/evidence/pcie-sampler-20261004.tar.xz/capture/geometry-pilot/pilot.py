import sys,json,gzip,shutil
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import characterize_pcie_sampler as s
b=Path('/dev/shm/nssoc-sampler-full-ng47-20261004');out=Path('/dev/shm/nssoc-sampler-v2-pilot-20261004');r=json.loads((b/'result.json').read_text())
record={'baseline_result_sha256':s.rx.tx.sha(b/'result.json'),'modification':'Only four native collector rppd lengths; widths, topology, stimulus, limits unchanged','rows':[]}
for length in ('2.08','2.12'):
 for name in ['hbt_wcs_res_bcs_125_1.71','hbt_wcs_res_wcs_125_1.71','hbt_typ_res_typ_27_1.8']:
  row=next(x for x in r['cases'] if x['case']['name']==name);d=out/(length+'-'+name);d.mkdir()
  for f in ['bench.cir',s.rx.NETLIST.name]:shutil.copyfile(b/name/f,d/f)
  txt=(b/name/s.NETLIST.name).read_text();assert txt.count('l=2.04u')==2
  (d/s.NETLIST.name).write_text(txt.replace('l=2.04u','l='+length+'u'))
  execution=s.rx.execute(row['execution']['command'],d,d/'run.log');m=s.measure(d/'wave.dat',row['case'])
  x={'length_um':length,'case':row['case'],'execution':execution,'measurement':m,'diagnostics':s.diagnostics.diagnostics((d/'run.log').read_text()),'wave_sha256':s.rx.tx.sha(d/'wave.dat')}
  with (d/'wave.dat').open('rb') as a,gzip.open(d/'wave.dat.gz','wb',compresslevel=1) as z:shutil.copyfileobj(a,z)
  (d/'wave.dat').unlink();x['outputs']={p.name:s.rx.tx.sha(p) for p in d.iterdir()};record['rows'].append(x);(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
  print(length,name,m['min_signed_margin_v'],min(z['min_vce_v'] for z in m['devices'].values()),m['screen_pass'],flush=True)
