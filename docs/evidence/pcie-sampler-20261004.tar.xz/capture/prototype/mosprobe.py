from pathlib import Path
import sys,json,shutil
sys.path.insert(0,str(Path.cwd()/'scripts'))
import characterize_pcie_rx_v2 as rx
from bisect import bisect_left
root=Path('/dev/shm/nssoc-sampler-probe-20261004')
models=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/ngspice/models')
osdi=Path('/dev/shm/nssoc-rx-v2-final-ng47-20261004/r3_cmc.osdi')
ng=Path('/dev/shm/nssoc-ngspice47-20261004/root/usr/bin/ngspice')
latch='''* Native current-steering latch; track when cp > cn.
.subckt latch dp dn qp qn cp cn avdd avss sub ref
XDP qn dp se sub npn13G2 Nx=4
XDN qp dn se sub npn13G2 Nx=4
XLP qn qp he sub npn13G2 Nx=4
XLN qp qn he sub npn13G2 Nx=4
XCS se cp te sub npn13G2 Nx=4
XCH he cn te sub npn13G2 Nx=4
XT te ref avss avss sg13_lv_nmos w=640u l=.13u ng=64
XRP avdd qp sub rsil w=2u l=27.5u b=0 sw_et=1
XRN avdd qn sub rsil w=2u l=27.5u b=0 sw_et=1
.ends latch
.subckt sampler dp dn qp qn cp cn avdd avss sub ref
XREF ref ref avss avss sg13_lv_nmos w=160u l=.13u ng=16
XM dp dn mp mn cn cp avdd avss sub ref latch
XS mp mn qp qn cp cn avdd avss sub ref latch
.ends sampler
'''
def run(name,temp=27,vdd=1.8,vee=0,ccm=1.15,amp=.15,tail=.0005,cap=30e-15):
 d=root/name;d.mkdir();(d/'latch.spice').write_text(latch);shutil.copyfile(rx.NETLIST,d/rx.NETLIST.name)
 c=rx.cases(True)[0]|dict(temp=temp,supply=vdd,cap_f=5e-15)
 text,bits=rx.deck(c,models,osdi)
 extra=[f'.lib "{models}/cornerMOSlv.lib" mos_tt', '.include "latch.spice"',f'VEE vee 0 {vee}',f'ISAMP avdd sr {tail}',f'VSCP scp0 0 PULSE({ccm-amp} {ccm+amp} {rx.rx.START+.5*rx.UI-5e-12:.12g} 10p 10p 52.5p 125p)',f'VSCN scn0 0 PULSE({ccm+amp} {ccm-amp} {rx.rx.START+.5*rx.UI-5e-12:.12g} 10p 10p 52.5p 125p)','RCP scp0 scp 50','RCN scn0 scn 50','XSAMP op on qp qn scp scn avdd vee 0 sr sampler',f'CQP qp 0 {cap}',f'CQN qn 0 {cap}']
 fields=['v(qp)','v(qn)','v(scp)','v(scn)','v(sr)']
 for stage in ('m','s'):
  fields.extend(f'v(xsamp.x{stage}.{node})' for node in ('se','he','te'))
  fields.extend(f'@q.xsamp.x{stage}.x{x}.qnpn13g2[ic]' for x in ('dp','dn','lp','ln','cs','ch','t'))
 fields+=['v(xsamp.mp)','v(xsamp.mn)','i(vee)','i(vscp)','i(vscn)']
 fields=[f for f in fields if not '.xt.' in f]; vectors=rx.rx.VECTORS+fields
 text=text.replace('pre_osdi '+str(osdi), 'pre_osdi '+str(osdi)+'\npre_osdi /dev/shm/nssoc-sampler-probe-20261004/psp103.osdi'); text=text.replace('.control','\n'.join(extra)+'\n.control').replace('save '+' '.join(rx.rx.VECTORS),'save '+' '.join(vectors)).replace('wrdata wave.dat '+' '.join(rx.rx.VECTORS),'wrdata wave.dat '+' '.join(vectors))
 (d/'bench.cir').write_text(text)
 try:
  execution=rx.execute([str(ng),'-n','-b','bench.cir'],d,d/'run.log')
  data=rx.rx.read_table(d/'wave.dat',['time',*vectors]);ts=data['time'];begin=bisect_left(ts,rx.rx.START)
  diff=[a-b for a,b in zip(data['v(qp)'],data['v(qn)'])]
  samples=[rx.tx.interpolate(ts,diff,rx.rx.START+(i+p)*rx.UI)*(1 if bits[i] else -1) for i in range(16,rx.BITS-1) for p in (.8,1.05,1.3)]
  vces={}
  for stage in ('m','s'):
   p,n=('v(xsamp.mp)','v(xsamp.mn)') if stage=='m' else ('v(qp)','v(qn)')
   prefix=f'v(xsamp.x{stage}.'
   for device,cn,en in [('dp',n,prefix+'se)'),('dn',p,prefix+'se)'),('lp',n,prefix+'he)'),('ln',p,prefix+'he)'),('cs',prefix+'se)',prefix+'te)'),('ch',prefix+'he)',prefix+'te)'),('t',prefix+'te)',None)]:
    vals=[data[cn][i]-(data[en][i] if en else vee) for i in range(begin,len(ts))]
    ic=data[f'@q.xsamp.x{stage}.x{device}.qnpn13g2[ic]'] if device!='t' else [1.]*len(ts)
    active=[v for i,v in enumerate(vals,begin) if ic[i]>.0001]
    vces[stage+device]={'min':min(vals),'max':max(vals),'active_min':min(active) if active else None,'icmax':max(ic[begin:])}
  result={'margin':min(samples),'errors':sum(v<=0 for v in samples),'vces':vces,'native':execution}
 except Exception as exc: result={'error':repr(exc)}
 (d/'measurement.json').write_text(json.dumps(result,indent=2)+'\n');print(name,json.dumps(result),flush=True)
if __name__=='__main__':
 for args in [('mos_nom',27,1.8,0,1.02),('mos_cold',-40,1.71,0,1.02),('mos_hot',125,1.71,0,1.02)]:run(*args,cap=30e-15)
