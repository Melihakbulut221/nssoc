import sys
sys.path.insert(0,'/dev/shm/nssoc-sampler-probe-20261004')
import probe as p
p.latch=p.latch.replace('l=41.785u','l=27.5u')
p.latch=p.latch.replace('.ends latch','XBS se avss sub rppd w=1u l=38.4u b=0 sw_et=1\nXBH he avss sub rppd w=1u l=38.4u b=0 sw_et=1\n.ends latch')
p.latch=p.latch.replace('XM dp dn mp mn','XIP dp lp sub rppd w=1u l=3.6u b=0 sw_et=1\nXIN dn ln sub rppd w=1u l=3.6u b=0 sw_et=1\nXBP avdd lp sub rppd w=1u l=3.6u b=0 sw_et=1\nXBN avdd ln sub rppd w=1u l=3.6u b=0 sw_et=1\nXM lp ln mp mn')
orig=p.rx.execute
def execute(cmd,cwd,log):
 bench=cwd/'bench.cir';s=bench.read_text().replace('10p 10p 52.5p','5p 5p 57.5p').replace('2.0575e-09','2.06e-09').replace('RCP scp0 scp 50','RCP scp0 scp 10').replace('RCN scn0 scn 50','RCN scn0 scn 10');v=2.5
 s=s.replace('XSAMP op on qp qn scp scn avdd vee','VSAMP savdd 0 '+str(v)+'\nXSAMP op on qp qn scp scn savdd vee').replace('ISAMP avdd sr','ISAMP savdd sr')
 bench.write_text(s);return orig(cmd,cwd,log)
p.rx.execute=execute
for name,t,v in [('shift_nom',27,1.8),('shift_cold',-40,1.71),('shift_hot',125,1.71)]:p.run(name,t,v,0,1.25,cap=100e-15)
