import sys
sys.path.insert(0,'/dev/shm/nssoc-sampler-probe-20261004')
import probe as p
p.latch=p.latch.replace('l=41.785u','l=18.93u').replace('sub npn13G2 Nx=4','sub npn13G2 Nx=2').replace('te sub npn13G2 Nx=2','te sub npn13G2 Nx=4').replace('avss sub npn13G2 Nx=2','avss sub npn13G2 Nx=4')
p.latch=p.latch.replace('rsil w=2u l=18.93u', 'rppd w=8u l=2.04u')
p.latch=p.latch.replace('.ends latch','XBS se avss sub rppd w=1u l=38.4u b=0 sw_et=1\nXBH he avss sub rppd w=1u l=38.4u b=0 sw_et=1\n.ends latch')
p.latch=p.latch.replace('XM dp dn mp mn','XIP dp lp sub rppd w=1u l=3.6u b=0 sw_et=1\nXIN dn ln sub rppd w=1u l=3.6u b=0 sw_et=1\nXBP avdd lp sub rppd w=1u l=3.6u b=0 sw_et=1\nXBN avdd ln sub rppd w=1u l=3.6u b=0 sw_et=1\nXM lp ln mp mn')
orig=p.rx.execute
sv=2.5
def execute(cmd,cwd,log):
 bench=cwd/'bench.cir';s=bench.read_text().replace('10p 10p 52.5p','5p 5p 57.5p').replace('2.0575e-09','2.06e-09').replace('RCP scp0 scp 50','RCP scp0 scp 10').replace('RCN scn0 scn 50','RCN scn0 scn 10')
 s=s.replace('XSAMP op on qp qn scp scn avdd vee','VSAMP savdd 0 '+str(sv)+'\nXSAMP op on qp qn scp scn savdd vee').replace('ISAMP avdd sr','ISAMP savdd sr')
 if 'wcs' in cwd.name:s=s.replace('hbt_typ','hbt_wcs').replace('res_typ','res_wcs')
 bench.write_text(s);return orig(cmd,cwd,log)
p.rx.execute=execute
for name,t,v,supply in [('rp_nom',27,1.8,2.5),('rp_cold',-40,1.71,2.375),('rp_hot',125,1.71,2.375),('rp_wcs_hot',125,1.71,2.375),('rp_wcs_cold',-40,1.71,2.375)]:
 sv=supply;p.run(name,t,v,0,1.29,cap=150e-15)
