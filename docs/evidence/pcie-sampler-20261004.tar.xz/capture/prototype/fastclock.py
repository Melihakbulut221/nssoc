import sys
sys.path.insert(0,'/dev/shm/nssoc-sampler-probe-20261004')
import probe as p
p.latch=p.latch.replace('l=41.785u','l=27.5u')
orig=p.rx.execute
def execute(cmd,cwd,log):
 bench=cwd/'bench.cir';s=bench.read_text().replace('10p 10p 52.5p','2p 2p 60.5p').replace('2.0575e-09','2.0615e-09').replace('RCP scp0 scp 50','RCP scp0 scp 10').replace('RCN scn0 scn 50','RCN scn0 scn 10');bench.write_text(s)
 return orig(cmd,cwd,log)
p.rx.execute=execute
for name,t,v in [('fast_nom',27,1.8),('fast_cold',-40,1.71),('fast_hot',125,1.71)]:p.run(name,t,v,-.35,.95,cap=150e-15)
