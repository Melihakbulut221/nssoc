import sys
sys.path.insert(0,'/dev/shm/nssoc-sampler-probe-20261004')
import mosprobe as p
p.latch=p.latch.replace('w=640u l=.13u ng=64','w=1600u l=.5u ng=160').replace('w=160u l=.13u ng=16','w=400u l=.5u ng=40').replace('l=27.5u','l=34.6425u')
p.latch=p.latch.replace('sub npn13G2 Nx=4','sub npn13G2 Nx=2').replace('te sub npn13G2 Nx=2','te sub npn13G2 Nx=4')
# Load NQS definitions too; the actual tail uses rfmode=0, while the PDK declares both model families.
old=p.rx.deck
def deck(*a,**k):
 text,bits=old(*a,**k);return text.replace('.control','.control\npre_osdi /dev/shm/nssoc-sampler-probe-20261004/psp103_nqs.osdi'),bits
p.rx.deck=deck
for args in [('mos2_nom',27,1.8,0,.95),('mos2_cold',-40,1.71,0,.95),('mos2_hot',125,1.71,0,.95)]:p.run(*args,cap=30e-15)
