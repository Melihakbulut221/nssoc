from pathlib import Path
import hashlib,json,re,subprocess,time
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';run=c/'runs/electrical-incremental18';step=run/'1-openroad-resizertimingpostgrt'
while not (run/'final/nl/soc_top.nl.v').exists():
 if 'Flow failed' in (c/'electrical-incremental18-driver.log').read_text():raise SystemExit('ECO18 flow failed')
 time.sleep(5)
assert (step/'soc_top.grt.spef').stat().st_size>1000000
assert 'EST-0026' not in (c/'electrical-incremental18-driver.log').read_text()
assert (run/'final/nl/soc_top.nl.v').read_text().count('sg13g2_buf_8 fast_macro18_')==11
d=c/'electrical18-sta';d.mkdir(exist_ok=False)
app=root/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
for corner in ['fast','typ','slow']:
 s=(c/f'electrical17-sta/{corner}.tcl').read_text().replace('electrical-incremental17','electrical-incremental18').replace('electrical17-sta','electrical18-sta')
 s=s.replace('exit\n','report_parasitic_annotation > {'+str(d/f'{corner}-annotation.rpt')+'}\nreport_checks -path_delay min -group_path_count 20 -format full_clock_expanded -digits 6 > {'+str(d/f'{corner}-min.rpt')+'}\nexit\n')
 p=d/f'{corner}.tcl';p.write_text(s)
 with (d/f'{corner}.log').open('w') as f:r=subprocess.run([str(app),'sta','-exit',str(p)],stdout=f,stderr=subprocess.STDOUT)
 text=(d/f'{corner}.log').read_text();assert r.returncode==0 and not re.search(r'(?im)^(Error|Warning):',text),text
 print(corner,re.search(r'CORNER_RESULT.*',text)[0],flush=True)
