from pathlib import Path
from collections import defaultdict, Counter
import hashlib, json, re, sys
c=Path(__file__).resolve().parent
variant=int(sys.argv[1]);d=c/f'electrical{variant}-sta';p=c/f'electrical{variant}-proof'
proof=json.loads((p/'result.json').read_text());assert proof['status']=='PASS within scope'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for path,expected in proof['sources'].items():assert sha(path)==expected,path
for name in ['after.json','after-libraries.json']:assert sha(p/name)==proof['generated'][name]
m=json.loads((p/'after.json').read_text())['modules']['soc_top'];lib=json.loads((p/'after-libraries.json').read_text())['modules'];sinks=defaultdict(list)
for name,cell in m['cells'].items():
 for port,bits in cell['connections'].items():
  if cell['port_directions'][port] in ('input','inout'):
   for bit in bits:sinks[bit].append(name+'/'+port)
for name,port in m['ports'].items():
 if port['direction'] in ('output','inout'):
  for bit in port['bits']:sinks[bit].append('PORT:'+name)
text=(d/'unannotated-drivers.rpt').read_text();expected=int(re.search(r'Found (\d+) unannotated drivers',text)[1]);rows=[]
for name in text.splitlines():
 name=name.strip()
 if '/' not in name:continue
 cn,pn=name.rsplit('/',1);cell=m['cells'][cn];ports=lib[cell['type']]['ports'];key=pn if pn in ports else pn.split('[')[0];port=ports[key];assert port['direction']=='output'
 bits=cell['connections'].get(key)
 if pn!=key:
  idx=int(pn.rsplit('[',1)[1][:-1])-port.get('offset',0)
  assert 0<=idx<len(port['bits'])
  if bits is not None:bits=[bits[idx]]
 loads=[x for b in bits for x in sinks[b]] if bits is not None else []
 assert not loads,(name,loads)
 rows.append({'driver':name,'type':cell['type'],'classification':'disconnected declared output' if bits is None else 'connected net without any sink'})
assert len(rows)==expected
result={'status':'PASS within scope','unannotated_drivers':expected,'counts':dict(Counter(r['classification'] for r in rows)),'scope':'All listed unannotated output drivers have no logical sinks in the source-bound connectivity. This does not validate RC accuracy, final extraction or timing closure.','sources':{str(path.relative_to(c)):sha(path) for path in [p/'result.json',p/'after.json',p/'after-libraries.json',d/'unannotated-drivers.rpt',Path(__file__)]},'drivers':rows}
(d/'annotation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result['counts'])
