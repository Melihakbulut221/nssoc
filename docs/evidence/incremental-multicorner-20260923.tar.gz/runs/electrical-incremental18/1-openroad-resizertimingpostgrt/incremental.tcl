source $::env(SCRIPTS_DIR)/openroad/common/io.tcl
source $::env(SCRIPTS_DIR)/openroad/common/resizer.tcl
read_current_odb
set_thread_count 4
set_propagated_clock [all_clocks]
remove_fillers
set block [ord::get_db_block]
foreach n [$block getNets] {set w [$n getWire];if {$w ne "NULL"} {odb::dbWire_destroy $w}}
source $::env(SCRIPTS_DIR)/openroad/common/set_rc.tcl
source $::env(SCRIPTS_DIR)/openroad/common/dpl.tcl
source $::env(SCRIPTS_DIR)/openroad/common/grt.tcl
estimate_parasitics -global_routing
report_check_types -max_slew -max_capacitance -violators -digits 6 > $::env(STEP_DIR)/electrical-before.rpt
for {set iteration 0} {$iteration<3} {incr iteration} {
 global_route -start_incremental
 repair_design -slew_margin 20 -cap_margin 20 -verbose
 source $::env(SCRIPTS_DIR)/openroad/common/dpl.tcl
 global_route -end_incremental
 estimate_parasitics -global_routing
 report_check_types -max_slew -max_capacitance -violators -digits 6 > $::env(STEP_DIR)/electrical-$iteration.rpt
 puts "ECO15_ITER $iteration SETUP [sta::worst_slack -max] HOLD [sta::worst_slack -min]"
}
global_route -start_incremental
set serial 0
foreach name {u_eth.u_mac.tx_fifo.fifo_inst.mem.0.7/B_CLK u_eth.u_mac.tx_fifo.fifo_inst.mem.0.6/B_CLK u_eth.u_mac.rx_fifo.fifo_inst.mem.0.0/A_CLK u_eth.u_mac.rx_fifo.fifo_inst.mem.0.7/A_CLK u_eth.u_mac.rx_fifo.fifo_inst.mem.0.7/A_ADDR[6] u_eth.u_mac.rx_fifo.fifo_inst.mem.0.7/A_ADDR[2] u_eth.u_mac.rx_fifo.fifo_inst.mem.0.1/A_CLK u_eth.u_mac.rx_fifo.fifo_inst.mem.0.6/A_CLK u_eth.u_mac.rx_fifo.fifo_inst.mem.0.6/A_ADDR[2] u_eth.u_mac.tx_fifo.fifo_inst.mem.0.7/A_ADDR[5] u_ram.g_ram_2048x64_ecc.u_b0/A_ADDR[4]} {
 set k [string last / $name];set inst [$block findInst [string range $name 0 [expr {$k-1}]]]
 if {$inst eq "NULL"} {error "Missing macro $name"}
 set pin [$inst findITerm [string range $name [expr {$k+1}] end]]
 if {$pin eq "NULL" || [$pin getIoType] ne "INPUT"} {error "Missing macro input $name"}
 lassign [$pin getAvgXY] valid x y
 if {!$valid} {error "No physical location $name"}
 insert_buffer -buffer_cell sg13g2_buf_8 -load_pins [get_pins [list $name]] -buffer_name fast_macro18_${serial} -net_name fast_macro18_net_${serial} -location [list [ord::dbu_to_microns $x] [ord::dbu_to_microns $y]]
 incr serial
}
source $::env(SCRIPTS_DIR)/openroad/common/dpl.tcl
global_route -end_incremental
estimate_parasitics -global_routing
puts "ECO18_SETUP [sta::worst_slack -max] HOLD [sta::worst_slack -min]"
report_checks -path_delay max -group_path_count 100 -fields {fanout cap slew} -digits 6 > $::env(STEP_DIR)/max.rpt
report_check_types -max_slew -max_capacitance -violators -digits 6 > $::env(STEP_DIR)/electrical.rpt
estimate_parasitics -global_routing -spef_file $::env(STEP_DIR)/soc_top.grt.spef
if {![file exists $::env(STEP_DIR)/soc_top.grt.spef] || [file size $::env(STEP_DIR)/soc_top.grt.spef] < 1000000} {error "Missing global-route SPEF"}
write_guides $::env(STEP_DIR)/soc_top.final.guide
write_views
