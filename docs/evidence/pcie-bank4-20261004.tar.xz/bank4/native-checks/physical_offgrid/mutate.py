import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-bank-02/nssoc_pcie_analog_bank4.gds')
c=l.cell('nssoc_pcie_analog_bank4')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-bank-check-final/physical_offgrid/wrong.gds')
