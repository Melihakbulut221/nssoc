read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-bank-02/nssoc_pcie_analog_bank4.lef}
set master [[ord::get_db] findMaster nssoc_pcie_analog_bank4]
if {$master eq "NULL"} {error "Analog master missing"}
if {[$master getWidth] != 260000 || [$master getHeight] != 1460000} {error "Analog outline changed"}
if {[llength [$master getMTerms]] != 47} {error "Analog terminal census changed"}
set term [$master findMTerm AVDD]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 218000 0 222000 4000}}} {error "Analog port geometry differs"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 230000 0 234000 4000}}} {error "Analog port geometry differs"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal2 242000 0 246000 4000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_TX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 59000 2000 61000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_TX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 59000 260000 61000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_TX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 67000 260000 69000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_TX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 67000 2000 69000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_TX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 31000 2000 33000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_RX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 244000 2000 246000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_RX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 244000 260000 246000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_RX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 252000 260000 254000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_RX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 252000 2000 254000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_RX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 216000 2000 218000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L0_RX_VCM]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 332000 260000 334000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_TX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 419000 2000 421000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_TX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 419000 260000 421000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_TX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 427000 260000 429000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_TX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 427000 2000 429000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_TX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 391000 2000 393000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_RX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 604000 2000 606000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_RX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 604000 260000 606000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_RX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 612000 260000 614000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_RX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 612000 2000 614000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_RX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 576000 2000 578000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L1_RX_VCM]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 692000 260000 694000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_TX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 779000 2000 781000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_TX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 779000 260000 781000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_TX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 787000 260000 789000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_TX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 787000 2000 789000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_TX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 751000 2000 753000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_RX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 964000 2000 966000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_RX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 964000 260000 966000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_RX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 972000 260000 974000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_RX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 972000 2000 974000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_RX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 936000 2000 938000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L2_RX_VCM]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 1052000 260000 1054000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_TX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1139000 2000 1141000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_TX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 1139000 260000 1141000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_TX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 1147000 260000 1149000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_TX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1147000 2000 1149000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_TX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1111000 2000 1113000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_RX_INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1324000 2000 1326000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_RX_INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 1324000 260000 1326000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_RX_OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 1332000 260000 1334000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_RX_OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1332000 2000 1334000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_RX_IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 0 1296000 2000 1298000}}} {error "Analog port geometry differs"}
set term [$master findMTerm L3_RX_VCM]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{TopMetal1 258000 1412000 260000 1414000}}} {error "Analog port geometry differs"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "Analog blockage layer census changed"}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
