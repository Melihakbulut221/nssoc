import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-bank-02/nssoc_pcie_analog_bank4.gds')
c=l.cell('nssoc_pcie_analog_bank4')
matches=[]
for i in c.each_inst():
    b=i.dbbox(); child=l.cell(i.cell_index)
    if abs(b.center().x-31.0)<0.001 and abs(b.center().y-965.0)<0.001 and not pya.Region(child.begin_shapes_rec(l.layer(125,0))).is_empty():matches.append(i)
if len(matches)!=1:raise ValueError('Physical open must remove exactly one measured topvia1 instance')
matches[0].delete()
l.write('/dev/shm/nssoc-bank-check-final/physical_open/wrong.gds')
