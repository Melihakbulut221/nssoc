import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-bank-02/nssoc_pcie_analog_bank4.gds')
c=l.cell('nssoc_pcie_analog_bank4')
c.shapes(l.layer(134,0)).insert(pya.DBox(230,1,246,3))
l.write('/dev/shm/nssoc-bank-check-final/physical_bulk_short/wrong.gds')
