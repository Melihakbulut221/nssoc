# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Replay exact native outputs and package measured bank/RX physical scope."""
from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile
ROOT=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc');B=ROOT/'hw/soc/out/pcie-bank4-20261004'

def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=h)

inputs={};outputs={};native={};members={}
for kind,layout,checks in [('rx-v2',Path('/dev/shm/nssoc-rx-v2-bank-01'),Path('/dev/shm/nssoc-bank-rx-check-final')),('bank4',Path('/dev/shm/nssoc-bank-02'),Path('/dev/shm/nssoc-bank-check-final'))]:
 d=json.loads((checks/'result.json').read_text());g=json.loads((layout/'result.json').read_text())
 assert d['status']=='PASS_NATIVE_'+('BANK4' if kind=='bank4' else 'RX_V2')+'_MAIN_DRC_STRICT_LVS_LEF_AND_NEGATIVE_CONTROLS_ONLY'
 for path,h in d['inputs'].items():
  if path not in inputs:inputs[path]=pin(path)
  assert inputs[path]['sha256']==h
 for path,h in d['outputs'].items():
  p=checks/path;v=pin(p);assert v['sha256']==h;outputs[str(p)]=v
 for path,h in g['output_sha256'].items():assert pin(layout/path)['sha256']==h
 steps={s['name']:s for s in d['steps']};assert steps['drc']['measurement']['category_count']==560 and steps['drc']['measurement']['status']=='PASS'
 audit=steps['lvs']['audit'];assert audit['extraction_diagnostics']==[] and audit['circuit_status_counts']=={'Match':1}
 expected=57 if kind=='bank4' else 9
 assert len(audit['circuits'])==1 and audit['circuits'][0]['layout_devices_recursive']==expected and audit['circuits'][0]['schematic_devices_recursive']==expected
 assert steps['physical_offgrid']['measurement']['categories']['metal1_drw_Offgrid']==4
 assert steps['lef']['status']=='PASS' and steps['lef_missing_pin']['status']=='EXPECTED_REJECTION'
 for s in d['steps']:
  if s['name'] not in ('drc','physical_offgrid','lef','lef_missing_pin','lvs'):
   assert s['status']=='FAIL' and s['audit_execution']['returncode']==1
   assert s['audit']['circuit_status_counts']==({'Match':1} if s['name']=='physical_open' else {'NoMatch':1})
 native[kind]=dict(layout_result=pin(layout/'result.json'),check_result=pin(checks/'result.json'),status=d['status'],
                  generated_views={name:pin(layout/name) for name in g['output_sha256']},inputs_rehashed=len(d['inputs']),outputs_rehashed=len(d['outputs']),
                  native_steps=[dict(name=s['name'],status=s['status'],returncode=s['execution']['returncode'],seconds=s['execution']['seconds'],
                                     audit_returncode=s.get('audit_execution',{}).get('returncode')) for s in d['steps']],
                  drc_categories=560,drc_markers=0,primitive_devices=expected,ports=len(g['ports']))
 for base,label in [(layout,kind+'/layout'),(checks,kind+'/native-checks')]:
  for p in sorted(base.rglob('*')):
   if p.is_file():members[label+'/'+str(p.relative_to(base))]=p.read_bytes()
owned=['hw/soc/flow/make_pcie_rx_cell_v2.py','hw/soc/flow/make_pcie_analog_bank.py','hw/soc/flow/check_pcie_analog_bank.py','sw/tests/test_pcie_analog_bank.py']
methods=owned+['hw/soc/analog/pcie/rx_hbt_rsil_v2.spice','hw/soc/analog/pcie/tx_cml_rsil.spice','hw/soc/flow/make_pcie_tx_cell.py',
 'hw/soc/flow/check_pcie_rx_cell.py','hw/soc/flow/check_ihp_drc.py','hw/soc/flow/prepare_ihp_drc.py','hw/soc/flow/audit_klayout_lvs.py','hw/soc/pnr/ihp-drc.lock.json','hw/soc/pnr/ihp-lvs.lock.json']
sourcepins={name:pin(ROOT/name) for name in methods}
for name in methods:members['methods/'+name]=(ROOT/name).read_bytes()
for label,command in [('tests',[str(ROOT/'.venv/bin/python'),'-m','pytest','-q','-p','no:cacheprovider','sw/tests/test_pcie_analog_bank.py','sw/tests/test_pcie_rx_cell.py','sw/tests/test_pcie_tx_cell.py','sw/tests/test_pcie_tx_rsil.py']),('ruff',[str(ROOT/'hw/soc/tools/dev-env/bin/ruff'),'check',*owned])]:
 with (B/(label+'.log')).open('w') as log:r=subprocess.run(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0
 (B/(label+'.json')).write_text(json.dumps(dict(command=command,returncode=r.returncode,log=pin(B/(label+'.log'))),indent=2)+'\n')
for p in sorted(B.iterdir()):
 if p.is_file() and p.suffix in ('.py','.log','.json','.svg','.png') and p.name not in ('source-validation.json',):members['reproduction/'+p.name]=p.read_bytes()
# Preserve original native diagnostics, not a claim of complete replay of superseded sources.
for label,directory,names in [('initial-bank-minimum-width','/dev/shm/nssoc-bank-check-01',['result.json','drc/run.log','drc/deck.log','drc/drc.lyrdb']),('strict-port-negative-collector-stop','/dev/shm/nssoc-bank-check-02',['result.json','physical_open/deck.log','physical_open/extracted.cir','physical_open/audit.json'])]:
 for name in names:members['superseded-diagnostics/'+label+'/'+name]=(Path(directory)/name).read_bytes()
archive=B/'rx-v2-bank4-native.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:xz') as tar:
 assert set(tar.getnames())==set(members)
 for m in tar:
  assert hashlib.sha256(tar.extractfile(m).read()).digest()==hashlib.sha256(members[m.name]).digest()
receipt=dict(status='PASS_SOURCE_BOUND_NATIVE_RX_V2_AND_FOUR_LANE_ANALOG_BANK_PHYSICAL_SCOPE',sources=sourcepins,owned_sources=owned,
 native=native,archive={**pin(archive),'path':str(archive.relative_to(ROOT)),'members':len(members),'roundtrip_all_members_verified':True},
 source_input_union_count=len(inputs),native_output_union_count=len(outputs),all_inputs_and_outputs_rehashed=True,
 geometry=dict(bank_bbox_um=[0,0,260,1460],lanes=4,instances=8,hbt=32,rsil=24,square_ptap_contacts=64,combined_tap_area_um2=256,combined_tap_perimeter_um=512,
               shared_real_metal_nets=['AVDD','AVSS','SUB'],explicit_signal_bias_boundary_ports=44,total_boundary_ports=47),
 root_review_inputs=dict(independent_geometry_review=pin(ROOT/'hw/soc/out/pcie-bank-peer-20261004/geometry-review.json')),
 original_tx_geometry_sha256='e94cfeb84b007ae23449de25e2c35fd63720f52ccfd5fa44d8d3a6f4380fa7c2',
 rendering=dict(svg=pin(B/'bank4-actual-layout.svg'),png=pin(B/'bank4-actual-layout.png'),record=pin(B/'rendering.json'),scope='Actual GDS polygons; selected drawing layers; view rotated90degrees only.'),
 controls=dict(bank=['physical_offgrid','wrong_load','wrong_lane','missing_tap','physical_open','physical_bulk_short','lef_missing_pin'],rx_v2=['physical_offgrid','wrong_load','wrong_input','missing_tap','lef_missing_pin'],
               physical_open='Exact removed lane2 RX input via, missing-onlyL2_RX_INP strict-port rejection, intact57device circuit; all other LVS negatives requireNoMatch.'),
 limits=['This separate analog bank is not instantiated in soc_top or the current digital chip shell.','No serializer/deserializer, slicer, PLL/CDR, equalizer or PCIe PHY/link acceptance.','No RF pad/ESD or package connection, interconnect PEX, EM, supply IR-drop, post-layout analog PVT, Liberty or production signoff.','Main560categoryDRC only; density/antenna and chip context are separate gates.','External per-cell current biases and per-laneVCM remain explicit ports.','Analogv2 PVT result is separate evidence; physical PASS does not override unresolved compact-model initialization warnings.'],
 superseded_diagnostics='Initial bank had276TM1 minimumwidth violations; explicit2.4um nativevia landing metal fixedthem. Collector initially requiredNoMatch for portopen; strict vendor portfailure was alreadycorrect, exact specificnegativepredicate nowverified in fresh finalruns. Original failedrecords retained.')
(B/'source-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(receipt=pin(B/'source-validation.json'),archive=pin(archive),sources={k:sourcepins[k] for k in owned},native=native),indent=2))
