# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Read actual GDS drawing polygons; rotate view only, never change geometry."""
import hashlib,json
from pathlib import Path
import pya
root=Path('/home/hasanmelih/Documents/ChatGPT/nnsoc')
out=root/'hw/soc/out/pcie-bank4-20261004'
gds=Path('/dev/shm/nssoc-bank-02/nssoc_pcie_analog_bank4.gds')
layout=pya.Layout();layout.read(str(gds));top=layout.cell('nssoc_pcie_analog_bank4')
selected=[(1,'#64748b','Activ'),(5,'#aa77bb','GatPoly'),(8,'#b09f4c','Metal1'),(10,'#57a773','Metal2'),(30,'#427db8','Metal3'),(50,'#4a9a9b','Metal4'),(67,'#e6b85c','Metal5'),(126,'#e07a5f','TopMetal1'),(134,'#71a8dc','TopMetal2')]
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1480" height="370" viewBox="0 0 1480 370">','<rect width="1480" height="370" fill="#101724"/>','<text x="20" y="25" fill="white" font-family="sans-serif" font-size="17">Four-lane TX / RX analog bank — actual GDS polygons, view rotated 90°</text>','<text x="20" y="47" fill="#cbd5e1" font-family="sans-serif" font-size="12">Physical size: 260 × 1460 µm. Separate block; not a complete PCIe PHY or main-chip integration.</text>']
counts={}
for layer,color,name in selected:
    region=pya.Region(top.begin_shapes_rec(layout.layer(layer,0)))
    paths=[];count=0
    for polygon in region.each():
        points=[list(polygon.each_point_hull())]+[list(polygon.each_point_hole(i)) for i in range(polygon.holes())]
        for ring in points:
            paths.append('M '+' L '.join(f'{p.y*layout.dbu+10:.3f},{330-p.x*layout.dbu:.3f}' for p in ring)+' Z')
        count+=1
    svg.append('<path fill="'+color+'" fill-rule="evenodd" d="'+' '.join(paths)+'"/>');counts[name]=count
for lane in range(4):
    x=10+lane*360
    svg.append(f'<text x="{x+100}" y="67" fill="white" font-family="sans-serif" font-size="12">Lane {lane}: TX  |  RX v2</text>')
for x,name in [(5,'AVDD'),(17,'AVSS'),(29,'SUB')]:
    svg.append(f'<text x="1440" y="{111-x}" fill="white" font-family="sans-serif" font-size="9">{name}</text>')
svg += ['<text x="20" y="354" fill="#cbd5e1" font-family="sans-serif" font-size="11">Blue: TopMetal2 supply/substrate trunks. Orange: actual TopMetal1 pin escapes. Lower layers show native device geometry.</text>','</svg>']
path=out/'bank4-actual-layout.svg';path.write_text('\n'.join(svg)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(scope='Read-only actual GDS drawing polygon rendering; selected layers listed; annotations not geometry; view rotation only.',gds_sha256=sha(gds),method_sha256=sha(Path(__file__)),svg_sha256=sha(path),selected_layer_polygon_counts=counts,klayout_version=pya.__version__)
(out/'rendering.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
