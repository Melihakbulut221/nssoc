import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-rx-v2-bank-01/nssoc_rx_hbt_v2_layout.gds')
c=l.cell('nssoc_rx_hbt_v2_layout')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2,2.102,2.1))
l.write('/dev/shm/nssoc-bank-rx-check-final/physical_offgrid/wrong.gds')
