read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-bank-rx-check-final/lef_missing_pin/wrong.lef}
set master [[ord::get_db] findMaster nssoc_rx_hbt_v2_layout]
if {$master eq "NULL"} {error "Analog master missing"}
if {[$master getWidth] != 167000 || [$master getHeight] != 158000} {error "Analog outline changed"}
if {[llength [$master getMTerms]] != 9} {error "Analog terminal census changed"}
set term [$master findMTerm INP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 54000 2000 56000}}} {error "Analog port geometry differs"}
set term [$master findMTerm INN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 54000 167000 56000}}} {error "Analog port geometry differs"}
set term [$master findMTerm OUTN]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 62000 2000 64000}}} {error "Analog port geometry differs"}
set term [$master findMTerm OUTP]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 62000 167000 64000}}} {error "Analog port geometry differs"}
set term [$master findMTerm IREF]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 26000 2000 28000}}} {error "Analog port geometry differs"}
set term [$master findMTerm AVDD]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 124000 167000 126000}}} {error "Analog port geometry differs"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 70500 0 72500 2000}}} {error "Analog port geometry differs"}
set term [$master findMTerm VCM]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 142000 167000 144000}}} {error "Analog port geometry differs"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "Analog terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "Analog pin direction/use differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 156000 167000 158000}}} {error "Analog port geometry differs"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "Analog blockage layer census changed"}
puts PASS_NATIVE_ANALOG_BANK_LEF_ONLY
