"""Bound each complete measurement process group, including descendants."""
import os
import signal
import subprocess
import time


def terminate_group(child, grace=5.0):
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    deadline = time.monotonic() + grace
    while time.monotonic() < deadline:
        child.poll()
        try:
            os.killpg(child.pid, 0)
        except ProcessLookupError:
            break
        time.sleep(0.05)
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait()


def bounded_run(command, *, stdout, timeout, preexec_fn=None):
    child = subprocess.Popen(command, stdout=stdout, stderr=subprocess.STDOUT,
                             start_new_session=True, preexec_fn=preexec_fn)
    try:
        code = child.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        terminate_group(child)
        code = 124
    except BaseException:
        terminate_group(child)
        raise
    return subprocess.CompletedProcess(command, code)
