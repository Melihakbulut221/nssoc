"""Real SoC placement/routing for transistor LVS, not SRAM timing acceptance.

The independently generated SRAMs have no characterized Liberty. Keep their
real geometry and connectivity; do not fabricate arcs or reuse vendor timing.
Timing optimization and timing acceptance are deliberately outside this flow.
"""
from librelane.flows import Flow
from librelane.flows.classic import Classic

excluded={'Verilator.Lint','Checker.LintTimingConstructs','Checker.LintErrors',
 'Checker.LintWarnings','Yosys.Synthesis','Checker.YosysUnmappedCells',
 'Checker.YosysSynthChecks','Checker.NetlistAssignStatements',
 'OpenROAD.STAPrePNR','OpenROAD.STAMidPNR','OpenROAD.STAMidPNR-1',
 'OpenROAD.STAMidPNR-2','OpenROAD.STAMidPNR-3','OpenROAD.STAPostPNR',
 'OpenROAD.ResizerTimingPostCTS','OpenROAD.ResizerTimingPostGRT',
 'OpenROAD.IRDropReport','Magic.StreamOut'}
steps=[]
for step in Classic.Steps:
 if step.id not in excluded:steps.append(step)
 if step.id=='KLayout.StreamOut':break

@Flow.factory.register()
class SRAMChipConnectivity(Classic):
 Steps=steps

if __name__=='__main__':
 from librelane.__main__ import cli
 cli()
