"""Require actual complete power-grid connectivity before CTS/routing."""
from pathlib import Path
from librelane.flows import Flow
from librelane.steps import OpenROAD
from connectivity_flow import SRAMChipConnectivity


class PowerCheckedPlacement(OpenROAD.DetailedPlacement):
    def get_script_path(self):
        original = Path(super().get_script_path())
        source = original.read_text()
        extra = '''
# Real placed design, all standard cells and all32 independent SRAMs retained.
check_power_grid -net VPWR -error_file $::env(STEP_DIR)/VPWR-connectivity.rpt
check_power_grid -net VGND -error_file $::env(STEP_DIR)/VGND-connectivity.rpt
puts "COMPLETE_PLACED_POWER_GRIDS_CONNECTED"
'''
        output = Path(self.step_dir) / 'power_checked_placement.tcl'
        output.write_text(source + extra)
        return str(output)


@Flow.factory.register()
class SRAMChipConnectivityPowerChecked(SRAMChipConnectivity):
    Steps = [PowerCheckedPlacement if step == OpenROAD.DetailedPlacement else step
             for step in SRAMChipConnectivity.Steps]


if __name__ == '__main__':
    from librelane.__main__ import cli
    cli()
