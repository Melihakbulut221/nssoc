#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""Prepare or run this exact connectivity profile in a new output directory.

Requires the pinned Linux LibreLane AppImage and an existing pinned IHP PDK.
No download or replacement of installed tools/PDKs is performed. A routing
completion is not LVS, timing, DRC/density or production acceptance.
"""
import argparse
import hashlib
import json
from pathlib import Path
import resource
import sys
import time


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app', required=True, type=Path)
    parser.add_argument('--pdk', required=True, type=Path,
                        help='Actual ihp-sg13g2 directory containing libs.ref and libs.tech')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--wall-seconds', type=int, default=28800,
                        help='Physical-run wall budget, 300..43200 seconds; default eight hours')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--run', action='store_true')
    mode.add_argument('--validate-header', action='store_true',
                      help='Only validate the configuration and generate the top module header')
    args = parser.parse_args()
    if not 300 <= args.wall_seconds <= 43200:
        parser.error('Wall budget must be between 300 and 43200 seconds')
    tool_timeout = min(args.wall_seconds, 300) if args.validate_header else args.wall_seconds
    bundle = Path(__file__).resolve().parent
    manifest = json.loads((bundle / 'manifest.json').read_text())
    app, pdk = args.app.resolve(strict=True), args.pdk.resolve(strict=True)
    if digest(app) != manifest['app_sha256']:
        parser.error('AppImage identity differs from the recorded version')
    pins = {str(app): digest(app)}
    for root, entries in [(bundle, manifest['bundle_sha256']), (pdk, manifest['pdk_sha256'])]:
        for name, expected in entries.items():
            path = (root / name).resolve(strict=True)
            if not path.is_relative_to(root) or digest(path) != expected:
                parser.error('Changed or escaped dependency: ' + name)
            pins[str(path)] = expected
    def resolve(value):
        if isinstance(value, dict):
            return {key: resolve(item) for key, item in value.items()}
        if isinstance(value, list):
            return [resolve(item) for item in value]
        if isinstance(value, str) and value.startswith('@file:'):
            name = value.removeprefix('@file:')
            if name not in manifest['bundle_sha256']:
                raise ValueError('Unlisted input token')
            return str((bundle / name).resolve(strict=True))
        if isinstance(value, str) and value.startswith('@dir:'):
            name = value.removeprefix('@dir:')
            if name not in manifest['directory_paths']:
                raise ValueError('Unlisted directory token')
            path = (bundle / name).resolve(strict=True)
            if not path.is_dir() or not path.is_relative_to(bundle):
                raise ValueError('Escaped directory token')
            return str(path)
        return value
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    (out / 'run').mkdir()
    (out / 'pdk-root').mkdir()
    (out / 'pdk-root' / 'ihp-sg13g2').symlink_to(pdk, target_is_directory=True)
    for name in ['config', 'state']:
        value = resolve(json.loads((bundle / (name + '-template.json')).read_text()))
        (out / (name + '.json')).write_text(json.dumps(value, indent=2) + '\n')
    command = [str(app), 'python', str(bundle / 'flow' / 'connectivity_power_flow.py'),
               '--flow', 'SRAMChipConnectivityPowerChecked', '--manual-pdk',
               '--pdk-root', str(out / 'pdk-root'), '--pdk', 'ihp-sg13g2',
               '--force-run-dir', str(out / 'run'), '--with-initial-state',
               str(out / 'state.json')]
    if args.validate_header:
        command += ['--to', 'Yosys.JsonHeader']
    command.append(str(out / 'config.json'))
    record = {'status': 'PREPARED_NOT_EXECUTED', 'command': command,
              'input_sha256': pins, 'timing_acceptance': False,
              'wall_budget_seconds': args.wall_seconds,
              'effective_tool_timeout_seconds': tool_timeout,
              'address_space_limit_bytes': 12 * 1024**3,
              'production_acceptance': False}
    def save():
        (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
    save()
    if args.run or args.validate_header:
        sys.path.insert(0, str(bundle / 'flow'))
        from bounded_process import bounded_run
        def limit():
            resource.setrlimit(resource.RLIMIT_AS, (12 * 1024**3, 12 * 1024**3))
        record['status'] = 'RUNNING'; save(); started = time.monotonic()
        with (out / 'run.log').open('x') as log:
            result = bounded_run(command, stdout=log, timeout=tool_timeout, preexec_fn=limit)
        if any(digest(Path(name)) != expected for name, expected in pins.items()):
            raise ValueError('Input changed during replay')
        record.update(returncode=result.returncode, elapsed_seconds=time.monotonic()-started)
        record['status'] = ('PASS_HEADER_VALIDATION_ONLY' if args.validate_header else
                            'ROUTING_COMPLETE_REQUIRES_FULL_VERIFICATION') if result.returncode == 0 else 'FAILED'
        save()
        if result.returncode:
            raise SystemExit(result.returncode)
    print(record['status'])


if __name__ == '__main__':
    main()
