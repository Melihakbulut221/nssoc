(* blackbox *) module SP6TSRAM512x64(input clk,input [8:0]a,input [63:0]d,input[7:0]we,output[63:0]q); endmodule
(* blackbox *) module DP8TSRAMDP256x16(input clk1,clk2,input[7:0]a1,a2,input[15:0]d1,d2,input[1:0]we1,we2,output[15:0]q1,q2); endmodule
