"""Verify explicit replay budgets and reject invalid limits before tool/output creation."""
from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent
out=p/'replay-budget-guard-v3';out.mkdir(exist_ok=False)
source=p/'replay-inputs-v3'
reloc=json.loads((p/'replay-relocation-check-v3/result.json').read_text())
assert reloc['status']=='PASS_RELOCATED_HEADER_AND_CHANGED_ADDRESS_WIDTH_REJECTED'
header=json.loads((p/'replay-relocation-check-v3/valid/result.json').read_text())
assert header['wall_budget_seconds']==28800 and header['effective_tool_timeout_seconds']==300
assert header['address_space_limit_bytes']==12*1024**3
command=list(reloc['valid_command']);command[1]=str(source/'replay.py');command.remove('--validate-header')
cases=[]
for budget,tag,expected in [(36000,'valid-override',0),(0,'zero',2),(43201,'excessive',2)]:
    cmd=list(command);cmd[cmd.index('--output')+1]=str(out/tag);cmd+=['--wall-seconds',str(budget)]
    with(out/(tag+'.log')).open('x')as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    assert q.returncode==expected,(tag,q.returncode)
    if expected:
        assert not(out/tag).exists()
        assert 'Wall budget must be between 300 and 43200 seconds'in(out/(tag+'.log')).read_text()
    else:
        record=json.loads((out/tag/'result.json').read_text())
        assert record['status']=='PREPARED_NOT_EXECUTED'
        assert record['wall_budget_seconds']==record['effective_tool_timeout_seconds']==budget
        assert '--to'not in record['command']
    cases.append({'name':tag,'command':cmd,'returncode':q.returncode,'tools_executed':False})
def sha(path):
    with path.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
old=json.loads((p/'replay-inputs-v2/manifest.json').read_text());new=json.loads((source/'manifest.json').read_text())
assert old['original_config_sha256']==new['original_config_sha256']
assert old['design_inputs']==new['design_inputs'] and old['pdk_sha256']==new['pdk_sha256']
assert set(old['bundle_sha256'])==set(new['bundle_sha256'])
changed=[n for n in old['bundle_sha256']if old['bundle_sha256'][n]!=new['bundle_sha256'][n]]
assert changed==['replay.py'],changed
for n,h in new['bundle_sha256'].items():assert sha(source/n)==h,n
record={'status':'PASS_EXPLICIT_BUDGET_CONTROLS_ALL_DESIGN_INPUTS_UNCHANGED',
        'cases':cases,'changed_bundle_members':changed,'source_manifest_sha256':sha(source/'manifest.json'),
        'default_physical_wall_seconds':28800,'header_timeout_seconds':300,
        'allowed_wall_seconds':[300,43200],'full_route_replay':False,'lvs_acceptance':False}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'])
