"""Reject changed copied include source before tool execution; original bundle stays intact."""
from pathlib import Path
import json,hashlib,subprocess,shutil,time
p=Path(__file__).resolve().parent;source=p/'replay-inputs-v3';clone=p/'replay relocation inputs v3';out=p/'replay-include-guard-v3';out.mkdir(exist_ok=False)
def sha(f):
 with f.open('rb')as s:return hashlib.file_digest(s,'sha256').hexdigest()
r=json.loads((p/'replay-relocation-check-v3/result.json').read_text());assert r['status']=='PASS_RELOCATED_HEADER_AND_CHANGED_ADDRESS_WIDTH_REJECTED'
m=json.loads((source/'manifest.json').read_text())
# Restore the previous, isolated width mutation before testing a different dependency.
model=next(name for name in m['bundle_sha256']if name.endswith('/independent_bb.v'));shutil.copy2(source/model,clone/model)
for n,h in m['bundle_sha256'].items():assert sha(clone/n)==h==sha(source/n),n
name=next(n for n in sorted(m['bundle_sha256'])if n.startswith('include-dirs/')and n.endswith('.v'))
f=clone/name;before=sha(f);f.write_bytes(f.read_bytes()+b'\n// Intentional source-identity negative control.\n');after=sha(f)
cmd=list(r['valid_command']);cmd[cmd.index('--output')+1]=str(out/'changed-include')
start=time.monotonic()
with (out/'run.log').open('x')as log:q=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert q.returncode==2 and not (out/'changed-include').exists()
assert 'Changed or escaped dependency: '+name in(out/'run.log').read_text()
for n,h in m['bundle_sha256'].items():assert sha(source/n)==h,n
record={'status':'PASS_CHANGED_COPIED_INCLUDE_REJECTED_BEFORE_TOOLS','command':cmd,'returncode':q.returncode,'elapsed_seconds':time.monotonic()-start,'mutation':{'bundle_path':name,'before_sha256':before,'after_sha256':after},'source_bundle_manifest_sha256':sha(source/'manifest.json'),'source_bundle_unchanged':True,'scope':__doc__}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'])
