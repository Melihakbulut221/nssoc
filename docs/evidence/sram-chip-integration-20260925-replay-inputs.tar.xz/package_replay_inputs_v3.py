"""Archive checked replay inputs locally without asserting completed routing."""
from pathlib import Path
import hashlib, json, tarfile, lzma
r=Path.cwd(); p=Path(__file__).resolve().parent
out=p/'replay-bundle-v3'; out.mkdir(exist_ok=False)
def sha(f):
 with Path(f).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(f):return json.loads(f.read_text())
bundle=p/'replay-inputs-v3'; manifest=read(bundle/'manifest.json')
for n,h in manifest['bundle_sha256'].items():assert sha(bundle/n)==h,n
header=read(p/'replay-relocation-check-v3/valid/result.json')
reloc=read(p/'replay-relocation-check-v3/result.json')
assert header['status']=='PASS_HEADER_VALIDATION_ONLY'
assert reloc['status']=='PASS_RELOCATED_HEADER_AND_CHANGED_ADDRESS_WIDTH_REJECTED'
assert reloc['source_bundle_manifest_sha256']==sha(bundle/'manifest.json')
assert reloc['all_resolved_design_paths_inside_relocated_bundle']
include=read(p/'replay-include-guard-v3/result.json');assert include['status']=='PASS_CHANGED_COPIED_INCLUDE_REJECTED_BEFORE_TOOLS'
budget=read(p/'replay-budget-guard-v3/result.json');assert budget['status']=='PASS_EXPLICIT_BUDGET_CONTROLS_ALL_DESIGN_INPUTS_UNCHANGED'
readme=out/'README.md'
readme.write_text('''# Exact 32-SRAM connectivity replay inputs

This package starts a fresh physical run from the mapped `soc_top` netlist.
It preserves the original 20 ns core and 8 ns Ethernet clock constraints,
0.95/1.05 derates, die, macro placement, power recipe and diode-only antenna
repair configuration. The two Verilog include directories are also copied and hash-pinned; no resolved
design path points to the original checkout. It contains sixteen 512x64 single-port memories and
sixteen 256x16 dual-port memories. No characterized SRAM Liberty is supplied.
This is a connectivity implementation flow, not final timing qualification.

Install the separately supplied, pinned LibreLane 3.0.5 Linux AppImage and
IHP SG13G2 PDK c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c. The launcher checks
actual file hashes, including all 26 PDK files listed in the manifest.
It does not download tools, modify the PDK, or overwrite an existing run.

From the extracted archive:

```sh
python3 replay-inputs-v3/replay.py --app /absolute/path/to/librelane.AppImage \\
  --pdk /absolute/path/to/ihp-sg13g2 --output /new/output/path --validate-header
```

Use `--run` instead of `--validate-header` for placement and routing in another
new output path. Omit both flags to generate the command and resolved inputs
without executing tools. The launcher limits the process to 12 GiB address
space and eight hours by default. Use `--wall-seconds N` to select an explicit\n300..43200-second physical-run budget; the receipt records it. Header-only\nvalidation is limited to 300 seconds. Sufficient local memory and disk space are required.

The bundled checks validate configuration/header generation after relocation,
including a directory containing spaces, and reject a changed SRAM address
width or copied include source before tool execution. They do not constitute a second full physical
run or a transistor LVS result. A completed route must undergo full transistor
LVS using the unchanged foundry deck and independent complete memory CDLs,
final power checks, and mapped-to-routed logic verification. DRC/density and
qualified timing are separate acceptance gates.

See NOTICES.txt and LICENSES for source licensing. All generated artifacts
retain their source identities in manifest.json. The recorded absolute source
paths are provenance only; the launcher resolves its design inputs locally.
''')
notice=out/'NOTICES.txt'
notice.write_text((p/'distribution-sources-v2/NOTICES.txt').read_text())
files={str(f.relative_to(p)):f for f in sorted(bundle.rglob('*')) if f.is_file() and '__pycache__' not in f.parts}
files.update({'README.md':readme,'NOTICES.txt':notice,'package_replay_inputs_v3.py':Path(__file__).resolve(),'build_replay_inputs_v3.py':p/'build_replay_inputs_v3.py','check_replay_relocation_v3.py':p/'check_replay_relocation_v3.py','check_replay_include_guard_v3.py':p/'check_replay_include_guard_v3.py'})
for name in ['Apache-2.0.txt','CERN-OHL-W-2.0.txt','CC-BY-4.0.txt','MIT.txt','LGPL-2.1-or-later.txt']:files['LICENSES/'+name]=r/'LICENSES'/name
files['LICENSES/Ibex-NOTICE']=r/'hw/soc/ext/ibex/NOTICE'
files['LICENSES/Ibex-CREDITS.md']=r/'hw/soc/ext/ibex/CREDITS.md'
files['check_replay_budget_v3.py']=p/'check_replay_budget_v3.py'
files['corresponding-source-record.json']=p/'distribution-sources-v2/result.json'
files['LICENSES/SRAM-original-LICENSE.md']=p.parent/'sram-alternative-research/ihp-dev-sram/LICENSE.md'
for folder in ['replay-relocation-check-v3','replay-relocation-check-v3/valid','replay-include-guard-v3','replay-budget-guard-v3','replay-budget-guard-v3/valid-override']:
 for name in ['result.json','valid.log','changed-input.log','run.log','zero.log','excessive.log','valid-override.log']:
  f=p/folder/name
  if f.is_file():files['checks/'+folder+'/'+name]=f
pins={n:sha(f)for n,f in files.items()}
archive=out/'replay-inputs-v3.tar.xz'
with tarfile.open(archive,'w:xz',preset=9|lzma.PRESET_EXTREME)as tar:
 for n,f in sorted(files.items()):tar.add(f,arcname=n)
with tarfile.open(archive)as tar:
 assert len(tar.getmembers())==len(files)
 for n,h in pins.items():
  with tar.extractfile(n)as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==h==sha(files[n]),n
record={'status':'PASS_LOSSLESS_REPLAY_INPUT_ARCHIVE_HEADER_CHECKS_ONLY','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':pins,'resource_controls':budget,'full_route_replay':False,'lvs_acceptance':False,'timing_acceptance':False}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['status'],record['archive_bytes'])
