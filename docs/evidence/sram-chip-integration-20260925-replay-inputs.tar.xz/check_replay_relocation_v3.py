"""Check a relocated bundle and reject a changed SRAM interface before tools run."""
from pathlib import Path
import shutil,json,hashlib,subprocess,sys,time
r=Path.cwd();p=Path(__file__).resolve().parent
source=p/'replay-inputs-v3';clone=p/'replay relocation inputs v3';out=p/'replay-relocation-check-v3';out.mkdir(exist_ok=False);shutil.copytree(source,clone)
app=r/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage';pdk=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2')
def sha(f):
 with Path(f).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
manifest=json.loads((source/'manifest.json').read_text());expected={name:sha(source/name)for name in manifest['bundle_sha256']}
command=[sys.executable,str(clone/'replay.py'),'--app',str(app),'--pdk',str(pdk),'--output',str(out/'valid'),'--validate-header']
start=time.monotonic()
with (out/'valid.log').open('x')as log:q=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert q.returncode==0 and json.loads((out/'valid/result.json').read_text())['status']=='PASS_HEADER_VALIDATION_ONLY'
config=json.loads((out/'valid/config.json').read_text())
assert str(clone)in json.dumps(config) and str(source)not in json.dumps(config)

def all_paths(value):
 if isinstance(value,dict):
  for item in value.values():yield from all_paths(item)
 elif isinstance(value,list):
  for item in value:yield from all_paths(item)
 elif isinstance(value,str)and value.startswith('/'):yield Path(value)
paths=list(all_paths(config))+list(all_paths(json.loads((out/'valid/state.json').read_text())))
assert len(paths)>10 and len(config['VERILOG_INCLUDE_DIRS'])==2
assert all(f.resolve(strict=True).is_relative_to(clone.resolve())for f in paths)

model=next(clone/name for name in expected if name.endswith('/independent_bb.v'));before=sha(model);text=model.read_text();assert '[8:0]a'in text;model.write_text(text.replace('[8:0]a','[7:0]a',1));after=sha(model);assert before!=after
wrong=[*command];wrong[wrong.index('--output')+1]=str(out/'changed-input')
with (out/'changed-input.log').open('x')as log:bad=subprocess.run(wrong,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert bad.returncode==2 and not (out/'changed-input').exists()
assert 'Changed or escaped dependency'in(out/'changed-input.log').read_text()
for name,h in expected.items():assert sha(source/name)==h,name
record={'status':'PASS_RELOCATED_HEADER_AND_CHANGED_ADDRESS_WIDTH_REJECTED','elapsed_seconds':time.monotonic()-start,'valid_command':command,'negative_command':wrong,'valid_returncode':q.returncode,'negative_returncode':bad.returncode,'mutation':{'file':str(model),'before_sha256':before,'after_sha256':after,'original':'[8:0]a','replacement':'[7:0]a'},'source_bundle_manifest_sha256':sha(source/'manifest.json'),'source_bundle_unchanged':True,'all_resolved_design_paths_inside_relocated_bundle':True,'resolved_design_path_count':len(paths),'include_directory_count':len(config['VERILOG_INCLUDE_DIRS']),'scope':__doc__+' Header/configuration replay only; no routing, timing or LVS acceptance.'}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'])
