# Exact 32-SRAM connectivity replay inputs

This package starts a fresh physical run from the mapped `soc_top` netlist.
It preserves the original 20 ns core and 8 ns Ethernet clock constraints,
0.95/1.05 derates, die, macro placement, power recipe and diode-only antenna
repair configuration. The two Verilog include directories are also copied and hash-pinned; no resolved
design path points to the original checkout. It contains sixteen 512x64 single-port memories and
sixteen 256x16 dual-port memories. No characterized SRAM Liberty is supplied.
This is a connectivity implementation flow, not final timing qualification.

Install the separately supplied, pinned LibreLane 3.0.5 Linux AppImage and
IHP SG13G2 PDK c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c. The launcher checks
actual file hashes, including all 26 PDK files listed in the manifest.
It does not download tools, modify the PDK, or overwrite an existing run.

From the extracted archive:

```sh
python3 replay-inputs-v3/replay.py --app /absolute/path/to/librelane.AppImage \
  --pdk /absolute/path/to/ihp-sg13g2 --output /new/output/path --validate-header
```

Use `--run` instead of `--validate-header` for placement and routing in another
new output path. Omit both flags to generate the command and resolved inputs
without executing tools. The launcher limits the process to 12 GiB address
space and eight hours by default. Use `--wall-seconds N` to select an explicit
300..43200-second physical-run budget; the receipt records it. Header-only
validation is limited to 300 seconds. Sufficient local memory and disk space are required.

The bundled checks validate configuration/header generation after relocation,
including a directory containing spaces, and reject a changed SRAM address
width or copied include source before tool execution. They do not constitute a second full physical
run or a transistor LVS result. A completed route must undergo full transistor
LVS using the unchanged foundry deck and independent complete memory CDLs,
final power checks, and mapped-to-routed logic verification. DRC/density and
qualified timing are separate acceptance gates.

See NOTICES.txt and LICENSES for source licensing. All generated artifacts
retain their source identities in manifest.json. The recorded absolute source
paths are provenance only; the launcher resolves its design inputs locally.
