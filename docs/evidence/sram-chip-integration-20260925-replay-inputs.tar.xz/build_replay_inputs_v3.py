"""Export byte-identical design dependencies and a relocatable fresh-run profile."""
from pathlib import Path
import hashlib,json,shutil,re,glob
r=Path.cwd();p=Path(__file__).resolve().parent;c=p.parent
out=p/'replay-inputs-v3';out.mkdir(exist_ok=False);(out/'flow').mkdir()
def sha(f):
 with Path(f).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
original=json.loads((p/'physical-controller-v5/config.json').read_text())
resolved=json.loads((p/'pnr-v5/resolved.json').read_text())
pdk=Path(resolved['PDK_ROOT'])/resolved['PDK']
inputs={};reverse={};directories={}
def add_directory(source):
 source=Path(source).resolve(strict=True);assert source.is_relative_to(r)
 name="include-dirs/"+hashlib.sha256(str(source).encode()).hexdigest()[:16]
 target=out/name;target.mkdir(parents=True,exist_ok=False)
 for f in sorted(source.rglob("*")):
  assert not f.is_symlink(),f
  if f.is_file():
   destination=target/f.relative_to(source);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,destination);assert sha(destination)==sha(f)
 directories[str(source)]=name;reverse[name]=str(source)
 return name
def add(source):
 source=Path(source).resolve(strict=True);assert source.is_relative_to(r)
 if str(source)in inputs:return inputs[str(source)]['bundle_path']
 group=hashlib.sha256(str(source.parent).encode()).hexdigest()[:16]
 name='inputs/'+group+'/'+source.name;target=out/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 h=sha(source);assert sha(target)==h;inputs[str(source)]={'bundle_path':name,'sha256':h};reverse[name]=str(source)
 if source.suffix=='.sdc':
  for sibling in re.findall(r'source\s+\[file join \[file dirname \[info script\]\] ([A-Za-z0-9_.-]+)\]',source.read_text()):add(source.parent/sibling)
 return name
def convert(value):
 if isinstance(value,dict):return {k:convert(v)for k,v in value.items()}
 if isinstance(value,list):return [convert(v)for v in value]
 if isinstance(value,str)and value.startswith('/'):
  if Path(value).is_file():return '@file:'+add(value)
  if Path(value).is_dir():return '@dir:'+add_directory(value)
  raise ValueError('Unresolved absolute configuration path: '+value)
 return value
def restore(value):
 if isinstance(value,dict):return {k:restore(v)for k,v in value.items()}
 if isinstance(value,list):return [restore(v)for v in value]
 if isinstance(value,str)and value.startswith('@file:'):return reverse[value[6:]]
 if isinstance(value,str)and value.startswith('@dir:'):return reverse[value[5:]]
 return value
config=convert(original);assert restore(config)==original
state=convert({'nl':str(p/'synthesis-v3/soc_top.netlist.v'),'metrics':{}})
for name,value in [('config',config),('state',state)]: (out/(name+'-template.json')).write_text(json.dumps(value,indent=2)+'\n')
for source in [p/'connectivity_flow.py',p/'connectivity_power_flow.py',c/'bounded_process.py']:shutil.copy2(source,out/'flow'/source.name)
shutil.copy2(p/'replay_launcher_template_v3.py',out/'replay.py')
pdk_files=set()
def collect(value):
 if isinstance(value,dict):
  for v in value.values():collect(v)
 elif isinstance(value,list):
  for v in value:collect(v)
 elif isinstance(value,str)and value.startswith(str(pdk)+'/'):
  for name in glob.glob(value):
   f=Path(name).resolve()
   if f.is_file()and f.is_relative_to(pdk):pdk_files.add(f)
collect(resolved)
for rel in ['libs.ref/sg13g2_stdcell/cdl/sg13g2_stdcell.cdl','libs.ref/sg13g2_stdcell/verilog/sg13g2_stdcell.v']:pdk_files.add(pdk/rel)
assert len(pdk_files)>10
app=r/'hw/soc/tools/physical/librelane-3.0.5-x86_64.AppImage'
manifest={'status':'EXPORTED_REQUIRES_REPLAY_VALIDATION','scope':__doc__,'original_config_sha256':sha(p/'physical-controller-v5/config.json'),'restored_config_identical':True,'design_inputs':inputs,'directory_inputs':directories,'directory_paths':sorted(directories.values()),'app_sha256':sha(app),'pdk_sha256':{str(f.relative_to(pdk)):sha(f)for f in sorted(pdk_files)},'bundle_sha256':{str(f.relative_to(out)):sha(f)for f in sorted(out.rglob('*'))if f.is_file()},'limitations':['Fresh run from actual mapped32-SRAM netlist; no original failed or partial GDS is reused.','Original clocks, die, core, macro placements and diode-only antenna repair configuration retained.','No SRAM Liberty or timing/production acceptance. Header-only validation is not placement/routing or LVS verification.']}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(inputs),'design file dependencies;',len(directories),'directory dependencies;',len(pdk_files),'PDK files pinned')
