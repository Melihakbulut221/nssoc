`timescale 1ns/1ps
module head_control;
reg [63:0] memory;reg [3:0] parity;reg [1:0] address;
integer i,j,k;reg [15:0] expected;reg expected_par;
wire w0,w1,w2,w3,w4,w5,w6,w7,w8,w9,w10,w11,w12,w13,w14,w15,w16,w17,w18,w19,w20,w21,w22,w23,w24,w25,w26,w27,w28,w29,w30,w31,w32,w33,w34,w35,w36,w37,w38,w39,w40,w41,w42,w43,w44,w45,w46,w47,w48,w49,w50,w51,w52,w53,w54,w55,w56,w57,w58,w59,w60,w61,w62,w63,w64,w65,w66,w67,w68,w69,w70,w71,w72,w73;
sg13g2_and2_1 _077268_ (.A(address[0]),.B(address[1]),.X(w1));
sg13g2_buf_1 _077269_ (.A(w1),.X(w2));
sg13g2_nor2b_1 _077270_ (.A(address[1]),.B_N(address[0]),.Y(w3));
sg13g2_a22oi_1 _077271_ (.A1(memory[60]),.A2(w2),.B1(w3),.B2(memory[28]),.Y(w4));
sg13g2_nor2_1 _077272_ (.A(address[0]),.B(address[1]),.Y(w5));
sg13g2_nor2b_1 _077273_ (.A(address[0]),.B_N(address[1]),.Y(w6));
sg13g2_a22oi_1 _077274_ (.A1(memory[12]),.A2(w5),.B1(w6),.B2(memory[44]),.Y(w7));
sg13g2_nand2_1 _077275_ (.A(w4),.B(w7),.Y(w8));
sg13g2_buf_1 _077276_ (.A(w2),.X(w9));
sg13g2_buf_1 _077277_ (.A(w3),.X(w10));
sg13g2_a22oi_1 _077278_ (.A1(memory[61]),.A2(w9),.B1(w10),.B2(memory[29]),.Y(w11));
sg13g2_buf_1 _077279_ (.A(w5),.X(w12));
sg13g2_a22oi_1 _077280_ (.A1(memory[13]),.A2(w12),.B1(w6),.B2(memory[45]),.Y(w13));
sg13g2_nand2_1 _077281_ (.A(w11),.B(w13),.Y(w14));
sg13g2_xor2_1 _077282_ (.A(w8),.B(w14),.X(w15));
sg13g2_buf_1 _077283_ (.A(w6),.X(w16));
sg13g2_a22oi_1 _077284_ (.A1(memory[62]),.A2(w2),.B1(w16),.B2(memory[46]),.Y(w17));
sg13g2_a22oi_1 _077285_ (.A1(memory[14]),.A2(w5),.B1(w3),.B2(memory[30]),.Y(w18));
sg13g2_nand2_1 _077286_ (.A(w17),.B(w18),.Y(w19));
sg13g2_a22oi_1 _077287_ (.A1(memory[15]),.A2(w12),.B1(w10),.B2(memory[31]),.Y(w20));
sg13g2_a22oi_1 _077288_ (.A1(memory[63]),.A2(w2),.B1(w16),.B2(memory[47]),.Y(w21));
sg13g2_nand2_1 _077289_ (.A(w20),.B(w21),.Y(w22));
sg13g2_xor2_1 _077290_ (.A(w19),.B(w22),.X(w23));
sg13g2_xnor2_1 _077291_ (.A(w15),.B(w23),.Y(w24));
sg13g2_a22oi_1 _077292_ (.A1(memory[27]),.A2(w10),.B1(w16),.B2(memory[43]),.Y(w25));
sg13g2_a22oi_1 _077293_ (.A1(memory[59]),.A2(w2),.B1(w12),.B2(memory[11]),.Y(w26));
sg13g2_nand2_1 _077294_ (.A(w25),.B(w26),.Y(w27));
sg13g2_a22oi_1 _077295_ (.A1(memory[58]),.A2(w9),.B1(w10),.B2(memory[26]),.Y(w28));
sg13g2_a22oi_1 _077296_ (.A1(memory[10]),.A2(w12),.B1(w16),.B2(memory[42]),.Y(w29));
sg13g2_nand2_1 _077297_ (.A(w28),.B(w29),.Y(w30));
sg13g2_xnor2_1 _077298_ (.A(w27),.B(w30),.Y(w31));
sg13g2_a22oi_1 _077299_ (.A1(memory[9]),.A2(w12),.B1(w10),.B2(memory[25]),.Y(w32));
sg13g2_a22oi_1 _077300_ (.A1(memory[57]),.A2(w9),.B1(w16),.B2(memory[41]),.Y(w33));
sg13g2_nand2_1 _077301_ (.A(w32),.B(w33),.Y(w34));
sg13g2_a22oi_1 _077302_ (.A1(memory[8]),.A2(w12),.B1(w10),.B2(memory[24]),.Y(w35));
sg13g2_a22oi_1 _077303_ (.A1(memory[56]),.A2(w9),.B1(w16),.B2(memory[40]),.Y(w36));
sg13g2_nand2_1 _077304_ (.A(w35),.B(w36),.Y(w37));
sg13g2_xnor2_1 _077305_ (.A(w34),.B(w37),.Y(w38));
sg13g2_xnor2_1 _077306_ (.A(w31),.B(w38),.Y(w39));
sg13g2_xnor2_1 _077307_ (.A(w24),.B(w39),.Y(w40));
sg13g2_a22oi_1 _077308_ (.A1(memory[52]),.A2(w2),.B1(w5),.B2(memory[4]),.Y(w41));
sg13g2_a22oi_1 _077309_ (.A1(memory[20]),.A2(w3),.B1(w6),.B2(memory[36]),.Y(w42));
sg13g2_nand2_1 _077310_ (.A(w41),.B(w42),.Y(w43));
sg13g2_a22oi_1 _077311_ (.A1(memory[5]),.A2(w5),.B1(w6),.B2(memory[37]),.Y(w44));
sg13g2_a22oi_1 _077312_ (.A1(memory[53]),.A2(w2),.B1(w3),.B2(memory[21]),.Y(w45));
sg13g2_nand2_1 _077313_ (.A(w44),.B(w45),.Y(w46));
sg13g2_xor2_1 _077314_ (.A(w43),.B(w46),.X(w47));
sg13g2_a22oi_1 _077315_ (.A1(memory[48]),.A2(w2),.B1(w5),.B2(memory[0]),.Y(w48));
sg13g2_a22oi_1 _077316_ (.A1(memory[16]),.A2(w3),.B1(w6),.B2(memory[32]),.Y(w49));
sg13g2_nand2_1 _077317_ (.A(w48),.B(w49),.Y(w50));
sg13g2_a22oi_1 _077318_ (.A1(memory[17]),.A2(w3),.B1(w6),.B2(memory[33]),.Y(w51));
sg13g2_a22oi_1 _077319_ (.A1(memory[49]),.A2(w2),.B1(w5),.B2(memory[1]),.Y(w52));
sg13g2_nand2_1 _077320_ (.A(w51),.B(w52),.Y(w53));
sg13g2_xnor2_1 _077321_ (.A(w50),.B(w53),.Y(w54));
sg13g2_xnor2_1 _077322_ (.A(w47),.B(w54),.Y(w55));
sg13g2_a22oi_1 _077323_ (.A1(memory[6]),.A2(w12),.B1(w16),.B2(memory[38]),.Y(w56));
sg13g2_a22oi_1 _077324_ (.A1(memory[54]),.A2(w9),.B1(w10),.B2(memory[22]),.Y(w57));
sg13g2_nand2_1 _077325_ (.A(w56),.B(w57),.Y(w58));
sg13g2_xnor2_1 _077326_ (.A(w55),.B(w58),.Y(w59));
sg13g2_a22oi_1 _077327_ (.A1(memory[7]),.A2(w12),.B1(w16),.B2(memory[39]),.Y(w60));
sg13g2_a22oi_1 _077328_ (.A1(memory[55]),.A2(w9),.B1(w10),.B2(memory[23]),.Y(w61));
sg13g2_nand2_1 _077329_ (.A(w60),.B(w61),.Y(w62));
sg13g2_xnor2_1 _077330_ (.A(w0),.B(w62),.Y(w63));
sg13g2_a22oi_1 _077331_ (.A1(memory[50]),.A2(w9),.B1(w10),.B2(memory[18]),.Y(w64));
sg13g2_a22oi_1 _077332_ (.A1(memory[2]),.A2(w12),.B1(w16),.B2(memory[34]),.Y(w65));
sg13g2_nand2_1 _077333_ (.A(w64),.B(w65),.Y(w66));
sg13g2_a22oi_1 _077334_ (.A1(memory[51]),.A2(w9),.B1(w10),.B2(memory[19]),.Y(w67));
sg13g2_a22oi_1 _077335_ (.A1(memory[3]),.A2(w12),.B1(w16),.B2(memory[35]),.Y(w68));
sg13g2_nand2_1 _077336_ (.A(w67),.B(w68),.Y(w69));
sg13g2_xor2_1 _077337_ (.A(w66),.B(w69),.X(w70));
sg13g2_xnor2_1 _077338_ (.A(w63),.B(w70),.Y(w71));
sg13g2_xnor2_1 _077339_ (.A(w59),.B(w71),.Y(w72));
sg13g2_xnor2_1 _077340_ (.A(w40),.B(w72),.Y(w73));
sg13g2_mux4_1 _136725_ (.A0(parity[0]),.A1(parity[1]),.A2(parity[2]),.A3(parity[3]),.S0(address[0]),.S1(address[1]),.X(w0));
wire [15:0] observed={w22,w19,w14,w8,w27,w30,w34,w37,w62,w58,w46,w43,w69,w66,w53,w50};
wire observed_par=w0;
wire observed_bad=w73;
task check;
begin #1; expected=memory[address*16+:16];expected_par=parity[address];
if(observed!==expected || observed_par!==expected_par || observed_bad!==(^{expected_par,expected}))
$fatal(1,"Mapped head/parity labels differ i=%0d address=%b",i,address);
end endtask
initial begin
for(i=0;i<256;i=i+1)begin
memory={16'h1234,16'habcd,16'h2468,16'h1357} ^ (64'h0101010101010101*i);
parity=i;for(j=0;j<4;j=j+1)begin address=j;check;end
end
// Unknown stored data is observed only when selected; no X-to-zero oracle.
for(k=0;k<64;k=k+1)begin
memory=64'h0123456789abcdef;memory[k]=1'bx;parity=4'b1010;
for(j=0;j<4;j=j+1)begin address=j;check;end
end
for(k=0;k<4;k=k+1)begin
memory=64'h0123456789abcdef;parity=4'b1010;parity[k]=1'bx;
for(j=0;j<4;j=j+1)begin address=j;check;end
end
$display("EVQ_HEAD_NATIVE_PASS checks=1296");$finish;
end
endmodule
