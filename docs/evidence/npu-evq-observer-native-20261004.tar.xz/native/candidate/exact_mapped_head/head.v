`timescale 1ns/1ps
module head_control;
reg [63:0] memory;reg [3:0] parity;reg [1:0] address;
integer i,j,k;reg [15:0] expected;reg expected_par;
wire w0,w1,w2,w3,w4,w5,w6,w7,w8,w9,w10,w11,w12,w13,w14,w15,w16,w17,w18,w19,w20,w21,w22,w23,w24,w25,w26,w27,w28,w29,w30,w31,w32,w33,w34,w35,w36,w37,w38,w39,w40,w41,w42,w43,w44,w45,w46,w47,w48,w49,w50,w51,w52,w53,w54,w55,w56,w57,w58,w59,w60,w61,w62,w63,w64,w65,w66,w67,w68,w69,w70,w71,w72,w73;
sg13g2_nor2b_1 _079173_ (.A(address[0]),.B_N(address[1]),.Y(w1));
sg13g2_buf_1 _079174_ (.A(w1),.X(w2));
sg13g2_nor2b_1 _079175_ (.A(address[1]),.B_N(address[0]),.Y(w3));
sg13g2_buf_1 _079176_ (.A(w3),.X(w4));
sg13g2_a22oi_1 _079177_ (.A1(memory[40]),.A2(w2),.B1(w4),.B2(memory[24]),.Y(w5));
sg13g2_nor2_1 _079178_ (.A(address[0]),.B(address[1]),.Y(w6));
sg13g2_and2_1 _079179_ (.A(address[0]),.B(address[1]),.X(w7));
sg13g2_buf_1 _079180_ (.A(w7),.X(w8));
sg13g2_a22oi_1 _079181_ (.A1(memory[8]),.A2(w6),.B1(w8),.B2(memory[56]),.Y(w9));
sg13g2_nand2_1 _079182_ (.A(w5),.B(w9),.Y(w10));
sg13g2_a22oi_1 _079183_ (.A1(memory[41]),.A2(w2),.B1(w4),.B2(memory[25]),.Y(w11));
sg13g2_buf_1 _079184_ (.A(w6),.X(w12));
sg13g2_buf_1 _079185_ (.A(w8),.X(w13));
sg13g2_a22oi_1 _079186_ (.A1(memory[9]),.A2(w12),.B1(w13),.B2(memory[57]),.Y(w14));
sg13g2_nand2_1 _079187_ (.A(w11),.B(w14),.Y(w15));
sg13g2_xnor2_1 _079188_ (.A(w10),.B(w15),.Y(w16));
sg13g2_a22oi_1 _079189_ (.A1(memory[26]),.A2(w4),.B1(w12),.B2(memory[10]),.Y(w17));
sg13g2_a22oi_1 _079190_ (.A1(memory[42]),.A2(w1),.B1(w8),.B2(memory[58]),.Y(w18));
sg13g2_nand2_1 _079191_ (.A(w17),.B(w18),.Y(w19));
sg13g2_a22oi_1 _079192_ (.A1(memory[11]),.A2(w12),.B1(w13),.B2(memory[59]),.Y(w20));
sg13g2_a22oi_1 _079193_ (.A1(memory[43]),.A2(w2),.B1(w4),.B2(memory[27]),.Y(w21));
sg13g2_nand2_1 _079194_ (.A(w20),.B(w21),.Y(w22));
sg13g2_xnor2_1 _079195_ (.A(w19),.B(w22),.Y(w23));
sg13g2_xnor2_1 _079196_ (.A(w16),.B(w23),.Y(w24));
sg13g2_a22oi_1 _079197_ (.A1(memory[37]),.A2(w2),.B1(w4),.B2(memory[21]),.Y(w25));
sg13g2_a22oi_1 _079198_ (.A1(memory[5]),.A2(w12),.B1(w13),.B2(memory[53]),.Y(w26));
sg13g2_nand2_1 _079199_ (.A(w25),.B(w26),.Y(w27));
sg13g2_a22oi_1 _079200_ (.A1(memory[20]),.A2(w4),.B1(w12),.B2(memory[4]),.Y(w28));
sg13g2_a22oi_1 _079201_ (.A1(memory[36]),.A2(w2),.B1(w13),.B2(memory[52]),.Y(w29));
sg13g2_nand2_1 _079202_ (.A(w28),.B(w29),.Y(w30));
sg13g2_xor2_1 _079203_ (.A(w27),.B(w30),.X(w31));
sg13g2_xnor2_1 _079204_ (.A(w24),.B(w31),.Y(w32));
sg13g2_a22oi_1 _079205_ (.A1(memory[32]),.A2(w2),.B1(w12),.B2(memory[0]),.Y(w33));
sg13g2_a22oi_1 _079206_ (.A1(memory[16]),.A2(w3),.B1(w8),.B2(memory[48]),.Y(w34));
sg13g2_nand2_1 _079207_ (.A(w33),.B(w34),.Y(w35));
sg13g2_a22oi_1 _079208_ (.A1(memory[33]),.A2(w2),.B1(w12),.B2(memory[1]),.Y(w36));
sg13g2_a22oi_1 _079209_ (.A1(memory[17]),.A2(w4),.B1(w13),.B2(memory[49]),.Y(w37));
sg13g2_nand2_1 _079210_ (.A(w36),.B(w37),.Y(w38));
sg13g2_xnor2_1 _079211_ (.A(w35),.B(w38),.Y(w39));
sg13g2_a22oi_1 _079212_ (.A1(memory[34]),.A2(w2),.B1(w4),.B2(memory[18]),.Y(w40));
sg13g2_a22oi_1 _079213_ (.A1(memory[2]),.A2(w12),.B1(w13),.B2(memory[50]),.Y(w41));
sg13g2_nand2_1 _079214_ (.A(w40),.B(w41),.Y(w42));
sg13g2_a22oi_1 _079215_ (.A1(memory[19]),.A2(w4),.B1(w13),.B2(memory[51]),.Y(w43));
sg13g2_a22oi_1 _079216_ (.A1(memory[35]),.A2(w2),.B1(w12),.B2(memory[3]),.Y(w44));
sg13g2_nand2_1 _079217_ (.A(w43),.B(w44),.Y(w45));
sg13g2_xnor2_1 _079218_ (.A(w42),.B(w45),.Y(w46));
sg13g2_xnor2_1 _079219_ (.A(w39),.B(w46),.Y(w47));
sg13g2_a22oi_1 _079220_ (.A1(memory[46]),.A2(w1),.B1(w8),.B2(memory[62]),.Y(w48));
sg13g2_a22oi_1 _079221_ (.A1(memory[30]),.A2(w3),.B1(w6),.B2(memory[14]),.Y(w49));
sg13g2_nand2_1 _079222_ (.A(w48),.B(w49),.Y(w50));
sg13g2_a22oi_1 _079223_ (.A1(memory[31]),.A2(w3),.B1(w8),.B2(memory[63]),.Y(w51));
sg13g2_a22oi_1 _079224_ (.A1(memory[47]),.A2(w1),.B1(w6),.B2(memory[15]),.Y(w52));
sg13g2_nand2_1 _079225_ (.A(w51),.B(w52),.Y(w53));
sg13g2_xnor2_1 _079226_ (.A(w50),.B(w53),.Y(w54));
sg13g2_a22oi_1 _079227_ (.A1(memory[45]),.A2(w1),.B1(w3),.B2(memory[29]),.Y(w55));
sg13g2_a22oi_1 _079228_ (.A1(memory[13]),.A2(w6),.B1(w8),.B2(memory[61]),.Y(w56));
sg13g2_nand2_1 _079229_ (.A(w55),.B(w56),.Y(w57));
sg13g2_a22oi_1 _079230_ (.A1(memory[44]),.A2(w1),.B1(w8),.B2(memory[60]),.Y(w58));
sg13g2_a22oi_1 _079231_ (.A1(memory[28]),.A2(w3),.B1(w6),.B2(memory[12]),.Y(w59));
sg13g2_nand2_1 _079232_ (.A(w58),.B(w59),.Y(w60));
sg13g2_xnor2_1 _079233_ (.A(w57),.B(w60),.Y(w61));
sg13g2_xnor2_1 _079234_ (.A(w54),.B(w61),.Y(w62));
sg13g2_a22oi_1 _079235_ (.A1(memory[23]),.A2(w4),.B1(w12),.B2(memory[7]),.Y(w63));
sg13g2_a22oi_1 _079236_ (.A1(memory[39]),.A2(w2),.B1(w13),.B2(memory[55]),.Y(w64));
sg13g2_nand2_1 _079237_ (.A(w63),.B(w64),.Y(w65));
sg13g2_a22oi_1 _079238_ (.A1(memory[38]),.A2(w1),.B1(w3),.B2(memory[22]),.Y(w66));
sg13g2_a22oi_1 _079239_ (.A1(memory[6]),.A2(w6),.B1(w8),.B2(memory[54]),.Y(w67));
sg13g2_nand2_1 _079240_ (.A(w66),.B(w67),.Y(w68));
sg13g2_xor2_1 _079241_ (.A(w0),.B(w68),.X(w69));
sg13g2_xnor2_1 _079242_ (.A(w65),.B(w69),.Y(w70));
sg13g2_xnor2_1 _079243_ (.A(w62),.B(w70),.Y(w71));
sg13g2_xnor2_1 _079244_ (.A(w47),.B(w71),.Y(w72));
sg13g2_xnor2_1 _079245_ (.A(w32),.B(w72),.Y(w73));
sg13g2_mux4_1 _137323_ (.A0(parity[0]),.A1(parity[1]),.A2(parity[2]),.A3(parity[3]),.S0(address[0]),.S1(address[1]),.X(w0));
wire [15:0] observed={w53,w50,w57,w60,w22,w19,w15,w10,w65,w68,w27,w30,w45,w42,w38,w35};
wire observed_par=w0;
wire observed_bad=w73;
task check;
begin #1; expected=memory[address*16+:16];expected_par=parity[address];
if(observed!==expected || observed_par!==expected_par || observed_bad!==(^{expected_par,expected}))
$fatal(1,"Mapped head/parity labels differ i=%0d address=%b",i,address);
end endtask
initial begin
for(i=0;i<256;i=i+1)begin
memory={16'h1234,16'habcd,16'h2468,16'h1357} ^ (64'h0101010101010101*i);
parity=i;for(j=0;j<4;j=j+1)begin address=j;check;end
end
// Unknown stored data is observed only when selected; no X-to-zero oracle.
for(k=0;k<64;k=k+1)begin
memory=64'h0123456789abcdef;memory[k]=1'bx;parity=4'b1010;
for(j=0;j<4;j=j+1)begin address=j;check;end
end
for(k=0;k<4;k=k+1)begin
memory=64'h0123456789abcdef;parity=4'b1010;parity[k]=1'bx;
for(j=0;j<4;j=j+1)begin address=j;check;end
end
$display("EVQ_HEAD_NATIVE_PASS checks=1296");$finish;
end
endmodule
