from pathlib import Path
import klayout.db as db
import sys,re,json
root=Path.cwd();sys.path.insert(0,str(root/'hw/soc/flow'));from transistor_schematic import read_cdl
pdk=Path('/home/hasanmelih/.ciel/ihp-sg13g2');name='RM_IHPSG13_2P_256x16_c2_bm_bist';l=db.Layout();l.read(str(pdk/f'libs.ref/sg13g2_sram/gds/{name}.gds'));defs,_=read_cdl([pdk/f'libs.ref/sg13g2_sram/cdl/{name}.cdl']);rows=[]
for cell in l.each_cell():
 for layer in [10,30]:
  shapes=[s for s in cell.shapes(l.layer(layer,29)).each() if not s.is_text()]
  if shapes:rows.append({'cell':cell.name,'layer':layer,'markers':len(shapes),'marker_boxes':[str(s.bbox()) for s in shapes[:4]],'cdl_resistors':[line for line in re.sub(r'\n\s*\+\s*',' ',defs.get(cell.name,'')).splitlines() if line.upper().startswith('R')][:4]})
c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';(c/'resistor-cell-inventory.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
