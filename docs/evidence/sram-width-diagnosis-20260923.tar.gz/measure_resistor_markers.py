from pathlib import Path
import klayout.db as db
from collections import Counter
import hashlib,json
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';p=Path('/home/hasanmelih/.ciel/ihp-sg13g2/libs.ref/sg13g2_sram/gds/RM_IHPSG13_2P_256x16_c2_bm_bist.gds').resolve();l=db.Layout();l.read(str(p));top=l.top_cell();rows={}
def summary(region):
 counts=Counter();nonrect=0
 for poly in region.each():
  b=poly.bbox();counts[tuple(sorted((round(b.width()*l.dbu,6),round(b.height()*l.dbu,6))))]+=1
  nonrect += poly.area()!=b.area()
 return {'polygons':sum(counts.values()),'nonrectangular':nonrect,'bbox_dimensions_um':[{'sides_um':list(d),'count':n} for d,n in sorted(counts.items())]}
for metal,layer in [('Metal1',8),('Metal2',10),('Metal3',30)]:
 markers=db.Region(top.begin_shapes_rec(l.layer(layer,29)));wires=db.Region(top.begin_shapes_rec(l.layer(layer,0)));markers.merge();wires.merge();body=markers&wires
 rows[metal]={'layer':layer,'markers':summary(markers),'metal_intersection':summary(body)}
r={'scope':'Original macro marker polygons versus their intersection with drawing metal; geometry measurement, not extraction acceptance. No source edits.','gds':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'dbu':l.dbu,'layers':rows};(c/'sram-resistor-markers.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
