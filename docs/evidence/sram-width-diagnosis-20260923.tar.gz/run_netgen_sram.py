from pathlib import Path
import json,hashlib,subprocess,time,resource
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';out=c/'sram256-netgen-control';out.mkdir(exist_ok=False);b=c/'sram256-port-seeded';layout=b/'extracted.cir.before-compare.cir';reference=b/'extracted.cir.reference.cir';setup=Path('/home/hasanmelih/.ciel/ihp-sg13g2/libs.tech/netgen/ihp-sg13g2_setup.tcl').resolve();name='RM_IHPSG13_2P_256x16_c2_bm_bist'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
cmd=['netgen','-batch','lvs',str(layout)+' '+name,str(reference)+' '+name.upper(),str(setup),str(out/'compare.log'),'-json'];inputs={str(p):sha(p) for p in [layout,reference,setup]};start=time.monotonic()
def limit():resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
with (out/'run.log').open('w') as f:
 try:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=180,preexec_fn=limit,cwd=out).returncode
 except subprocess.TimeoutExpired:rc=124
r=dict(scope='Independent comparison-engine diagnostic of KLayout experimental extracted and reference graphs; original Netgen PDK setup unchanged. No blackbox flag. Not independent extraction or foundry acceptance.',command=cmd,returncode=rc,elapsed_s=time.monotonic()-start,inputs=inputs,inputs_unchanged=all(sha(Path(p))==h for p,h in inputs.items()));(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(r['returncode'],r['elapsed_s'],r['inputs_unchanged'])
