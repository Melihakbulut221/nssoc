from pathlib import Path
import json,hashlib,shutil,subprocess,time,resource,sys
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';out=c/'lvsres-dimension-controls';out.mkdir(exist_ok=False)
up=c/'sram256-wldrv-flatten/deck';deck=out/'deck';shutil.copytree(up,deck)
p=deck/'rule_decks/custom_reader.lvs';s=p.read_text();anchor='    model.downcase\n  end\n';assert s.count(anchor)==1;s=s.replace(anchor,'    # IHP LVS device documentation identifies legacy lvsres as Metal1.\n    model.downcase == "lvsres" ? "res_metal1" : model.downcase\n  end\n')
anchor="    elsif num_nets == 2 && model.downcase.include?('tap')";assert s.count(anchor)==1;s=s.replace(anchor,"    elsif num_nets == 2 && model.downcase == 'res_metal1'\n      RES2.new\n"+anchor);p.write_text(s)
# Preserve exact vendor primitive geometry/CDL for the positive arm.
src=root/'hw/soc/out/external-review-20260919/sram-dummy-repro';print(list(src.glob('*')),flush=True)
import klayout.db as db
l=db.Layout();l.read(str(src/'dummy.gds'));cell=l.top_cell();top=l.create_cell('DUMMY_TOP');top.insert(db.CellInstArray(cell.cell_index(),db.Trans()));l.write(str(out/'dummy-parent.gds'))
ref=(src/'dummy.cdl').read_text()+'\n.SUBCKT DUMMY_TOP A Z VDD! VSS!\nX0 A Z VDD! VSS! RSC_IHPSG13_CDLYX1_DUMMY\n.ENDS DUMMY_TOP\n'
refs={'positive':ref,'wrong-width':ref.replace('w=2.6e-07','w=5.2e-07'),'wrong-length':ref.replace('l=6e-07','l=1.2e-06'),'missing-resistor':'\n'.join(x for x in ref.splitlines() if not x.startswith('R0 '))+'\n'}
assert len(set(refs.values()))==4
results=[]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def limit():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
for tag,reference in refs.items():
 d=out/tag;d.mkdir();cdl=d/'reference.cdl';cdl.write_text(reference)
 flags=dict(input=str(out/'dummy-parent.gds'),schematic=str(cdl),topcell='DUMMY_TOP',run_mode='deep',report=str(d/'report.lvsdb'),log=str(d/'deck.log'),target_netlist=str(d/'extracted.cir'))
 for k in ['no_net_names','spice_comments','net_only','top_lvl_pins','no_simplify','no_series_res','no_parallel_res','combine_devices','purge','purge_nets','verbose','ignore_top_ports_mismatch','disable_tap_extraction','purge_devices']:flags[k]='false'
 cmd=['klayout','-b','-zz','-r',str(deck/'sg13g2.lvs')]
 for k,v in flags.items():cmd+=['-rd',k+'='+v]
 inputs={str(p):sha(p) for p in [out/'dummy-parent.gds',cdl,*sorted(deck.rglob('*.lvs'))]};start=time.monotonic()
 with (d/'run.log').open('w') as f:
  try:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=limit,timeout=90).returncode
  except subprocess.TimeoutExpired:rc=124
 r=dict(case=tag,command=cmd,returncode=rc,elapsed_s=time.monotonic()-start,inputs=inputs,inputs_unchanged=all(sha(Path(p))==h for p,h in inputs.items()))
 if (d/'report.lvsdb').exists():
  with (d/'audit.log').open('w') as f:subprocess.run(['python','hw/soc/flow/audit_klayout_lvs.py',str(d/'report.lvsdb'),'--top','DUMMY_TOP','--deck-log',str(d/'deck.log'),'--output',str(d/'audit.json')],stdout=f,stderr=subprocess.STDOUT)
  if (d/'audit.json').exists():r['audit']=json.loads((d/'audit.json').read_text())
 (d/'result.json').write_text(json.dumps(r,indent=2)+'\n');results.append(r);print(tag,rc,r.get('audit',{}).get('status','no audit'),flush=True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
