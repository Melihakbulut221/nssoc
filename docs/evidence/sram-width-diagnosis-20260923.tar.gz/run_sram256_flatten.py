from pathlib import Path
import hashlib,json,subprocess,shutil,time,resource
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';out=c/'sram256-wldrv-flatten';out.mkdir(exist_ok=False)
up=root/'hw/soc/tools/ihp-lvs-5e6d592/ihp-sg13g2/libs.tech/klayout/tech/lvs';deck=out/'deck';shutil.copytree(up,deck)
p=deck/'rule_decks/layers_definitions.lvs';s=p.read_text();assert s.count('metal1_text = labels(8, 25)')==1;s=s.replace('metal1_text = labels(8, 25)','metal1_text = labels(8, 25) + labels(8, 2)');p.write_text(s)
p=deck/'sg13g2.lvs';s=p.read_text();anchor='# === Tech Switches ===';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\n# Diagnostic only: require physical closure at the macro boundary.\nconnect_implicit("RSC_IHPSG13_DFPQD_MSAFFX2P", "VDD!")\ntop_level(true)\n');p.write_text(s)
p=deck/'sg13g2.lvs';s=p.read_text();anchor='  align\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'  # Diagnostic: preserve all devices while removing the affected boundary.\n  netlist.flatten_circuit("RSC_IHPSG13_WLDRVX8")\n  schematic.flatten_circuit("RSC_IHPSG13_WLDRVX8")\n');p.write_text(s)
pdk=Path('/home/hasanmelih/.ciel/ihp-sg13g2').resolve();name='RM_IHPSG13_2P_256x16_c2_bm_bist';gds=pdk/f'libs.ref/sg13g2_sram/gds/{name}.gds';cdl=pdk/f'libs.ref/sg13g2_sram/cdl/{name}.cdl'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
flags=dict(input=str(gds),schematic=str(cdl),topcell=name,run_mode='deep',report=str(out/(name+'.lvsdb')),log=str(out/'deck.log'),target_netlist=str(out/'extracted.cir'))
for k in ['no_net_names','spice_comments','net_only','top_lvl_pins','no_simplify','no_series_res','no_parallel_res','combine_devices','purge','purge_nets','verbose','ignore_top_ports_mismatch','disable_tap_extraction','purge_devices']:flags[k]='false'
cmd=['klayout','-b','-zz','-r',str(deck/'sg13g2.lvs')]
for k,v in flags.items():cmd+=['-rd',k+'='+v]
inputs={str(p):sha(p) for p in [gds,cdl,*sorted(deck.rglob('*.lvs'))]}
r=dict(scope='Diagnostic only: original vendor SRAM GDS/CDL, separate copied deck reads datatype-2 Metal1 labels and requires physical closure of DFPQD VDD! at strict top level. WLDRV is flattened on both netlists to test device externalization; all devices retained. No resistor aliases, tolerances, blackboxes or source edits. Does not establish foundry acceptance.',command=cmd,inputs=inputs)
(out/'inputs.json').write_text(json.dumps(r,indent=2)+'\n')
def limit():resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3))
start=time.monotonic()
with (out/'run.log').open('w') as f:
 try:ret=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=limit,timeout=600).returncode
 except subprocess.TimeoutExpired:ret=124
r.update(returncode=ret,elapsed_s=time.monotonic()-start,inputs_unchanged=all(sha(Path(p))==h for p,h in inputs.items()))
if (out/(name+'.lvsdb')).exists():
 with (out/'audit.log').open('w') as f:subprocess.run(['python','hw/soc/flow/audit_klayout_lvs.py',str(out/(name+'.lvsdb')),'--top',name,'--deck-log',str(out/'deck.log'),'--output',str(out/'audit.json')],stdout=f,stderr=subprocess.STDOUT)
 if (out/'audit.json').exists():r['audit']=json.loads((out/'audit.json').read_text())
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print({k:r[k] for k in ['returncode','elapsed_s','inputs_unchanged']},r.get('audit',{}).get('status','no audit'),flush=True)
