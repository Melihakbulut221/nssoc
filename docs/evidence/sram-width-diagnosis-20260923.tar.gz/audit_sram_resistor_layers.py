from pathlib import Path
from collections import Counter
import re,json,hashlib
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';b=c/'sram256-port-seeded';result={}
for side,name in [('layout','extracted.cir.before-compare.cir'),('reference','extracted.cir.reference.cir')]:
 p=b/name;body=re.sub(r'\n\s*\+\s*',' ',p.read_text());hist=Counter();models=Counter()
 for line in body.splitlines():
  fields=line.split()
  if not fields or not fields[0].upper().startswith('R'):continue
  assert len(fields)>5 and '=' not in fields[4],line
  model=fields[4].lower();props=dict(x.split('=',1) for x in fields[5:]);assert 'L' in props and 'W' in props
  models[model]+=1;hist[(model,props['L'],props['W'])]+=1
 result[side]={'source':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Written primitive resistor definitions in the already context-flattened graph, not recursively expanded instances','models':dict(models),'dimensions':[{'model':m,'L':l,'W':w,'count':n} for (m,l,w),n in sorted(hist.items())]}
result['status']='REJECT global Metal1 mapping: original macro extraction also has Metal2 and Metal3 resistors'
(c/'sram-resistor-layer-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
