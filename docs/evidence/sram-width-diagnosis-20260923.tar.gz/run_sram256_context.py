from pathlib import Path
import hashlib,json,subprocess,shutil,time,resource
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';out=c/'sram256-context-flatten';out.mkdir(exist_ok=False)
up=c/'lvsres-dimension-controls2/deck';deck=out/'deck';shutil.copytree(up,deck)
p=deck/'sg13g2.lvs';s=p.read_text();anchor='  align\n';assert s.count(anchor)==1
added=''
for cell in ['RSC_IHPSG13_CINVX2','RSC_IHPSG13_CINVX8','RSC_IHPSG13_FILLCAP4','RSC_IHPSG13_FILLCAP8']:
 added += f'  netlist.flatten_circuit("{cell}")\n  schematic.flatten_circuit("{cell}")\n'
s=s.replace(anchor,anchor+added);p.write_text(s)
pdk=Path('/home/hasanmelih/.ciel/ihp-sg13g2').resolve();name='RM_IHPSG13_2P_256x16_c2_bm_bist';gds=pdk/f'libs.ref/sg13g2_sram/gds/{name}.gds';cdl=pdk/f'libs.ref/sg13g2_sram/cdl/{name}.cdl'
import sys,re
sys.path.insert(0,str(root/'hw/soc/flow'))
from transistor_schematic import read_cdl
original_cdl=cdl;definitions,ports=read_cdl([original_cdl]);reachable=set();references={}
def visit(n):
 if n in reachable:return
 assert n in definitions,n
 reachable.add(n);children=[]
 for line in re.sub(r'\n\s*\+\s*',' ',definitions[n]).splitlines():
  fields=line.split()
  if fields and fields[0][0].upper()=='X':
   child=fields[-1];assert child in definitions,child;children.append(child);visit(child)
 references[n]=children
visit(name)
cdl=out/'reachable-reference.cdl';cdl.write_text('* Exact reachable vendor subcircuits, no body edits.\n'+'\n'.join(v for k,v in definitions.items() if k in reachable)+'\n')
(out/'reachability.json').write_text(json.dumps({'top':name,'original':str(original_cdl),'reachable':sorted(reachable),'excluded_unreachable':sorted(set(definitions)-reachable),'references':references,'verbatim_bodies':True},indent=2)+'\n')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
flags=dict(input=str(gds),schematic=str(cdl),topcell=name,run_mode='deep',report=str(out/(name+'.lvsdb')),log=str(out/'deck.log'),target_netlist=str(out/'extracted.cir'))
for k in ['no_net_names','spice_comments','net_only','top_lvl_pins','no_simplify','no_series_res','no_parallel_res','combine_devices','purge','purge_nets','verbose','ignore_top_ports_mismatch','disable_tap_extraction','purge_devices']:flags[k]='false'
cmd=['klayout','-b','-zz','-r',str(deck/'sg13g2.lvs')]
for k,v in flags.items():cmd+=['-rd',k+'='+v]
inputs={str(p):sha(p) for p in [gds,original_cdl,cdl,*sorted(deck.rglob('*.lvs'))]}
r=dict(scope='Diagnostic only: original vendor SRAM GDS/CDL, separate copied deck reads datatype-2 Metal1 labels and requires physical closure of DFPQD VDD! at strict top level. Additionally normalize the documented legacy lvsres Metal1 class with active W/L comparison, flatten WLDRV and the four unmatched context-externalized inverter/fill-cap boundaries on both sides retaining every primitive, and retain only reachable verbatim schematic definitions. No tolerances or blackboxes. Original GDS/CDL files untouched; this experimental deck is not foundry acceptance. Does not establish foundry acceptance.',command=cmd,inputs=inputs)
(out/'inputs.json').write_text(json.dumps(r,indent=2)+'\n')
def limit():resource.setrlimit(resource.RLIMIT_AS,(4*1024**3,4*1024**3))
start=time.monotonic()
with (out/'run.log').open('w') as f:
 try:ret=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=limit,timeout=600).returncode
 except subprocess.TimeoutExpired:ret=124
r.update(returncode=ret,elapsed_s=time.monotonic()-start,inputs_unchanged=all(sha(Path(p))==h for p,h in inputs.items()))
if (out/(name+'.lvsdb')).exists():
 with (out/'audit.log').open('w') as f:subprocess.run(['python','hw/soc/flow/audit_klayout_lvs.py',str(out/(name+'.lvsdb')),'--top',name,'--deck-log',str(out/'deck.log'),'--output',str(out/'audit.json')],stdout=f,stderr=subprocess.STDOUT)
 if (out/'audit.json').exists():r['audit']=json.loads((out/'audit.json').read_text())
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print({k:r[k] for k in ['returncode','elapsed_s','inputs_unchanged']},r.get('audit',{}).get('status','no audit'),flush=True)
