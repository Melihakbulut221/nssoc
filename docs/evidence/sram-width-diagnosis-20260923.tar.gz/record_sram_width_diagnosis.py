from pathlib import Path
import json,hashlib,tarfile
root=Path.cwd();c=root/'hw/soc/out/external-review-20260919/route-closure-20260923'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
w=json.loads((c/'sram-bitcell-width-witness/result.json').read_text());assert w['widths_um']=={'layout':0.2,'reference':0.26}
controls=json.loads((c/'lvsres-dimension-controls2/results.json').read_text());assert [r['audit']['status'] for r in controls]==['PASS within comparison scope','FAIL','FAIL','FAIL'];assert all(r['inputs_unchanged'] for r in controls)
for r in controls:
 for path,digest in r['inputs'].items():assert sha(Path(path))==digest
runs={}
for name in ['sram256-strict-hierarchy','sram256-wldrv-flatten','sram256-documented-reader','sram256-context-flatten','sram256-port-seeded','sram256-netgen-control']:
 r=json.loads((c/name/'result.json').read_text());assert r['inputs_unchanged'];runs[name]={'returncode':r['returncode'],'elapsed_s':r['elapsed_s'],'audit':r.get('audit'),'scope':r.get('scope','')}
files=[c/n for n in ['record_sram_width_diagnosis.py','run_sram256_strict.py','run_sram256_flatten.py','run_sram256_documented.py','run_sram256_context.py','run_sram256_seeded.py','run_netgen_sram.py','run_lvsres_controls.py','run_lvsres_controls2.py','audit_sram_resistor_layers.py','measure_resistor_markers.py','inspect_resistor_cells.py','inspect_resistor_parents.py','prepare_bitcell_width_witness.py','sram-resistor-layer-audit.json','sram-resistor-markers.json','resistor-cell-inventory.json','sram-cdl-upstream-history.json']]
for name in [*runs,'lvsres-dimension-controls','lvsres-dimension-controls2','sram-bitcell-width-witness','full-schematic-reachable']:
 for p in (c/name).rglob('*'):
  if not p.is_file():continue
  # All control databases are small and retained. Large intermediate failed
  # macro databases remain local with their recorded digests; retain the last
  # completed macro database for independent inspection of the failed scope.
  if p.suffix=='.lvsdb' and name.startswith('sram256-') and name!='sram256-documented-reader':continue
  if 'deck' in p.relative_to(c/name).parts and p.name not in ['sg13g2.lvs','custom_reader.lvs','layers_definitions.lvs']:continue
  files.append(p)
a=root/'docs/evidence/sram-width-diagnosis-20260923.tar.gz';license_path=root/'hw/soc/tools/ihp-lvs-5e6d592/LICENSE'
with tarfile.open(a,'w:gz',compresslevel=4) as t:
 for p in files:t.add(p,arcname=str(p.relative_to(c)))
 t.add(license_path,arcname='upstream-LICENSE.txt')
with tarfile.open(a) as t:
 for p in files:assert hashlib.sha256(t.extractfile(str(p.relative_to(c))).read()).hexdigest()==sha(p)
r={'date':'2026-09-23','status':'OPEN: original SRAM reference/layout resistor-width mismatch; no macro LVS acceptance','scope':'Research using separate copied decks. Original GDS/CDL and production/locked decks remain unchanged. A passing isolated Metal1 control cannot be extrapolated to the macro.','bitcell_witness':w,'resistor_inventory':json.loads((c/'sram-resistor-layer-audit.json').read_text()),'direct_geometry':json.loads((c/'sram-resistor-markers.json').read_text()),'isolated_Metal1_controls':[{k:r[k] for k in ['case','returncode','elapsed_s','audit']} for r in controls],'macro_diagnostics':runs,'rejected_generalization':'The documented legacy Metal1 normalization passes the original dummy cell and rejects altered W, L and deleted-resistor references. Whole-macro application is invalid: the macro contains Metal2 and Metal3 resistors and widths 0.20/0.24um, while the vendor CDL uses 0.26um. Neither aliasing every model to Metal1 nor disabling width comparison is accepted. The seeded KLayout attempt was stopped (-9 after SIGTERM did not stop comparison); Netgen stopped (-15). The earlier unseeded comparison hit its 600-second bound. No interrupted process is a pass.','hierarchy_findings':'Cell-scoped DFPQD must-connect with strict top-level handling yields no unresolved extraction diagnostics in the bounded macro experiment. Flattening WLDRV and context-externalized cells preserves devices but does not establish top equivalence. Intermediate audit Match rows are not acceptance of the full macro.','upstream_history':json.loads((c/'sram-cdl-upstream-history.json').read_text()),'references':['https://ihp-open-pdk-docs.readthedocs.io/en/latest/verification/lvs/04_05_res.html','https://www.klayout.de/doc/manual/lvs_tweaks.html','https://www.klayout.org/downloads/master/doc-qt5/about/lvs_ref_netter.html','https://github.com/IHP-GmbH/IHP-Open-PDK/pull/1121'],'archive':{'path':str(a.relative_to(root)),'sha256':sha(a),'bytes':a.stat().st_size,'members':{**{str(p.relative_to(c)):sha(p) for p in files},'upstream-LICENSE.txt':sha(license_path)}}}
(root/'docs/evidence/sram-width-diagnosis-20260923.json').write_text(json.dumps(r,indent=2)+'\n');print('published SRAM width diagnosis',a.stat().st_size)
