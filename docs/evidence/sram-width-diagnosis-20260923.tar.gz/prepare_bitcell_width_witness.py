from pathlib import Path
import klayout.db as db
import sys,re,json,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'hw/soc/flow'));from transistor_schematic import read_cdl
c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';out=c/'sram-bitcell-width-witness';out.mkdir(exist_ok=False);pdk=Path('/home/hasanmelih/.ciel/ihp-sg13g2').resolve();macro='RM_IHPSG13_2P_256x16_c2_bm_bist';gds=pdk/f'libs.ref/sg13g2_sram/gds/{macro}.gds';cdl=pdk/f'libs.ref/sg13g2_sram/cdl/{macro}.cdl';defs,_=read_cdl([cdl]);layout_cell='RM_IHPSG13_2P_BITKIT_CELL';reference_cell='RM_IHPSG13_256x16_c2_2P_BITKIT_CELL'
l=db.Layout();l.read(str(gds));source=l.cell(layout_cell);assert source is not None
subset=db.Layout();subset.dbu=l.dbu;top=subset.create_cell(layout_cell);top.copy_tree(source);subset.write(str(out/'bitcell.gds'))
body=defs[reference_cell];header=cdl.read_text().split('.SUBCKT',1)[0];(out/'bitcell.cdl').write_text(header+body+'\n');rows=[]
for metal,layer in [('Metal2',10),('Metal3',30)]:
 markers=db.Region(top.begin_shapes_rec(subset.layer(layer,29)));wire=db.Region(top.begin_shapes_rec(subset.layer(layer,0)));markers.merge();wire.merge()
 for poly in markers.each():
  b=poly.bbox();assert poly.area()==b.area();intersection=db.Region(poly)&wire;assert intersection.area()==poly.area()
  rows.append({'metal':metal,'marker_bbox_dbu':str(b),'sides_um':sorted([round(b.width()*l.dbu,6),round(b.height()*l.dbu,6)]),'marker_fully_covered_by_metal':True})
res=[line for line in re.sub(r'\n\s*\+\s*',' ',body).splitlines() if line.startswith('R')];assert len(rows)==len(res)==6 and all(r['sides_um']==[0.2,0.6] for r in rows);assert all('w=2.6e-07 l=6e-07' in line for line in res)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r={'status':'CONFIRMED dimension mismatch in the original bit-cell views','scope':'Geometry and CDL witness, not an LVS verdict. The library uses a generic GDS bit-cell name and a size-qualified CDL bit-cell name; both are preserved. No source dimensions, device classes or tolerances changed.','layout_cell':layout_cell,'reference_cell':reference_cell,'dbu':l.dbu,'layout_markers':rows,'verbatim_reference_resistors':res,'widths_um':{'layout':0.2,'reference':0.26},'source':{str(p):sha(p) for p in [gds,cdl]},'subset':{p.name:sha(p) for p in out.iterdir() if p.is_file()}};(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
