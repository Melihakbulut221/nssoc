from pathlib import Path
import klayout.db as db
import sys,re,json,hashlib
root=Path.cwd();sys.path.insert(0,str(root/'hw/soc/flow'));from transistor_schematic import read_cdl,reachable_cdl
c=root/'hw/soc/out/external-review-20260919/route-closure-20260923';out=c/'sram-resistor-mismatch-parent-inventory';out.mkdir(exist_ok=False);pdk=Path('/home/hasanmelih/.ciel/ihp-sg13g2').resolve();macro='RM_IHPSG13_2P_256x16_c2_bm_bist';gds=pdk/f'libs.ref/sg13g2_sram/gds/{macro}.gds';cdl=pdk/f'libs.ref/sg13g2_sram/cdl/{macro}.cdl';l=db.Layout();l.read(str(gds));defs,_=read_cdl([cdl]);rows=[]
for cell in l.each_cell():
 children=[i.cell.name for i in cell.each_inst() if i.cell.name.startswith('lvsres_db_')]
 if not children:continue
 rows.append({'cell':cell.name,'resistor_pcell_children':children,'reference_resistors':[line for line in re.sub(r'\n\s*\+\s*',' ',defs.get(cell.name,'')).splitlines() if line.upper().startswith('R')]})
(out/'parents.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
