module ibex_top (
	clk_i,
	rst_ni,
	test_en_i,
	ram_cfg_icache_tag_i,
	ram_cfg_icache_tag_o,
	ram_cfg_icache_data_i,
	ram_cfg_icache_data_o,
	cheriot_enable_i,
	hart_id_i,
	boot_addr_i,
	trvk_heap_base_addr_i,
	instr_req_o,
	instr_gnt_i,
	instr_rvalid_i,
	instr_addr_o,
	instr_rdata_i,
	instr_rdata_intg_i,
	instr_err_i,
	data_req_o,
	data_gnt_i,
	data_rvalid_i,
	data_we_o,
	data_be_o,
	data_addr_o,
	data_wdata_o,
	data_wdata_intg_o,
	data_tag_o,
	data_rdata_i,
	data_rdata_intg_i,
	data_tag_i,
	data_err_i,
	trvk_revbm_req_o,
	trvk_revbm_gnt_i,
	trvk_revbm_rvalid_i,
	trvk_revbm_addr_o,
	trvk_revbm_rdata_i,
	trvk_revbm_rdata_intg_i,
	trvk_revbm_err_i,
	irq_software_i,
	irq_timer_i,
	irq_external_i,
	irq_fast_i,
	irq_nm_i,
	scramble_key_valid_i,
	scramble_key_i,
	scramble_nonce_i,
	scramble_req_o,
	debug_req_i,
	crash_dump_o,
	double_fault_seen_o,
	fetch_enable_i,
	mcounteren_writable_i,
	alert_minor_o,
	alert_major_internal_o,
	alert_major_bus_o,
	core_sleep_o,
	scan_rst_ni,
	lockstep_cmp_en_o,
	data_req_shadow_o,
	data_we_shadow_o,
	data_be_shadow_o,
	data_addr_shadow_o,
	data_wdata_shadow_o,
	data_wdata_intg_shadow_o,
	instr_req_shadow_o,
	instr_addr_shadow_o
);
	parameter integer BaseIsa = 32'sd0;
	parameter [0:0] PMPEnable = 1'b0;
	parameter [31:0] PMPGranularity = 0;
	parameter [31:0] PMPNumRegions = 4;
	parameter [31:0] MHPMCounterNum = 0;
	parameter [31:0] MHPMCounterWidth = 40;
	localparam [31:0] ibex_pkg_PMP_MAX_REGIONS = 16;
	localparam [95:0] ibex_pkg_PmpCfgRst = 96'b000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
	parameter [95:0] PMPRstCfg = ibex_pkg_PmpCfgRst;
	localparam [31:0] ibex_pkg_PMP_ADDR_MSB = 33;
	localparam [543:0] ibex_pkg_PmpAddrRst = 544'h0;
	parameter [543:0] PMPRstAddr = ibex_pkg_PmpAddrRst;
	localparam [2:0] ibex_pkg_PmpMseccfgRst = 3'b000;
	parameter [2:0] PMPRstMsecCfg = ibex_pkg_PmpMseccfgRst;
	parameter [31:0] CheriotRevBitmapAddrWidth = 32'd11;
	parameter [31:0] CheriotRevBitmapBaseAddr = 32'h00000000;
	parameter [0:0] RV32E = 1'b0;
	parameter integer RV32M = 32'sd2;
	parameter integer RV32B = 32'sd0;
	parameter integer RV32ZC = 32'sd3;
	parameter integer RegFile = 32'sd0;
	parameter [0:0] BranchTargetALU = 1'b0;
	parameter [0:0] WritebackStage = 1'b0;
	parameter [0:0] ICache = 1'b0;
	parameter [0:0] ICacheECC = 1'b0;
	parameter [0:0] BranchPredictor = 1'b0;
	parameter [0:0] DbgTriggerEn = 1'b0;
	parameter [31:0] DbgHwBreakNum = 1;
	parameter [0:0] SecureIbex = 1'b0;
	parameter [31:0] LockstepOffset = 1;
	parameter [0:0] MemECC = SecureIbex;
	parameter [31:0] MemDataWidth = (MemECC ? 39 : 32);
	parameter [0:0] ICacheScramble = 1'b0;
	parameter [31:0] ICacheScrNumPrinceRoundsHalf = 2;
	parameter [0:0] ICacheTweakInfection = SecureIbex;
	localparam signed [31:0] ibex_pkg_LfsrWidth = 32;
	localparam [31:0] ibex_pkg_RndCnstLfsrSeedDefault = 32'hac533bf4;
	parameter [31:0] RndCnstLfsrSeed = ibex_pkg_RndCnstLfsrSeedDefault;
	localparam [159:0] ibex_pkg_RndCnstLfsrPermDefault = 160'h1e35ecba467fd1b12e958152c04fa43878a8daed;
	parameter [159:0] RndCnstLfsrPerm = ibex_pkg_RndCnstLfsrPermDefault;
	parameter [31:0] DmBaseAddr = 32'h1a110000;
	parameter [31:0] DmAddrMask = 32'h00000fff;
	parameter [31:0] DmHaltAddr = 32'h1a110800;
	parameter [31:0] DmExceptionAddr = 32'h1a110808;
	localparam [31:0] ibex_pkg_SCRAMBLE_KEY_W = 128;
	localparam [127:0] ibex_pkg_RndCnstIbexKeyDefault = 128'h14e8cecae3040d5e12286bb3cc113298;
	parameter [127:0] RndCnstIbexKey = ibex_pkg_RndCnstIbexKeyDefault;
	localparam [31:0] ibex_pkg_SCRAMBLE_NONCE_W = 64;
	localparam [63:0] ibex_pkg_RndCnstIbexNonceDefault = 64'hf79780bc735f3843;
	parameter [63:0] RndCnstIbexNonce = ibex_pkg_RndCnstIbexNonceDefault;
	parameter [31:0] CsrMvendorId = 32'b00000000000000000000000000000000;
	parameter [31:0] CsrMimpId = 32'b00000000000000000000000000000000;
	input wire clk_i;
	input wire rst_ni;
	input wire test_en_i;
	localparam [31:0] ibex_pkg_IC_NUM_WAYS = 2;
	localparam [31:0] prim_ram_1p_pkg_Ram1pReqWidth = 32'd12;
	input wire [(ibex_pkg_IC_NUM_WAYS * prim_ram_1p_pkg_Ram1pReqWidth) - 1:0] ram_cfg_icache_tag_i;
	localparam [31:0] prim_ram_1p_pkg_Ram1pRspWidth = 32'd1;
	output wire [(ibex_pkg_IC_NUM_WAYS * prim_ram_1p_pkg_Ram1pRspWidth) - 1:0] ram_cfg_icache_tag_o;
	input wire [(ibex_pkg_IC_NUM_WAYS * prim_ram_1p_pkg_Ram1pReqWidth) - 1:0] ram_cfg_icache_data_i;
	output wire [(ibex_pkg_IC_NUM_WAYS * prim_ram_1p_pkg_Ram1pRspWidth) - 1:0] ram_cfg_icache_data_o;
	localparam signed [31:0] ibex_pkg_IbexMuBiWidth = 4;
	input wire [3:0] cheriot_enable_i;
	input wire [31:0] hart_id_i;
	input wire [31:0] boot_addr_i;
	input wire [31:0] trvk_heap_base_addr_i;
	output wire instr_req_o;
	input wire instr_gnt_i;
	input wire instr_rvalid_i;
	output wire [31:0] instr_addr_o;
	input wire [31:0] instr_rdata_i;
	input wire [6:0] instr_rdata_intg_i;
	input wire instr_err_i;
	output wire data_req_o;
	input wire data_gnt_i;
	input wire data_rvalid_i;
	output wire data_we_o;
	output wire [3:0] data_be_o;
	output wire [31:0] data_addr_o;
	output wire [31:0] data_wdata_o;
	output wire [6:0] data_wdata_intg_o;
	output wire data_tag_o;
	input wire [31:0] data_rdata_i;
	input wire [6:0] data_rdata_intg_i;
	input wire data_tag_i;
	input wire data_err_i;
	output wire trvk_revbm_req_o;
	input wire trvk_revbm_gnt_i;
	input wire trvk_revbm_rvalid_i;
	output wire [31:0] trvk_revbm_addr_o;
	input wire [31:0] trvk_revbm_rdata_i;
	input wire [6:0] trvk_revbm_rdata_intg_i;
	input wire trvk_revbm_err_i;
	input wire irq_software_i;
	input wire irq_timer_i;
	input wire irq_external_i;
	input wire [14:0] irq_fast_i;
	input wire irq_nm_i;
	input wire scramble_key_valid_i;
	input wire [127:0] scramble_key_i;
	input wire [63:0] scramble_nonce_i;
	output wire scramble_req_o;
	input wire debug_req_i;
	output wire [159:0] crash_dump_o;
	output wire double_fault_seen_o;
	input wire [3:0] fetch_enable_i;
	input wire [3:0] mcounteren_writable_i;
	output wire alert_minor_o;
	output wire alert_major_internal_o;
	output wire alert_major_bus_o;
	output wire core_sleep_o;
	input wire scan_rst_ni;
	output wire [3:0] lockstep_cmp_en_o;
	output wire data_req_shadow_o;
	output wire data_we_shadow_o;
	output wire [3:0] data_be_shadow_o;
	output wire [31:0] data_addr_shadow_o;
	output wire [31:0] data_wdata_shadow_o;
	output wire [6:0] data_wdata_intg_shadow_o;
	output wire instr_req_shadow_o;
	output wire [31:0] instr_addr_shadow_o;
	localparam [0:0] Lockstep = SecureIbex;
	localparam [0:0] ResetAll = Lockstep;
	localparam [0:0] DummyInstructions = SecureIbex;
	localparam [0:0] RegFileECC = 1'b0;
	localparam [0:0] RegFileLockstepECC = Lockstep;
	localparam [31:0] RegFileDataWidth = 32;
	localparam [31:0] RegFileDataEccWidth = 39;
	localparam [31:0] ibex_cheriot_pkg_REGCAP_W = 35;
	localparam [31:0] RegFileCapEccWidth = 42;
	localparam [31:0] ibex_pkg_BUS_SIZE = 32;
	localparam [31:0] ibex_pkg_IC_DATA_ECC_SIZE = 7;
	localparam [31:0] BusSizeECC = (ICacheECC ? ibex_pkg_BUS_SIZE + ibex_pkg_IC_DATA_ECC_SIZE : ibex_pkg_BUS_SIZE);
	localparam [31:0] ibex_pkg_BUS_BYTES = 4;
	localparam [31:0] ibex_pkg_IC_LINE_SIZE = 64;
	localparam [31:0] ibex_pkg_IC_LINE_BYTES = 8;
	localparam [31:0] ibex_pkg_IC_LINE_BEATS = ibex_pkg_IC_LINE_BYTES / ibex_pkg_BUS_BYTES;
	localparam [31:0] LineSizeECC = BusSizeECC * ibex_pkg_IC_LINE_BEATS;
	localparam [31:0] ibex_pkg_IC_TAG_ECC_SIZE = 6;
	localparam [31:0] ibex_pkg_ADDR_W = 32;
	localparam [31:0] ibex_pkg_IC_SIZE_BYTES = 4096;
	localparam [31:0] ibex_pkg_IC_NUM_LINES = (ibex_pkg_IC_SIZE_BYTES / ibex_pkg_IC_NUM_WAYS) / ibex_pkg_IC_LINE_BYTES;
	localparam [31:0] ibex_pkg_IC_INDEX_W = $clog2(ibex_pkg_IC_NUM_LINES);
	localparam [31:0] ibex_pkg_IC_LINE_W = 3;
	localparam [31:0] ibex_pkg_IC_TAG_SIZE = ((ibex_pkg_ADDR_W - ibex_pkg_IC_INDEX_W) - ibex_pkg_IC_LINE_W) + 1;
	localparam [31:0] TagSizeECC = (ICacheECC ? ibex_pkg_IC_TAG_SIZE + ibex_pkg_IC_TAG_ECC_SIZE : ibex_pkg_IC_TAG_SIZE);
	localparam [31:0] NumAddrScrRounds = (ICacheScramble ? 2 : 0);
	localparam [31:0] MaxOutstandingDSideAccesses = 2;
	wire clk;
	wire [3:0] core_busy_d;
	reg [3:0] core_busy_q;
	wire clock_en;
	wire irq_pending;
	wire dummy_instr_id;
	wire dummy_instr_wb;
	wire [4:0] rf_raddr_a;
	wire [4:0] rf_raddr_b;
	wire [4:0] rf_waddr_wb;
	wire rf_we_wb;
	wire [31:0] rf_wdata_wb;
	wire [31:0] rf_rdata_a;
	wire [31:0] rf_rdata_b;
	wire [34:0] rf_rcap_a;
	wire [34:0] rf_rcap_b;
	wire [34:0] rf_wcap;
	wire [MemDataWidth - 1:0] data_wdata_core;
	wire [MemDataWidth - 1:0] data_rdata_core;
	wire [MemDataWidth - 1:0] instr_rdata_core;
	wire trvk_req;
	wire trvk_gnt;
	wire trvk_rvalid;
	wire trvk_we;
	wire [3:0] trvk_be;
	wire [31:0] trvk_addr;
	wire [31:0] trvk_wdata;
	wire [6:0] trvk_wdata_intg;
	wire trvk_wtag;
	wire [31:0] trvk_rdata;
	wire [6:0] trvk_rdata_intg;
	wire trvk_rtag;
	wire trvk_err;
	wire trvk_revbm_data_intg_error;
	wire trvk_revbm_device_error;
	wire [1:0] ic_tag_req;
	wire ic_tag_write;
	wire [ibex_pkg_IC_INDEX_W - 1:0] ic_tag_addr;
	wire [TagSizeECC - 1:0] ic_tag_wdata;
	wire [(ibex_pkg_IC_NUM_WAYS * TagSizeECC) - 1:0] ic_tag_rdata;
	wire [1:0] ic_data_req;
	wire ic_data_write;
	wire [ibex_pkg_IC_INDEX_W - 1:0] ic_data_addr;
	wire [LineSizeECC - 1:0] ic_data_wdata;
	wire [(ibex_pkg_IC_NUM_WAYS * LineSizeECC) - 1:0] ic_data_rdata;
	wire ic_scr_key_req;
	wire core_alert_major_internal;
	wire core_alert_major_bus;
	wire core_alert_minor;
	wire lockstep_alert_major_internal;
	wire lockstep_alert_major_bus;
	wire lockstep_alert_minor;
	reg [127:0] scramble_key_q;
	reg [63:0] scramble_nonce_q;
	wire scramble_key_valid_d;
	reg scramble_key_valid_q;
	wire scramble_req_d;
	reg scramble_req_q;
	wire [3:0] fetch_enable_buf;
	wire [3:0] mcounteren_writable_buf;
	localparam [3:0] ibex_pkg_IbexMuBiOff = 4'b1010;
	generate
		if (SecureIbex) begin : g_clock_en_secure
			prim_generic_flop #(
				.Width(ibex_pkg_IbexMuBiWidth),
				.ResetValue(ibex_pkg_IbexMuBiOff)
			) u_prim_core_busy_flop(
				.clk_i(clk_i),
				.rst_ni(rst_ni),
				.d_i(core_busy_d),
				.q_o(core_busy_q)
			);
			assign clock_en = (((core_busy_q != ibex_pkg_IbexMuBiOff) | debug_req_i) | irq_pending) | irq_nm_i;
		end
		else begin : g_clock_en_non_secure
			always @(posedge clk_i or negedge rst_ni)
				if (!rst_ni)
					core_busy_q <= ibex_pkg_IbexMuBiOff;
				else
					core_busy_q <= core_busy_d;
			assign clock_en = ((core_busy_q[0] | debug_req_i) | irq_pending) | irq_nm_i;
			wire unused_core_busy;
			assign unused_core_busy = ^core_busy_q[3:1];
		end
	endgenerate
	assign core_sleep_o = ~clock_en;
	prim_clock_gating core_clock_gate_i(
		.clk_i(clk_i),
		.en_i(clock_en),
		.test_en_i(test_en_i),
		.clk_o(clk)
	);
	prim_generic_buf #(.Width(ibex_pkg_IbexMuBiWidth)) u_fetch_enable_buf(
		.in_i(fetch_enable_i),
		.out_o(fetch_enable_buf)
	);
	prim_generic_buf #(.Width(ibex_pkg_IbexMuBiWidth)) u_mcounteren_writable_buf(
		.in_i(mcounteren_writable_i),
		.out_o(mcounteren_writable_buf)
	);
	assign data_rdata_core[31:0] = trvk_rdata;
	assign instr_rdata_core[31:0] = instr_rdata_i;
	generate
		if (MemECC) begin : gen_mem_rdata_ecc
			assign data_rdata_core[MemDataWidth - 1:32] = trvk_rdata_intg;
			assign instr_rdata_core[MemDataWidth - 1:32] = instr_rdata_intg_i;
		end
		else begin : gen_non_mem_rdata_ecc
			wire unused_intg;
			assign unused_intg = ^{instr_rdata_intg_i, trvk_rdata_intg};
		end
	endgenerate
	ibex_core #(
		.PMPEnable(PMPEnable),
		.PMPGranularity(PMPGranularity),
		.PMPNumRegions(PMPNumRegions),
		.PMPRstCfg(PMPRstCfg),
		.PMPRstAddr(PMPRstAddr),
		.PMPRstMsecCfg(PMPRstMsecCfg),
		.MHPMCounterNum(MHPMCounterNum),
		.MHPMCounterWidth(MHPMCounterWidth),
		.RV32E(RV32E),
		.RV32M(RV32M),
		.RV32B(RV32B),
		.RV32ZC(RV32ZC),
		.BranchTargetALU(BranchTargetALU),
		.ICache(ICache),
		.ICacheECC(ICacheECC),
		.ICacheTweakInfection(ICacheTweakInfection),
		.BusSizeECC(BusSizeECC),
		.TagSizeECC(TagSizeECC),
		.LineSizeECC(LineSizeECC),
		.BranchPredictor(BranchPredictor),
		.DbgTriggerEn(DbgTriggerEn),
		.DbgHwBreakNum(DbgHwBreakNum),
		.WritebackStage(WritebackStage),
		.ResetAll(ResetAll),
		.RndCnstLfsrSeed(RndCnstLfsrSeed),
		.RndCnstLfsrPerm(RndCnstLfsrPerm),
		.SecureIbex(SecureIbex),
		.DummyInstructions(DummyInstructions),
		.RegFileECC(RegFileECC),
		.RegFileDataWidth(RegFileDataWidth),
		.RegFileCapEccWidth(ibex_cheriot_pkg_REGCAP_W),
		.MemECC(MemECC),
		.MemDataWidth(MemDataWidth),
		.DmBaseAddr(DmBaseAddr),
		.DmAddrMask(DmAddrMask),
		.DmHaltAddr(DmHaltAddr),
		.DmExceptionAddr(DmExceptionAddr),
		.CsrMvendorId(CsrMvendorId),
		.CsrMimpId(CsrMimpId),
		.BaseIsa(BaseIsa)
	) u_ibex_core(
		.clk_i(clk),
		.rst_ni(rst_ni),
		.hart_id_i(hart_id_i),
		.boot_addr_i(boot_addr_i),
		.cheriot_enable_i(cheriot_enable_i),
		.instr_req_o(instr_req_o),
		.instr_gnt_i(instr_gnt_i),
		.instr_rvalid_i(instr_rvalid_i),
		.instr_addr_o(instr_addr_o),
		.instr_rdata_i(instr_rdata_core),
		.instr_err_i(instr_err_i),
		.data_req_o(trvk_req),
		.data_gnt_i(trvk_gnt),
		.data_rvalid_i(trvk_rvalid),
		.data_we_o(trvk_we),
		.data_be_o(trvk_be),
		.data_addr_o(trvk_addr),
		.data_wdata_o(data_wdata_core),
		.data_tag_o(trvk_wtag),
		.data_rdata_i(data_rdata_core),
		.data_tag_i(trvk_rtag),
		.data_err_i(trvk_err),
		.dummy_instr_id_o(dummy_instr_id),
		.dummy_instr_wb_o(dummy_instr_wb),
		.rf_raddr_a_o(rf_raddr_a),
		.rf_raddr_b_o(rf_raddr_b),
		.rf_waddr_wb_o(rf_waddr_wb),
		.rf_we_wb_o(rf_we_wb),
		.rf_wdata_wb_ecc_o(rf_wdata_wb),
		.rf_rdata_a_ecc_i(rf_rdata_a),
		.rf_rdata_b_ecc_i(rf_rdata_b),
		.rf_wcap_ecc_wb_o(rf_wcap),
		.rf_rcap_a_ecc_i(rf_rcap_a),
		.rf_rcap_b_ecc_i(rf_rcap_b),
		.ic_tag_req_o(ic_tag_req),
		.ic_tag_write_o(ic_tag_write),
		.ic_tag_addr_o(ic_tag_addr),
		.ic_tag_wdata_o(ic_tag_wdata),
		.ic_tag_rdata_i(ic_tag_rdata),
		.ic_data_req_o(ic_data_req),
		.ic_data_write_o(ic_data_write),
		.ic_data_addr_o(ic_data_addr),
		.ic_data_wdata_o(ic_data_wdata),
		.ic_data_rdata_i(ic_data_rdata),
		.ic_scr_key_valid_i(scramble_key_valid_q),
		.ic_scr_key_req_o(ic_scr_key_req),
		.irq_software_i(irq_software_i),
		.irq_timer_i(irq_timer_i),
		.irq_external_i(irq_external_i),
		.irq_fast_i(irq_fast_i),
		.irq_nm_i(irq_nm_i),
		.irq_pending_o(irq_pending),
		.debug_req_i(debug_req_i),
		.crash_dump_o(crash_dump_o),
		.double_fault_seen_o(double_fault_seen_o),
		.fetch_enable_i(fetch_enable_buf),
		.mcounteren_writable_i(mcounteren_writable_buf),
		.alert_minor_o(core_alert_minor),
		.alert_major_internal_o(core_alert_major_internal),
		.alert_major_bus_o(core_alert_major_bus),
		.core_busy_o(core_busy_d)
	);
	localparam [38:0] prim_secded_pkg_SecdedInv3932ZeroWord = 39'h2a00000000;
	function automatic [31:0] sv2v_cast_DEBC9;
		input reg [31:0] inp;
		sv2v_cast_DEBC9 = inp;
	endfunction
	generate
		if (RegFile == 32'sd0) begin : gen_regfile_ff
			ibex_register_file_ff #(
				.BaseIsa(BaseIsa),
				.RV32E(RV32E),
				.DataWidth(RegFileDataWidth),
				.DummyInstructions(DummyInstructions),
				.WordZeroVal(sv2v_cast_DEBC9(prim_secded_pkg_SecdedInv3932ZeroWord))
			) register_file_i(
				.clk_i(clk),
				.rst_ni(rst_ni),
				.test_en_i(test_en_i),
				.dummy_instr_id_i(dummy_instr_id),
				.dummy_instr_wb_i(dummy_instr_wb),
				.cheriot_enable_i(cheriot_enable_i),
				.raddr_a_i(rf_raddr_a),
				.rdata_a_o(rf_rdata_a),
				.rcap_a_o(rf_rcap_a),
				.raddr_b_i(rf_raddr_b),
				.rdata_b_o(rf_rdata_b),
				.rcap_b_o(rf_rcap_b),
				.waddr_a_i(rf_waddr_wb),
				.wdata_a_i(rf_wdata_wb),
				.wcap_a_i(rf_wcap),
				.we_a_i(rf_we_wb)
			);
		end
		else if (RegFile == 32'sd1) begin : gen_regfile_fpga
			ibex_register_file_fpga #(
				.BaseIsa(BaseIsa),
				.RV32E(RV32E),
				.DataWidth(RegFileDataWidth),
				.DummyInstructions(DummyInstructions),
				.WordZeroVal(sv2v_cast_DEBC9(prim_secded_pkg_SecdedInv3932ZeroWord))
			) register_file_i(
				.clk_i(clk),
				.rst_ni(rst_ni),
				.test_en_i(test_en_i),
				.dummy_instr_id_i(dummy_instr_id),
				.dummy_instr_wb_i(dummy_instr_wb),
				.cheriot_enable_i(cheriot_enable_i),
				.raddr_a_i(rf_raddr_a),
				.rdata_a_o(rf_rdata_a),
				.rcap_a_o(rf_rcap_a),
				.raddr_b_i(rf_raddr_b),
				.rdata_b_o(rf_rdata_b),
				.rcap_b_o(rf_rcap_b),
				.waddr_a_i(rf_waddr_wb),
				.wdata_a_i(rf_wdata_wb),
				.wcap_a_i(rf_wcap),
				.we_a_i(rf_we_wb)
			);
		end
		else if (RegFile == 32'sd2) begin : gen_regfile_latch
			ibex_register_file_latch #(
				.BaseIsa(BaseIsa),
				.RV32E(RV32E),
				.DataWidth(RegFileDataWidth),
				.DummyInstructions(DummyInstructions),
				.WordZeroVal(sv2v_cast_DEBC9(prim_secded_pkg_SecdedInv3932ZeroWord))
			) register_file_i(
				.clk_i(clk),
				.rst_ni(rst_ni),
				.test_en_i(test_en_i),
				.dummy_instr_id_i(dummy_instr_id),
				.dummy_instr_wb_i(dummy_instr_wb),
				.cheriot_enable_i(cheriot_enable_i),
				.raddr_a_i(rf_raddr_a),
				.rdata_a_o(rf_rdata_a),
				.rcap_a_o(rf_rcap_a),
				.raddr_b_i(rf_raddr_b),
				.rdata_b_o(rf_rdata_b),
				.rcap_b_o(rf_rcap_b),
				.waddr_a_i(rf_waddr_wb),
				.wdata_a_i(rf_wdata_wb),
				.wcap_a_i(rf_wcap),
				.we_a_i(rf_we_wb)
			);
		end
		if (ICacheScramble) begin : gen_scramble
			assign scramble_key_valid_d = (scramble_req_q ? scramble_key_valid_i : (ic_scr_key_req ? 1'b0 : scramble_key_valid_q));
			always @(posedge clk_i or negedge rst_ni)
				if (!rst_ni) begin
					scramble_key_q <= RndCnstIbexKey;
					scramble_nonce_q <= RndCnstIbexNonce;
				end
				else if (scramble_key_valid_i) begin
					scramble_key_q <= scramble_key_i;
					scramble_nonce_q <= scramble_nonce_i;
				end
			always @(posedge clk_i or negedge rst_ni)
				if (!rst_ni) begin
					scramble_key_valid_q <= 1'b1;
					scramble_req_q <= 1'sb0;
				end
				else begin
					scramble_key_valid_q <= scramble_key_valid_d;
					scramble_req_q <= scramble_req_d;
				end
			assign scramble_req_d = (scramble_req_q ? ~scramble_key_valid_i : ic_scr_key_req);
			assign scramble_req_o = scramble_req_q;
		end
		else begin : gen_noscramble
			reg unused_scramble_inputs = (((((((((((scramble_key_valid_i & |scramble_key_i) & |RndCnstIbexKey) & |scramble_nonce_i) & |RndCnstIbexNonce) & scramble_req_q) & ic_scr_key_req) & scramble_key_valid_d) & scramble_req_d) & |scramble_key_q) & |scramble_nonce_q) & scramble_key_valid_q) & scramble_key_valid_d;
			assign scramble_req_d = 1'b0;
			wire [1:1] sv2v_tmp_2E9FB;
			assign sv2v_tmp_2E9FB = 1'b0;
			always @(*) scramble_req_q = sv2v_tmp_2E9FB;
			assign scramble_req_o = 1'b0;
			wire [128:1] sv2v_tmp_E270A;
			assign sv2v_tmp_E270A = 1'sb0;
			always @(*) scramble_key_q = sv2v_tmp_E270A;
			wire [64:1] sv2v_tmp_F758A;
			assign sv2v_tmp_F758A = 1'sb0;
			always @(*) scramble_nonce_q = sv2v_tmp_F758A;
			wire [1:1] sv2v_tmp_604FC;
			assign sv2v_tmp_604FC = 1'b1;
			always @(*) scramble_key_valid_q = sv2v_tmp_604FC;
			assign scramble_key_valid_d = 1'b1;
		end
	endgenerate
	wire [1:0] icache_tag_alert;
	wire [1:0] icache_data_alert;
	localparam [0:0] prim_ram_1p_pkg_RAM_1P_CFG_RSP_DEFAULT = 1'sb0;
	function automatic [0:0] sv2v_cast_97975;
		input reg [0:0] inp;
		sv2v_cast_97975 = inp;
	endfunction
	function automatic [TagSizeECC - 1:0] sv2v_cast_0CBAD;
		input reg [TagSizeECC - 1:0] inp;
		sv2v_cast_0CBAD = inp;
	endfunction
	function automatic [LineSizeECC - 1:0] sv2v_cast_033B0;
		input reg [LineSizeECC - 1:0] inp;
		sv2v_cast_033B0 = inp;
	endfunction
	generate
		if (ICache) begin : gen_rams
			genvar _gv_way_1;
			for (_gv_way_1 = 0; _gv_way_1 < ibex_pkg_IC_NUM_WAYS; _gv_way_1 = _gv_way_1 + 1) begin : gen_rams_inner
				localparam way = _gv_way_1;
				if (ICacheScramble) begin : gen_scramble_rams
					prim_ram_1p_scr #(
						.Width(TagSizeECC),
						.Depth(ibex_pkg_IC_NUM_LINES),
						.DataBitsPerMask(TagSizeECC),
						.EnableParity(0),
						.NumPrinceRoundsHalf(ICacheScrNumPrinceRoundsHalf),
						.NumAddrScrRounds(NumAddrScrRounds)
					) tag_bank(
						.clk_i(clk_i),
						.rst_ni(rst_ni),
						.key_valid_i(scramble_key_valid_q),
						.key_i(scramble_key_q),
						.nonce_i(scramble_nonce_q),
						.req_i(ic_tag_req[way]),
						.gnt_o(),
						.write_i(ic_tag_write),
						.addr_i(ic_tag_addr),
						.wdata_i(ic_tag_wdata),
						.wmask_i({TagSizeECC {1'b1}}),
						.intg_error_i(1'b0),
						.rdata_o(ic_tag_rdata[(1 - way) * TagSizeECC+:TagSizeECC]),
						.rvalid_o(),
						.raddr_o(),
						.rerror_o(),
						.cfg_i(ram_cfg_icache_tag_i[way * prim_ram_1p_pkg_Ram1pReqWidth+:prim_ram_1p_pkg_Ram1pReqWidth]),
						.cfg_o(ram_cfg_icache_tag_o[way * prim_ram_1p_pkg_Ram1pRspWidth+:prim_ram_1p_pkg_Ram1pRspWidth]),
						.wr_collision_o(),
						.write_pending_o(),
						.alert_o(icache_tag_alert[way])
					);
					prim_ram_1p_scr #(
						.Width(LineSizeECC),
						.Depth(ibex_pkg_IC_NUM_LINES),
						.DataBitsPerMask(LineSizeECC),
						.ReplicateKeyStream(1),
						.EnableParity(0),
						.NumPrinceRoundsHalf(ICacheScrNumPrinceRoundsHalf),
						.NumAddrScrRounds(NumAddrScrRounds)
					) data_bank(
						.clk_i(clk_i),
						.rst_ni(rst_ni),
						.key_valid_i(scramble_key_valid_q),
						.key_i(scramble_key_q),
						.nonce_i(scramble_nonce_q),
						.req_i(ic_data_req[way]),
						.gnt_o(),
						.write_i(ic_data_write),
						.addr_i(ic_data_addr),
						.wdata_i(ic_data_wdata),
						.wmask_i({LineSizeECC {1'b1}}),
						.intg_error_i(1'b0),
						.rdata_o(ic_data_rdata[(1 - way) * LineSizeECC+:LineSizeECC]),
						.rvalid_o(),
						.raddr_o(),
						.rerror_o(),
						.cfg_i(ram_cfg_icache_data_i[way * prim_ram_1p_pkg_Ram1pReqWidth+:prim_ram_1p_pkg_Ram1pReqWidth]),
						.cfg_o(ram_cfg_icache_data_o[way * prim_ram_1p_pkg_Ram1pRspWidth+:prim_ram_1p_pkg_Ram1pRspWidth]),
						.wr_collision_o(),
						.write_pending_o(),
						.alert_o(icache_data_alert[way])
					);
				end
				else begin : gen_noscramble_rams
					prim_ram_1p #(
						.Width(TagSizeECC),
						.Depth(ibex_pkg_IC_NUM_LINES),
						.DataBitsPerMask(TagSizeECC)
					) tag_bank(
						.clk_i(clk_i),
						.rst_ni(rst_ni),
						.req_i(ic_tag_req[way]),
						.write_i(ic_tag_write),
						.addr_i(ic_tag_addr),
						.wdata_i(ic_tag_wdata),
						.wmask_i({TagSizeECC {1'b1}}),
						.rdata_o(ic_tag_rdata[(1 - way) * TagSizeECC+:TagSizeECC]),
						.cfg_i(ram_cfg_icache_tag_i[way * prim_ram_1p_pkg_Ram1pReqWidth+:prim_ram_1p_pkg_Ram1pReqWidth]),
						.cfg_o(ram_cfg_icache_tag_o[way * prim_ram_1p_pkg_Ram1pRspWidth+:prim_ram_1p_pkg_Ram1pRspWidth])
					);
					prim_ram_1p #(
						.Width(LineSizeECC),
						.Depth(ibex_pkg_IC_NUM_LINES),
						.DataBitsPerMask(LineSizeECC)
					) data_bank(
						.clk_i(clk_i),
						.rst_ni(rst_ni),
						.req_i(ic_data_req[way]),
						.write_i(ic_data_write),
						.addr_i(ic_data_addr),
						.wdata_i(ic_data_wdata),
						.wmask_i({LineSizeECC {1'b1}}),
						.rdata_o(ic_data_rdata[(1 - way) * LineSizeECC+:LineSizeECC]),
						.cfg_i(ram_cfg_icache_data_i[way * prim_ram_1p_pkg_Ram1pReqWidth+:prim_ram_1p_pkg_Ram1pReqWidth]),
						.cfg_o(ram_cfg_icache_data_o[way * prim_ram_1p_pkg_Ram1pRspWidth+:prim_ram_1p_pkg_Ram1pRspWidth])
					);
					assign icache_tag_alert = {ibex_pkg_IC_NUM_WAYS {1'b0}};
					assign icache_data_alert = {ibex_pkg_IC_NUM_WAYS {1'b0}};
				end
			end
		end
		else begin : gen_norams
			wire unused_ram_cfg;
			wire unused_ram_inputs;
			assign unused_ram_cfg = |{ram_cfg_icache_tag_i, ram_cfg_icache_data_i};
			assign ram_cfg_icache_tag_o = {ibex_pkg_IC_NUM_WAYS {sv2v_cast_97975(prim_ram_1p_pkg_RAM_1P_CFG_RSP_DEFAULT)}};
			assign ram_cfg_icache_data_o = {ibex_pkg_IC_NUM_WAYS {sv2v_cast_97975(prim_ram_1p_pkg_RAM_1P_CFG_RSP_DEFAULT)}};
			assign unused_ram_inputs = (((((((|ic_tag_req & ic_tag_write) & |ic_tag_addr) & |ic_tag_wdata) & |ic_data_req) & ic_data_write) & |ic_data_addr) & |ic_data_wdata) & |NumAddrScrRounds;
			assign ic_tag_rdata = {ibex_pkg_IC_NUM_WAYS {sv2v_cast_0CBAD('b0)}};
			assign ic_data_rdata = {ibex_pkg_IC_NUM_WAYS {sv2v_cast_033B0('b0)}};
			assign icache_tag_alert = {ibex_pkg_IC_NUM_WAYS {1'b0}};
			assign icache_data_alert = {ibex_pkg_IC_NUM_WAYS {1'b0}};
		end
	endgenerate
	assign trvk_wdata = data_wdata_core[31:0];
	generate
		if (MemECC) begin : gen_mem_wdata_ecc
			prim_generic_buf #(.Width(7)) u_prim_generic_buf_data_wdata_intg(
				.in_i(data_wdata_core[MemDataWidth - 1:32]),
				.out_o(trvk_wdata_intg)
			);
		end
		else begin : gen_no_mem_ecc
			assign trvk_wdata_intg = 1'sb0;
		end
	endgenerate
	localparam [31:0] ibex_cheriot_pkg_CBOUND_W = 9;
	localparam [31:0] ibex_cheriot_pkg_CEXP_W = 4;
	localparam [31:0] ibex_cheriot_pkg_CPERMS_W = 6;
	localparam [31:0] ibex_cheriot_pkg_OTYPE_W = 3;
	function automatic [34:0] sv2v_cast_F2778;
		input reg [34:0] inp;
		sv2v_cast_F2778 = inp;
	endfunction
	function automatic [34:0] ibex_cheriot_pkg_cheriot_vec_to_regcap;
		input reg [34:0] vec_in;
		ibex_cheriot_pkg_cheriot_vec_to_regcap = sv2v_cast_F2778(vec_in);
	endfunction
	generate
		if (Lockstep) begin : gen_lockstep
			localparam [31:0] NumBufferBits = (((((((((((((((((((((99 + MemDataWidth) + 74) + MemDataWidth) + 2) + RegFileDataWidth) + RegFileDataWidth) + ibex_pkg_IC_NUM_WAYS) + 1) + ibex_pkg_IC_INDEX_W) + TagSizeECC) + ibex_pkg_IC_NUM_WAYS) + 1) + ibex_pkg_IC_INDEX_W) + LineSizeECC) + 184) + ibex_pkg_IbexMuBiWidth) + ibex_pkg_IbexMuBiWidth) + ibex_pkg_IbexMuBiWidth) + ibex_pkg_IbexMuBiWidth) + ibex_cheriot_pkg_REGCAP_W) + ibex_cheriot_pkg_REGCAP_W) + ibex_cheriot_pkg_REGCAP_W;
			wire [NumBufferBits - 1:0] buf_in;
			wire [NumBufferBits - 1:0] buf_out;
			wire [31:0] hart_id_local;
			wire [31:0] boot_addr_local;
			wire instr_req_local;
			wire instr_gnt_local;
			wire instr_rvalid_local;
			wire [31:0] instr_addr_local;
			wire [MemDataWidth - 1:0] instr_rdata_local;
			wire instr_err_local;
			wire data_req_local;
			wire data_gnt_local;
			wire data_rvalid_local;
			wire data_we_local;
			wire [3:0] data_be_local;
			wire [31:0] data_addr_local;
			wire [31:0] data_wdata_local;
			wire data_tag_local;
			wire [MemDataWidth - 1:0] data_rdata_local;
			wire data_rdata_tag_local;
			wire data_err_local;
			wire [31:0] rf_rdata_a_local;
			wire [31:0] rf_rdata_b_local;
			wire [3:0] cheriot_enable_local;
			wire [34:0] rf_wcap_vec_local;
			wire [34:0] rf_rcap_a_vec_local;
			wire [34:0] rf_rcap_b_vec_local;
			wire [34:0] rf_wcap_local;
			wire [34:0] rf_rcap_a_local;
			wire [34:0] rf_rcap_b_local;
			wire [1:0] ic_tag_req_local;
			wire ic_tag_write_local;
			wire [ibex_pkg_IC_INDEX_W - 1:0] ic_tag_addr_local;
			wire [TagSizeECC - 1:0] ic_tag_wdata_local;
			wire [1:0] ic_data_req_local;
			wire ic_data_write_local;
			wire [ibex_pkg_IC_INDEX_W - 1:0] ic_data_addr_local;
			wire [LineSizeECC - 1:0] ic_data_wdata_local;
			wire scramble_key_valid_local;
			wire ic_scr_key_req_local;
			wire irq_software_local;
			wire irq_timer_local;
			wire irq_external_local;
			wire [14:0] irq_fast_local;
			wire irq_nm_local;
			wire irq_pending_local;
			wire debug_req_local;
			wire [159:0] crash_dump_local;
			wire double_fault_seen_local;
			wire [3:0] fetch_enable_local;
			wire [3:0] mcounteren_writable_local;
			wire [3:0] core_busy_local;
			assign buf_in = {hart_id_i, boot_addr_i, instr_req_o, instr_gnt_i, instr_rvalid_i, instr_addr_o, instr_rdata_core, instr_err_i, trvk_req, trvk_gnt, trvk_rvalid, trvk_we, trvk_be, trvk_addr, trvk_wdata, trvk_wtag, data_rdata_core, trvk_rtag, trvk_err, rf_rdata_a, rf_rdata_b, ic_tag_req, ic_tag_write, ic_tag_addr, ic_tag_wdata, ic_data_req, ic_data_write, ic_data_addr, ic_data_wdata, scramble_key_valid_q, ic_scr_key_req, irq_software_i, irq_timer_i, irq_external_i, irq_fast_i, irq_nm_i, irq_pending, debug_req_i, crash_dump_o, double_fault_seen_o, fetch_enable_i, mcounteren_writable_i, core_busy_d, cheriot_enable_i, rf_wcap, rf_rcap_a, rf_rcap_b};
			assign {hart_id_local, boot_addr_local, instr_req_local, instr_gnt_local, instr_rvalid_local, instr_addr_local, instr_rdata_local, instr_err_local, data_req_local, data_gnt_local, data_rvalid_local, data_we_local, data_be_local, data_addr_local, data_wdata_local, data_tag_local, data_rdata_local, data_rdata_tag_local, data_err_local, rf_rdata_a_local, rf_rdata_b_local, ic_tag_req_local, ic_tag_write_local, ic_tag_addr_local, ic_tag_wdata_local, ic_data_req_local, ic_data_write_local, ic_data_addr_local, ic_data_wdata_local, scramble_key_valid_local, ic_scr_key_req_local, irq_software_local, irq_timer_local, irq_external_local, irq_fast_local, irq_nm_local, irq_pending_local, debug_req_local, crash_dump_local, double_fault_seen_local, fetch_enable_local, mcounteren_writable_local, core_busy_local, cheriot_enable_local, rf_wcap_vec_local, rf_rcap_a_vec_local, rf_rcap_b_vec_local} = buf_out;
			assign rf_wcap_local = ibex_cheriot_pkg_cheriot_vec_to_regcap(rf_wcap_vec_local);
			assign rf_rcap_a_local = ibex_cheriot_pkg_cheriot_vec_to_regcap(rf_rcap_a_vec_local);
			assign rf_rcap_b_local = ibex_cheriot_pkg_cheriot_vec_to_regcap(rf_rcap_b_vec_local);
			prim_generic_buf #(.Width(NumBufferBits)) u_signals_prim_generic_buf(
				.in_i(buf_in),
				.out_o(buf_out)
			);
			wire [(ibex_pkg_IC_NUM_WAYS * TagSizeECC) - 1:0] ic_tag_rdata_local;
			wire [(ibex_pkg_IC_NUM_WAYS * LineSizeECC) - 1:0] ic_data_rdata_local;
			genvar _gv_k_1;
			for (_gv_k_1 = 0; _gv_k_1 < ibex_pkg_IC_NUM_WAYS; _gv_k_1 = _gv_k_1 + 1) begin : gen_ways
				localparam k = _gv_k_1;
				prim_generic_buf #(.Width(TagSizeECC)) u_tag_prim_generic_buf(
					.in_i(ic_tag_rdata[(1 - k) * TagSizeECC+:TagSizeECC]),
					.out_o(ic_tag_rdata_local[(1 - k) * TagSizeECC+:TagSizeECC])
				);
				prim_generic_buf #(.Width(LineSizeECC)) u_data_prim_generic_buf(
					.in_i(ic_data_rdata[(1 - k) * LineSizeECC+:LineSizeECC]),
					.out_o(ic_data_rdata_local[(1 - k) * LineSizeECC+:LineSizeECC])
				);
			end
			wire lockstep_alert_minor_local;
			wire lockstep_alert_major_internal_local;
			wire lockstep_alert_major_bus_local;
			ibex_lockstep #(
				.PMPEnable(PMPEnable),
				.PMPGranularity(PMPGranularity),
				.PMPNumRegions(PMPNumRegions),
				.PMPRstCfg(PMPRstCfg),
				.PMPRstAddr(PMPRstAddr),
				.PMPRstMsecCfg(PMPRstMsecCfg),
				.MHPMCounterNum(MHPMCounterNum),
				.MHPMCounterWidth(MHPMCounterWidth),
				.RV32E(RV32E),
				.RV32M(RV32M),
				.RV32B(RV32B),
				.RV32ZC(RV32ZC),
				.BranchTargetALU(BranchTargetALU),
				.ICache(ICache),
				.ICacheECC(ICacheECC),
				.ICacheTweakInfection(ICacheTweakInfection),
				.BusSizeECC(BusSizeECC),
				.TagSizeECC(TagSizeECC),
				.LineSizeECC(LineSizeECC),
				.BranchPredictor(BranchPredictor),
				.DbgTriggerEn(DbgTriggerEn),
				.DbgHwBreakNum(DbgHwBreakNum),
				.WritebackStage(WritebackStage),
				.ResetAll(ResetAll),
				.RndCnstLfsrSeed(RndCnstLfsrSeed),
				.RndCnstLfsrPerm(RndCnstLfsrPerm),
				.SecureIbex(SecureIbex),
				.LockstepOffset(LockstepOffset),
				.DummyInstructions(DummyInstructions),
				.RegFileECC(RegFileLockstepECC),
				.RegFileDataWidth(RegFileDataWidth),
				.RegFileDataEccWidth(RegFileDataEccWidth),
				.RegFileCapEccWidth(RegFileCapEccWidth),
				.RegFile(RegFile),
				.MemECC(MemECC),
				.DmBaseAddr(DmBaseAddr),
				.DmAddrMask(DmAddrMask),
				.DmHaltAddr(DmHaltAddr),
				.DmExceptionAddr(DmExceptionAddr),
				.CsrMvendorId(CsrMvendorId),
				.CsrMimpId(CsrMimpId),
				.BaseIsa(BaseIsa)
			) u_ibex_lockstep(
				.clk_i(clk),
				.rst_ni(rst_ni),
				.hart_id_i(hart_id_local),
				.boot_addr_i(boot_addr_local),
				.cheriot_enable_i(cheriot_enable_local),
				.instr_req_i(instr_req_local),
				.instr_gnt_i(instr_gnt_local),
				.instr_rvalid_i(instr_rvalid_local),
				.instr_addr_i(instr_addr_local),
				.instr_rdata_i(instr_rdata_local),
				.instr_err_i(instr_err_local),
				.data_req_i(data_req_local),
				.data_gnt_i(data_gnt_local),
				.data_rvalid_i(data_rvalid_local),
				.data_we_i(data_we_local),
				.data_be_i(data_be_local),
				.data_addr_i(data_addr_local),
				.data_wdata_i(data_wdata_local),
				.data_tag_i(data_tag_local),
				.data_rdata_i(data_rdata_local),
				.data_rdata_tag_i(data_rdata_tag_local),
				.data_err_i(data_err_local),
				.rf_rdata_a_i(rf_rdata_a_local),
				.rf_rdata_b_i(rf_rdata_b_local),
				.rf_wcap_wb_i(rf_wcap_local),
				.rf_rcap_a_i(rf_rcap_a_local),
				.rf_rcap_b_i(rf_rcap_b_local),
				.ic_tag_req_i(ic_tag_req_local),
				.ic_tag_write_i(ic_tag_write_local),
				.ic_tag_addr_i(ic_tag_addr_local),
				.ic_tag_wdata_i(ic_tag_wdata_local),
				.ic_tag_rdata_i(ic_tag_rdata_local),
				.ic_data_req_i(ic_data_req_local),
				.ic_data_write_i(ic_data_write_local),
				.ic_data_addr_i(ic_data_addr_local),
				.ic_data_wdata_i(ic_data_wdata_local),
				.ic_data_rdata_i(ic_data_rdata_local),
				.ic_scr_key_valid_i(scramble_key_valid_local),
				.ic_scr_key_req_i(ic_scr_key_req_local),
				.irq_software_i(irq_software_local),
				.irq_timer_i(irq_timer_local),
				.irq_external_i(irq_external_local),
				.irq_fast_i(irq_fast_local),
				.irq_nm_i(irq_nm_local),
				.irq_pending_i(irq_pending_local),
				.debug_req_i(debug_req_local),
				.crash_dump_i(crash_dump_local),
				.double_fault_seen_i(double_fault_seen_local),
				.fetch_enable_i(fetch_enable_local),
				.mcounteren_writable_i(mcounteren_writable_local),
				.alert_minor_o(lockstep_alert_minor_local),
				.alert_major_internal_o(lockstep_alert_major_internal_local),
				.alert_major_bus_o(lockstep_alert_major_bus_local),
				.core_busy_i(core_busy_local),
				.test_en_i(test_en_i),
				.scan_rst_ni(scan_rst_ni),
				.lockstep_cmp_en_o(lockstep_cmp_en_o),
				.data_req_shadow_o(data_req_shadow_o),
				.data_we_shadow_o(data_we_shadow_o),
				.data_be_shadow_o(data_be_shadow_o),
				.data_addr_shadow_o(data_addr_shadow_o),
				.data_wdata_shadow_o(data_wdata_shadow_o),
				.data_wdata_intg_shadow_o(data_wdata_intg_shadow_o),
				.instr_req_shadow_o(instr_req_shadow_o),
				.instr_addr_shadow_o(instr_addr_shadow_o)
			);
			prim_generic_buf u_prim_generic_buf_alert_minor(
				.in_i(lockstep_alert_minor_local),
				.out_o(lockstep_alert_minor)
			);
			prim_generic_buf u_prim_generic_buf_alert_major_internal(
				.in_i(lockstep_alert_major_internal_local),
				.out_o(lockstep_alert_major_internal)
			);
			prim_generic_buf u_prim_generic_buf_alert_major_bus(
				.in_i(lockstep_alert_major_bus_local),
				.out_o(lockstep_alert_major_bus)
			);
		end
		else begin : gen_no_lockstep
			assign lockstep_alert_major_internal = 1'b0;
			assign lockstep_alert_major_bus = 1'b0;
			assign lockstep_alert_minor = 1'b0;
			assign lockstep_cmp_en_o = ibex_pkg_IbexMuBiOff;
			assign data_req_shadow_o = 1'b0;
			assign data_we_shadow_o = 1'b0;
			assign data_be_shadow_o = 1'sb0;
			assign data_addr_shadow_o = 1'sb0;
			assign data_wdata_shadow_o = 1'sb0;
			assign data_wdata_intg_shadow_o = 1'sb0;
			assign instr_req_shadow_o = 1'b0;
			assign instr_addr_shadow_o = 1'sb0;
			wire unused_scan;
			assign unused_scan = scan_rst_ni;
		end
		if (BaseIsa == 32'sd1) begin : gen_cheriot_trvk
			ibex_trvk #(
				.NumOutstanding(MaxOutstandingDSideAccesses),
				.MemECC(MemECC),
				.RevBitmapAddrWidth(CheriotRevBitmapAddrWidth),
				.RevBitmapBaseAddr(CheriotRevBitmapBaseAddr)
			) i_ibex_trvk(
				.clk_i(clk),
				.rst_ni(rst_ni),
				.heap_base_addr_i(trvk_heap_base_addr_i),
				.upstream_req_i(trvk_req),
				.upstream_gnt_o(trvk_gnt),
				.upstream_rvalid_o(trvk_rvalid),
				.upstream_we_i(trvk_we),
				.upstream_be_i(trvk_be),
				.upstream_addr_i(trvk_addr),
				.upstream_wdata_i(trvk_wdata),
				.upstream_wdata_intg_i(trvk_wdata_intg),
				.upstream_rdata_o(trvk_rdata),
				.upstream_rdata_intg_o(trvk_rdata_intg),
				.upstream_err_o(trvk_err),
				.upstream_tag_i(trvk_wtag),
				.upstream_tag_o(trvk_rtag),
				.downstream_req_o(data_req_o),
				.downstream_gnt_i(data_gnt_i),
				.downstream_rvalid_i(data_rvalid_i),
				.downstream_we_o(data_we_o),
				.downstream_be_o(data_be_o),
				.downstream_addr_o(data_addr_o),
				.downstream_wdata_o(data_wdata_o),
				.downstream_wdata_intg_o(data_wdata_intg_o),
				.downstream_rdata_i(data_rdata_i),
				.downstream_rdata_intg_i(data_rdata_intg_i),
				.downstream_err_i(data_err_i),
				.downstream_tag_o(data_tag_o),
				.downstream_tag_i(data_tag_i),
				.revbm_req_o(trvk_revbm_req_o),
				.revbm_gnt_i(trvk_revbm_gnt_i),
				.revbm_rvalid_i(trvk_revbm_rvalid_i),
				.revbm_addr_o(trvk_revbm_addr_o),
				.revbm_rdata_i(trvk_revbm_rdata_i),
				.revbm_rdata_intg_i(trvk_revbm_rdata_intg_i),
				.revbm_err_i(trvk_revbm_err_i),
				.revbm_data_intg_error_o(trvk_revbm_data_intg_error),
				.revbm_device_error_o(trvk_revbm_device_error)
			);
		end
		else begin : gen_no_cheriot_trvk
			wire unused_trvk;
			assign trvk_revbm_req_o = 1'sb0;
			assign trvk_revbm_addr_o = 1'sb0;
			assign trvk_rtag = 1'b0;
			assign data_tag_o = 1'b0;
			assign trvk_revbm_data_intg_error = 1'b0;
			assign trvk_revbm_device_error = 1'b0;
			assign unused_trvk = ^{trvk_heap_base_addr_i, trvk_revbm_gnt_i, trvk_revbm_rvalid_i, trvk_revbm_rdata_i, trvk_revbm_rdata_intg_i, trvk_revbm_err_i, trvk_wtag, data_tag_i};
			assign data_req_o = trvk_req;
			assign trvk_gnt = data_gnt_i;
			assign trvk_rvalid = data_rvalid_i;
			assign data_we_o = trvk_we;
			assign data_be_o = trvk_be;
			assign data_addr_o = trvk_addr;
			assign data_wdata_o = trvk_wdata;
			assign data_wdata_intg_o = trvk_wdata_intg;
			assign trvk_rdata = data_rdata_i;
			assign trvk_rdata_intg = data_rdata_intg_i;
			assign trvk_err = data_err_i;
		end
	endgenerate
	wire icache_alert_major_internal;
	assign icache_alert_major_internal = |icache_tag_alert | (|icache_data_alert);
	assign alert_major_internal_o = (core_alert_major_internal | lockstep_alert_major_internal) | icache_alert_major_internal;
	assign alert_major_bus_o = ((core_alert_major_bus | lockstep_alert_major_bus) | trvk_revbm_data_intg_error) | trvk_revbm_device_error;
	assign alert_minor_o = core_alert_minor | lockstep_alert_minor;
endmodule
