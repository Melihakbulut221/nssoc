module ibex_decoder (
	clk_i,
	rst_ni,
	cheriot_enable_i,
	illegal_insn_o,
	ebrk_insn_o,
	mret_insn_o,
	dret_insn_o,
	ecall_insn_o,
	wfi_insn_o,
	jump_set_o,
	branch_taken_i,
	icache_inval_o,
	instr_first_cycle_i,
	instr_rdata_i,
	instr_rdata_alu_i,
	illegal_c_insn_i,
	imm_a_mux_sel_o,
	imm_b_mux_sel_o,
	bt_a_mux_sel_o,
	bt_b_mux_sel_o,
	imm_i_type_o,
	imm_s_type_o,
	imm_b_type_o,
	imm_u_type_o,
	imm_j_type_o,
	zimm_rs1_type_o,
	rf_wdata_sel_o,
	rf_we_o,
	rf_we_or_load_o,
	rf_raddr_a_o,
	rf_raddr_b_o,
	rf_waddr_o,
	rf_ren_a_o,
	rf_ren_b_o,
	alu_operator_o,
	alu_op_a_mux_sel_o,
	alu_op_b_mux_sel_o,
	alu_multicycle_o,
	mult_en_o,
	div_en_o,
	mult_sel_o,
	div_sel_o,
	multdiv_operator_o,
	multdiv_signed_mode_o,
	csr_access_o,
	csr_op_o,
	csr_addr_o,
	csr_cheriot_always_ok_o,
	data_req_o,
	cheriot_data_req_o,
	data_we_o,
	data_type_o,
	data_sign_extension_o,
	jump_in_dec_o,
	branch_in_dec_o,
	instr_is_cheriot_o,
	instr_is_legal_cheriot_o,
	cheriot_imm12_o,
	cheriot_imm20_o,
	cheriot_imm21_o,
	cheriot_operator_o,
	cheriot_cs2_dec_o,
	cheriot_cap_field_sel_o,
	cheriot_adder_a_sel_o,
	cheriot_adder_b_sel_o,
	cheriot_setaddr_sel_o,
	cheriot_setbounds_sel_o
);
	reg _sv2v_0;
	parameter [0:0] RV32E = 0;
	parameter integer RV32M = 32'sd2;
	parameter integer RV32B = 32'sd0;
	parameter [0:0] BranchTargetALU = 0;
	parameter integer BaseIsa = 32'sd1;
	input wire clk_i;
	input wire rst_ni;
	localparam signed [31:0] ibex_pkg_IbexMuBiWidth = 4;
	input wire [3:0] cheriot_enable_i;
	output wire illegal_insn_o;
	output reg ebrk_insn_o;
	output reg mret_insn_o;
	output reg dret_insn_o;
	output reg ecall_insn_o;
	output reg wfi_insn_o;
	output reg jump_set_o;
	input wire branch_taken_i;
	output reg icache_inval_o;
	input wire instr_first_cycle_i;
	input wire [31:0] instr_rdata_i;
	input wire [31:0] instr_rdata_alu_i;
	input wire illegal_c_insn_i;
	output reg imm_a_mux_sel_o;
	output reg [2:0] imm_b_mux_sel_o;
	output reg [1:0] bt_a_mux_sel_o;
	output reg [2:0] bt_b_mux_sel_o;
	output wire [31:0] imm_i_type_o;
	output wire [31:0] imm_s_type_o;
	output wire [31:0] imm_b_type_o;
	output wire [31:0] imm_u_type_o;
	output wire [31:0] imm_j_type_o;
	output wire [31:0] zimm_rs1_type_o;
	output reg rf_wdata_sel_o;
	output wire rf_we_o;
	output wire rf_we_or_load_o;
	output wire [4:0] rf_raddr_a_o;
	output wire [4:0] rf_raddr_b_o;
	output wire [4:0] rf_waddr_o;
	output reg rf_ren_a_o;
	output reg rf_ren_b_o;
	output reg [6:0] alu_operator_o;
	output reg [1:0] alu_op_a_mux_sel_o;
	output reg alu_op_b_mux_sel_o;
	output reg alu_multicycle_o;
	output wire mult_en_o;
	output wire div_en_o;
	output reg mult_sel_o;
	output reg div_sel_o;
	output reg [1:0] multdiv_operator_o;
	output reg [1:0] multdiv_signed_mode_o;
	output reg csr_access_o;
	output reg [1:0] csr_op_o;
	output wire [11:0] csr_addr_o;
	output reg csr_cheriot_always_ok_o;
	output reg data_req_o;
	output reg cheriot_data_req_o;
	output reg data_we_o;
	output reg [1:0] data_type_o;
	output reg data_sign_extension_o;
	output reg jump_in_dec_o;
	output reg branch_in_dec_o;
	output reg instr_is_cheriot_o;
	output wire instr_is_legal_cheriot_o;
	output wire [11:0] cheriot_imm12_o;
	output wire [19:0] cheriot_imm20_o;
	output wire [20:0] cheriot_imm21_o;
	output reg [25:0] cheriot_operator_o;
	output wire [4:0] cheriot_cs2_dec_o;
	output reg [2:0] cheriot_cap_field_sel_o;
	output reg [2:0] cheriot_adder_a_sel_o;
	output reg [1:0] cheriot_adder_b_sel_o;
	output reg [2:0] cheriot_setaddr_sel_o;
	output reg [2:0] cheriot_setbounds_sel_o;
	localparam [0:0] CheriLimit16Regs = BaseIsa == 32'sd1;
	reg illegal_insn;
	wire illegal_reg_16;
	reg csr_illegal;
	reg rf_we;
	wire [31:0] instr;
	wire [31:0] instr_alu;
	wire [9:0] unused_instr_alu;
	wire [4:0] instr_rs1;
	wire [4:0] instr_rs2;
	wire [4:0] instr_rs3;
	wire [4:0] instr_rd;
	reg use_rs3_d;
	reg use_rs3_q;
	reg [1:0] csr_op;
	reg [6:0] opcode;
	reg [6:0] opcode_alu;
	wire instr_is_legal_cheriot;
	assign instr = instr_rdata_i;
	assign instr_alu = instr_rdata_alu_i;
	assign imm_i_type_o = {{20 {instr[31]}}, instr[31:20]};
	assign imm_s_type_o = {{20 {instr[31]}}, instr[31:25], instr[11:7]};
	assign imm_b_type_o = {{19 {instr[31]}}, instr[31], instr[7], instr[30:25], instr[11:8], 1'b0};
	assign imm_u_type_o = {instr[31:12], 12'b000000000000};
	assign imm_j_type_o = {{12 {instr[31]}}, instr[19:12], instr[20], instr[30:21], 1'b0};
	assign csr_addr_o = instr[31:20];
	assign zimm_rs1_type_o = {27'b000000000000000000000000000, instr_rs1};
	generate
		if (RV32B != 32'sd0) begin : gen_rs3_flop
			always @(posedge clk_i or negedge rst_ni)
				if (!rst_ni)
					use_rs3_q <= 1'b0;
				else
					use_rs3_q <= use_rs3_d;
		end
		else begin : gen_no_rs3_flop
			wire unused_clk;
			wire unused_rst_n;
			assign unused_clk = clk_i;
			assign unused_rst_n = rst_ni;
			wire [1:1] sv2v_tmp_12378;
			assign sv2v_tmp_12378 = use_rs3_d;
			always @(*) use_rs3_q = sv2v_tmp_12378;
		end
	endgenerate
	assign instr_rs1 = instr[19:15];
	assign instr_rs2 = instr[24:20];
	assign instr_rs3 = instr[31:27];
	wire [4:0] raddr_a;
	wire [4:0] raddr_b;
	assign raddr_a = (cheriot_operator_o[22] ? 5'h03 : (use_rs3_q & ~instr_first_cycle_i ? instr_rs3 : instr_rs1));
	assign raddr_b = instr_rs2;
	assign instr_rd = instr[11:7];
	localparam [3:0] ibex_pkg_IbexMuBiOn = 4'b0101;
	generate
		if (CheriLimit16Regs) begin : gen_16_regs
			assign rf_raddr_a_o = (cheriot_enable_i == ibex_pkg_IbexMuBiOn ? {1'b0, raddr_a[3:0]} : raddr_a);
			assign rf_raddr_b_o = (cheriot_enable_i == ibex_pkg_IbexMuBiOn ? {1'b0, raddr_b[3:0]} : raddr_b);
			assign rf_waddr_o = (cheriot_enable_i == ibex_pkg_IbexMuBiOn ? {1'b0, instr_rd[3:0]} : instr_rd);
		end
		else begin : gen_regs
			assign rf_raddr_a_o = raddr_a;
			assign rf_raddr_b_o = raddr_b;
			assign rf_waddr_o = instr_rd;
		end
	endgenerate
	wire rf_we_or_load;
	assign rf_we_or_load = rf_we | (opcode == 7'h03);
	assign rf_we_or_load_o = rf_we_or_load;
	generate
		if (RV32E || CheriLimit16Regs) begin : gen_16reg_check_active
			assign illegal_reg_16 = (RV32E || (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) && ((((raddr_a[4] && rf_ren_a_o) || (raddr_b[4] && rf_ren_b_o)) || ((instr_rs3[4] && use_rs3_d) && rf_ren_a_o)) || (instr_rd[4] && rf_we_or_load));
		end
		else begin : gen_16reg_check_inactive
			assign illegal_reg_16 = 1'b0;
		end
	endgenerate
	always @(*) begin : csr_operand_check
		if (_sv2v_0)
			;
		csr_op_o = csr_op;
		if (((csr_op == 2'd2) || (csr_op == 2'd3)) && (instr_rs1 == {5 {1'sb0}}))
			csr_op_o = 2'd0;
	end
	always @(*) begin
		if (_sv2v_0)
			;
		jump_in_dec_o = 1'b0;
		jump_set_o = 1'b0;
		branch_in_dec_o = 1'b0;
		icache_inval_o = 1'b0;
		multdiv_operator_o = 2'd0;
		multdiv_signed_mode_o = 2'b00;
		rf_wdata_sel_o = 1'd0;
		rf_we = 1'b0;
		rf_ren_a_o = 1'b0;
		rf_ren_b_o = 1'b0;
		csr_access_o = 1'b0;
		csr_illegal = 1'b0;
		csr_op = 2'd0;
		csr_cheriot_always_ok_o = 1'b0;
		data_we_o = 1'b0;
		data_type_o = 2'b00;
		data_sign_extension_o = 1'b0;
		data_req_o = 1'b0;
		cheriot_data_req_o = 1'b0;
		illegal_insn = 1'b0;
		ebrk_insn_o = 1'b0;
		mret_insn_o = 1'b0;
		dret_insn_o = 1'b0;
		ecall_insn_o = 1'b0;
		wfi_insn_o = 1'b0;
		cheriot_operator_o = 1'sb0;
		instr_is_cheriot_o = 1'b0;
		cheriot_cap_field_sel_o = 3'h0;
		cheriot_adder_a_sel_o = 3'h0;
		cheriot_adder_b_sel_o = 2'h0;
		cheriot_setaddr_sel_o = 3'h0;
		cheriot_setbounds_sel_o = 3'h0;
		opcode = instr[6:0];
		(* full_case, parallel_case *)
		case (opcode)
			7'h6f:
				if (((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) & ~illegal_c_insn_i) begin
					cheriot_operator_o[20] = 1'b1;
					instr_is_cheriot_o = 1'b1;
					illegal_insn = 1'b0;
					rf_we = 1'b1;
					cheriot_adder_a_sel_o = 3'h2;
					cheriot_adder_b_sel_o = 2'h2;
					cheriot_setaddr_sel_o = 3'h1;
				end
				else begin
					jump_in_dec_o = 1'b1;
					if (instr_first_cycle_i) begin
						rf_we = BranchTargetALU;
						jump_set_o = 1'b1;
					end
					else
						rf_we = 1'b1;
				end
			7'h67:
				if (((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) & ~illegal_c_insn_i) begin
					if (instr[14:12] == 3'b000)
						cheriot_operator_o[19] = 1'b1;
					instr_is_cheriot_o = 1'b1;
					rf_ren_a_o = 1'b1;
					rf_we = 1'b1;
					cheriot_adder_a_sel_o = 3'h1;
					cheriot_adder_b_sel_o = 2'h1;
					cheriot_setaddr_sel_o = 3'h1;
					if (instr[14:12] != 3'b000)
						illegal_insn = 1'b1;
				end
				else begin
					jump_in_dec_o = 1'b1;
					if (instr_first_cycle_i) begin
						rf_we = BranchTargetALU;
						jump_set_o = 1'b1;
					end
					else
						rf_we = 1'b1;
					if (instr[14:12] != 3'b000)
						illegal_insn = 1'b1;
					rf_ren_a_o = 1'b1;
				end
			7'h63: begin
				branch_in_dec_o = 1'b1;
				(* full_case, parallel_case *)
				case (instr[14:12])
					3'b000, 3'b001, 3'b100, 3'b101, 3'b110, 3'b111: illegal_insn = 1'b0;
					default: illegal_insn = 1'b1;
				endcase
				rf_ren_a_o = 1'b1;
				rf_ren_b_o = 1'b1;
			end
			7'h23: begin
				rf_ren_a_o = 1'b1;
				rf_ren_b_o = 1'b1;
				data_req_o = 1'b1;
				data_we_o = 1'b1;
				if (instr[14])
					illegal_insn = 1'b1;
				else if (instr[13:12] == 2'b11) begin
					if ((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) begin
						cheriot_operator_o[17] = ~illegal_c_insn_i;
						instr_is_cheriot_o = ~illegal_c_insn_i;
						cheriot_data_req_o = ~illegal_c_insn_i;
						data_req_o = 1'b0;
						illegal_insn = 1'b0;
					end
					else begin
						cheriot_data_req_o = 1'b0;
						illegal_insn = 1'b1;
					end
				end
				(* full_case, parallel_case *)
				case (instr[13:12])
					2'b00: data_type_o = 2'b10;
					2'b01: data_type_o = 2'b01;
					2'b10: data_type_o = 2'b00;
					default: data_type_o = 2'b00;
				endcase
			end
			7'h03: begin
				rf_ren_a_o = 1'b1;
				data_req_o = 1'b1;
				data_type_o = 2'b00;
				data_sign_extension_o = ~instr[14];
				(* full_case, parallel_case *)
				case (instr[13:12])
					2'b00: data_type_o = 2'b10;
					2'b01: data_type_o = 2'b01;
					2'b10: begin
						data_type_o = 2'b00;
						if (instr[14])
							illegal_insn = 1'b1;
					end
					2'b11:
						if ((((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) && ~instr[14]) && ~illegal_c_insn_i) begin
							cheriot_operator_o[15] = 1'b1;
							instr_is_cheriot_o = 1'b1;
							cheriot_data_req_o = 1'b1;
							data_req_o = 1'b0;
							illegal_insn = 1'b0;
						end
						else begin
							cheriot_data_req_o = 1'b0;
							illegal_insn = 1'b1;
						end
					default: illegal_insn = 1'b1;
				endcase
			end
			7'h37: rf_we = 1'b1;
			7'h17:
				if (((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) & ~illegal_c_insn_i) begin
					cheriot_operator_o[21] = 1'b1;
					instr_is_cheriot_o = 1'b1;
					illegal_insn = 1'b0;
					rf_we = 1'b1;
					cheriot_adder_a_sel_o = 3'h3;
					cheriot_adder_b_sel_o = 2'h2;
					cheriot_setaddr_sel_o = 3'h2;
				end
				else
					rf_we = 1'b1;
			7'h13: begin
				rf_ren_a_o = 1'b1;
				rf_we = 1'b1;
				(* full_case, parallel_case *)
				case (instr[14:12])
					3'b000, 3'b010, 3'b011, 3'b100, 3'b110, 3'b111: illegal_insn = 1'b0;
					3'b001:
						(* full_case, parallel_case *)
						case (instr[31:27])
							5'b00000: illegal_insn = (instr[26:25] == 2'b00 ? 1'b0 : 1'b1);
							5'b00100: illegal_insn = ((RV32B == 32'sd2) || (RV32B == 32'sd3) ? 1'b0 : 1'b1);
							5'b01001, 5'b00101, 5'b01101: illegal_insn = (RV32B != 32'sd0 ? instr[26:25] != 2'b00 : 1'b1);
							5'b00001:
								if (instr[26] == 1'b0)
									illegal_insn = ((RV32B == 32'sd2) || (RV32B == 32'sd3) ? 1'b0 : 1'b1);
								else
									illegal_insn = 1'b1;
							5'b01100:
								(* full_case, parallel_case *)
								case (instr[26:20])
									7'b0000000, 7'b0000001, 7'b0000010, 7'b0000100, 7'b0000101: illegal_insn = (RV32B != 32'sd0 ? 1'b0 : 1'b1);
									7'b0010000, 7'b0010001, 7'b0010010, 7'b0011000, 7'b0011001, 7'b0011010: illegal_insn = ((RV32B == 32'sd2) || (RV32B == 32'sd3) ? 1'b0 : 1'b1);
									default: illegal_insn = 1'b1;
								endcase
							default: illegal_insn = 1'b1;
						endcase
					3'b101:
						if (instr[26])
							illegal_insn = (RV32B != 32'sd0 ? 1'b0 : 1'b1);
						else
							(* full_case, parallel_case *)
							case (instr[31:27])
								5'b00000, 5'b01000: illegal_insn = (instr[26:25] == 2'b00 ? 1'b0 : 1'b1);
								5'b00100: illegal_insn = ((RV32B == 32'sd2) || (RV32B == 32'sd3) ? 1'b0 : 1'b1);
								5'b01100, 5'b01001: illegal_insn = (RV32B != 32'sd0 ? instr[26:25] != 2'b00 : 1'b1);
								5'b01101:
									if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
										illegal_insn = 1'b0;
									else if (RV32B == 32'sd1)
										illegal_insn = (instr[24:20] == 5'b11000 ? 1'b0 : 1'b1);
									else
										illegal_insn = 1'b1;
								5'b00101:
									if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
										illegal_insn = 1'b0;
									else if (instr[24:20] == 5'b00111)
										illegal_insn = (RV32B == 32'sd1 ? 1'b0 : 1'b1);
									else
										illegal_insn = 1'b1;
								5'b00001: illegal_insn = ((RV32B == 32'sd2) || (RV32B == 32'sd3) ? 1'b0 : 1'b1);
								default: illegal_insn = 1'b1;
							endcase
					default: illegal_insn = 1'b1;
				endcase
			end
			7'h33: begin
				rf_ren_a_o = 1'b1;
				rf_ren_b_o = 1'b1;
				rf_we = 1'b1;
				if ({instr[26], instr[13:12]} == 3'b101)
					illegal_insn = (RV32B != 32'sd0 ? 1'b0 : 1'b1);
				else
					(* full_case, parallel_case *)
					case ({instr[31:25], instr[14:12]})
						10'b0000000000, 10'b0100000000, 10'b0000000010, 10'b0000000011, 10'b0000000100, 10'b0000000110, 10'b0000000111, 10'b0000000001, 10'b0000000101, 10'b0100000101: illegal_insn = 1'b0;
						10'b0010000010, 10'b0010000100, 10'b0010000110, 10'b0100000111, 10'b0100000110, 10'b0100000100, 10'b0110000001, 10'b0110000101, 10'b0000101100, 10'b0000101110, 10'b0000101101, 10'b0000101111, 10'b0000100100, 10'b0100100100, 10'b0000100111, 10'b0100100001, 10'b0010100001, 10'b0110100001, 10'b0100100101, 10'b0100100111: illegal_insn = (RV32B != 32'sd0 ? 1'b0 : 1'b1);
						10'b0110100101, 10'b0010100101, 10'b0000100001, 10'b0000100101, 10'b0010100010, 10'b0010100100, 10'b0010100110, 10'b0010000001, 10'b0010000101, 10'b0000101001, 10'b0000101010, 10'b0000101011: illegal_insn = ((RV32B == 32'sd2) || (RV32B == 32'sd3) ? 1'b0 : 1'b1);
						10'b0100100110, 10'b0000100110: illegal_insn = (RV32B == 32'sd3 ? 1'b0 : 1'b1);
						10'b0000001000: begin
							multdiv_operator_o = 2'd0;
							multdiv_signed_mode_o = 2'b00;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						10'b0000001001: begin
							multdiv_operator_o = 2'd1;
							multdiv_signed_mode_o = 2'b11;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						10'b0000001010: begin
							multdiv_operator_o = 2'd1;
							multdiv_signed_mode_o = 2'b01;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						10'b0000001011: begin
							multdiv_operator_o = 2'd1;
							multdiv_signed_mode_o = 2'b00;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						10'b0000001100: begin
							multdiv_operator_o = 2'd2;
							multdiv_signed_mode_o = 2'b11;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						10'b0000001101: begin
							multdiv_operator_o = 2'd2;
							multdiv_signed_mode_o = 2'b00;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						10'b0000001110: begin
							multdiv_operator_o = 2'd3;
							multdiv_signed_mode_o = 2'b11;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						10'b0000001111: begin
							multdiv_operator_o = 2'd3;
							multdiv_signed_mode_o = 2'b00;
							illegal_insn = (RV32M == 32'sd0 ? 1'b1 : 1'b0);
						end
						default: illegal_insn = 1'b1;
					endcase
			end
			7'h0f:
				(* full_case, parallel_case *)
				case (instr[14:12])
					3'b000: rf_we = 1'b0;
					3'b001: begin
						jump_in_dec_o = 1'b1;
						rf_we = 1'b0;
						if (instr_first_cycle_i) begin
							jump_set_o = 1'b1;
							icache_inval_o = 1'b1;
						end
					end
					default: illegal_insn = 1'b1;
				endcase
			7'h73:
				if (instr[14:12] == 3'b000) begin
					(* full_case, parallel_case *)
					case (instr[31:20])
						12'h000: ecall_insn_o = 1'b1;
						12'h001: ebrk_insn_o = 1'b1;
						12'h302: mret_insn_o = 1'b1;
						12'h7b2: dret_insn_o = 1'b1;
						12'h105: wfi_insn_o = 1'b1;
						default: illegal_insn = 1'b1;
					endcase
					if ((instr_rs1 != 5'b00000) || (instr_rd != 5'b00000))
						illegal_insn = 1'b1;
				end
				else begin
					csr_access_o = 1'b1;
					rf_wdata_sel_o = 1'd1;
					rf_we = 1'b1;
					if (~instr[14])
						rf_ren_a_o = 1'b1;
					(* full_case, parallel_case *)
					case (instr[13:12])
						2'b01: csr_op = 2'd1;
						2'b10: csr_op = 2'd2;
						2'b11: csr_op = 2'd3;
						default: csr_illegal = 1'b1;
					endcase
					csr_cheriot_always_ok_o = ((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) & ((instr[31:28] == 4'hc) && ((instr[27] == 1'b0) || (instr[26:25] == 2'b00)));
					illegal_insn = csr_illegal;
				end
			7'h5b:
				if (((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) & ~illegal_c_insn_i) begin
					instr_is_cheriot_o = 1'b1;
					rf_ren_a_o = 1'b1;
					rf_we = 1'b1;
					if (instr[14:12] == 3'b000) begin
						if (instr[31:25] == 7'h7f)
							(* full_case, parallel_case *)
							case (instr[24:20])
								5'h00: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h0;
								end
								5'h01: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h1;
								end
								5'h02: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h2;
								end
								5'h03: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h3;
								end
								5'h04: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h4;
								end
								5'h08: begin
									cheriot_operator_o[23] = 1'b1;
									cheriot_setbounds_sel_o = 3'h5;
								end
								5'h09: begin
									cheriot_operator_o[24] = 1'b1;
									cheriot_setbounds_sel_o = 3'h6;
								end
								5'h0a: cheriot_operator_o[12] = 1'b1;
								5'h0b: cheriot_operator_o[14] = 1'b1;
								5'h0f: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h5;
								end
								5'h17: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h6;
								end
								5'h18: begin
									cheriot_operator_o[0] = 1'b1;
									cheriot_cap_field_sel_o = 3'h7;
								end
								default: illegal_insn = 1'b1;
							endcase
						else if (instr[31:25] == 7'h01) begin
							cheriot_operator_o[18] = 1'b1;
							cheriot_setaddr_sel_o = 3'h4;
						end
						else begin
							rf_ren_b_o = 1'b1;
							(* full_case, parallel_case *)
							case (instr[31:25])
								7'h08: begin
									cheriot_operator_o[7] = 1'b1;
									cheriot_setbounds_sel_o = 3'h1;
								end
								7'h09: begin
									cheriot_operator_o[8] = 1'b1;
									cheriot_setbounds_sel_o = 3'h3;
								end
								7'h0a: begin
									cheriot_operator_o[25] = 1'b1;
									cheriot_setbounds_sel_o = 3'h2;
								end
								7'h0b: cheriot_operator_o[1] = 1'b1;
								7'h0c: cheriot_operator_o[2] = 1'b1;
								7'h0d: cheriot_operator_o[3] = 1'b1;
								7'h10: begin
									cheriot_operator_o[4] = 1'b1;
									cheriot_adder_a_sel_o = 3'h4;
									cheriot_setaddr_sel_o = 3'h3;
								end
								7'h11: begin
									cheriot_operator_o[5] = 1'b1;
									cheriot_adder_a_sel_o = 3'h4;
									cheriot_adder_b_sel_o = 2'h1;
									cheriot_setaddr_sel_o = 3'h3;
								end
								7'h14: cheriot_operator_o[13] = 1'b1;
								7'h16: cheriot_operator_o[16] = 1'b1;
								7'h20: cheriot_operator_o[10] = 1'b1;
								7'h21: cheriot_operator_o[11] = 1'b1;
								default: illegal_insn = 1'b1;
							endcase
						end
					end
					else if (instr[14:12] == 3'b001) begin
						cheriot_operator_o[6] = 1'b1;
						cheriot_adder_a_sel_o = 3'h1;
						cheriot_adder_b_sel_o = 2'h1;
						cheriot_setaddr_sel_o = 3'h3;
					end
					else if (instr[14:12] == 3'b010) begin
						cheriot_operator_o[9] = 1'b1;
						cheriot_setbounds_sel_o = 3'h4;
					end
					else
						illegal_insn = 1'b1;
				end
				else
					illegal_insn = 1'b1;
			7'h7b:
				if (((BaseIsa == 32'sd1) & (cheriot_enable_i == ibex_pkg_IbexMuBiOn)) & ~illegal_c_insn_i) begin
					cheriot_operator_o[22] = 1'b1;
					instr_is_cheriot_o = 1'b1;
					rf_ren_a_o = 1'b1;
					rf_we = 1'b1;
					illegal_insn = 1'b0;
					cheriot_adder_a_sel_o = 3'h3;
					cheriot_adder_b_sel_o = 2'h1;
					cheriot_setaddr_sel_o = 3'h3;
				end
				else
					illegal_insn = 1'b1;
			default: illegal_insn = 1'b1;
		endcase
		if (illegal_c_insn_i)
			illegal_insn = 1'b1;
		if (illegal_insn) begin
			rf_we = 1'b0;
			data_req_o = 1'b0;
			data_we_o = 1'b0;
			jump_in_dec_o = 1'b0;
			jump_set_o = 1'b0;
			branch_in_dec_o = 1'b0;
			csr_access_o = 1'b0;
		end
	end
	always @(*) begin
		if (_sv2v_0)
			;
		alu_operator_o = 7'd44;
		alu_op_a_mux_sel_o = 2'd3;
		alu_op_b_mux_sel_o = 1'd1;
		imm_a_mux_sel_o = 1'd1;
		imm_b_mux_sel_o = 3'd0;
		bt_a_mux_sel_o = 2'd2;
		bt_b_mux_sel_o = 3'd0;
		opcode_alu = instr_alu[6:0];
		use_rs3_d = 1'b0;
		alu_multicycle_o = 1'b0;
		mult_sel_o = 1'b0;
		div_sel_o = 1'b0;
		(* full_case, parallel_case *)
		case (opcode_alu)
			7'h6f: begin
				if (BranchTargetALU) begin
					bt_a_mux_sel_o = 2'd2;
					bt_b_mux_sel_o = 3'd4;
				end
				if (instr_first_cycle_i && !BranchTargetALU) begin
					alu_op_a_mux_sel_o = 2'd2;
					alu_op_b_mux_sel_o = 1'd1;
					imm_b_mux_sel_o = 3'd4;
					alu_operator_o = 7'd0;
				end
				else begin
					alu_op_a_mux_sel_o = 2'd2;
					alu_op_b_mux_sel_o = 1'd1;
					imm_b_mux_sel_o = 3'd5;
					alu_operator_o = 7'd0;
				end
			end
			7'h67: begin
				if (BranchTargetALU) begin
					bt_a_mux_sel_o = 2'd0;
					bt_b_mux_sel_o = 3'd0;
				end
				if (instr_first_cycle_i && !BranchTargetALU) begin
					alu_op_a_mux_sel_o = 2'd0;
					alu_op_b_mux_sel_o = 1'd1;
					imm_b_mux_sel_o = 3'd0;
					alu_operator_o = 7'd0;
				end
				else begin
					alu_op_a_mux_sel_o = 2'd2;
					alu_op_b_mux_sel_o = 1'd1;
					imm_b_mux_sel_o = 3'd5;
					alu_operator_o = 7'd0;
				end
			end
			7'h63: begin
				(* full_case, parallel_case *)
				case (instr_alu[14:12])
					3'b000: alu_operator_o = 7'd29;
					3'b001: alu_operator_o = 7'd30;
					3'b100: alu_operator_o = 7'd25;
					3'b101: alu_operator_o = 7'd27;
					3'b110: alu_operator_o = 7'd26;
					3'b111: alu_operator_o = 7'd28;
					default:
						;
				endcase
				if (BranchTargetALU) begin
					bt_a_mux_sel_o = 2'd2;
					bt_b_mux_sel_o = (branch_taken_i ? 3'd2 : 3'd5);
				end
				if (instr_first_cycle_i) begin
					alu_op_a_mux_sel_o = 2'd0;
					alu_op_b_mux_sel_o = 1'd0;
				end
				else if (!BranchTargetALU) begin
					alu_op_a_mux_sel_o = 2'd2;
					alu_op_b_mux_sel_o = 1'd1;
					imm_b_mux_sel_o = (branch_taken_i ? 3'd2 : 3'd5);
					alu_operator_o = 7'd0;
				end
			end
			7'h23: begin
				alu_op_a_mux_sel_o = 2'd0;
				alu_op_b_mux_sel_o = 1'd0;
				alu_operator_o = 7'd0;
				if (!instr_alu[14]) begin
					imm_b_mux_sel_o = 3'd1;
					alu_op_b_mux_sel_o = 1'd1;
				end
			end
			7'h03: begin
				alu_op_a_mux_sel_o = 2'd0;
				alu_operator_o = 7'd0;
				alu_op_b_mux_sel_o = 1'd1;
				imm_b_mux_sel_o = 3'd0;
			end
			7'h37: begin
				alu_op_a_mux_sel_o = 2'd3;
				alu_op_b_mux_sel_o = 1'd1;
				imm_a_mux_sel_o = 1'd1;
				imm_b_mux_sel_o = 3'd3;
				alu_operator_o = 7'd0;
			end
			7'h17: begin
				alu_op_a_mux_sel_o = 2'd2;
				alu_op_b_mux_sel_o = 1'd1;
				imm_b_mux_sel_o = 3'd3;
				alu_operator_o = 7'd0;
			end
			7'h13: begin
				alu_op_a_mux_sel_o = 2'd0;
				alu_op_b_mux_sel_o = 1'd1;
				imm_b_mux_sel_o = 3'd0;
				(* full_case, parallel_case *)
				case (instr_alu[14:12])
					3'b000: alu_operator_o = 7'd0;
					3'b010: alu_operator_o = 7'd43;
					3'b011: alu_operator_o = 7'd44;
					3'b100: alu_operator_o = 7'd2;
					3'b110: alu_operator_o = 7'd3;
					3'b111: alu_operator_o = 7'd4;
					3'b001:
						if (RV32B != 32'sd0)
							(* full_case, parallel_case *)
							case (instr_alu[31:27])
								5'b00000: alu_operator_o = 7'd10;
								5'b00100:
									if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
										alu_operator_o = 7'd12;
								5'b01001: alu_operator_o = 7'd50;
								5'b00101: alu_operator_o = 7'd49;
								5'b01101: alu_operator_o = 7'd51;
								5'b00001:
									if (instr_alu[26] == 0)
										alu_operator_o = 7'd17;
								5'b01100:
									(* full_case, parallel_case *)
									case (instr_alu[26:20])
										7'b0000000: alu_operator_o = 7'd40;
										7'b0000001: alu_operator_o = 7'd41;
										7'b0000010: alu_operator_o = 7'd42;
										7'b0000100: alu_operator_o = 7'd38;
										7'b0000101: alu_operator_o = 7'd39;
										7'b0010000:
											if ((RV32B == 32'sd2) || (RV32B == 32'sd3)) begin
												alu_operator_o = 7'd59;
												alu_multicycle_o = 1'b1;
											end
										7'b0010001:
											if ((RV32B == 32'sd2) || (RV32B == 32'sd3)) begin
												alu_operator_o = 7'd61;
												alu_multicycle_o = 1'b1;
											end
										7'b0010010:
											if ((RV32B == 32'sd2) || (RV32B == 32'sd3)) begin
												alu_operator_o = 7'd63;
												alu_multicycle_o = 1'b1;
											end
										7'b0011000:
											if ((RV32B == 32'sd2) || (RV32B == 32'sd3)) begin
												alu_operator_o = 7'd60;
												alu_multicycle_o = 1'b1;
											end
										7'b0011001:
											if ((RV32B == 32'sd2) || (RV32B == 32'sd3)) begin
												alu_operator_o = 7'd62;
												alu_multicycle_o = 1'b1;
											end
										7'b0011010:
											if ((RV32B == 32'sd2) || (RV32B == 32'sd3)) begin
												alu_operator_o = 7'd64;
												alu_multicycle_o = 1'b1;
											end
										default:
											;
									endcase
								default:
									;
							endcase
						else
							alu_operator_o = 7'd10;
					3'b101:
						if (RV32B != 32'sd0) begin
							if (instr_alu[26] == 1'b1) begin
								alu_operator_o = 7'd48;
								alu_multicycle_o = 1'b1;
								if (instr_first_cycle_i)
									use_rs3_d = 1'b1;
								else
									use_rs3_d = 1'b0;
							end
							else
								(* full_case, parallel_case *)
								case (instr_alu[31:27])
									5'b00000: alu_operator_o = 7'd9;
									5'b01000: alu_operator_o = 7'd8;
									5'b00100:
										if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
											alu_operator_o = 7'd11;
									5'b01001: alu_operator_o = 7'd52;
									5'b01100: begin
										alu_operator_o = 7'd13;
										alu_multicycle_o = 1'b1;
									end
									5'b01101: alu_operator_o = 7'd15;
									5'b00101: alu_operator_o = 7'd16;
									5'b00001:
										if ((RV32B == 32'sd2) || (RV32B == 32'sd3)) begin
											if (instr_alu[26] == 1'b0)
												alu_operator_o = 7'd18;
										end
									default:
										;
								endcase
						end
						else if (instr_alu[31:27] == 5'b00000)
							alu_operator_o = 7'd9;
						else if (instr_alu[31:27] == 5'b01000)
							alu_operator_o = 7'd8;
					default:
						;
				endcase
			end
			7'h33: begin
				alu_op_a_mux_sel_o = 2'd0;
				alu_op_b_mux_sel_o = 1'd0;
				if (instr_alu[26]) begin
					if (RV32B != 32'sd0)
						(* full_case, parallel_case *)
						case ({instr_alu[26:25], instr_alu[14:12]})
							5'b11001: begin
								alu_operator_o = 7'd46;
								alu_multicycle_o = 1'b1;
								if (instr_first_cycle_i)
									use_rs3_d = 1'b1;
								else
									use_rs3_d = 1'b0;
							end
							5'b11101: begin
								alu_operator_o = 7'd45;
								alu_multicycle_o = 1'b1;
								if (instr_first_cycle_i)
									use_rs3_d = 1'b1;
								else
									use_rs3_d = 1'b0;
							end
							5'b10001: begin
								alu_operator_o = 7'd47;
								alu_multicycle_o = 1'b1;
								if (instr_first_cycle_i)
									use_rs3_d = 1'b1;
								else
									use_rs3_d = 1'b0;
							end
							5'b10101: begin
								alu_operator_o = 7'd48;
								alu_multicycle_o = 1'b1;
								if (instr_first_cycle_i)
									use_rs3_d = 1'b1;
								else
									use_rs3_d = 1'b0;
							end
							default:
								;
						endcase
				end
				else
					(* full_case, parallel_case *)
					case ({instr_alu[31:25], instr_alu[14:12]})
						10'b0000000000: alu_operator_o = 7'd0;
						10'b0100000000: alu_operator_o = 7'd1;
						10'b0000000010: alu_operator_o = 7'd43;
						10'b0000000011: alu_operator_o = 7'd44;
						10'b0000000100: alu_operator_o = 7'd2;
						10'b0000000110: alu_operator_o = 7'd3;
						10'b0000000111: alu_operator_o = 7'd4;
						10'b0000000001: alu_operator_o = 7'd10;
						10'b0000000101: alu_operator_o = 7'd9;
						10'b0100000101: alu_operator_o = 7'd8;
						10'b0110000001:
							if (RV32B != 32'sd0) begin
								alu_operator_o = 7'd14;
								alu_multicycle_o = 1'b1;
							end
						10'b0110000101:
							if (RV32B != 32'sd0) begin
								alu_operator_o = 7'd13;
								alu_multicycle_o = 1'b1;
							end
						10'b0000101100:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd31;
						10'b0000101110:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd33;
						10'b0000101101:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd32;
						10'b0000101111:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd34;
						10'b0000100100:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd35;
						10'b0100100100:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd36;
						10'b0000100111:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd37;
						10'b0100000100:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd5;
						10'b0100000110:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd6;
						10'b0100000111:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd7;
						10'b0010000010:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd22;
						10'b0010000100:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd23;
						10'b0010000110:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd24;
						10'b0100100001:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd50;
						10'b0010100001:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd49;
						10'b0110100001:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd51;
						10'b0100100101:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd52;
						10'b0100100111:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd55;
						10'b0110100101:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd15;
						10'b0010100101:
							if (RV32B != 32'sd0)
								alu_operator_o = 7'd16;
						10'b0000100001:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd17;
						10'b0000100101:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd18;
						10'b0010100010:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd19;
						10'b0010100100:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd20;
						10'b0010100110:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd21;
						10'b0010000001:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd12;
						10'b0010000101:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd11;
						10'b0000101001:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd56;
						10'b0000101010:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd57;
						10'b0000101011:
							if ((RV32B == 32'sd2) || (RV32B == 32'sd3))
								alu_operator_o = 7'd58;
						10'b0100100110:
							if (RV32B == 32'sd3) begin
								alu_operator_o = 7'd54;
								alu_multicycle_o = 1'b1;
							end
						10'b0000100110:
							if (RV32B == 32'sd3) begin
								alu_operator_o = 7'd53;
								alu_multicycle_o = 1'b1;
							end
						10'b0000001000: begin
							alu_operator_o = 7'd0;
							mult_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						10'b0000001001: begin
							alu_operator_o = 7'd0;
							mult_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						10'b0000001010: begin
							alu_operator_o = 7'd0;
							mult_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						10'b0000001011: begin
							alu_operator_o = 7'd0;
							mult_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						10'b0000001100: begin
							alu_operator_o = 7'd0;
							div_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						10'b0000001101: begin
							alu_operator_o = 7'd0;
							div_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						10'b0000001110: begin
							alu_operator_o = 7'd0;
							div_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						10'b0000001111: begin
							alu_operator_o = 7'd0;
							div_sel_o = (RV32M == 32'sd0 ? 1'b0 : 1'b1);
						end
						default:
							;
					endcase
			end
			7'h0f:
				(* full_case, parallel_case *)
				case (instr_alu[14:12])
					3'b000: begin
						alu_operator_o = 7'd0;
						alu_op_a_mux_sel_o = 2'd0;
						alu_op_b_mux_sel_o = 1'd1;
					end
					3'b001:
						if (BranchTargetALU) begin
							bt_a_mux_sel_o = 2'd2;
							bt_b_mux_sel_o = 3'd5;
						end
						else begin
							alu_op_a_mux_sel_o = 2'd2;
							alu_op_b_mux_sel_o = 1'd1;
							imm_b_mux_sel_o = 3'd5;
							alu_operator_o = 7'd0;
						end
					default:
						;
				endcase
			7'h73:
				if (instr_alu[14:12] == 3'b000) begin
					alu_op_a_mux_sel_o = 2'd0;
					alu_op_b_mux_sel_o = 1'd1;
				end
				else begin
					imm_a_mux_sel_o = 1'd0;
					if (instr_alu[14])
						alu_op_a_mux_sel_o = 2'd3;
					else
						alu_op_a_mux_sel_o = 2'd0;
				end
			default:
				;
		endcase
	end
	assign mult_en_o = (illegal_insn_o ? 1'b0 : mult_sel_o);
	assign div_en_o = (illegal_insn_o ? 1'b0 : div_sel_o);
	assign illegal_insn_o = illegal_insn | illegal_reg_16;
	assign rf_we_o = rf_we & ~illegal_reg_16;
	assign unused_instr_alu = {instr_alu[19:15], instr_alu[11:7]};
	assign instr_is_legal_cheriot = |cheriot_operator_o;
	assign instr_is_legal_cheriot_o = instr_is_legal_cheriot & ~illegal_reg_16;
	assign cheriot_cs2_dec_o = (cheriot_operator_o[18] ? instr[24:20] : 5'h00);
	assign cheriot_imm12_o = (((cheriot_operator_o[19] | cheriot_operator_o[9]) | cheriot_operator_o[6]) | cheriot_operator_o[15] ? {instr[31:25], instr[24:20]} : (cheriot_operator_o[17] ? {instr[31:25], instr[11:7]} : 12'h000));
	assign cheriot_imm20_o = (cheriot_operator_o[21] | cheriot_operator_o[22] ? instr[31:12] : 20'h00000);
	assign cheriot_imm21_o = (cheriot_operator_o[20] ? {instr[31], instr[19:12], instr[20], instr[30:21], 1'b0} : 21'h000000);
	generate
		if (BaseIsa != 32'sd1) begin : gen_no_cheriot_decoder
			wire unused_cheriot_enable;
			assign unused_cheriot_enable = ^cheriot_enable_i;
		end
	endgenerate
	initial _sv2v_0 = 0;
endmodule
