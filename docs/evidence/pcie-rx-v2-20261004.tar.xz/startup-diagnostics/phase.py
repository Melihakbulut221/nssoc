import os,sys,pty,subprocess,select,time,errno,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'));import characterize_pcie_rx as rx;import review_pcie_rx as rv
root=Path('/dev/shm/nssoc-rx-v2-probe-20261004');rows=[]
for version,tool in [(42,Path('hw/soc/tools/ngspice-42/usr/bin/ngspice').resolve()),(47,Path('/dev/shm/nssoc-ngspice47-20261004/root/usr/bin/ngspice'))]:
 dest=root/f'hot_native_phases_{version}';dest.mkdir()
 source=root/'hot100ohm';text=(source/'bench.cir').read_text().replace('tran 1e-12','echo NSSOC_OP_BEGIN\nop\nwrdata operating_point.dat '+ ' '.join(rx.VECTORS)+'\necho NSSOC_OP_END\necho NSSOC_TRAN_BEGIN\ntran 1e-12').replace('quit','echo NSSOC_TRAN_END\nquit')
 (dest/'bench.cir').write_text(text);(dest/rx.NETLIST.name).write_bytes((source/rx.NETLIST.name).read_bytes())
 master,slave=pty.openpty();env={k:v for k,v in os.environ.items()if k not in ['GH_TOKEN','GITHUB_TOKEN','LD_PRELOAD']};env.update(OMP_NUM_THREADS='1',RAYON_NUM_THREADS='1')
 start=time.monotonic();p=subprocess.Popen([str(tool),'-n','-b','bench.cir'],cwd=dest,stdout=slave,stderr=slave,env=env,preexec_fn=rx.resource_limit);os.close(slave);raw=bytearray()
 while True:
  if time.monotonic()-start>180:p.kill();raise RuntimeError('phase probe deadline')
  if not select.select([master],[],[],1)[0]:continue
  try:data=os.read(master,65536)
  except OSError as e:
   if e.errno==errno.EIO:break
   raise
  if not data:break
  raw.extend(data)
  if len(raw)>1024**2:p.kill();raise RuntimeError('phase output budget')
 os.close(master);code=p.wait();(dest/'run.pty.log').write_bytes(raw)
 phase='setup';events=[];markers=[]
 for line in raw.decode().splitlines():
  if line.startswith('NSSOC_'):
   markers.append(line)
   phase={'NSSOC_OP_BEGIN':'operating_point','NSSOC_OP_END':'after_operating_point','NSSOC_TRAN_BEGIN':'transient_initialization_and_simulation','NSSOC_TRAN_END':'after_transient'}[line]
  if any(k in line.lower()for k in ['nan','singular matrix','specified by jmax','specified by vmax','gmin stepping']):events.append(dict(phase=phase,line=line))
 assert code==0 and markers==['NSSOC_OP_BEGIN','NSSOC_OP_END','NSSOC_TRAN_BEGIN','NSSOC_TRAN_END']
 values=list(map(float,(dest/'operating_point.dat').read_text().splitlines()[1].split()))
 assert all(__import__('math').isfinite(x)for x in values)
 row=dict(version=version,tool_sha256=hashlib.sha256(tool.read_bytes()).hexdigest(),returncode=code,pty_combines_line_buffered_native_stdout_stderr=True,markers=markers,numerical_events=events,finite_native_op_values=values,outputs={f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in dest.iterdir()if f.is_file()})
 rows.append(row);print(version, len(events),sorted({e['phase']for e in events}),flush=True)
(root/'phase-result.json').write_text(json.dumps(rows,indent=2)+'\n')
