import sys,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import characterize_pcie_rx as rx
import review_pcie_rx as rv
root=Path('/dev/shm/nssoc-rx-v2-probe-20261004');case=dict(rx.cases(True)[0],hbt='hbt_wcs',resistor='res_wcs',temp=125,supply=1.71,reference_a=.00075,cap_f=150e-15)
models=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/ngspice/models');osdi=Path('/dev/shm/nssoc-rx-full-20261004/r3_cmc.osdi');ng=Path('hw/soc/tools/ngspice-42/usr/bin/ngspice').resolve()
rows=[]
for name,extra,ramp in [('hot_real_thermal_nodes','.nodeset v(xrx.xtail.t)=0 v(xrx.xref.t)=0 v(xrx.xp.t)=0 v(xrx.xn.t)=0\n',False),('hot_ramp','',True)]:
 d=root/name;d.mkdir();(d/rx.NETLIST.name).write_text(rx.NETLIST.read_text().replace('l=41.785u','l=27.5u'))
 text,bits=rx.deck(case,models,osdi)
 if ramp:
  text='\n'.join(line for line in text.splitlines()if not line.startswith('.nodeset'))+'\n'
  for line in ['VDD avdd 0 1.71','VCM cm 0 1.36','IREF avdd ref 0.00075']:
   text=text.replace(line,line.rsplit(' ',1)[0]+' PWL(0 0 1n '+line.rsplit(' ',1)[1]+')')
  text=text.replace('+ 0 1.44','+ 0 0\n+ 1e-9 1.44').replace('+ 0 1.28','+ 0 0\n+ 1e-9 1.28')
 text=text.replace('.control',extra+'.control');(d/'bench.cir').write_text(text)
 try:
  proc=rx.execute([str(ng),'-n','-b','bench.cir'],d,d/'run.log');m=rx.measure(d/'wave.dat',case,bits);diag=rv.diagnostics((d/'run.log').read_text())
  row=dict(name=name,case=case,execution=proc,measurement=m,diagnostics=diag)
  print(name,m['screen_pass'],m['min_signed_margin_v'],diag,flush=True)
 except Exception as e:row=dict(name=name,error=repr(e));print(row,flush=True)
 rows.append(row);(root/'startup-result.json').write_text(json.dumps(rows,indent=2)+'\n')
