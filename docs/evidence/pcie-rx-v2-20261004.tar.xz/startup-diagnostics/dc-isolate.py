import sys,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'));import characterize_pcie_rx as rx;import review_pcie_rx as rv
root=Path('/dev/shm/nssoc-rx-v2-probe-20261004');models=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/ngspice/models');ng=Path('hw/soc/tools/ngspice-42/usr/bin/ngspice').resolve()
rows=[]
for name,temp,guess,opt in [('diode27',27,'.85',''),('diode125',125,'.65',''),('diode125_nocm',125,'.65','.options noopiter\n'),('diode125_nothermalguess',125,'.65','.nodeset v(xq.t)=0\n')]:
 d=root/name;d.mkdir();text=f'''NSSOC isolated native diode-connected HBT model investigation
.lib "{models}/cornerHBT.lib" hbt_wcs
.temp {temp}
VDD vdd 0 1.71
IREF vdd ref .00075
XQ ref ref 0 0 npn13G2 Nx=1
.nodeset v(ref)={guess}
{opt}.control
op
print all
quit
.endc
.end
''';(d/'bench.cir').write_text(text)
 try:proc=rx.execute([str(ng),'-n','-b','bench.cir'],d,d/'run.log');row=dict(name=name,execution=proc,diagnostics=rv.diagnostics((d/'run.log').read_text()))
 except Exception as e:row=dict(name=name,error=repr(e))
 rows.append(row);print(name,row.get('diagnostics'),row.get('error'),flush=True)
(root/'diode-result.json').write_text(json.dumps(rows,indent=2)+'\n')
