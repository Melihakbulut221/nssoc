import sys,json,shutil
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import characterize_pcie_rx as rx
import review_pcie_rx as review
out=Path('/dev/shm/nssoc-rx-v2-probe-20261004')
models=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/ngspice/models')
osdi=Path('/dev/shm/nssoc-rx-full-20261004/r3_cmc.osdi')
ng=Path('hw/soc/tools/ngspice-42/usr/bin/ngspice').resolve()
rows=[]
base=rx.cases(True)[0]
for name,params,extra in [
 ('nominal100ohm',dict(),''),
 ('hot100ohm',dict(hbt='hbt_wcs',resistor='res_wcs',temp=125,supply=1.71),''),
 ('cold100ohm',dict(hbt='hbt_wcs',resistor='res_wcs',temp=-40,supply=1.71),''),
 ('hot_nodeset',dict(hbt='hbt_wcs',resistor='res_wcs',temp=125,supply=1.71),'.nodeset v(xrx.xrp.dt)=0 v(xrx.xrn.dt)=0 v(xrx.xrtp.dt)=0 v(xrx.xrtn.dt)=0\n'),
 ('hot_source',dict(hbt='hbt_wcs',resistor='res_wcs',temp=125,supply=1.71),'.options noopiter gminsteps=0 srcsteps=1\n'),
 ('hot_gmin',dict(hbt='hbt_wcs',resistor='res_wcs',temp=125,supply=1.71),'.options noopiter\n'),
 ('hot_gmin_hbt',dict(hbt='hbt_wcs',resistor='res_wcs',temp=125,supply=1.71),'.options noopiter\n.nodeset v(xrx.xtail.dt)=0 v(xrx.xref.dt)=0 v(xrx.xp.dt)=0 v(xrx.xn.dt)=0\n')]:
 case=dict(base,reference_a=.00075,cap_f=150e-15,**params);d=out/name;d.mkdir()
 (d/rx.NETLIST.name).write_text(rx.NETLIST.read_text().replace('l=41.785u','l=27.5u'))
 text,bits=rx.deck(case,models,osdi)
 text=text.replace('.control',extra+'.control')
 (d/'bench.cir').write_text(text)
 try:
  proc=rx.execute([str(ng),'-n','-b','bench.cir'],d,d/'run.log')
  m=rx.measure(d/'wave.dat',case,bits);diag=review.diagnostics((d/'run.log').read_text())
  row=dict(name=name,case=case,extra=extra,execution=proc,measurement=m,diagnostics=diag)
  print(name,m['screen_pass'],m['min_signed_margin_v'],m['min_vce_v'],diag['thermal_nan_reported'],diag['singular_matrix_reported'],diag['native_resistor_limit_warning'],flush=True)
 except Exception as e:row=dict(name=name,error=repr(e));print(row,flush=True)
 rows.append(row);(out/'result.json').write_text(json.dumps(rows,indent=2)+'\n')
