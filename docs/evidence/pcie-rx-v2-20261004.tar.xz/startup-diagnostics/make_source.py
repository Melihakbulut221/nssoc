from pathlib import Path
source=Path('scripts/characterize_pcie_rx.py').read_text()
start=source.index('def main():')
main=source[start:]
main=main.replace("inputs = [NETLIST, Path(__file__).resolve(), Path(tx.__file__), Path(resistor.__file__),", "inputs = [NETLIST, Path(__file__).resolve(), Path(rx.__file__), Path(diagnostic.__file__), Path(tx.__file__), Path(resistor.__file__),")
main=main.replace('ideal_reference_a=.0005','ideal_reference_a=.00075').replace('output_load_each_f=100e-15','output_load_each_f=150e-15')
main=main.replace("entry['measurement']=measure(dest/'wave.dat', case, bits)","entry['measurement']=measure(dest/'wave.dat', case, bits)\n            entry['numerical_diagnostics']=diagnostic.diagnostics((dest/'run.log').read_text())")
main=main.replace("record['status']='PASS_RX_PREAMP_SCREEN_ONLY' if passed else 'FAIL_RX_PREAMP_SCREEN'", "record['numerical_clean']=all(x['numerical_diagnostics']['numerical_clean'] for x in record['cases'] if x['case']['fault'] is None)\n        record['status']=disposition(passed, record['numerical_clean'])")
main=main.replace("return 0 if record['status']=='PASS_RX_PREAMP_SCREEN_ONLY' else 1", "return 0 if record['status']=='PASS_RX_V2_LIMITED_SCREEN' else 2 if record['status']=='RX_V2_MEASUREMENT_PASS_NUMERICAL_RESIDUAL' else 1")
header='''#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
"""RX v2 real 150 fF load screen; immutable v1 equations and limits remain in use."""
import argparse
import gzip
import itertools
import json
from pathlib import Path
import shutil

import characterize_pcie_rx as rx
import review_pcie_rx as diagnostic

ROOT, tx, resistor = rx.ROOT, rx.tx, rx.resistor
NETLIST = ROOT / 'hw/soc/analog/pcie/rx_hbt_rsil_v2.spice'
UI, BITS, LIMITS = rx.UI, rx.BITS, dict(rx.LIMITS)
execute, measure, measure_ac = rx.execute, rx.measure, rx.measure_ac


def cases(quick=False):
    """Keep every v1 corner/negative, make 150 fF the full-matrix required load."""
    result = []
    for original in rx.cases(quick):
        case = dict(original)
        if case['reference_a'] == .0005:
            case['reference_a'] = .00075
        if case['cap_f'] == 100e-15:
            case['cap_f'] = 150e-15
        if case['name'] == 'load_150fF':
            case.update(name='load_100fF', cap_f=100e-15)
        result.append(case)
    return result


def sequence(case):
    return rx.sequence(case)


def deck(case, models, osdi, ac=False):
    """Same native bench, 50-ohm sources, thresholds, options and self-heating."""
    text, bits = rx.deck(case, models, osdi, ac=ac)
    if text.count('rx_hbt_rsil.spice') != 1 or text.count('nssoc_rx_hbt_rsil') != 1:
        raise ValueError('Immutable v1 bench interface changed')
    text = text.replace('rx_hbt_rsil.spice', NETLIST.name)
    text = text.replace('nssoc_rx_hbt_rsil', 'nssoc_rx_hbt_rsil_v2')
    return text, bits


def disposition(measurements_passed, numerical_clean):
    if not measurements_passed:
        return 'FAIL_RX_V2_MEASUREMENT_SCREEN'
    if not numerical_clean:
        return 'RX_V2_MEASUREMENT_PASS_NUMERICAL_RESIDUAL'
    return 'PASS_RX_V2_LIMITED_SCREEN'


'''
Path('scripts/characterize_pcie_rx_v2.py').write_text(header+main)
