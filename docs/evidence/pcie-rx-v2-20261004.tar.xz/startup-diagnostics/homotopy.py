import sys,json
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'));import characterize_pcie_rx as rx;import review_pcie_rx as rv
root=Path('/dev/shm/nssoc-rx-v2-probe-20261004');case=dict(rx.cases(True)[0],hbt='hbt_wcs',resistor='res_wcs',temp=125,supply=1.71,reference_a=.00075,cap_f=150e-15)
models=Path('/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/ngspice/models');osdi=Path('/dev/shm/nssoc-rx-full-20261004/r3_cmc.osdi');ng=Path('hw/soc/tools/ngspice-42/usr/bin/ngspice').resolve();rows=[]
for name,opt,control in [
 ('hot_iterations','.options itl1=1000\n',''),
 ('hot_source_2','.options noopiter gminsteps=0 srcsteps=100\n',''),
 ('hot_bias_continuation','', '\n'.join('alter IREF '+str(x*1e-6)+'\nop'for x in [1,10,50,100,250,500,750])+'\n'),
 ('hot_initial_alltemps','.nodeset v(xrx.xtail.t)=0 v(xrx.xref.t)=0 v(xrx.xp.t)=0 v(xrx.xn.t)=0 v(xrx.xrp.dt)=0 v(xrx.xrn.dt)=0 v(xrx.xrtp.dt)=0 v(xrx.xrtn.dt)=0\n','')]:
 d=root/name;d.mkdir();(d/rx.NETLIST.name).write_text(rx.NETLIST.read_text().replace('l=41.785u','l=27.5u'));text,bits=rx.deck(case,models,osdi)
 text=text.replace('.control',opt+'.control').replace('tran 1e-12',control+'tran 1e-12');(d/'bench.cir').write_text(text)
 try:
  proc=rx.execute([str(ng),'-n','-b','bench.cir'],d,d/'run.log');m=rx.measure(d/'wave.dat',case,bits);diag=rv.diagnostics((d/'run.log').read_text());row=dict(name=name,execution=proc,measurement=m,diagnostics=diag);print(name,m['min_signed_margin_v'],diag['thermal_nan_reported'],diag['singular_matrix_reported'],diag['native_resistor_limit_warning'],flush=True)
 except Exception as e:row=dict(name=name,error=repr(e));print(row,flush=True)
 rows.append(row);(root/'homotopy-result.json').write_text(json.dumps(rows,indent=2)+'\n')
