from pathlib import Path
import collections,json,odb,re
p=Path('/workspace/nssoc-eco/first-detail-rc')
s=(p/'sta.log').read_text()
m=re.search(r'Found (\d+) unannotated drivers\.\n(.*?)Found (\d+) partially unannotated drivers',s,re.S)
names=m[2].strip().splitlines()
assert len(names)==int(m[1])
db=odb.dbDatabase.create()
odb.read_db(db,'/workspace/nssoc-eco/route/08-openroad-detailedrouting/drt-run-0/soc_top.odb')
b=db.getChip().getBlock(); counts=collections.Counter(); loaded=[]
for name in names:
 name=name.strip()
 if '/' in name:
  inst,pin=name.rsplit('/',1)
  i=b.findInst(inst); t=i.findITerm(pin) if i else None
 else: t=b.findBTerm(name)
 if t is None:
  counts['unresolved']+=1;loaded.append(name);continue
 net=t.getNet()
 if net is None:
  counts['no_net']+=1;continue
 others=[x for x in net.getITerms() if x!=t and str(x.getMTerm().getIoType()) in ('INPUT','INOUT')]
 others.extend(x for x in net.getBTerms() if x!=t and str(x.getIoType()) in ('OUTPUT','INOUT'))
 if others: counts['with_load']+=1;loaded.append(name)
 else: counts['no_load']+=1
(p/'annotation.json').write_text(json.dumps({'unannotated':len(names),'partially_unannotated':int(m[3]),'physical_connectivity':dict(counts),'requires_review':loaded},indent=2)+'\n')
