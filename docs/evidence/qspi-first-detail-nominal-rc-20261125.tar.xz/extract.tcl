read_db {/workspace/nssoc-eco/route/08-openroad-detailedrouting/drt-run-0/soc_top.odb}
set_thread_count 2
define_process_corner -ext_model_index 0 nominal
extract_parasitics -ext_model_file {/workspace/nssoc/hw/soc/tools/pdk-bootstrap-ca/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.tech/librelane/IHP_rcx_patterns.rules} -lef_res
write_spef {/workspace/nssoc-eco/first-detail-rc/nominal.spef}
