###############################################################################
# Created by write_sdc
###############################################################################
current_design tiny
###############################################################################
# Timing Constraints
###############################################################################
create_clock -name clk -period 20.0000 [get_ports {clk}]
set_input_delay 0.1000 -clock [get_clocks {clk}] -min -add_delay [get_ports {d0}]
set_input_delay 0.5000 -clock [get_clocks {clk}] -max -add_delay [get_ports {d0}]
set_input_delay 0.1000 -clock [get_clocks {clk}] -min -add_delay [get_ports {d1}]
set_input_delay 0.5000 -clock [get_clocks {clk}] -max -add_delay [get_ports {d1}]
set_input_delay 0.1000 -clock [get_clocks {clk}] -min -add_delay [get_ports {other}]
set_input_delay 0.5000 -clock [get_clocks {clk}] -max -add_delay [get_ports {other}]
set_output_delay 0.0000 -clock [get_clocks {clk}] -min -add_delay [get_ports {q0}]
set_output_delay 0.5000 -clock [get_clocks {clk}] -max -add_delay [get_ports {q0}]
set_output_delay 0.0000 -clock [get_clocks {clk}] -min -add_delay [get_ports {q1}]
set_output_delay 0.5000 -clock [get_clocks {clk}] -max -add_delay [get_ports {q1}]
set_output_delay 0.0000 -clock [get_clocks {clk}] -min -add_delay [get_ports {spare}]
set_output_delay 0.5000 -clock [get_clocks {clk}] -max -add_delay [get_ports {spare}]
###############################################################################
# Environment
###############################################################################
###############################################################################
# Design Rules
###############################################################################
