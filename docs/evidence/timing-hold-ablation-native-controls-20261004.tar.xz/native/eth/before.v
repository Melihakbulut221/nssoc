module tiny(input clk,input rst_n,input d0,input d1,input other,output q0,output q1,output spare);
 wire target0,target1;
 sg13g2_dfrbpq_1 driver0(.CLK(clk),.RESET_B(rst_n),.D(d0),.Q(target0));
 sg13g2_dfrbpq_1 sink0(.CLK(clk),.RESET_B(rst_n),.D(target0),.Q(q0));
 sg13g2_dfrbpq_1 driver1(.CLK(clk),.RESET_B(rst_n),.D(d1),.Q(target1));
 sg13g2_dfrbpq_1 sink1(.CLK(clk),.RESET_B(rst_n),.D(target1),.Q(q1));
 sg13g2_dlygate4sd3_1 nssoc_explicit_sd31(.A(other),.X(spare));
endmodule
