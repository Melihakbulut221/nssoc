module tiny (clk,
    d0,
    d1,
    other,
    q0,
    q1,
    rst_n,
    spare);
 input clk;
 input d0;
 input d1;
 input other;
 output q0;
 output q1;
 input rst_n;
 output spare;

 wire target0;
 wire target1;
 wire nssoc_ablation_eth_net1;

 sg13g2_dfrbpq_1 driver0 (.RESET_B(rst_n),
    .D(d0),
    .Q(nssoc_ablation_eth_net1),
    .CLK(clk));
 sg13g2_dfrbpq_1 driver1 (.RESET_B(rst_n),
    .D(d1),
    .Q(target1),
    .CLK(clk));
 sg13g2_dlygate4sd3_1 nssoc_ablation_eth_sd31 (.A(nssoc_ablation_eth_net1),
    .X(target0));
 sg13g2_dlygate4sd3_1 nssoc_explicit_sd31 (.A(other),
    .X(spare));
 sg13g2_dfrbpq_1 sink0 (.RESET_B(rst_n),
    .D(target0),
    .Q(q0),
    .CLK(clk));
 sg13g2_dfrbpq_1 sink1 (.RESET_B(rst_n),
    .D(target1),
    .Q(q1),
    .CLK(clk));
endmodule
