#!/usr/bin/env python3
"""Replay already-completed tiny native RX records; no native/layout execution."""
import datetime,hashlib,json,subprocess,tarfile
from pathlib import Path
ROOT=Path.cwd();B=ROOT/'hw/soc/out/pcie-rx-layout-20261004';L=Path('/dev/shm/nssoc-rx-layout-v2');V=Path('/dev/shm/nssoc-rx-checks-final')
def pin(path):
 with path.open('rb') as f: h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=path.stat().st_size,sha256=h)
def load(path):return json.loads(path.read_text())
gen=load(L/'result.json');verify=load(V/'result.json')
assert verify['status']=='PASS_RX_CELL_MAIN_DRC_LVS_AND_SEVEN_NEGATIVE_CONTROLS_WITH_NATIVE_LEF_ONLY'
for path,expected in verify['inputs'].items():assert pin(Path(path))['sha256']==expected,path
for name,expected in gen['output_sha256'].items():assert pin(L/name)['sha256']==expected,name
for name,expected in verify['output_sha256'].items():assert pin(V/name)['sha256']==expected,name
steps={r['name']:r for r in verify['steps']};assert set(steps)=={'drc','drc_offgrid','lvs','termination_width','tail_nx','missing_tap','wrong_input','bulk_short','lef','lef_missing_pin'}
assert steps['drc']['measurement']['markers']==0 and steps['drc']['measurement']['category_count']==560
assert steps['drc_offgrid']['measurement']['markers']==6 and steps['drc_offgrid']['measurement']['category_count']==560
assert steps['drc_offgrid']['measurement']['categories']=={"'M1.a'":2,'metal1_drw_Offgrid':4}
assert steps['lvs']['audit']['circuit_status_counts']=={'Match':1} and steps['lvs']['audit']['extraction_diagnostics']==[]
assert steps['lvs']['audit']['circuits']==[dict(layout='nssoc_rx_hbt_layout',schematic='NSSOC_RX_HBT_LAYOUT',status='Match',layout_devices_recursive=9,schematic_devices_recursive=9)]
for name in ('termination_width','tail_nx','missing_tap','wrong_input','bulk_short'):
 r=steps[name];assert r['execution']['returncode']==0 and r['audit_execution']['returncode']==1 and r['audit']['circuit_status_counts']=={'NoMatch':1} and not r['audit']['extraction_diagnostics']
assert steps['lef']['execution']['returncode']==0 and steps['lef_missing_pin']['execution']['returncode']!=0
assert 'RX terminal census changed' in (V/'lef_missing_pin/native.log').read_text()
assert 'PASS_RX_NATIVE_LEF_NINE_REAL_PORTS_SEVEN_OBSTRUCTED_LAYERS_NO_TIMING_ACCEPTANCE' in (V/'lef/native.log').read_text()
oldpath=ROOT/'hw/soc/out/pcie-tx-layout-20260926/layout-v5/result.json';old=load(oldpath);oldpub=load(ROOT/'docs/evidence/pcie-tx-cell-20260926.json')
assert pin(oldpath)['sha256']==oldpub['final']['input_sha256']['hw/soc/out/pcie-tx-layout-20260926/layout-v5/result.json']
pcells={k:v for k,v in gen['input_sha256'].items() if '.ciel/' in k}
assert len(pcells)==89 and all(old['input_sha256'].get(k)==v for k,v in pcells.items())
methods=['hw/soc/flow/make_pcie_rx_cell.py','hw/soc/flow/check_pcie_rx_cell.py','sw/tests/test_pcie_rx_cell.py','hw/soc/analog/pcie/rx_hbt_rsil.spice','hw/soc/flow/check_ihp_drc.py','hw/soc/flow/prepare_ihp_drc.py','hw/soc/flow/audit_klayout_lvs.py','hw/soc/pnr/ihp-drc.lock.json','hw/soc/pnr/ihp-lvs.lock.json']
source_pins={n:pin(ROOT/n) for n in methods}
# Retain actual completed pure-test/lint logs for the now-frozen source.
commands=[('pytest',[str(ROOT/'.venv/bin/python'),'-m','pytest','-q','-p','no:cacheprovider','sw/tests/test_pcie_rx_cell.py','sw/tests/test_pcie_tx_cell.py']),('ruff',[str(ROOT/'hw/soc/tools/dev-env/bin/ruff'),'check',*methods[:3]])]
executions={}
for name,command in commands:
 with (B/(name+'-final.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,check=False)
 assert r.returncode==0,name
 executions[name]=dict(command=command,returncode=0,log=pin(B/(name+'-final.log')))
assert '47 passed' in (B/'pytest-final.log').read_text()
assert source_pins=={n:pin(ROOT/n) for n in methods}
archive=B/'rx-native-physical-final.tar.xz';items={}
for prefix,path in [('layout',L),('native-checks',V)]:
 for p in sorted(path.rglob('*')):
  if p.is_file():items[prefix+'/'+str(p.relative_to(path))]=p
for name in methods:items['methods/'+name]=ROOT/name
for name in ['generate-v1.log','generate-v1.json','generate-v2.log','generate-v2.json','pytest-final.log','ruff-final.log','review_physical.py']:items['review/'+name]=B/name
# Preserve the parser naming error separately from the accepted final replay.
for rel in ['result.json','drc/result.json','drc/native.log']:items['earlier-log-name-failure/'+rel]=Path('/dev/shm/nssoc-rx-checks-v2')/rel
with tarfile.open(archive,'w:xz',preset=3) as t:
 for name,path in sorted(items.items()):
  info=t.gettarinfo(str(path),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with path.open('rb') as f:t.addfile(info,f)
member_pins={n:pin(p) for n,p in items.items()}
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(items)
 for info in t.getmembers():
  raw=t.extractfile(info).read();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==member_pins[info.name]
receipt=dict(schema=1,status='FROZEN_RX_PREAMPLIFIER_PHYSICAL_CELL_MAIN_DRC_LVS_AND_NATIVE_LEF_PASS_ONLY',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_files=source_pins,source_pdk_pcell_files_match_published_tx_source=89,historical_pcell_reference=dict(path=str(oldpath.relative_to(ROOT)),pin=pin(oldpath),publication='docs/evidence/pcie-tx-cell-20260926.json'),generator_result=pin(L/'result.json'),verifier_result=pin(V/'result.json'),verified_input_files=len(verify['inputs']),verified_output_files=len(verify['output_sha256']),gds=pin(L/'nssoc_rx_hbt_layout.gds'),lef=pin(L/'nssoc_rx_hbt_layout.lef'),cdl=pin(L/'schematic.cir'),outline_um=[167,158],ports=gen['ports'],summary={name:dict(status=r['status'],returncode=r['execution']['returncode'],seconds=r['execution']['seconds'],**({'measurement':r['measurement']} if 'measurement' in r else {})) for name,r in steps.items()},actual_lvs=steps['lvs']['audit'],pure_checks=executions,archive=pin(archive),archive_path=str(archive.relative_to(ROOT)),archive_members=member_pins,archive_roundtrip_verified=True,full_chip_native_executed=False,phy_complete=False,chip_integration=False,qualified_pex=False,manufacturing_approval=False,open_gates=['Density and antenna checks were not run; only all560 main DRC categories are claimed.','No extracted interconnect/coupled RC,EM/current crowding,noise,offset or timing/power Liberty qualification.','Prelayout analog SUB is ideal bulk; physical CDL has eight real square taps between SUB and BULK. Those added physical substrate resistances are not included in the analog screen.','ExternalVCM/currentreference and pad/ESD/package remain required; this is one continuous-time preamplifier, not CTLE,slicer,CDR,PLL,PCIePHY or link.','LEF has actual boundary ports and conservative7-metal obstructions but has not been placed or connected in the SoC.'],earlier_development_failures=['First generator used unavailable Polygon decomposition API; corrected to actual Region API before anyGDSwasexported.','First physical verifier requested run.log while using native.log; rawDRC0markers/560,LVSchecks completed but collector correctlystopped. Frozenfinalmethod freshlyrerunsallchecks withoutalteringgeometry.'])
(B/'source-validation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(dict(receipt=pin(B/'source-validation.json'),archive=pin(archive),sources=source_pins,output_count=len(verify['output_sha256']))))
