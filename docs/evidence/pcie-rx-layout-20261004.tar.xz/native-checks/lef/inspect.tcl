read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-rx-layout-v2/nssoc_rx_hbt_layout.lef}
set master [[ord::get_db] findMaster nssoc_rx_hbt_layout]
if {$master eq "NULL"} {error "RX master missing"}
if {[$master getWidth] != 167000 || [$master getHeight] != 158000} {error "RX outline changed"}
if {[llength [$master getMTerms]] != 9} {error "RX terminal census changed"}
set term [$master findMTerm INP]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 54000 2000 56000}}} {error "RX terminal geometry differs: INP"}
set term [$master findMTerm INN]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 54000 167000 56000}}} {error "RX terminal geometry differs: INN"}
set term [$master findMTerm OUTP]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 62000 167000 64000}}} {error "RX terminal geometry differs: OUTP"}
set term [$master findMTerm OUTN]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "OUTPUT" || [$term getSigType] ne "SIGNAL"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 62000 2000 64000}}} {error "RX terminal geometry differs: OUTN"}
set term [$master findMTerm AVDD]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "POWER"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 124000 167000 126000}}} {error "RX terminal geometry differs: AVDD"}
set term [$master findMTerm AVSS]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 70500 0 72500 2000}}} {error "RX terminal geometry differs: AVSS"}
set term [$master findMTerm SUB]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "INOUT" || [$term getSigType] ne "GROUND"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 156000 167000 158000}}} {error "RX terminal geometry differs: SUB"}
set term [$master findMTerm IREF]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 0 26000 2000 28000}}} {error "RX terminal geometry differs: IREF"}
set term [$master findMTerm VCM]
if {$term eq "NULL"} {error "RX terminal missing"}
if {[$term getIoType] ne "INPUT" || [$term getSigType] ne "SIGNAL"} {error "RX terminal type differs"}
set boxes {}; foreach pin [$term getMPins] {foreach box [$pin getGeometry] {lappend boxes [list [[$box getTechLayer] getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]}}
if {$boxes ne {{Metal5 165000 142000 167000 144000}}} {error "RX terminal geometry differs: VCM"}
set obs {}; foreach box [$master getObstructions] {lappend obs [[$box getTechLayer] getName]}
if {[lsort -unique $obs] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "RX obstruction layer census differs"}
if {[llength $obs] != 20} {error "RX obstruction box census differs"}
puts PASS_RX_NATIVE_LEF_NINE_REAL_PORTS_SEVEN_OBSTRUCTED_LAYERS_NO_TIMING_ACCEPTANCE
