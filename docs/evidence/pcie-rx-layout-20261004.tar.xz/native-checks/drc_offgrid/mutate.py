import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-rx-layout-v2/nssoc_rx_hbt_layout.gds')
c=l.cell('nssoc_rx_hbt_layout')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2.0,2.102,2.1))
l.write('/dev/shm/nssoc-rx-checks-final/drc_offgrid/wrong.gds')
