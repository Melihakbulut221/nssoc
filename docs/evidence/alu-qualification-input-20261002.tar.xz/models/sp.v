
module SP6TSRAM512x64(a, d, we, clk, q);
  input wire [8:0] a;
  input wire [63:0] d;
  input wire [7:0] we;
  input wire clk;
  output wire [63:0] q;

  reg [63:0] mem [0:511];
  reg [8:0] a_latch;

  always @(posedge clk) begin
    a_latch <= a;
    if (we[0]) begin
      mem[a][7:0] <= d[7:0];
    end
    if (we[1]) begin
      mem[a][15:8] <= d[15:8];
    end
    if (we[2]) begin
      mem[a][23:16] <= d[23:16];
    end
    if (we[3]) begin
      mem[a][31:24] <= d[31:24];
    end
    if (we[4]) begin
      mem[a][39:32] <= d[39:32];
    end
    if (we[5]) begin
      mem[a][47:40] <= d[47:40];
    end
    if (we[6]) begin
      mem[a][55:48] <= d[55:48];
    end
    if (we[7]) begin
      mem[a][63:56] <= d[63:56];
    end
  end

  assign q = mem[a_latch];
endmodule
