// Research model: current-address writes and clocked read outputs.
// Read-output hold is supported by the separately archived DP125 TT circuit run.
// Simultaneous same-address accesses and arbitrary dual-writer use are unqualified.
module DP8TSRAMDP256x16(input[7:0]a1,a2,input[15:0]d1,d2,input[1:0]we1,we2,input clk1,clk2,output reg[15:0]q1,q2);
reg[15:0]mem[0:255];
always @(posedge clk1)begin
 if(we1[0])mem[a1][7:0]<=d1[7:0];
 if(we1[1])mem[a1][15:8]<=d1[15:8];
 q1<={we1[1]?d1[15:8]:mem[a1][15:8],we1[0]?d1[7:0]:mem[a1][7:0]};
end
always @(posedge clk2)begin
 if(we2[0])mem[a2][7:0]<=d2[7:0];
 if(we2[1])mem[a2][15:8]<=d2[15:8];
 q2<={we2[1]?d2[15:8]:mem[a2][15:8],we2[0]?d2[7:0]:mem[a2][7:0]};
end
endmodule
