create_clock -name virtual_pmp -period 20
set_input_delay 0 -clock virtual_pmp [all_inputs]
set_output_delay 0 -clock virtual_pmp [all_outputs]
set_driving_cell -lib_cell sg13g2_buf_4 [all_inputs]
set_load 0.005 [all_outputs]
set_timing_derate -early 0.95
set_timing_derate -late 1.05
