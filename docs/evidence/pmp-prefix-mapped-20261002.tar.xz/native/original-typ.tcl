read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_stdcell.lef}
read_liberty {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib}
read_verilog {/home/hasanmelih/Documents/ChatGPT/nnsoc/hw/soc/out/resume-20261002-0800/pmp-mapped-native-final/original.sta.v}
link_design ibex_pmp
read_sdc {/home/hasanmelih/Documents/ChatGPT/nnsoc/hw/soc/out/resume-20261002-0800/pmp-mapped-native-final/pmp.sdc}
if {[llength [all_inputs]] != 278 || [llength [all_outputs]] != 3} { error "Unexpected PMP interface" }
puts "PMP_INTERFACE 278 3"
puts [format "PMP_WORST_SETUP_NS %s" [sta::format_time [sta::worst_slack_cmd max] 9]]
foreach port [lsort [all_outputs]] {
    puts "PMP_OUTPUT_BEGIN [get_property $port full_name]"
    report_checks -path_delay max -to $port -group_path_count 1 -fields {fanout cap slew} -digits 9
    puts "PMP_OUTPUT_END"
}
puts "PMP_STA_COMPLETE"
exit
