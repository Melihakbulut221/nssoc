`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_clk_i;
  soc_req_pipe_formal UUT (
    .clk_i(PI_clk_i)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$222  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$228  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$252  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$264  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$270  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$276  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$226  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$232  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$238  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$244  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$250  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$256  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$268  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$274  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$280  = 1'b1;
    // UUT.$past$soc_req_pipe_props.\v:45$10$0  = 1'b0;
    // UUT.$past$soc_req_pipe_props.\v:49$12$0  = 1'b0;
    // UUT.$past$soc_req_pipe_props.\v:50$13$0  = 1'b0;
    UUT._witness_.anyinit_procdff_208 = 69'b000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.accepted = 8'b00000000;
    UUT.delivered = 8'b10000000;
    UUT.dut._witness_.anyinit_procdff_216 = 1'b0;
    UUT.dut.payload_q = 69'b000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.past_valid = 1'b0;
    UUT.token = 69'b000000000000000000000000000000000000000000000000000000000000000000000;

    // state 0
    PI_clk_i = 1'b0;
    UUT.gnt_i = 1'b0;
    UUT.payload = 69'b000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.req_i = 1'b0;
    UUT.rst_ni = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_clk_i <= 1'b0;
      UUT.gnt_i <= 1'b0;
      UUT.payload <= 69'b000000000000000000000000000000000000000000000000000000000000000000000;
      UUT.req_i <= 1'b1;
      UUT.rst_ni <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_clk_i <= 1'b0;
      UUT.gnt_i <= 1'b0;
      UUT.payload <= 69'b000000000000000000000000000000000000000000000000000000000000000000000;
      UUT.req_i <= 1'b0;
      UUT.rst_ni <= 1'b0;
    end

    genclock <= cycle < 2;
    cycle <= cycle + 1;
  end
endmodule
