`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_clk_i;
  soc_req_pipe_formal UUT (
    .clk_i(PI_clk_i)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$221  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$227  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$251  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$263  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$269  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$275  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$225  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$231  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$237  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$243  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$249  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$255  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$267  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$273  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$279  = 1'b1;
    // UUT.$past$soc_req_pipe_props.\v:45$9$0  = 1'b0;
    // UUT.$past$soc_req_pipe_props.\v:49$11$0  = 1'b0;
    // UUT.$past$soc_req_pipe_props.\v:50$12$0  = 1'b0;
    UUT._witness_.anyinit_procdff_207 = 69'b000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.accepted = 8'b00000000;
    UUT.delivered = 8'b10000000;
    UUT.dut._witness_.anyinit_procdff_215 = 1'b0;
    UUT.dut.payload_q = 69'b100000000000000000001111111111111111111111111111110111111111111111111;
    UUT.past_valid = 1'b0;
    UUT.token = 69'b100000000000000000000000000000000000000000000000011000000000000000000;

    // state 0
    PI_clk_i = 1'b0;
    UUT.gnt_i = 1'b0;
    UUT.payload = 69'b000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.req_i = 1'b0;
    UUT.rst_ni = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_clk_i <= 1'b0;
      UUT.gnt_i <= 1'b0;
      UUT.payload <= 69'b100000000000000000000000000000000000000000000000010000000000000000000;
      UUT.req_i <= 1'b1;
      UUT.rst_ni <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_clk_i <= 1'b0;
      UUT.gnt_i <= 1'b0;
      UUT.payload <= 69'b100000000000000000000000000000000000000000000000010000000000000000000;
      UUT.req_i <= 1'b0;
      UUT.rst_ni <= 1'b1;
    end

    // state 3
    if (cycle == 2) begin
      PI_clk_i <= 1'b0;
      UUT.gnt_i <= 1'b0;
      UUT.payload <= 69'b000000000000000000000000000000000000000000000000000000000000000000000;
      UUT.req_i <= 1'b0;
      UUT.rst_ni <= 1'b1;
    end

    // state 4
    if (cycle == 3) begin
      PI_clk_i <= 1'b0;
      UUT.gnt_i <= 1'b0;
      UUT.payload <= 69'b000000000000000000000000000000000000000000000000000000000000000000000;
      UUT.req_i <= 1'b0;
      UUT.rst_ni <= 1'b0;
    end

    genclock <= cycle < 4;
    cycle <= cycle + 1;
  end
endmodule
