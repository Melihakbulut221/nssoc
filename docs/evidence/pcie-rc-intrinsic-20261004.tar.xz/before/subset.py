import pya,json
from pathlib import Path
l=pya.Layout();l.read('/dev/shm/nssoc-pad-boundary-03/nssoc_pcie_pad_boundary.gds');t=l.cell('nssoc_pcie_pad_boundary');region=pya.Region(t.begin_shapes_rec(l.layer(134,0))).merged()
if region.count()!=2:raise ValueError('Expected two actual physical TopMetal2 nets')
out=pya.Layout();out.dbu=l.dbu;c=out.create_cell('pad_tm2');c.shapes(out.layer(134,0)).insert(region)
ctrl=out.create_cell('sheet_tm2');ctrl.shapes(out.layer(134,0)).insert(pya.DBox(0,0,20,4))
out.write('/dev/shm/nssoc-pad-tm2-rc-01/subset.gds')
Path('/dev/shm/nssoc-pad-tm2-rc-01/geometry.json').write_text(json.dumps(dict(source_layer='134/0',actual_merged_polygons=region.count(),actual_area_um2=region.area()*l.dbu*l.dbu,source_layer_xor_zero=(region^pya.Region(c.begin_shapes_rec(out.layer(134,0)))).is_empty(),excluded='All other metal/doping/device/via layers and their shielding/coupling; no ESD-device model in this RC extraction'),indent=2))
