puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-coupled-rc-01/fixed}
drc off
load coupled
box values 0um 0um 20um 4um
paint metal7
box values 0um 6um 20um 10um
paint metal7
box values 1um 0um 1um 4um
label A center metal7
port make 1
port class inout
port use signal
box values 19um 0um 19um 4um
label B center metal7
port make 2
port class inout
port use signal
box values 1um 6um 1um 10um
label C center metal7
port make 3
port class inout
port use signal
box values 19um 6um 19um 10um
label D center metal7
port make 4
port class inout
port use signal
save coupled
extract unique all
extract style ngspice()
extract all
ext2sim labels on
ext2sim
extresist threshold 0
extresist tolerance 0.000001
extresist simplify off
extresist all
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o coupled.spice
quit -noprompt
