puts "NSSOC_LOADED_NATIVE_LIBRARIES [info loaded]"
cd {/dev/shm/nssoc-native-retirement-controls-final/renamed_killnode}
ext2spice lvs
ext2spice global off
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o tiny.spice tiny.ext
quit -noprompt
