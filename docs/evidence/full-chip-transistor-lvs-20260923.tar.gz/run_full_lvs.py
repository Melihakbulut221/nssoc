from pathlib import Path
import subprocess,json,hashlib,time
root=Path.cwd();b=Path(__file__).resolve().parent
out=b/'full-lvs-run2';out.mkdir(exist_ok=False)
gds=b/'selected/pnr/runs/route-resume/final/klayout_gds/soc_top.klayout.gds';schematic=b/'full-lvs/schematic.cir'
lock=root/'hw/soc/pnr/ihp-lvs.lock.json';r=json.loads(lock.read_text());cache=root/'hw/soc/tools/ihp-lvs-5e6d592'
files=[gds,schematic,lock]+[cache/x['path'] for x in r['files']]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for x in r['files']:
 assert sha(cache/x['path'])==x['sha256']
cmd=['klayout','-b','-zz','-r',str(cache/'ihp-sg13g2/libs.tech/klayout/tech/lvs/sg13g2.lvs')]
for k,v in {'input':gds,'schematic':schematic,'topcell':'soc_top','report':out/'soc_top.lvsdb','log':out/'deck.log','target_netlist':out/'extracted.cir','run_mode':'deep','thr':2}.items():cmd+=['-rd',str(k)+'='+str(v)]
expected={str(p):sha(p) for p in files}
(out/'inputs.json').write_text(json.dumps({'command':cmd,'inputs':expected},indent=2))
with (out/'process.log').open('w') as f:rc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
unchanged=all(sha(Path(p))==h for p,h in expected.items())
(out/'process-result.json').write_text(json.dumps({'returncode':rc,'inputs_unchanged':unchanged,'finished':time.time()},indent=2))
raise SystemExit(rc if unchanged else 2)
