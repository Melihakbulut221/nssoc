from pathlib import Path
import json,subprocess,time
c=Path(__file__).resolve().parent; d=c/'full-lvs-run2'
while not (d/'process-result.json').exists():time.sleep(15)
r=json.loads((d/'process-result.json').read_text());assert r['returncode']==0 and r['inputs_unchanged'],r
print('Writer finished and all pinned inputs unchanged:',r,flush=True)
p=subprocess.run(['python3','hw/soc/flow/audit_klayout_lvs.py',str(d/'soc_top.lvsdb'),'--top','soc_top','--deck-log',str(d/'deck.log'),'--output',str(d/'audit-final.json')])
raise SystemExit(p.returncode)
