import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-pad-boundary-03/nssoc_pcie_pad_boundary.gds')
c=l.cell('nssoc_pcie_pad_boundary')
c.shapes(l.layer(134,0)).insert(pya.DBox(48,208,152,212))
l.write('/dev/shm/nssoc-pad-check-final/pad_short/wrong.gds')
