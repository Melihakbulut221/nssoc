import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-pad-boundary-03/nssoc_pcie_pad_boundary.gds')
c=l.cell('nssoc_pcie_pad_boundary')
c.shapes(l.layer(8,0)).insert(pya.DBox(2.002,2.0,2.102,2.1))
l.write('/dev/shm/nssoc-pad-check-final/offgrid/wrong.gds')
