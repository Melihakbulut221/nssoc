import pya
l=pya.Layout()
l.read('/dev/shm/nssoc-pad-boundary-03/nssoc_pcie_pad_boundary.gds')
c=l.cell('nssoc_pcie_pad_boundary')
matches=[i for i in c.each_inst() if l.cell(i.cell_index).name.startswith('via_stack') and i.dbbox().center()==pya.DPoint(50.,140.) and not pya.Region(l.cell(i.cell_index).begin_shapes_rec(l.layer(133,0))).is_empty()]
if len(matches)!=1:raise ValueError('Specific PADP TopVia2 not unique')
for i in matches:i.delete()
l.write('/dev/shm/nssoc-pad-check-final/pad_open/wrong.gds')
