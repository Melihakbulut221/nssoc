read_lef {/home/hasanmelih/.ciel/ciel/ihp-sg13g2/versions/c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef}
read_lef {/dev/shm/nssoc-pad-boundary-03/nssoc_pcie_pad_boundary.lef}
set master [[ord::get_db] findMaster nssoc_pcie_pad_boundary]
if {$master eq "NULL"} {error "Pad master missing"}
if {[$master getWidth]!=220000 || [$master getHeight]!=220000} {error "Pad outline changed"}
if {[llength [$master getMTerms]]!=4} {error "Pad terminal census changed"}
set t [$master findMTerm PADP]
if {$t eq "NULL" || [$t getIoType] ne "INOUT" || [$t getSigType] ne "SIGNAL"} {error "Pad terminal type changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {[lsort $boxes] ne [lsort {{TopMetal2 35000 45000 65000 75000} {TopMetal2 48000 216000 52000 220000}}]} {error "Pad terminal geometry changed"}
set t [$master findMTerm PADN]
if {$t eq "NULL" || [$t getIoType] ne "INOUT" || [$t getSigType] ne "SIGNAL"} {error "Pad terminal type changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {[lsort $boxes] ne [lsort {{TopMetal2 135000 45000 165000 75000} {TopMetal2 148000 216000 152000 220000}}]} {error "Pad terminal geometry changed"}
set t [$master findMTerm AVDD]
if {$t eq "NULL" || [$t getIoType] ne "INOUT" || [$t getSigType] ne "POWER"} {error "Pad terminal type changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {[lsort $boxes] ne [lsort {{Metal5 0 178000 4000 182000}}]} {error "Pad terminal geometry changed"}
set t [$master findMTerm AVSS]
if {$t eq "NULL" || [$t getIoType] ne "INOUT" || [$t getSigType] ne "GROUND"} {error "Pad terminal type changed"}
set boxes {}; foreach p [$t getMPins] {foreach b [$p getGeometry] {lappend boxes [list [[$b getTechLayer] getName] [$b xMin] [$b yMin] [$b xMax] [$b yMax]]}}
if {[lsort $boxes] ne [lsort {{Metal5 0 198000 4000 202000}}]} {error "Pad terminal geometry changed"}
set layers {}; foreach b [$master getObstructions] {lappend layers [[$b getTechLayer] getName]}
if {[lsort -unique $layers] ne {Metal1 Metal2 Metal3 Metal4 Metal5 TopMetal1 TopMetal2}} {error "Pad obstruction layers changed"}
puts PASS_NATIVE_PAD_LEF_FOUR_NETS_SIX_ACCESSES_NO_RF_APPROVAL
