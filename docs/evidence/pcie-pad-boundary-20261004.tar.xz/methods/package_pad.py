# SPDX-FileCopyrightText: 2026 Hasan Melih Akbulut
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json,tarfile,io
r=Path.cwd();b=r/'hw/soc/out/pcie-pad-rc-20261004';layout=Path('/dev/shm/nssoc-pad-boundary-03');check=Path('/dev/shm/nssoc-pad-check-final');loading=Path('/dev/shm/nssoc-pad-loading-final')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
methods=[r/'hw/soc/flow'/n for n in ['make_pcie_pad_boundary.py','check_pcie_pad_boundary.py','check_pcie_esd_loading.py']]+[r/'sw/tests/test_pcie_pad_boundary.py']
records={};files={};verified={}
for tag,d in [('layout',layout),('physical',check),('loading',loading)]:
 rec=json.loads((d/'result.json').read_text());records[tag]=rec
 inputs=rec.get('input_sha256',rec.get('inputs'));outputs=rec['output_sha256']
 for p,h in inputs.items():
  if p not in verified:assert sha(p)==h,p;verified[p]=h
  else:assert verified[p]==h,p
 for n,h in outputs.items():assert sha(d/n)==h,n;files[tag+'/'+n]=d/n
 files[tag+'/result.json']=d/'result.json'
for p in methods:files['methods/'+str(p.relative_to(r))]=p
model=next(Path(p) for p in verified if p.endswith('/sg13g2_esd.lib'));files['native-model/sg13g2_esd.lib']=model
files['methods/package_pad.py']=Path(__file__).resolve()
notice='''Native differential pad boundary research evidence. No HBM/CDM, RF, PEX, bank/main-chip or production approval.\nGenerated layout and circuit: 2026 Hasan Melih Akbulut, CERN-OHL-W-2.0.\nProject Python sources: 2026 Hasan Melih Akbulut, Apache-2.0.\nFixed IHP diode geometry, bondpad/via PCell geometry and native diode models: IHP PDK Authors, Apache-2.0, exact c4b8b4e5e7a05f375cca3815d51b3a37721fbf5c inputs identified in receipts.\nNative tool output/reports: generated factual measurements; project explanatory material CC-BY-4.0.\nUnchanged IHP strict deck inputs pinned to5e6d592e4002946a4616f798c357f0f3c06cf3b6; no comparison waiver.\nKLayout/OpenROAD/ngspice binaries are not redistributed here; exact input identities and invocation records are preserved.\n'''
(b/'PAD-NOTICES.txt').write_text(notice);files['NOTICES.txt']=b/'PAD-NOTICES.txt'
archive=b/'pad-boundary-native.tar.xz'
with tarfile.open(archive,'w:xz',preset=9) as t:
 for n,p in sorted(files.items()):
  data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mtime=0;info.mode=0o644;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(files)
 for n,p in files.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==sha(p)
rec=dict(status='FROZEN_NATIVE_PAD_STRUCTURE_AND_MODEL_LOADING_ONLY',sources={str(p.relative_to(r)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in methods},native_status={tag:rec['status'] for tag,rec in records.items()},raw_roots={k:str(p) for k,p in [('layout',layout),('physical',check),('loading',loading)]},raw_result_pins={tag:sha(d/'result.json') for tag,d in [('layout',layout),('physical',check),('loading',loading)]},source_input_count=len(verified),output_counts={tag:len(rec['output_sha256']) for tag,rec in records.items()},native_checks=dict(main_drc_markers=0,main_drc_categories=560,strict_lvs_devices=4,strict_lvs_ports=4,negative_controls=7,physical_accesses=6,unchanged_fixed_primitives=4,exact_seven_layer_obstruction_union=True),loading=dict(cases=27,frequencies_per_case=3,native_controls=2,min_capacitance_f=records['loading']['min_capacitance_f'],max_capacitance_f=records['loading']['max_capacitance_f'],max_abs_leakage_a=records['loading']['max_abs_leakage_a']),tests=dict(command='PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q sw/tests/test_pcie_pad_boundary.py sw/tests/test_pcie_analog_bank.py sw/tests/test_pcie_rx_cell.py -p no:cacheprovider',passed=69,ruff='PASS'),capsule=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(files),roundtrip_all_members=True),limitations=['Separate two-pad physical boundary; no analog-bank/main-chip integration.','Native2kv cell name is not assembled-device HBM/CDM qualification; no rail clamp/package discharge path validation.','Model-only fixed diode voltage/bias/temperature sweep excludes bondpad/wire/package parasitics and has no native process-corner variants.','LVS writer raw C/B/E text is not passed to SPICE; literal source VDD/PAD/VSS model and actual named LVSDB terminals are checked.','No qualified PEX, RF/link eye/compliance or manufacturing approval.'])
(b/'pad-source-validation.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2))
