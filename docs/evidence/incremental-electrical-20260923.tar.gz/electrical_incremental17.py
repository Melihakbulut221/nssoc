from pathlib import Path
from librelane.flows import Flow,SequentialFlow
from librelane.steps import OpenROAD
class Incremental(OpenROAD.ResizerTimingPostGRT):
 def get_script_path(self):
  s='''source $::env(SCRIPTS_DIR)/openroad/common/io.tcl
source $::env(SCRIPTS_DIR)/openroad/common/resizer.tcl
read_current_odb
set_thread_count 4
set_propagated_clock [all_clocks]
remove_fillers
set block [ord::get_db_block]
foreach n [$block getNets] {set w [$n getWire];if {$w ne "NULL"} {odb::dbWire_destroy $w}}
source $::env(SCRIPTS_DIR)/openroad/common/set_rc.tcl
source $::env(SCRIPTS_DIR)/openroad/common/dpl.tcl
source $::env(SCRIPTS_DIR)/openroad/common/grt.tcl
estimate_parasitics -global_routing
report_check_types -max_slew -max_capacitance -violators -digits 6 > $::env(STEP_DIR)/electrical-before.rpt
for {set iteration 0} {$iteration<3} {incr iteration} {
 global_route -start_incremental
 repair_design -slew_margin 20 -cap_margin 20 -verbose
 source $::env(SCRIPTS_DIR)/openroad/common/dpl.tcl
 global_route -end_incremental
 estimate_parasitics -global_routing
 report_check_types -max_slew -max_capacitance -violators -digits 6 > $::env(STEP_DIR)/electrical-$iteration.rpt
 puts "ECO15_ITER $iteration SETUP [sta::worst_slack -max] HOLD [sta::worst_slack -min]"
}
report_checks -path_delay max -group_path_count 100 -fields {fanout cap slew} -digits 6 > $::env(STEP_DIR)/max.rpt
report_check_types -max_slew -max_capacitance -violators -digits 6 > $::env(STEP_DIR)/electrical.rpt
estimate_parasitics -global_routing -spef_file $::env(STEP_DIR)/soc_top.grt.spef
if {![file exists $::env(STEP_DIR)/soc_top.grt.spef] || [file size $::env(STEP_DIR)/soc_top.grt.spef] < 1000000} {error "Missing global-route SPEF"}
write_guides $::env(STEP_DIR)/soc_top.final.guide
write_views
'''
  p=Path(self.step_dir)/'incremental.tcl';p.write_text(s);return str(p)
@Flow.factory.register()
class ElectricalIncremental17(SequentialFlow):Steps=[Incremental]
if __name__=='__main__':
 from librelane.__main__ import cli
 cli()
