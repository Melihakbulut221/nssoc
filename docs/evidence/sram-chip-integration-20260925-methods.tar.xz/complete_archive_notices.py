"""Add complete source-component notices; preserve every design/check byte."""
from pathlib import Path
import hashlib, io, json, lzma, resource, tarfile

resource.setrlimit(resource.RLIMIT_AS, (3*1024**3, 3*1024**3))
r=Path.cwd().resolve(); p=Path(__file__).resolve().parent
out=p/'distribution-packages'; out.mkdir(exist_ok=False)
sources=p/'distribution-sources-v2'
source_record=json.loads((sources/'result.json').read_text())
assert source_record['status']=='PASS_EXACT_SYNTHESIS_SOURCES_AND_COMPONENT_NOTICES_SNAPSHOT'

def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()

assert sha(sources/'corresponding-sources.tar.xz')==source_record['archive_sha256']
notice=(sources/'NOTICES.txt').read_bytes()
extra={
 'COMPONENT-NOTICES.txt':notice,
 'LICENSES/MIT.txt':(r/'LICENSES/MIT.txt').read_bytes(),
 'LICENSES/LGPL-2.1-or-later.txt':(r/'LICENSES/LGPL-2.1-or-later.txt').read_bytes(),
 'LICENSES/Ibex-NOTICE':(r/'hw/soc/ext/ibex/NOTICE').read_bytes(),
 'LICENSES/Ibex-CREDITS.md':(r/'hw/soc/ext/ibex/CREDITS.md').read_bytes(),
 'corresponding-source-record.json':(sources/'result.json').read_bytes(),
 'complete_archive_notices.py':Path(__file__).read_bytes(),
}
result={'status':'PACKAGING','scope':__doc__,'archives':{},
        'corresponding_source_archive_sha256':source_record['archive_sha256'],
        'physical_acceptance':False}
def save(): (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
save()
for folder,name in [('method-bundle','methods.tar.xz'),('replay-bundle-v2','replay-inputs-v2.tar.xz')]:
    old=p/folder/name; old_hash=sha(old); archive=out/name
    original={}; members={}; replaced=[]
    with tarfile.open(old) as src, tarfile.open(archive,'w:xz',preset=9|lzma.PRESET_EXTREME) as dst:
        for member in src.getmembers():
            assert member.isfile(), member.name
            with src.extractfile(member) as stream: data=stream.read()
            original[member.name]=hashlib.sha256(data).hexdigest()
            if Path(member.name).name=='NOTICES.txt':
                data=notice; replaced.append(member.name)
            members[member.name]=hashlib.sha256(data).hexdigest()
            member.size=len(data); dst.addfile(member,io.BytesIO(data))
        assert replaced
        for n,data in extra.items():
            assert n not in members
            info=tarfile.TarInfo(n); info.size=len(data); info.mode=0o644
            dst.addfile(info,io.BytesIO(data)); members[n]=hashlib.sha256(data).hexdigest()
        payload=(json.dumps(members,indent=2)+'\n').encode()
        info=tarfile.TarInfo('MEMBERS.json'); info.size=len(payload); info.mode=0o644
        dst.addfile(info,io.BytesIO(payload))
    with tarfile.open(archive) as check:
        assert len(check.getmembers())==len(members)+1
        assert set(check.getnames())==set(members)|{'MEMBERS.json'}
        for n,h in members.items():
            with check.extractfile(n) as stream: assert hashlib.file_digest(stream,'sha256').hexdigest()==h,n
            if n in original and n not in replaced: assert h==original[n],n
        assert json.load(check.extractfile('MEMBERS.json'))==members
    assert sha(old)==old_hash
    result['archives'][name]={'sha256':sha(archive),'bytes':archive.stat().st_size,
        'source_archive_sha256':old_hash,'only_replaced_members':replaced,
        'added_members':list(extra),'members':members}
    save()
result['status']='PASS_NOTICES_COMPLETE_ALL_DESIGN_AND_CHECK_BYTES_UNCHANGED';save()
print(result['status'])
