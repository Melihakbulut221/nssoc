module wb_probe;
  integer faults=0;
  always @(posedge tb_soc.clk) begin
    if (tb_soc.rst_n && tb_soc.dut.u_ibex.u_ibex_core.csr_save_cause) begin
      $display("[WB-PROBE] cycle=%0d cause=%h pc_id=%h pc_wb=%h save_if/id/wb=%b%b%b", tb_soc.cycles, tb_soc.dut.u_ibex.u_ibex_core.exc_cause, tb_soc.dut.u_ibex.u_ibex_core.pc_id, tb_soc.dut.u_ibex.u_ibex_core.pc_wb, tb_soc.dut.u_ibex.u_ibex_core.csr_save_if, tb_soc.dut.u_ibex.u_ibex_core.csr_save_id, tb_soc.dut.u_ibex.u_ibex_core.csr_save_wb);
      faults=faults+1;
      if (faults==4) $fatal(1,"Diagnostic stop after four exceptions");
    end
  end
endmodule
